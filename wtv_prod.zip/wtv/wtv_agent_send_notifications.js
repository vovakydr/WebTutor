﻿if (tools.sys_db_capability & tools.UNI_CAP_WEB_ROLE)
{
	alert('Server Agents under Cluster Web Role not supported');
}
else if ( (tools.sys_db_capability & tools.UNI_CAP_WORKER_ROLE)==0 || tools.sys_db_capability_role_tags == 0 || (tools.sys_db_capability_role_tags & tools.UNI_CAP_NOTIFICATION_ROLE_TAG)>0 )
{
	iSentNum = 0;
	function process_notification_list()
	{
		for ( catActiveNotificationElem in ArraySelectAll( XQuery( "for $elem in active_notifications where $elem/status = 'send_error' and $elem/send_counter > " + global_settings.settings.own_org.send_attempt_num + " return $elem/Fields('id')" ) ) )
			try
			{
				DeleteDoc( UrlFromDocID( catActiveNotificationElem.id ) );
			}
			catch ( err )
			{
				LogEvent( 'email', 'Error. Delete sent notification ID ' + catActiveNotificationElem.id + ' falied. ' + err );
			}

		bTrashFlag = true;
		sQueryCond = '';
		switch ( global_settings.settings.own_org.after_send_action )
		{
			case 'save':
				sQueryCond = " and $elem/send_date < date('" + DateOffset( Date(), 0 - 3600 * global_settings.settings.own_org.sent_save_hours ) + "')";
				break;

			case 'trash':
				bTrashFlag = false;
				break;
		}

		iSentNum = 0;
		if ( global_settings.settings.own_org.smtp_server.HasValue )
		{
			for ( catActiveNotificationElem in ArraySelectAll( XQuery( "for $elem in active_notifications where $elem/send_date < date('" + Date() + "') and ( $elem/status = 'active' or $elem/status = 'send_error' ) return $elem/Fields('id')" ) ) )
				try
				{
					iSentNum++;
					tools.send_notification( catActiveNotificationElem.id );

				}
				catch ( err )
				{
					LogEvent( 'email', 'Error. Send notification ID ' + catActiveNotificationElem.id + ' falied. ' + err );
				}
		}

		for ( catActiveNotificationElem in ArraySelectAll( XQuery( "for $elem in active_notifications where $elem/status = 'sent'" + sQueryCond + " return $elem/Fields('id')" ) ) )
			try
			{
				DeleteDoc( UrlFromDocID( catActiveNotificationElem.id ), bTrashFlag );
			}
			catch ( err )
			{
				LogEvent( 'email', 'Error. Delete sent notification ID ' + catActiveNotificationElem.id + ' falied. ' + err );
			}
	}

	var iTicks = 0;
	while ( true )
	{
		iTicks = GetCurTicks();
		try
		{
			process_notification_list();
		}
		catch ( err )
		{
			alert( err );
		}

		iDeltaTicks = 60000 + iTicks - GetCurTicks();
		if ( iDeltaTicks > 0 )
			Sleep( iDeltaTicks )
		else
			LogEvent( 'email', 'Warning. Too long sending notifications. Number sent: ' + iSentNum + '.' );
	}
}
else
{
	alert('Server Agents under Cluster Worker Role and UNI_CAP_NOTIFICATION_ROLE_TAG not supported');
}