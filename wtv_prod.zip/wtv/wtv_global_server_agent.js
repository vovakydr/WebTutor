﻿var iSleepSec = 4;
var iSleepTicks = iSleepSec * 1000;
var iLastTicks = GetCurTicks();
var iCurTicks;
var iCurTicksDelta = 20000;
var iCurTicksCounter = 0;
var iCurTicksCounterMax = iCurTicksDelta / iSleepTicks + 2;
var iMaxAgentTime = 7200;

var oProvider;
//if ( (tools.sys_db_capability_ex & tools.UNI_CAP_BASIC) != 0 )
	oProvider = tools.spxml_unibridge.Object.provider;

if (tools.sys_db_capability & tools.UNI_CAP_WEB_ROLE)
{
	alert('Server Agents under Cluster Web Role not supported');
}
else
{
	alert('Global Server Agent Manager initialized');

	function process_agent_list( dDateParam )
	{
		try
		{
			for ( catServerAgentElem in server_agents )
			{
				try
				{
					if ( catServerAgentElem.check_time_step( dDateParam, iSleepSec ) )
					{
						if ( (tools.sys_db_capability & tools.UNI_CAP_WORKER_ROLE)>0 && (tools.sys_db_capability & tools.UNI_CAP_CLUSTER)>0 )
						{
							if ( tools.sys_db_capability_role_tags == 0 || (tools.sys_db_capability_role_tags & tools.UNI_CAP_AGENT_ROLE_TAG)>0 )
							{
								uid = String(UniqueID());
								real_uid = oProvider.GetSetUserData( 'ag_scheduled_spin_'+catServerAgentElem.id, uid,iMaxAgentTime );
								if (real_uid == uid)
								{
									ag_running_index = oProvider.QueueIndexOf('ag_running',String(catServerAgentElem.id));
									//alert('ag_running_index='+ag_running_index);
									if (ag_running_index<0)
									{
										//alert('Run Queued')
										sCommandXml = tools.get_agent_command_queue_xml( catServerAgentElem.id, '', '', dDateParam );
										oProvider.PutMessageInQueue( 'command-queue', sCommandXml );
									}
									else
									{
										//alert('Agent {'+catServerAgentElem.id+'} is already running');
										oProvider.RemoveUserData('ag_scheduled_spin_'+catServerAgentElem.id);
									}
								}
							}
						}
						else
						{
							//alert('Run Standard')
							tools.start_agent( catServerAgentElem.id, '', '', dDateParam );
						}
					}
				}
				catch ( forerr )
				{
					LogEvent( 'agent', 'Error. ' + forerr );
				}
			}
		}
		catch ( err )
		{
			alert( err );
			LogEvent( 'agent', 'Error. ' + err );
		}
	}


	while ( true )
	try
	{
		iCurTicks = GetCurTicks();
		if ( iCurTicks - iLastTicks < iCurTicksDelta )
		{
			iCurTicksCounter++;
			Sleep( iSleepTicks );

			if ( iCurTicksCounter > iCurTicksCounterMax )
			{
				iCurTicks = GetCurTicks();
				iLastTicks = ( iCurTicks - iCurTicksDelta ) - iSleepTicks;
				iCurTicksCounter = 0;
			}
		}
		else
		{
			dDate = RValue( Date() );
			iLastTicks = iCurTicks;
			iCurTicksCounter = 0;

			process_agent_list( dDate );
		}
	}
	catch ( e )
	{
		alert( e );
	}

}