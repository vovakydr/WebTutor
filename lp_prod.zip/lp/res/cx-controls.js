﻿//210522

var g_bWTCDebug = false;

{ // CXBtn
	window.CXBtn = function (oArgs)
	{
		this.oPlayer = oArgs.oPlayer;
		this.sId = ((oArgs.sId==null) ? TOOLS.GUID() : oArgs.sId);
		this.jContainer = oArgs.jContainer;
		this.jBtn = oArgs.jBtn;
		this.bToggle = (oArgs.bToggle==true);
		this.oContext = oArgs.oContext;
		this.fn = oArgs.fn;
		this.oArgs = oArgs.oArgs;
		this.oContextUnselect = oArgs.oContextUnselect;
		this.fnUnselect = oArgs.fnUnselect;
		this.oArgsUnselect = oArgs.oArgsUnselect;
		this.bSelected = false;
		this.bDisabled = false;
		this.oGroup = null;
		this.Constructor();
		return this;
	};
	CXBtn.prototype.Click = function ()
	{
		this.jBtn.click();
		return this;
	};
	CXBtn.prototype.Constructor = function ()
	{
		var oThis = this;
		this.jBtn.on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		return this;
	};
	CXBtn.prototype.Disable = function ()
	{
		this.jBtn.prop("disabled", true);
		this.bDisabled = true;
		return this;
	};
	CXBtn.prototype.Enable = function ()
	{
		this.jBtn.prop("disabled", false);
		this.bDisabled = false;
		return this;
	};
	CXBtn.prototype.Hide = function ()
	{
		this.jBtn.hide();
		return this;
	};
	CXBtn.prototype.Select = function ()
	{
		this.jBtn.attr({ "cx-state": "selected" });
		this.bSelected = true;
		if(this.oGroup!=null)
		{
			this.oGroup.Select({ oBtn: this });
		}
		return this;
	};
	CXBtn.prototype.Show = function ()
	{
		this.jBtn.show();
		return this;
	};
	CXBtn.prototype.UIEvent = function (oArgs)
	{
		switch(oArgs.oEvt.type)
		{
			case "click":
			{
				if(!this.bDisabled)
				{
					if(this.oGroup!=null)
					{
						if(!this.bSelected)
						{
							this.Select();
							if(this.fn!=null)
							{
								if(this.oArgs!=null && this.oArgs.oContext!=null)
								{
									this.fn.call(this.oArgs.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
								else if(this.oContext!=null)
								{
									this.fn.call(this.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
								else
								{
									this.fn({ oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
							}
						}
					}
					else
					{
						if(this.bToggle)
						{
							if(this.bSelected)
							{
								this.Unselect();
								if(this.fnUnselect!=null)
								{
									if(this.oArgsUnselect!=null && this.oArgsUnselect.oContext!=null)
									{
										this.fnUnselect.call(this.oArgsUnselect.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgsUnselect, oBtn: this });
									}
									else if(this.oContextUnselect!=null)
									{
										this.fnUnselect.call(this.oContextUnselect, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgsUnselect, oBtn: this });
									}
									else
									{
										this.fnUnselect({ oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgsUnselect, oBtn: this });
									}
								}
							}
							else
							{
								this.Select();
								if(this.fn!=null)
								{
									if(this.oArgs!=null && this.oArgs.oContext!=null)
									{
										this.fn.call(this.oArgs.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
									}
									else if(this.oContext!=null)
									{
										this.fn.call(this.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
									}
									else
									{
										this.fn({ oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
									}
								}
							}
						}
						else
						{
							if(this.fn!=null)
							{
								if(this.oArgs!=null && this.oArgs.oContext!=null)
								{
									this.fn.call(this.oArgs.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
								else if(this.oContext!=null)
								{
									this.fn.call(this.oContext, { oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
								else
								{
									this.fn({ oElem: this.jBtn[0], oEvt: oArgs.oEvt, oArgs: this.oArgs, oBtn: this });
								}
							}
						}
					}
				}
				break;
			}
		}
		return this;
	};
	CXBtn.prototype.Unselect = function ()
	{
		this.jBtn.removeAttr("cx-state");
		this.bSelected = false;
		return this;
	};
}

{ // CXControl
	window.CXControl = function (oArgs)
	{
		this.oPlayer = oArgs.oPlayer;
		this.jStorage = oArgs.jStorage;
		this.jTemplate = oArgs.jTemplate;
		this.oContainer = oArgs.oContainer;
		this.oLabel = oArgs.oLabel;
		this.oFld = oArgs.oFld;
		this.oSubscribers = {};
		this.bHasInitialValue = (oArgs.sValue!=null);
		this.bDisabled = (oArgs.bDisabled==true);
		this.bVisible = false;
		this.bField = (oArgs.bField==true);
		this.bSuppressEvent = false;
		this.sId = "CX_" + TOOLS.GUID();
		this.sValue = "";
		return this;
	};
	CXControl.prototype =
	{
		_GetValue: function ()
		{
			return this.sValue;
		},
		FireEvent: function (oArgs)
		{
			if(g_bWTCDebug && window.console)
			{
				console.log("fired " + oArgs.sEvent);
			}
			for(var sKey in this.oSubscribers)
			{
				if(this.oSubscribers[sKey]!=null)
				{
					for(var sKey2 in this.oSubscribers[sKey])
					{
						if(sKey2==oArgs.sEvent)
						{
							if(this.oSubscribers[sKey][sKey2]!=null)
							{
								for(var i=0; i<this.oSubscribers[sKey][sKey2].length; i++)
								{
									this.oSubscribers[sKey][sKey2][i].oArgs.oThis = this;
									if(this.oSubscribers[sKey][sKey2][i].oContext!=null)
									{
										this.oSubscribers[sKey][sKey2][i].fn.call(this.oSubscribers[sKey][sKey2][i].oContext, this.oSubscribers[sKey][sKey2][i].oArgs);
									}
									else
									{
										this.oSubscribers[sKey][sKey2][i].fn(this.oSubscribers[sKey][sKey2][i].oArgs);
									}
								}
							}
						}
					}
				}
			}
			return this;
		},
		Subscribe: function (oArgs)
		{
			if(this.oSubscribers[oArgs.sId]==null)
			{
				this.oSubscribers[oArgs.sId] = {};
			}
			if(this.oSubscribers[oArgs.sId][oArgs.sEvent]==null)
			{
				this.oSubscribers[oArgs.sId][oArgs.sEvent] = [];
			}
			for(var i=0; i<this.oSubscribers[oArgs.sId][oArgs.sEvent].length; i++)
			{
				if(this.oSubscribers[oArgs.sId][oArgs.sEvent].fn==oArgs.fn)
				{
					return this;
				}
			}
			this.oSubscribers[oArgs.sId][oArgs.sEvent].push({ fn: oArgs.fn, oArgs: oArgs.oArgs, oContext: oArgs.oContext });
			return this;
		},
		Unsubscribe: function (oArgs)
		{
			for(var i=0; i<this.oSubscribers[oArgs.sId][oArgs.sEvent].length; i++)
			{
				if(this.oSubscribers[oArgs.sId][oArgs.sEvent][i].fn==oArgs.fn)
				{
					this.oSubscribers[oArgs.sId][oArgs.sEvent].splice(i,1);
					return this;
				}
			}
			return this;
		}
	};
}

{ // CXInput
	window.CXInput = function (oArgs)
	{
		CXControl.call(this, oArgs);

		this.sName = oArgs.sName;
		this.sType = oArgs.sType;
		this.sId = oArgs.sId;
		this.nMin = oArgs.nMin;
		this.nMax = oArgs.nMax;
		this.iDec = (oArgs.iDec==null ? 0 : TOOLS.Refine({ sType: "int", sValue: oArgs.iDec }));
		this.sValue = null;
		this.Constructor();
		return this;
	};
	CXInput.prototype = Object.create(CXControl.prototype);
	CXInput.prototype.constructor = CXInput;
	CXInput.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		switch(this.sType)
		{
			case "string":
			{
				this.jFld = $(document.createElement("input")).addClass("wtp-text-fld").attr({ "type": "text", "name": "CTRL_" + this.sId }).val("").appendTo(this.oContainer);
				break;
			}
			case "text":
			{
				this.jFld = $(document.createElement("textarea")).addClass("wtp-textarea").attr({ "name": "CTRL_" + this.sId }).val("").appendTo(this.oContainer);
				break;
			}
			case "number":
			{
				this.jFld = $(document.createElement("input")).attr({ "type": "number", "name": "CTRL_" + this.sId }).val("").appendTo(this.oContainer);
				if(this.sDefault!=null)
				{
					this.jFld.val(this.sDefault);
				}
				if(this.nMin!=null)
				{
					this.jFld.attr({ "min": String(this.nMin) });
				}
				if(this.nMax!=null)
				{
					this.jFld.attr({ "max": String(this.nMax) });
				}
				break;
			}
		}
		if(this.bHasInitialValue)
		{
			this.bSuppressEvent = true;
			this.SetValue({ sValue: oArgs.sValue });
		}
		if(this.bDisabled)
		{
			this.Disable();
		}
		this.jFld.on("change keyup", function (e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
		return this;
	};
	CXInput.prototype.Disable = function ()
	{
		this.jFld.prop("disabled", true);
		this.bDisabled = true;
		this.FireEvent({ sEvent: "disable" });
		return this;
	};
	CXInput.prototype.Enable = function ()
	{
		this.jFld.prop("disabled", false);
		this.bDisabled = false;
		this.FireEvent({ sEvent: "enable" });
		return this;
	};
	CXInput.prototype.SetValue = function (oArgs)
	{
		if(oArgs==null)
		{
			return this;
		}
		if(oArgs.sValue==null || oArgs.sValue==this.sValue)
		{
			return this;
		}
		this.jFld.val(oArgs.sValue);
		this.sValue = oArgs.sValue;
		if(this.bSuppressEvent==true)
		{
			this.bSuppressEvent = false;
		}
		else
		{
			this.FireEvent({ sEvent: "change" });
		}
		return this;
	};
	CXInput.prototype.UIEvent = function (oArgs)
	{
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "change":
			{
				this.sValue = this.jFld.val();
				this.FireEvent({ sEvent: "change" });
				break;
			}
			case "keyup":
			{
				if(this.sType=="number")
				{
					this.Validate();
				}
				this.sValue = this.jFld.val();
				this.FireEvent({ sEvent: "keyup" });
				break;
			}
		}
		return this;
	};
	CXInput.prototype.Validate = function ()
	{
		if(this.bDisabled)
		{
			return this;
		}
		switch(this.sType)
		{
			case "number":
			{
				var sValue = this.jFld.val().toString();
				if(sValue.indexOf(",")!=-1)
				{
					sValue = sValue.split(",").join(".");
				}
				var nValue = (sValue.indexOf(".")!=-1) ? parseFloat(sValue) : parseInt(sValue,10);
				this.jFld.val(nValue);
				break;
			}
		}
		return this;
	};
}
{ // CXCheckBox
	window.CXCheckBox = function (oArgs)
	{
		CXControl.call(this, oArgs);
		this.sValueChecked = oArgs.sValueChecked;
		this.sClass = oArgs.sClass==null ? "" : oArgs.sClass;
		this.jBox = oArgs.jBox;
		this.bNoClick = oArgs.bNoClick==true;
		this.Constructor();
		if(this.bHasInitialValue)
		{
			this.bSuppressEvent = true;
			this.SetValue({ sValue: oArgs.sValue });
		}
		if(this.bDisabled)
		{
			this.Disable();
		}
		return this;
	};
	CXCheckBox.prototype = Object.create(CXControl.prototype);
	CXCheckBox.prototype.constructor = CXCheckBox;
	CXCheckBox.prototype.Check = function (oArgs)
	{
		if(this.bDisabled)
		{
			return this;
		}
		if(oArgs.bCheck==true)
		{
			this.jBox.attr({ "checked": "1" });
		}
		else
		{
			this.jBox.removeAttr("checked");
		}
		this.bChecked = (oArgs.bCheck==true);
		return this;
	};
	CXCheckBox.prototype.Constructor = function ()
	{
		var oThis = this;
		if(this.jBox==null)
		{
			this.jBox = this.jStorage.find("[cx-template='checkbox']").clone(true).removeAttr("cx-template").appendTo(this.oContainer);
		}
		if(this.sClass!="")
		{
			this.jBox.addClass(this.sClass);
		}
		if(this.bField)
		{
			this.jField = $(document.createElement("input")).attr({ "type": "hidden", "name": this.sName }).appendTo(this.jBox);
		}
		if(!this.bNoClick)
		{
			var sEvent = this.oPlayer.bMobile ? "touchstart" : "click";
			this.jBox.on(sEvent, function (e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
		}
		return this;
	};
	CXCheckBox.prototype.Disable = function ()
	{
		this.jBox.prop("disabled", true);
		this.bDisabled = true;
		return this;
	};
	CXCheckBox.prototype.Enable = function ()
	{
		this.jBox.prop("disabled", false);
		this.bDisabled = false;
		return this;
	};
	CXCheckBox.prototype.SetValue = function (oArgs)
	{
		if(oArgs==null)
		{
			return this;
		}
		if(oArgs.bCheck==true)
		{
			this.sValue = this.sValueChecked;
		}
		else
		{
			this.sValue = "";
		}
		this.Check(oArgs);
		if(this.bField)
		{
			this.jField.val(this.sValue);
		}
		if(this.bSuppressEvent || oArgs.bSuppressEvent==true)
		{
			this.bSuppressEvent = false;
		}
		else
		{
			this.FireEvent({ sEvent: "change" });
		}
		return this;
	};
	CXCheckBox.prototype.UIEvent = function (oArgs)
	{
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "click":
			case "touchstart":
			{
				this.SetValue({ bCheck: !this.bChecked });
				break;
			}
		}
		return this;
	};
}
{ // CXSlider
	window.CXSlider = function (oArgs)
	{
		CXControl.call(this, oArgs);

		this.sName = oArgs.sName;
		this.sType = oArgs.sType;
		this.jBlock = oArgs.jBlock;
		this.sId = oArgs.sId;
		this.nMin = oArgs.nMin;
		this.nMax = oArgs.nMax;
		this.nLimitMin = oArgs.nLimitMin==null ? this.nMin : oArgs.nLimitMin;
		this.nLimitMax = oArgs.nLimitMax==null ? this.nMax : oArgs.nLimitMax;
		this.nDefault = oArgs.nDefault==null ? 50 : oArgs.nDefault;
		this.iDec = (oArgs.iDec==null ? 0 : TOOLS.Refine({ sType: "int", sValue: oArgs.iDec }));
		this.sClass = oArgs.sClass==null ? "" : oArgs.sClass;
		this.sValue = null;
		this.Constructor();
		return this;
	};
	CXSlider.prototype = Object.create(CXControl.prototype);
	CXSlider.prototype.constructor = CXSlider;
	CXSlider.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		if(this.jBlock==null)
		{
			this.jBlock = this.jStorage.find("[cx-template='slider-block']").clone(true).removeAttr("cx-template").appendTo(this.oContainer);
		}
		this.jIcon = this.jBlock.find("[cx-role='slider-icon']");
		this.sIconBasicClass = this.jIcon.attr("class");
		this.jFld = this.jBlock.find("[cx-role='slider-value']");
		this.jLabels = this.jBlock.find("[cx-role='slider-label']");
		this.jLimitMin = this.jBlock.find("[cx-role='slider-limit-min']");
		this.jLimitMax = this.jBlock.find("[cx-role='slider-limit-max']");
		this.bHasLimits = (this.nLimitMin!=this.nMin || this.nLimitMax!=this.nMax);
		if(this.nLimitMin==this.nMin)
		{
			this.jLimitMin.hide();
		}
		else
		{
			this.jLimitMin.css({ "left": this.nLimitMin + "%" });
		}
		if(this.nLimitMax==this.nMax)
		{
			this.jLimitMax.hide();
		}
		else
		{
			this.jLimitMax.css({ "left": this.nLimitMax + "%" });
		}
		var oSliderParams =
		{
			animate: "fast",
			min: this.nMin,
			max: this.nMax,
			step: 1,
			value: this.nMin,
			range: "min",
			slide: function (evt, ui)
			{
				if(oThis.bHasLimits)
				{
					if(ui.value<oThis.nLimitMin || ui.value>oThis.nLimitMax)
					{
						return false;
					}
				}
				oThis.UIEvent({ oEvt: evt, oSlider: ui });
			},
			change: function (evt, ui)
			{
				oThis.UIEvent({ oEvt: evt, oSlider: ui });
			}
		};
		this.jSlider = this.jBlock.find("[cx-role='slider']").slider(oSliderParams);
		if(this.bHasInitialValue)
		{
			this.bSuppressEvent = true;
			this.SetValue({ sValue: oArgs.sValue });
		}
		if(this.bDisabled)
		{
			this.Disable();
		}
		this.jFld.on("change keyup", function (e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
		return this;
	};
	CXSlider.prototype.Disable = function ()
	{
		this.jFld.prop("disabled", true);
		this.jSlider.slider("disable");
		this.bDisabled = true;
		this.FireEvent({ sEvent: "disable" });
		return this;
	};
	CXSlider.prototype.Enable = function ()
	{
		this.jFld.prop("disabled", false);
		this.jSlider.slider("enable");
		this.bDisabled = false;
		this.FireEvent({ sEvent: "enable" });
		return this;
	};
	CXSlider.prototype.SetIcon = function (oArgs)
	{
		if(oArgs.bHideIcon)
		{
			this.jIcon.hide();
		}
		else
		{
			this.jIcon.attr({ "class": this.sIconBasicClass + " " + oArgs.sIconClass }).show();
		}
		return this;
	};
	CXSlider.prototype.SetLabel = function (oArgs)
	{
		if(this.jLabels.length!=0)
		{
			this.jLabels.html(oArgs.sLabel);
		}
		else
		{
			this.jBlock.attr({ "title": oArgs.sLabel });
		}
		return this;
	};
	CXSlider.prototype.SetValue = function (oArgs)
	{
		if(oArgs==null)
		{
			return this;
		}
		if(oArgs.sValue==null || oArgs.sValue==this.sValue)
		{
			return this;
		}
		var nValue = parseFloat(oArgs.sValue);
		if(isNaN(nValue))
		{
			nValue = this.nDefault;
		}
		this.jFld.val(nValue);
		this.jSlider.slider("value", nValue);
		this.sValue = nValue.toString();
		if(this.bSuppressEvent==true)
		{
			this.bSuppressEvent = false;
		}
		else
		{
			this.FireEvent({ sEvent: "change" });
		}
		return this;
	};
	CXSlider.prototype.UIEvent = function (oArgs)
	{
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "slide":
			{
				this.jFld.val(oArgs.oSlider.value.toString());
				break;
			}
			case "slidechange":
			{
				this.sValue = oArgs.oSlider.value.toString();
				this.jFld.val(this.sValue);
				this.FireEvent({ sEvent: "change" });
				break;
			}
			case "change":
			{
				this.Validate();
				this.jFld.removeAttr("cx-invalid");
				var nValue = parseFloat(this.jFld.val());
				this.jSlider.slider("value", nValue);
				this.sValue = nValue.toString();
				this.FireEvent({ sEvent: "change" });
				break;
			}
			case "keyup":
			{
				if(oArgs.oEvt.keyCode==9 || oArgs.oEvt.keyCode==13 || oArgs.oEvt.keyCode==27) // TAB, ENTER, ESC
				{
					this.jFld.blur();
				}
				else
				{
					this.Validate({ bNumericOnly: true });
					this.FireEvent({ sEvent: "keyup" });
				}
				break;
			}
		}
		return this;
	};
	CXSlider.prototype.Validate = function (oArgs)
	{
		var bNumericOnly = false;
		if(oArgs!=null)
		{
			bNumericOnly = (oArgs.bNumericOnly==true);
		}
		var sValue = this.jFld.val().toString();
		if(sValue.indexOf(",")!=-1)
		{
			sValue = sValue.replace(",", ".");
		}
		var aParts = sValue.split(".");
		var re1 = /-?\d+/;
		var re2 = /(\d+)?/;
		var aMatches;
		if(this.iDec!=0)
		{
			if(aParts.length>2)
			{
				for(var i=2; i<aParts.length; i++)
				{
					aParts[1] += aParts[i].toString();
				}
			}
			if(aParts[0]!=null)
			{
				aMatches = aParts[0].match(re1);
				if(aMatches==null)
				{
					aParts[0] = "";
				}
				else if(aMatches.length!=0)
				{
					aParts[0] = aMatches[0];
				}
				sValue = aParts[0];
			}
			if(aParts[1]!=null)
			{
				aMatches = aParts[1].match(re2);
				if(aMatches==null)
				{
					aParts[1] = "";
				}
				else if(aMatches.length!=0)
				{
					aParts[1] = aMatches[0];
				}
				if(sValue=="") sValue = "0";
				sValue += "." + aParts[1];
			}
		}
		else
		{
			if(aParts[0]!=null)
			{
				aMatches = aParts[0].match(re1);
				if(aMatches==null)
				{
					aParts[0] = "";
				}
				else if(aMatches.length!=0)
				{
					aParts[0] = aMatches[0];
				}
				sValue = aParts[0];
			}
		}
		var nValue = parseFloat(sValue);
		this.jFld.removeAttr("cx-invalid");
		if(this.bHasLimits)
		{
			if(nValue<this.nLimitMin)
			{
				if(bNumericOnly)
				{
					this.jFld.attr({ "cx-invalid": "1" });
				}
				else
				{
					nValue = this.nLimitMin;
				}
			}
			if(nValue>this.nLimitMax)
			{
				if(bNumericOnly)
				{
					this.jFld.attr({ "cx-invalid": "1" });
				}
				else
				{
					nValue = this.nLimitMax;
				}
			}
		}
		else
		{
			if(nValue<this.nMin)
			{
				if(bNumericOnly)
				{
					this.jFld.attr({ "cx-invalid": "1" });
				}
				else
				{
					nValue = this.nMin;
				}
			}
			if(nValue>this.nMax)
			{
				if(bNumericOnly)
				{
					this.jFld.attr({ "cx-invalid": "1" });
				}
				else
				{
					nValue = this.nMax;
				}
			}
		}
		this.jFld.val(isNaN(nValue) ? this.nLimitMin : nValue.toString());
		return this;
	};
}
{ // CXBtnSelect
	window.CXBtnSelect = function (oArgs)
	{
		CXControl.call(this, oArgs);

		this.sName = oArgs.sName;
		this.sType = oArgs.sType;
		this.jBlock = oArgs.jBlock;
		this.sId = oArgs.sId;
		this.sClass = oArgs.sClass==null ? "" : oArgs.sClass;
		this.sSelectorClass = oArgs.sSelectorClass==null ? "" : oArgs.sSelectorClass;
		this.aItems = oArgs.aItems;
		this.oBtns = {};
		this.sValue = null;
		this.Constructor();
		return this;
	};
	CXBtnSelect.prototype = Object.create(CXControl.prototype);
	CXBtnSelect.prototype.constructor = CXBtnSelect;
	CXBtnSelect.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		if(this.jBlock==null)
		{
			this.jBlock = this.jStorage.find("[cx-template='slider-block']").clone(true).removeAttr("cx-template").appendTo(this.oContainer);
		}
		this.jBlock.on("mouseover mouseout", function (e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
		this.jBtn = this.jBlock.find("[cx-role='select-btn-main']");
		this.sBtnBasicClass = this.jBtn.attr("class");
		this.jLabels = this.jBlock.find("[cx-role='select-btn-label']");
		this.jSelector = this.jBlock.find("[cx-role='select-btn-selector']");
		this.jSelector.attr({ "class": this.jSelector.attr("class") + " " + this.sSelectorClass });
		var jBtnTemplate = this.jStorage.find("[cx-template='select-btn']");
		for(var i=0; i<this.aItems.length; i++)
		{
			this.oBtns[this.aItems[i].sId] =
			{
				jBtn: jBtnTemplate.clone(true).removeAttr("cx-template").appendTo(this.jSelector),
				sName: this.aItems[i].sName,
				sClass: this.aItems[i].sClass
			};
			this.oBtns[this.aItems[i].sId].jBtn.attr({ "class": this.sBtnBasicClass + " " + this.aItems[i].sClass, "cx-id": this.aItems[i].sId, "title": this.aItems[i].sName }).on("click", function (e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
		}
		if(this.bHasInitialValue)
		{
			this.bSuppressEvent = true;
			this.SetValue({ sValue: oArgs.sValue });
		}
		if(this.bDisabled)
		{
			this.Disable();
		}
		return this;
	};
	CXBtnSelect.prototype.Disable = function ()
	{
		this.jBtn.prop("disabled", true);
		this.bDisabled = true;
		this.FireEvent({ sEvent: "disable" });
		return this;
	};
	CXBtnSelect.prototype.Enable = function ()
	{
		this.jBtn.prop("disabled", false);
		this.bDisabled = false;
		this.FireEvent({ sEvent: "enable" });
		return this;
	};
	CXBtnSelect.prototype.SetIcon = function (oArgs)
	{
		this.jBtn.attr({ "class": this.sBtnBasicClass + " " + oArgs.sIconClass });
		return this;
	};
	CXBtnSelect.prototype.SetLabel = function (oArgs)
	{
		this.jLabels.html(oArgs.sLabel);
		return this;
	};
	CXBtnSelect.prototype.SetValue = function (oArgs)
	{
		if(oArgs==null)
		{
			return this;
		}
		if(oArgs.sValue==null || oArgs.sValue==this.sValue)
		{
			return this;
		}
		this.sValue = oArgs.sValue;
		if(this.sValue!="")
		{
			this.SetIcon({ sIconClass: this.oBtns[this.sValue].sClass });
			this.jBtn.attr({ "title": this.oBtns[this.sValue].sName });
		}
		if(this.bSuppressEvent==true)
		{
			this.bSuppressEvent = false;
		}
		else
		{
			this.FireEvent({ sEvent: "change" });
		}
		return this;
	};
	CXBtnSelect.prototype.UIEvent = function (oArgs)
	{
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "mouseover":
			{
				this.jSelector.css({ "opacity": "0" }).css({ "display": "flex" });
				if(this.nSelectorH==null)
				{
					this.nSelectorH = this.jSelector.height();
					this.jSelector.height(this.nSelectorH);
				}
				if(this.nBlockH==null)
				{
					this.nBlockH = this.jBlock.height();
				}
				if((this.jBlock.offset().top - this.nSelectorH) > 10)
				{
					this.jSelector.css({ "top": "", "bottom": (this.nBlockH-1) + "px", "opacity": "1" });
				}
				else
				{
					this.jSelector.css({ "top": (this.nBlockH-1) + "px", "bottom": "", "opacity": "1" });
				}
				break;
			}
			case "mouseout":
			{
				this.jSelector.css({ "display": "none" });
				break;
			}
			case "click":
			{
				this.sValue = oArgs.oElem.getAttribute("cx-id");
				for(var sKey in this.oBtns)
				{
					if(sKey==this.sValue)
					{
						this.oBtns[sKey].jBtn.attr({ "cx-selected": "1" });
					}
					else
					{
						this.oBtns[sKey].jBtn.removeAttr("cx-selected");
					}
				}
				this.SetIcon({ sIconClass: this.oBtns[this.sValue].sClass });
				this.jSelector.css({ "display": "none" });
				this.FireEvent({ sEvent: "change" });
				break;
			}
		}
		return this;
	};
}
{ // CXParamList
	window.CXParamList = function (oArgs)
	{
		CXControl.call(this, oArgs);

		this.sName = oArgs.sName;
		this.sType = oArgs.sType;
		this.jBlock = oArgs.jBlock;
		this.sId = oArgs.sId;
		this.iMax = oArgs.iMax;
		this.sClass = oArgs.sClass==null ? "" : oArgs.sClass;
		this.sValue = "";
		this.bMultipleActionsFld = (oArgs.bMultipleActionsFld==true);
		this.oBtns = {};
		this.oPages = {};
		this.aTabs = [];
		this.aPages = [];
		this.aReorder = [];
		this.Constructor();
		return this;
	};
	CXParamList.prototype = Object.create(CXControl.prototype);
	CXParamList.prototype.constructor = CXParamList;
	CXParamList.prototype.AppendItem = function (oArgs)
	{
		var oThis = this;
		var sUID = null;
		if(oArgs!=null)
		{
			sUID = oArgs.sId;
		}
		if(sUID==null)
		{
			sUID = TOOLS.ShortID();
		}
		var jTab = this.jTabTemplate.clone(true).removeAttr("cx-template").attr({ "cx-id": sUID }).insertBefore(this.oBtns["add"].jContainer);
		var jPage = this.jPageTemplate.clone(true).removeAttr("cx-template").attr({ "id": sUID }).appendTo(this.jPageList);
		this.oBtns[sUID] =
		{
			"delete": new CXBtn({ oPlayer: this.oPlayer, jContainer: jPage, jBtn: jPage.find("[cx-role='btn-delete-item']"), fn: oThis.UIEvent, oArgs: { oContext: oThis, sId: sUID } }),
			"select": new CXBtn({ oPlayer: this.oPlayer, jContainer: this.jTabList, jBtn: jTab.find("[cx-role='obj-tab-btn']"), fn: oThis.UIEvent, oArgs: { oContext: oThis, sId: sUID } }),
		};
		this.oPages[sUID] = { sId: sUID, iIdx: this.aPages.length, iNum: this.aPages.length + 1, jPage: jPage, jTab: jTab, jBtn: jTab.find("[cx-role='obj-tab-btn']"), jNumber: jPage.find("[cx-role='obj-list-element-number']") };
		this.oPages[sUID].jBtn.attr({ "cx-id": sUID });
		this.oPages[sUID].jBtn.find("[cx-role='btn-text']").attr({ "title": this.oPlayer._GetString({ sId: "list-item-number" }).split("%1").join(this.oPages[sUID].iNum) }).html(this.oPages[sUID].iNum);
		this.oPages[sUID].jNumber.html(this.oPages[sUID].iNum);
		this.aPages.push(this.oPages[sUID]);
		if(oArgs.bSuppressEvent!=true)
		{
			this.FireEvent({ sEvent: "change" });
		}
		this.SetValue({ sValue: sUID, bSuppressEvent: true });
		return this;
	};
	CXParamList.prototype.Cleanup = function ()
	{
		this.jTabList.find("[role='tab']").remove();
		this.jPageList.html("");
		return this;
	};
	CXParamList.prototype.Constructor = function ()
	{
		var oThis = this;
		if(this.jBlock==null)
		{
			this.jBlock = this.jStorage.find("[cx-template='obj-list-block']").clone(true).removeAttr("cx-template").appendTo(this.oContainer);
		}
		this.jTabTemplate = this.jStorage.find("[cx-template='obj-list-tab']");
		this.jPageTemplate = this.jStorage.find("[cx-template='obj-list-page']");
		this.jTabList = this.jBlock.find("[cx-role='obj-list-tabs']");
		this.jPageList = this.jBlock.find("[cx-role='obj-list-pages']");
		this.oBtns["add"] = new CXBtn({ oPlayer: this.oPlayer, jContainer: this.jBlock.find("[cx-role='btn-list-add-item']"), jBtn: this.jBlock.find("[cx-role='btn-new-item']"), fn: oThis.UIEvent, oArgs: { oContext: oThis } });
		this.oBtns["prev"] = new CXBtn({ oPlayer: this.oPlayer, jContainer: this.jBlock.find("[cx-role='btn-list-add-item']"), jBtn: this.jBlock.find("[cx-role='btn-item-prev']"), fn: oThis.UIEvent, oArgs: { oContext: oThis } });
		this.oBtns["next"] = new CXBtn({ oPlayer: this.oPlayer, jContainer: this.jBlock.find("[cx-role='btn-list-add-item']"), jBtn: this.jBlock.find("[cx-role='btn-item-next']"), fn: oThis.UIEvent, oArgs: { oContext: oThis } });
		if(this.bDisabled)
		{
			this.Disable();
		}
		return this;
	};
	CXParamList.prototype.DeleteItem = function (oArgs)
	{
		var sJumpId = "";
		var iIdx;
		var i;
		for(i=0; i<this.aPages.length; i++)
		{
			if(this.aPages[i].sId==oArgs.sId)
			{
				iIdx = i;
				if(sJumpId=="")
				{
					if(this.aPages[i+1]!=null)
					{
						sJumpId = this.aPages[i+1].sId;
					}
				}
				break;
			}
			sJumpId = this.aPages[i].sId;
		}
		this.aPages.splice(iIdx,1);
		this.oPages[oArgs.sId].jTab.remove();
		this.oPages[oArgs.sId].jPage.remove();
		for(i=0; i<this.aPages.length; i++)
		{
			this.aPages[i].jBtn.find("[cx-role='btn-text']").html(i+1);
			this.aPages[i].jNumber.html(i+1);
		}
		this.SetValue({ sValue: sJumpId });
		this.oBtns[oArgs.sId]["select"] = null;
		this.oBtns[oArgs.sId]["delete"] = null;
		delete this.oBtns[oArgs.sId]["select"];
		delete this.oBtns[oArgs.sId]["delete"];
		delete this.oBtns[oArgs.sId];
		this.FireEvent({ sEvent: "change" });
		return this;
	};
	CXParamList.prototype.Disable = function ()
	{
		this.oBtns["add"].Disable();
		this.bDisabled = true;
		this.FireEvent({ sEvent: "disable" });
		return this;
	};
	CXParamList.prototype.Enable = function ()
	{
		this.oBtns["add"].Enable();
		this.bDisabled = false;
		this.FireEvent({ sEvent: "enable" });
		return this;
	};
	CXParamList.prototype.Reorder = function (oArgs)
	{
		var oSelectedItem = null;
		for(sKey in this.oPages)
		{
			if(sKey==this.sValue)
			{
				oSelectedItem = this.oPages[sKey];
				break;
			}
		}
		if(oSelectedItem!=null)
		{
			var iSelectedIdx = oSelectedItem.iIdx;
			var iTargetIdx = -1;
			if(oArgs.sDir=="prev")
			{
				if(iSelectedIdx!=0)
				{
					iTargetIdx = iSelectedIdx - 1;
				}
			}
			else if(oArgs.sDir=="next")
			{
				if(iSelectedIdx!=this.aPages.length-1)
				{
					iTargetIdx = iSelectedIdx + 1;
				}
			}
			if(iTargetIdx!=-1)
			{
				if(iTargetIdx>iSelectedIdx)
				{
					this.aPages[iTargetIdx].jTab.insertBefore(this.aPages[iSelectedIdx].jTab);
				}
				else
				{
					this.aPages[iTargetIdx].jTab.insertAfter(this.aPages[iSelectedIdx].jTab);
				}
				this.aPages[iTargetIdx] = this.aPages.splice(iSelectedIdx, 1, this.aPages[iTargetIdx])[0];
				this.aPages[iTargetIdx].iIdx = iTargetIdx;
				this.aPages[iTargetIdx].iNum = iTargetIdx + 1;
				this.aPages[iTargetIdx].jBtn.find("[cx-role='btn-text']").attr({ "title": this.oPlayer._GetString({ sId: "list-item-number" }).split("%1").join(this.aPages[iTargetIdx].iNum) }).html(this.aPages[iTargetIdx].iNum);
				this.aPages[iTargetIdx].jNumber.html(this.aPages[iTargetIdx].iNum);
				this.aPages[iSelectedIdx].iIdx = iSelectedIdx;
				this.aPages[iSelectedIdx].iNum = iSelectedIdx + 1;
				this.aPages[iSelectedIdx].jBtn.find("[cx-role='btn-text']").attr({ "title": this.oPlayer._GetString({ sId: "list-item-number" }).split("%1").join(this.aPages[iSelectedIdx].iNum) }).html(this.aPages[iSelectedIdx].iNum);
				this.aPages[iSelectedIdx].jNumber.html(this.aPages[iSelectedIdx].iNum);
				this.oBtns["prev"].Enable();
				this.oBtns["next"].Enable();
				if(iTargetIdx<=0)
				{
					this.oBtns["prev"].Disable();
				}
				if(iTargetIdx>=this.aPages.length-1)
				{
					this.oBtns["next"].Disable();
				}
				this.aReorder = [ iSelectedIdx, iTargetIdx ];
				if(oArgs.bSuppressEvent!=true)
				{
					this.FireEvent({ sEvent: "reorder" });
					this.FireEvent({ sEvent: "change" });
				}
				this.aReorder = [];
			}
		}
		return this;
	};
	CXParamList.prototype.Reset = function ()
	{
		for(var sKey in this.oPages)
		{
			if(this.oPages[sKey]!=null)
			{
				this.oPages[sKey].jTab.remove();
				this.oPages[sKey].jPage.remove();
			}
		}
		this.oPages = {};
		this.aPages = [];
		return this;
	};
	CXParamList.prototype.SetValue = function (oArgs)
	{
		if(oArgs!=null)
		{
			if(oArgs.sValue!=null)
			{
				var sKey;
				if(oArgs.sValue!="")
				{
					if(this.oPages[oArgs.sValue]!=null)
					{
						this.sValue = oArgs.sValue;
						for(sKey in this.oPages)
						{
							if(sKey==this.sValue)
							{
								this.oPages[sKey].jPage.show();
								this.oPages[sKey].jTab.attr({ "cx-state": "selected" });
								var iSelectedIdx = this.oPages[sKey].iIdx;
								this.oBtns["prev"].Enable();
								this.oBtns["next"].Enable();
								if(iSelectedIdx<=0)
								{
									this.oBtns["prev"].Disable();
								}
								if(iSelectedIdx>=this.aPages.length-1)
								{
									this.oBtns["next"].Disable();
								}
							}
							else
							{
								this.oPages[sKey].jPage.hide();
								this.oPages[sKey].jTab.removeAttr("cx-state");
							}
						}
						if(!oArgs.bSuppressEvent)
						{
							this.FireEvent({ sEvent: "select" });
						}
					}
				}
				else
				{
					this.sValue = "";
					for(sKey in this.oPages)
					{
						this.oPages[sKey].jPage.hide();
						this.oPages[sKey].jTab.removeAttr("cx-state");
					}
					if(!oArgs.bSuppressEvent)
					{
						this.FireEvent({ sEvent: "select" });
					}
				}
			}
		}
		return this;
	};
	CXParamList.prototype.UIEvent = function (oArgs)
	{
		var oThis = this;
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "click":
			{
				switch(oArgs.oElem.getAttribute("cx-role"))
				{
					case "obj-tab-btn":
					{
						this.SetValue({ sValue: oArgs.oElem.getAttribute("cx-id") });
						break;
					}
					case "btn-new-item":
					{
						oThis.FireEvent({ sEvent: "appendrequest" });
						break;
					}
					case "btn-item-prev":
					{
						oThis.Reorder({ sDir: "prev" });
						oThis.FireEvent({ sEvent: "orderrequest" });
						break;
					}
					case "btn-item-next":
					{
						oThis.Reorder({ sDir: "next" });
						oThis.FireEvent({ sEvent: "orderrequest" });
						break;
					}
					case "btn-delete-item":
					{
						oThis.sItemToDelete = oArgs.oArgs.sId;
						oThis.FireEvent({ sEvent: "deleterequest" });
						oThis.sItemToDelete = "";
						break;
					}
				}
				break;
			}
		}
		return this;
	};
}
{ // CXSelectBtn // iconized selectmenu
	window.CXSelectBtn = function (oArgs)
	{
		CXControl.call(this, oArgs);

		this.sName = oArgs.sName;
		this.sType = oArgs.sType;
		this.jBlock = oArgs.jBlock;
		this.sId = oArgs.sId;
		this.sSelectorClass = oArgs.sSelectorClass==null ? "" : oArgs.sSelectorClass;
		this.sPrefix = oArgs.sPrefix==null ? "" : oArgs.sPrefix;
		this.aItems = oArgs.aItems;
		this.sLabel = "";
		this.oBtns = {};
		this.sValue = null;
		this.Constructor();
		return this;
	};
	CXSelectBtn.prototype = Object.create(CXControl.prototype);
	CXSelectBtn.prototype.constructor = CXSelectBtn;
	CXSelectBtn.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		if(this.jBlock==null)
		{
			this.jBlock = this.jStorage.find("[cx-template='select-btn-block']").clone(true).removeAttr("cx-template").appendTo(this.oContainer);
		}
		this.jSelector = this.jBlock.find("[cx-role='select-btn-selector']");
		this.jSelector.attr({ "class": this.sSelectorClass });
		for(var i=0; i<this.aItems.length; i++)
		{
			this.jSelector.append('<option value="' + this.aItems[i].sId + '" cx-prefix="' + this.sPrefix + '">' + this.aItems[i].sName + '</option>');
		}
		this.jSelector.selectmenu(
		{
			position: { my: "left top+10", at: "left bottom", collision: "none" },
			classes:
			{
				"ui-selectmenu-button": "cx-select-menu-btn",
				"ui-selectmenu-menu": "cx-select-menu-wrapper"
			},
			change: function (e, ui)
			{
				oThis.UIEvent.call(oThis, { oEvt: e, oElem: ui.item });
			},
			open: function ()
			{
				var oInstance = $(this).selectmenu("instance");
				if(this.getAttribute("cx-ready")==null)
				{
					var aItems = oInstance.items;
					var aMenuItems = oInstance.menuItems;
					for(var i=0; i<aItems.length; i++)
					{
						$(aMenuItems[i]).attr({ "cx-select-icon": oThis.sPrefix + aItems[i].value }).html("&nbsp;");
						$(aMenuItems[i]).parent().attr({ "title": aItems[i].label });
					}
				}
				var nWH = $(window).height();
				var nH = oInstance.menuWrap.height();
				var nT = oInstance.menuWrap.offset().top;
				if((nT + nH + 20)>nWH)
				{
					$(this).selectmenu("option", "position", { my: "left bottom-10", at: "left top", collision: "none" }).selectmenu("close").selectmenu("open");
				}
			}
		});
		this.oSelectorInstance = this.jSelector.selectmenu("instance");
		if(this.bHasInitialValue)
		{
			this.bSuppressEvent = true;
			this.SetValue({ sValue: oArgs.sValue });
		}
		if(this.bDisabled)
		{
			this.Disable();
		}
		return this;
	};
	CXSelectBtn.prototype.Disable = function ()
	{
		this.jBtn.prop("disabled", true);
		this.bDisabled = true;
		this.FireEvent({ sEvent: "disable" });
		return this;
	};
	CXSelectBtn.prototype.Enable = function ()
	{
		this.jBtn.prop("disabled", false);
		this.bDisabled = false;
		this.FireEvent({ sEvent: "enable" });
		return this;
	};
	CXSelectBtn.prototype.SetIcon = function (oArgs)
	{
		this.jBtn.attr({ "class": this.sBtnBasicClass + " " + oArgs.sIconClass });
		return this;
	};
	CXSelectBtn.prototype.SetLabel = function (oArgs)
	{
		this.sLabel = oArgs.sLabel;
		this.oSelectorInstance.button.attr({ "title": this.sLabel + ": " + this.oSelectorInstance.button.attr("cx-value") });
		return this;
	};
	CXSelectBtn.prototype.SetValue = function (oArgs)
	{
		if(oArgs==null)
		{
			return this;
		}
		if(oArgs.sValue==null || oArgs.sValue==this.sValue)
		{
			return this;
		}
		this.sValue = oArgs.sValue;
		if(this.sValue!="")
		{
			var sName = "";
			for(var i=0; i<this.aItems.length; i++)
			{
				if(this.aItems[i].sId==this.sValue)
				{
					sName = this.aItems[i].sName;
				}
			}
			this.oSelectorInstance.button.attr({ "cx-select-icon": this.sPrefix + this.sValue, "cx-value": this.sValue, "title": this.sLabel + ": " + sName });
		}
		if(this.bSuppressEvent==true)
		{
			this.bSuppressEvent = false;
		}
		else
		{
			this.FireEvent({ sEvent: "change" });
		}
		return this;
	};
	CXSelectBtn.prototype.UIEvent = function (oArgs)
	{
		var oThis = this;
		if(this.bDisabled)
		{
			return this;
		}
		switch(oArgs.oEvt.type)
		{
			case "selectmenuchange":
			{
				oThis.SetValue({ sValue: oArgs.oElem.value });
				break;
			}
		}
		return this;
	};
}
