/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'bg', {
	label: 'Стилове',
	panelTitle: 'Стилове за форматиране',
	panelTitle1: 'Блокови стилове',
	panelTitle2: 'Поредови стилове',
	panelTitle3: 'Обектни стилове'
} );
