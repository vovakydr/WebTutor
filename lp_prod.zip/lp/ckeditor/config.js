/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 * Modified by WebSoft Ltd. Russia // 20150610
 */
var g_sLang = "ru";
var g_sDefaultSpan = '<span style="font-family:robotoregular,arial,helvetica,sans-serif;font-size:16px;color:#000000;">​&nbsp;</span>';
var g_aSpecialChars = [
	[ "&nbsp;", "Неразрывный пробел" ],
	[ "&quot;", "Двойная кавычка" ],
	[ "&laquo;", "Левая двойная кавычка" ],
	[ "&raquo;", "Правая двойная кавычка" ],
	[ "&acute;", "Ударение" ],
	[ "&ndash;", "Тире" ],
	[ "&mdash;", "Длинное тире" ],
	[ "&iexcl;", "Перевернутый восклицательный знак" ],
	[ "&iquest;", "Перевернутый вопросительный знак" ],
	[ "&sect;", "Параграф" ],
	[ "&copy;", "Копирайт" ],
	[ "&reg;", "Регистрация" ],
	[ "&trade;", "Торговая марка" ],
	[ "&dagger;", "Обелиск" ],
	[ "&Dagger;", "Двойной обелиск" ],
	[ "&bull;", "Буллет" ],
	[ "&larr;", "Стрелка влево" ],
	[ "&rarr;", "Стрелка вправо" ],
	[ "&uarr;", "Стрелка вверх" ],
	[ "&darr;", "Стрелка вниз" ],
	[ "&harr;", "Стрелка влево-вправо" ],
	[ "&crarr;", "Перевод каретки" ],
	[ "&lArr;", "Двойная стрелка влево" ],
	[ "&rArr;", "Двойная стрелка вправо" ],
	[ "&uArr;", "Двойная стрелка вверх" ],
	[ "&dArr;", "Двойная стрелка вниз" ],
	[ "&hArr;", "Двойная стрелка влево-вправо" ],
	[ "&deg;", "Градус" ],
	[ "&permil;", "Промилле" ],
	[ "&plusmn;", "Плюс-минус" ],
	[ "&frac14;", "Одна четверть" ],
	[ "&frac12;", "Половина" ],
	[ "&frac34;", "Три четверти" ],
	[ "&times;", "Умножение" ],
	[ "&divide;", "Деление" ],
	[ "&nabla;", "Набла" ],
	[ "&prod;", "Продукт" ],
	[ "&sum;", "Сумма" ],
	[ "&minus;", "Минус" ],
	[ "&radic;", "Корень" ],
	[ "&int;", "Интеграл" ],
	[ "&part;", "Дифференциал" ],
	[ "&asymp;", "Примерно равно" ],
	[ "&ne;", "Не равно" ],
	[ "&equiv;", "Полностью эквивалентно" ],
	[ "&le;", "Меньше или равно" ],
	[ "&ge;", "Больше или равно" ],
	[ "&infin;", "Бесконечность" ],
	[ "&ang;", "Угол" ],
	[ "&forall;", "Для всех" ],
	[ "&exist;", "Существует" ],
	[ "&there4;", "Следовательно" ],
	[ "&empty;", "Пустое множество" ],
	[ "&isin;", "Принадлежит" ],
	[ "&notin;", "Не принадлежит" ],
	[ "&ni;", "Содержит" ],
	[ "&prop;", "Пропорционален" ],
	[ "&cap;", "Пересечение" ],
	[ "&cup;", "Объединение" ],
	[ "&sub;", "Подмножество" ],
	[ "&sup;", "Супермножество" ],
	[ "&nsub;", "Не подмножество" ],
	[ "&sube;", "Подмножество или совпадение" ],
	[ "&supe;", "Супермножество или совпадение" ],
	[ "&Alpha;", "Альфа заглавная" ],
	[ "&alpha;", "Альфа прописная" ],
	[ "&Beta;", "Бета заглавная" ],
	[ "&beta;", "Бета прописная" ],
	[ "&Gamma;", "Гамма заглавная" ],
	[ "&gamma;", "Гамма прописная" ],
	[ "&Delta;", "Дельта заглавная" ],
	[ "&delta;", "Дельта прописная" ],
	[ "&Epsilon;", "Эпсилон заглавная" ],
	[ "&epsilon;", "Эпсилон прописная" ],
	[ "&Zeta;", "Дзета заглавная" ],
	[ "&zeta;", "Дзета прописная" ],
	[ "&Eta;", "Эта заглавная" ],
	[ "&eta;", "Эта прописная" ],
	[ "&Theta;", "Тета заглавная" ],
	[ "&theta;", "Тета прописная" ],
	[ "&Iota;", "Йота заглавная" ],
	[ "&iota;", "Йота прописная" ],
	[ "&Kappa;", "Каппа заглавная" ],
	[ "&kappa;", "Каппа прописная" ],
	[ "&Lambda;", "Лямбда заглавная" ],
	[ "&lambda;", "Лямбда прописная" ],
	[ "&Mu;", "Мю заглавная" ],
	[ "&mu;", "Мю прописная" ],
	[ "&Nu;", "Ню заглавная" ],
	[ "&nu;", "Ню прописная" ],
	[ "&Xi;", "Кси заглавная" ],
	[ "&xi;", "Кси прописная" ],
	[ "&Omicron;", "Омикрон заглавная" ],
	[ "&omicron;", "Омикрон прописная" ],
	[ "&Pi;", "Пи заглавная" ],
	[ "&pi;", "Пи прописная" ],
	[ "&Rho;", "Ро заглавная" ],
	[ "&rho;", "Ро прописная" ],
	[ "&Sigma;", "Сигма заглавная" ],
	[ "&sigma;", "Сигма прописная" ],
	[ "&Tau;", "Тау заглавная" ],
	[ "&tau;", "Тау прописная" ],
	[ "&Upsilon;", "Ипсилон заглавная" ],
	[ "&upsilon;", "Ипсилон прописная" ],
	[ "&Phi;", "Фи заглавная" ],
	[ "&phi;", "Фи прописная" ],
	[ "&Chi;", "Хи заглавная" ],
	[ "&chi;", "Хи прописная" ],
	[ "&Psi;", "Пси заглавная" ],
	[ "&psi;", "Пси прописная" ],
	[ "&Omega;", "Омега заглавная" ],
	[ "&omega;", "Омега прописная" ],
	[ "&micro;", "Микро - вариант" ],
	[ "&thetasym;", "Тета - вариант" ],
	[ "&upsih;", "Ипсилон - вариант" ],
	[ "&piv;", "Символ Пи греческий" ]
];

CKEDITOR.editorConfig = function( config )
{ 
	config.language = g_sLang;
	config.fontSize_sizes = "Small/0.75em;Normal/1em;Large/1.25em";
	config.fontSize_defaultLabel = "Normal";
	config.specialChars = g_aSpecialChars;
 	config.uiColor = "#dce7f5";
	//config.skin: "courselab";
	config.autoParagraph = false;
	config.browserContextMenuOnCtrl = true;
//	config.contentsCss = "ckeditor/cl-rte-fonts.css";
	config.removePlugins = "image";
	config.extraPlugins = "cl_bgswitch,stylescombo";
	config.removeDialogTabs = "link:advanced";
	config.dialog_noConfirmCancel = true;
	config.disableNativeSpellChecker = true;
	config.disableNativeTableHandles = false;
	config.startupFocus = true;
	config.dialog_backgroundCoverColor = "#ccc";
	config.allowedContent = 
	{
		"a":
		{
			attributes: "*",
			classes: true,
			styles: true
		},
		"abbr address b cite code dd dfn dl dt em i kbd pre samp section small span strong sub sup var":
		{
			attributes: [ "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"article aside figure figcaption footer header mark wbr":
		{
			attributes: false,
			classes: false,
			styles: false
		},
		"blockquote q":
		{
			attributes: [ "cite", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"br":
		{
			attributes: [ "clear" ],
			classes: true,
			styles: true
		},
		"button":
		{
			attributes: [ "accesskey", "autofocus", "disabled", "form", "name", "type", "value", "dir", "id", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"canvas":
		{
			attributes: [ "width", "height", "id", "data-*" ],
			classes: true,
			styles: true
		},
		"caption":
		{
			attributes: [ "align", "valign", "id", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"col colgroup":
		{
			attributes: [ "align", "span", "valign", "width", "dir", "id", "lang", "data-*" ],
			classes: false,
			styles: false
		},
		"del ins":
		{
			attributes: [ "cite", "datetime", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"div h1 h2 h3 h4 h5 h6 p":
		{
			attributes: [ "align", "title", "dir", "id", "lang", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"embed":
		{
			attributes: [ "align", "height", "hidden", "hspace", "pluginspage", "!src", "type", "vspace", "width", "id", "data-*" ],
			classes: true,
			styles: true
		},
		"fieldset":
		{
			attributes: [ "disabled", "form", "title", "dir", "id", "lang", "data-*" ],
			classes: true,
			styles: true
		},
		"form":
		{
			attributes: [ "accept-charset", "action", "autocomplete", "enctype", "method", "name", "target", "id", "dir", "lang", "title", "data-*" ],
			classes: true,
			styles: true
		},
		"hr":
		{
			attributes: [ "align", "color", "noshade", "size", "width", "id", "data-*" ],
			classes: true,
			styles: true
		},		
		"img":
		{
			attributes: [ "!src", "align", "alt", "height", "hspace", "vspace", "width", "id", "title", "onclick", "ondblclick", "onload", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"input":
		{
			attributes: [ "accept", "accesskey", "align", "alt", "autocomplete", "autofocus", "border", "checked", "disabled", "form*", "list", "max", "maxlength", "min", "multiple", "name", "pattern", "placeholder", "readonly", "required", "size", "src", "step", "tabindex", "!type", "value", "dir", "id", "lang", "title", "onblur", "onchange", "onclick", "ondblclick", "onfocus", "onkeydown", "onkeypress", "onkeyup", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"label":
		{
			attributes: [ "accesskey", "for", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},		
		"legend":
		{
			attributes: [ "accesskey", "align", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},		
		"li":
		{
			attributes: [ "type", "value", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},		
		"object":
		{
			attributes: [ "!data", "align", "archive", "classid", "code", "codebase", "codetype", "height", "hspace", "tabindex", "type", "vspace", "width", "id", "title", "onclick", "ondblclick", "onload", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"ol":
		{
			attributes: [ "type", "reversed", "start", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},		
		"optgroup":
		{
			attributes: [ "disabled", "label", "dir", "id", "lang", "onmouseover", "onmouseout", "title", "data-*" ],
			classes: true,
			styles: true
		},		
		"option":
		{
			attributes: [ "disabled", "label", "selected", "value", "dir", "id", "lang", "title", "onmouseover", "onmouseout", "data-*" ],
			classes: true,
			styles: true
		},		
		"param":
		{
			attributes: [ "name", "type", "value", "valuetype", "data-*" ],
			classes: false,
			styles: false
		},		
		"select":
		{
			attributes: [ "accesskey", "autofocus", "disabled", "form", "list", "multiple", "name", "required", "size", "tabindex", "dir", "id", "lang", "title", "onblur", "onchange", "onfocus", "data-*" ],
			classes: true,
			styles: true
		},
		"table":
		{
			attributes: [ "border", "cellpadding", "cols", "frame", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"tbody tfoot thead":
		{
			attributes: [ "align", "char", "charoff", "bgcolor", "valign", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"td th":
		{
			attributes: [ "abbr", "align", "background", "bgcolor", "bordercolor", "colspan", "headers", "height", "nowrap", "rowspan", "scope", "valign", "width", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"textarea":
		{
			attributes: [ "accesskey", "autofocus", "cols", "disabled", "form", "maxlength", "name", "placeholder", "readonly", "required", "rows", "tabindex", "wrap", "dir", "id", "lang", "title", "onblur", "onchange", "onclick", "ondblclick", "onfocus", "onkeydown", "onkeypress", "onkeyup", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"time":
		{
			attributes: [ "datetime", "pubdate", "data-*" ],
			classes: false,
			styles: false
		},		
		"tr":
		{
			attributes: [ "align", "bgcolor", "bordercolor", "valign", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"ul":
		{
			attributes: [ "type", "dir", "id", "lang", "title", "onclick", "ondblclick", "onmousedown", "onmouseover", "onmouseout", "onmouseup", "data-*" ],
			classes: true,
			styles: true
		},
		"u":
		{
			attributes: false,
			classes: false,
			styles: false
		},
		"s":
		{
			attributes: false,
			classes: false,
			styles: false
		}
	};
	config.disallowedContent = "table[align,cellspacing,summary,bgcolor,frame,rules,width]; td[axis,abbr,scope,align,bgcolor,char,charoff,height,nowrap,valign,width]; th[axis,abbr,align,bgcolor,char,charoff,height,nowrap,valign,width]; tbody[align,char,charoff,valign]; tfoot[align,char,charoff,valign]; thead[align,char,charoff,valign]; tr[align,bgcolor,char,charoff,valign]; col[align,char,charoff,valign,width]; colgroup[align,char,charoff,valign,width]";
	config.resize_enabled = false;
	config.toolbarGroups = [
		{ name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },
		{ name: 'editing',     groups: [ 'find', 'selection', 'spellchecker' ] },
		{ name: 'links' },
		{ name: 'insert' },
		{ name: 'forms' },
		{ name: 'tools' },
		{ name: 'document',	   groups: [ 'mode', 'document', 'doctools' ] },
		{ name: 'others' },
		'/',
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] },
		{ name: 'styles' },
		{ name: 'colors' },
		{ name: 'about' }
	];

	config.toolbar = [
		{ name: 'clipboard', items: [ 'Undo', 'Redo', '-', 'Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord'  ] },
		{ name: 'links', items: [ 'Link', 'Unlink' ] },
		{ name: 'paragraph', items: [ 'NumberedList', 'BulletedList', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock' ] },
		'/',
		{ name: 'basicstyles', items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', 'FontSize' ] },
		{ name: 'colors', items: [ 'TextColor', 'BGColor' ] },
		{ name: 'styles', items: [ 'Styles' ] },
		{ name: 'plugins', items: [ 'bgswitch' ] }
	];
};
