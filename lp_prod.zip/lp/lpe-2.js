// 220213
{ // CXFld
	window.CXFld = function (oArgs)
	{
		WTBaseObject.call(this, oArgs);
		this.oDialog = oArgs.oDialog;
		this.oPage = oArgs.oPage;
		this.jBlock = oArgs.jBlock;
		this.oFld = oArgs.oFld;
		this.sLabel = oArgs.sLabel;
		this.sType = this.oFld.type;
		this.sValue = "";
		this.sPrefix = "";
		this.aChildren = [];
		this.bIgnoreEvent = false;
		this.aDynamicOptions = [];
		this.oParentFld = oArgs.oParentFld;
		this.oParentList = oArgs.oParentList;
		this.oParentItem = oArgs.oParentItem;
		this.oFolder = oArgs.oFolder;
		this.Constructor();
		return this;
	};
	CXFld.prototype = Object.create(WTBaseObject.prototype);
	CXFld.prototype.constructor = CXFld;
	CXFld.prototype._GetCollectionParamName = function (oArgs)
	{
		var i,j;
		var sName = "";
		if(oArgs.bAfterLoad==true)
		{
			if(oArgs.oData!=null)
			{
				if(oArgs.oData.error==0)
				{
					if(oArgs.oData.collections!=null)
					{
						if(Array.isArray(oArgs.oData.collections))
						{
							if(oArgs.oData.collections.length>0)
							{
								this.oPlayer.oCurrentWebModeCopy.all_collections = [];
							}
							for(i=0; i<oArgs.oData.collections.length; i++)
							{
								this.oPlayer.oCurrentWebModeCopy.all_collections.push(JSON.parse(JSON.stringify(oArgs.oData.collections[i])));
							}
						}
					}
				}
			}
		}
		if(this.oCollectionFld==null)
		{
			var sPrefix = this.oFld.name.split(".")[0];
			if(this.bCommonMappingFld)
			{
				this.oCollectionFld = this.oPage.oFlds[sPrefix + "%46collection_common" ];
			}
			else
			{
				this.oCollectionFld = this.oPage.oFlds[sPrefix + "%46__collection__" ];
			}
		}
		if(this.oCollectionFld!=null)
		{
			this.sCollectionId = this.oCollectionFld._GetValue();
			var oCollection = null;
			if(this.oPlayer.oCurrentWebModeCopy.collections != null)
			{
				for(i=0; i<this.oPlayer.oCurrentWebModeCopy.collections.length; i++)
				{
					if(this.oPlayer.oCurrentWebModeCopy.collections[i].id == this.sCollectionId)
					{
						oCollection = this.oPlayer.oCurrentWebModeCopy.collections[i];
						break;
					}
				}
			}
			if(oCollection==null)
			{
				if(this.oPlayer.oCollections != null)
				{
					oCollection = this.oPlayer.oCollections[this.sCollectionId];
					if(oCollection==null)
					{
						for(i=0; i<this.oPlayer.aCollections.length; i++)
						{
							if(this.oPlayer.aCollections[i].id == this.sCollectionId)
							{
								oCollection = this.oPlayer.aCollections[i];
								break;
							}
						}
					}
				}
				else if(this.oPlayer.oCurrentWebModeCopy.all_collections != null)
				{
					for(i=0; i<this.oPlayer.oCurrentWebModeCopy.all_collections.length; i++)
					{
						if(this.oPlayer.oCurrentWebModeCopy.all_collections[i].id == this.sCollectionId)
						{
							oCollection = this.oPlayer.oCurrentWebModeCopy.all_collections[i];
							break;
						}
					}
				}
				else
				{
					oArgs.bAfterLoad = true;
					this.Load(
					{
						sURL: this.oPlayer.oConfig.sRootAPIURL,
						sData: "action={'action':'get_collection_list','catalog_name':''}",
						oContext: this,
						fnSuccess: this.Update,
						oSuccessArgs: oArgs
					});
				}
			}
			this.oSelectedCollection = oCollection;
			if(oCollection!=null)
			{
				for(j=0; j<this.oSelectedCollection.result_fields.length; j++)
				{
					if(this.oSelectedCollection.result_fields[j].name==oArgs.sParam)
					{
						sName = this.oSelectedCollection.result_fields[j].title;
						break;
					}
				}
			}
		}
		return sName;
	};
	CXFld.prototype._GetFontControlName = function (oArgs)
	{
		var sFontControlName = "";
		var aName = this.oFld.name.split(".");
		if(this.oFld.name.indexOf("_custom")!=-1)
		{
			sFontControlName = TOOLS.EncodeVarName({ sText: this.oFld.name.split("_custom").join("") });
		}
		else
		{
			if(aName.length>=2)
			{
				if(aName[1].indexOf("font_family")!=-1)
				{
					sFontControlName = TOOLS.EncodeVarName({ sText: this.oFld.name });
				}
				else if(aName[1].indexOf("font_size")!=-1)
				{
					sFontControlName = TOOLS.EncodeVarName({ sText: this.oFld.name.split("font_size").join("font_family") });
				}
				else if(aName[1].indexOf("font_weight")!=-1)
				{
					sFontControlName = TOOLS.EncodeVarName({ sText: this.oFld.name.split("font_weight").join("font_family") });
				}
				else if(aName[1].indexOf("font_style")!=-1)
				{
					sFontControlName = TOOLS.EncodeVarName({ sText: this.oFld.name.split("font_style").join("font_family") });
				}
			}
		}
		return sFontControlName;
	};
	CXFld.prototype._GetIndex = function (oArgs)
	{
		var iIdx = -1;
		switch(this.sType)
		{
			case "object":
			case "list":
			{
				var iCnt = 0;
				for(var sKey in this.oListItems)
				{
					if(sKey==this.oControl.sValue)
					{
						iIdx = iCnt;
						break;
					}
					iCnt++;
				}
				break;
			}
		}
		return iIdx;
	};
	CXFld.prototype._GetName = function (oArgs)
	{
		var sName = "";
		switch(this.sType)
		{
			case "foreign_elem":
			{
				sName = this.jFldValue.html();
				break;
			}
		}
		return sName;
	};
	CXFld.prototype._GetValue = function (oArgs)
	{
		var sValue = "";
		switch(this.sType)
		{
			case "mapping":
			{
				sValue = this.jControl.attr("cx-value");
				break;
			}
			case "slider":
			{
				sValue = this.oControl._GetValue();
				break;
			}
			case "integer":
			case "real":
			case "spinner":
			case "dec_spinner":
			{
				try
				{
					sValue = this.jControl.spinner("value");
				}
				catch(e)
				{
					sValue = this.jControl.val();
				}
				break;
			}
			case "date":
			case "heading":
			case "string":
			case "text":
			case "foreign_elem":
			case "select_to_foreign_elem":
			case "select_to_string":
			case "color":
			case "file":
			case "edit":
			case "select":
			case "combo":
			case "hidden":
			{
				if(this.sView=="btn" || this.sView=="selectbtn")
				{
					sValue = this.oControl._GetValue();
				}
				else
				{
					sValue = this.jControl.val();
				}
				break;
			}
			case "list":
			{
				sValue = this.jControl.val().join(";");
				break;
			}
			case "textedit":
			{
				sValue = (CKEDITOR.instances[this.sUID]!=null) ? CKEDITOR.instances[this.sUID].getData() : this.jControl.html();
				break;
			}
			case "bool":
			case "check":
			{
				if(this.oControl==null)
				{
					sValue = this.jControl.is(":checked");// ? "yes" : "no";
				}
				else
				{
					sValue = this.oControl.bChecked==true;// ? "yes" : "no";
				}
				break;
			}
			case "object":
			{
				var aValue = [];
				var iIdx;
				var sKey, sKey2;
				for(sKey in this.oListItems)
				{
					if(this.oListItems[sKey].oFlds!=null)
					{
						if(Object.keys(this.oListItems[sKey].oFlds).length>0)
						{
							iIdx = aValue.push({}) - 1;
							for(sKey2 in this.oListItems[sKey].oFlds)
							{
								aValue[iIdx][sKey2] = this.oListItems[sKey].oFlds[sKey2]._GetValue();
							}
						}
					}
				}
				sValue = JSON.stringify(aValue);
				break;
			}
		}
		if(oArgs!=null)
		{
			if(oArgs.bString==true && typeof sValue != "string")
			{
				sValue = String(sValue);
			}
		}
		return sValue;
	};
	CXFld.prototype.AddListItem = function (oArgs)
	{
		var oThis = this;
		if(this.oControl!=null)
		{
			if(this.oListItems==null)
			{
				this.oListItems = {};
			}
			var sUID = (oArgs!=null && oArgs.sUID!=null) ? oArgs.sUID : TOOLS.ShortID();
			this.oListItems[sUID] =
			{
				sId: sUID,
				bOpen: true,
				oFlds: {}
			};
			this.oControl.AppendItem({ sId: sUID, bSuppressEvent: (oArgs!=null && oArgs.bSuppressEvent==true) });
			this.oListItems[sUID].jBody = this.oControl.oPages[sUID].jPage;  // must be after AppendItem

			var jBlock, jFldBlock;
			var sFldType;
			var sFldName;
			for(var i=0; i<this.oFld.entries.length; i++)
			{
				jBlock = oThis.jParamBlockTemplate.clone(true).appendTo(oThis.oListItems[sUID].jBody);
				sFldName = TOOLS.EncodeVarName({ sText: this.oFld.entries[i].id });
				sFldType = this.oFld.entries[i].type=="" ? "string" : this.oFld.entries[i].type;
				if(sFldName.indexOf(".rtf_")!=-1)
				{
					sFldType = "textedit";
				}
				if(sFldName.indexOf(".color")!=-1)
				{
					sFldType = "color";
				}
				this.oListItems[sUID].oFlds[sFldName] = ( new CXFld({ oPlayer: oThis.oPlayer, oDialog: oThis.oDialog, oPage: oThis, bFromTemplate: true, jBlock: jBlock, oFld: this.oFld.entries[i], oParentList: oThis, oParentItem: oThis.oListItems[sUID] }) );
				if(sFldName.indexOf("column_size")!=-1)
				{
					this.oListItems[sUID].oFlds[sFldName].SetValue({ sValue: 50 });
				}
				this.oListItems[sUID].oFlds[sFldName].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: this.oFld.name } });
			}
			if(oArgs!=null && oArgs.bUserAction==true)
			{
				this.FireEvent({ sEvent: "list_item_appended", oArgs: { iNewItem: Object.keys(this.oListItems).length } });
			}
		}
		return this;
	};
	CXFld.prototype.ClearList = function (oArgs)
	{
		var oThis = this;
		for(var sKey in this.oListItems)
		{
			delete this.oListItems[sKey];
		}
		this.oListItems = {};
		if(this.oControl!=null)
		{
			this.oControl.Reset();
		}
		return this;
	};
	CXFld.prototype.CollapseListItem = function (oArgs)
	{
		var oThis = this;
		this.oListItems[oArgs.sId].jItem.attr({ "cx-state": "idle" });
		this.oListItems[oArgs.sId].jBody.slideUp("fast", function () { oThis.oListItems[oArgs.sId].bOpen = false; });
		return oThis;
	};
	CXFld.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		var i;
		this.sPrefix = this.sId.split(".")[0];
		if(this.sType=="")
		{
			this.sType = "string";
		}
		if(this.oFld.name.indexOf(".__PARAM_SET__")!=-1)
		{
			this.sType = "select_to_string";
			this.bParamSet = true;
		}
		if(this.oDialog.oObject!=null)
		{
			if(this.oDialog.oObject.bUseFontControl && this.oFld.name.indexOf("font_")!=-1 && this.oFld.name.indexOf("_shadow")==-1 && this.oFld.name.indexOf("color")==-1) // font parameters, except color and text shadow
			{
				var sFontControlName = this._GetFontControlName();
				if(sFontControlName!="")
				{
					var aName = this.oFld.name.split(".");
					this.bFontFld = true;
					if(this.oPage.oFontControls[sFontControlName]!=null)
					{
						if(this.oFld.name.indexOf("_custom")!=-1)
						{
							this.oPage.oFontControls[sFontControlName].oLinkedFlds["font-family-custom"] =  this;
							this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-family-custom", sValue: this.oFld.value, bSet: true });
							this.jControl = this.oPage.oFontControls[sFontControlName].jFontFamilyCustomValue;
						}
						else
						{
							if(aName.length>=2)
							{
								this.sType = "string";
								if(aName[1].indexOf("font_family")!=-1)
								{
									this.oPage.oFontControls[sFontControlName].oLinkedFlds["font-family"] =  this;
									this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-family", sValue: this.oFld.value, bSet: true });
									this.jControl = this.oPage.oFontControls[sFontControlName].jFontFamilyValue;
								}
								else if(aName[1].indexOf("font_size")!=-1)
								{
									this.oPage.oFontControls[sFontControlName].oLinkedFlds["font-size"] =  this;
									this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-size", sValue: this.oFld.value, bSet: true });
									this.jControl = this.oPage.oFontControls[sFontControlName].jFontSizeValue;
								}
								else if(aName[1].indexOf("font_weight")!=-1)
								{
									this.oPage.oFontControls[sFontControlName].oLinkedFlds["font-weight"] =  this;
									this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-weight", sValue: this.oFld.value, bSet: true });
									this.jControl = this.oPage.oFontControls[sFontControlName].jFontWeightValue;
								}
								else if(aName[1].indexOf("font_style")!=-1)
								{
									this.oPage.oFontControls[sFontControlName].oLinkedFlds["font-style"] =  this;
									this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-style", sValue: this.oFld.value, bSet: true });
									this.jControl = this.oPage.oFontControls[sFontControlName].jFontStyleValue;
								}
							}
						}
						return this;
					}
				}
			}
		}
		if(this.oFld.name.indexOf(".color")!=-1)
		{
			this.sType = "color";
		}
		if(this.oFld.name.indexOf(".__service__")!=-1)
		{
			this.sType = "hidden";
			this.oFld.bService = true;
			/*if(this.oFld.name.indexOf(".__service__collection_params")!=-1)
			{
				this.oDialog.oServiceFlds["collection_params"] = this;
				this.oFld.sServiceType = "collection_params";
			}
			else if(this.oFld.name.indexOf(".__service__common_collection_params")!=-1)
			{
				this.oDialog.oServiceFlds["common_collection_params"] = this;
				this.oFld.sServiceType = "common_collection_params";
			}
			else*/ if(this.oFld.name.indexOf(".__service__remote_action_params")!=-1)
			{
				this.oDialog.oServiceFlds["remote_action_params"] = this;
				this.oFld.sServiceType = "remote_action_params";
			}
			else if(this.oFld.name.indexOf(".__service__common_remote_action_params")!=-1)
			{
				this.oDialog.oServiceFlds["common_remote_action_params"] = this;
				this.oFld.sServiceType = "common_remote_action_params";
			}
		}
		this.bActionFld = (this.oFld.name.indexOf(".__remote_action__")!=-1 && this.sType=="foreign_elem");
		this.bCommonActionFld = (this.oFld.name.indexOf(".remote_action_common")!=-1 && this.sType=="foreign_elem");
		this.bMultipleActionsFld = (this.oFld.name.indexOf(".__remote_actions__")!=-1 && this.sType=="object");
		this.bActionItemFld = (this.oFld.id!=null && this.oFld.id.indexOf("__remote_action_item_id__")!=-1 && this.sType=="foreign_elem");
		this.bActionItemParams = (this.oFld.id!=null && this.oFld.id.indexOf("__remote_action_item_params__")!=-1 && this.sType=="text");
		this.bCollectionTypeSelector = (this.oFld.name.indexOf(".collection_type")!=-1 && this.sType=="combo");
		this.bCollectionFld = (this.oFld.name.indexOf(".__collection__")!=-1 && this.sType=="foreign_elem");
		this.bCommonCollectionFld = (this.oFld.name.indexOf(".collection_common")!=-1 && this.sType=="foreign_elem");
		this.bMappingFld = (this.oFld.name.indexOf(".__mapping__")!=-1 && this.sType=="string");
		this.bCommonMappingFld = this.bMappingFld && (this.oFld.name.indexOf("_common")!=-1);
		this.bMappingFldValue = (this.bMappingFld && this.oFld.name.indexOf("__value")!=-1);
		if(this.oFld.name.indexOf("__mapping__value")!=-1 && this.oFld.name.indexOf("__value__value")==-1 && this.oFld.name.indexOf("__value_common__value")==-1)
		{
			this.bMappingFldValue = false;
		}
		if(this.bCollectionTypeSelector)
		{
			this.Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oPage, fn: this.oPage.UpdateCollection, oArgs: { bFldModified: true, sFldName: this.oFld.name } });
		}
		if(this.bCommonCollectionFld)
		{
			this.bDynamicFill = true;
			this.Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oPage, fn: this.oPage.UpdateCollectionParams, oArgs: { bFldModified: true, sFldName: this.oFld.name } });
		}
		if(this.bActionFld || this.bCommonActionFld || this.bCollectionFld)
		{
			this.bDynamicFill = true;
			this.Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oPage, fn: this.oPage.UpdateDynamic, oArgs: { bFldModified: true, sFldName: this.oFld.name } });
		}
		if(this.bActionItemFld)
		{
			this.bDynamicFill = true;
			this.Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oPage, fn: this.oPage.oPage.UpdateDynamic, oArgs: { bFldModified: true, sFldName: this.oFld.id } });
		}
/*		if(this.bActionItemParams)
		{
			this.Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oPage, fn: this.oPage.UpdateActionItem, oArgs: { bFldModified: true, sFldName: this.oFld.name } });
		}*/
		if(this.bMappingFld)
		{
			this.sType = "mapping";
			if(this.oFolder!=null)
			{
				if(this.oFolder.bMappingFolder)
				{
					if(this.bMappingFldValue)
					{
						this.oFolder.oMappingValueFlds[this.oFld.name] = this.oFld;
						this.oFolder.aMappingValueFlds.push(this.oFolder.oMappingValueFlds[this.oFld.name]);
						this.sParentFldName = this.oFld.name.substring(0, this.oFld.name.lastIndexOf("__value"));
						this.jFldBlock = this.oPage.oFlds[ TOOLS.EncodeVarName({ sText: this.sParentFldName }) ].jFldBlock;
					}
					else
					{
						this.oFolder.oMappingFlds[this.oFld.name] = this.oFld;
						this.oFolder.aMappingFlds.push(this.oFolder.oMappingFlds[this.oFld.name]);
					}
				}
			}
		}
		if(this.oFld.name.indexOf(".rtf_")!=-1)
		{
			this.sType = "textedit";
		}
		if(this.oFld.id!=null)
		{
			if(this.oFld.id.indexOf(".rtf_")!=-1)
			{
				this.sType = "textedit";
			}
			if(this.oFld.id.indexOf(".color")!=-1)
			{
				this.sType = "color";
			}
		}
		this.sUID = TOOLS.ShortID();
		this.jParamBlockTemplate = this.oPlayer.jStorage.find("[cx-template='param-block']");
		if(!this.bMappingFldValue)
		{
			var jTemplate = this.bParamSet ? this.oPlayer.jStorage.find("[cx-template='fld-block-paramset']") : this.oPlayer.jStorage.find("[cx-template='fld-block-" + this.sType + "']");
			this.jFldBlock = jTemplate.clone(true).removeAttr("cx-template").appendTo(this.jBlock);
			this.jLabel = this.jFldBlock.find("[cx-role='label-text']");
			if(this.sLabel==null || this.sLabel=="" || this.sLabel==this.oFld.name)
			{
				this.sLabel = (this.oFld.description!=null && this.oFld.description!="") ? this.oFld.description : this.oFld.name;
			}
			if(this.sLabel.indexOf("--")!=-1)
			{
				var aParts = this.sLabel.split("--");
				if(aParts.length==2)
				{
					this.sLabel = aParts[0];
					this.sTitle = $.trim(aParts[1]);
				}
				else if(aParts.length>2)
				{
					this.sLabel = $.trim(aParts.shift());
					this.sTitle = $.trim(aParts.join("--"));
				}
				else
				{
					this.sTitle = this.sLabel;
				}
			}
			else
			{
				this.sTitle = this.sLabel;
			}
			this.jLabel.attr({ "title": this.sTitle }).html(this.sLabel);
			this.jFldBlock.attr({ "title": this.sTitle });
		}
		switch(this.sType)
		{
			case "mapping":
			{
				if(!this.bMappingFldValue)
				{
					this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").attr({ "cx-value": this.oFld.value });
					switch(this.oFld.value)
					{
						case "__substitution__":
						{
							this.jFldBlock.find("[cx-role='obj-fld-value']").show();
							this.jControl.html("").hide();
							break;
						}
						case "":
						{
							this.jFldBlock.find("[cx-role='obj-fld-value']").hide();
							this.jControl.html("").show();
							break;
						}
						default:
						{
							this.jFldBlock.find("[cx-role='obj-fld-value']").hide();
							this.jControl.html( this._GetCollectionParamName({ sParam: this.oFld.value }) ).show();
							break;
						}
					}
				}
				else
				{
					this.jControl = this.jFldBlock.find("[cx-role='obj-fld-value']").attr({ "cx-value": this.oFld.value }).html(this.oFld.value);
				}
				break;
			}
			case "integer":
			/*case "spinner":*/
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").val(this.oFld.value);
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").spinner(
				{
					step: 1,
					numberFormat: "n",
					change: function (e)
					{
						oThis.UIEvent({ oElem: this, oEvt: e, oThis: oThis });
					},
					stop: function (e)
					{
						oThis.UIEvent({ oElem: this, oEvt: e, oThis: oThis });
					}
				});
				break;
			}
			/*case "dec_spinner":*/
			case "real":
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").spinner(
				{
					step: 0.1,
					numberFormat: "n",
					change: function (e)
					{
						oThis.UIEvent({ oElem: this, oEvt: e, oThis: oThis });
					},
					stop: function (e)
					{
						oThis.UIEvent({ oElem: this, oEvt: e, oThis: oThis });
					}
				});
				break;
			}
			case "date":
			case "heading":
			case "string":
			case "text":
			case "":
			/*case "edit":*/
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").val(this.oFld.value);
				this.jControl.on("keyup change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				if(this.bActionItemParams)
				{
					this.jControl.on("blur", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				}
				break;
			}
			case "hidden":
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").val(this.oFld.value);
				this.jBlock.hide();
				break;
			}
			case "file":
			case "resource":
			{
				this.jBtn = this.jFldBlock.find("[cx-role='file-fld-btn']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				this.jClearBtn = this.jFldBlock.find("[cx-role='btn-clear-img-fld']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				this.jFldEmpty = this.jFldBlock.find("[cx-role='file-empty']");
				this.jFldValue = this.jFldBlock.find("[cx-role='file-value']");
				this.jFldPreview = this.jFldBlock.find("[cx-role='file-preview']");
				this.jFldFileName = this.jFldBlock.find("[cx-role='file-name']");
				this.jControl = this.jFldBlock.find("[cx-role='param-fld']");
				this.jControl.on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				break;
			}
			case "foreign_elem":
			{
				this.bFEMultiple = (this.oFld.value!=null && this.oFld.value.indexOf("[")==0 && this.oFld.value.indexOf("]")==this.oFld.value.length-1);
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").val(this.oFld.value);
				this.jBtn = this.jFldBlock.find("[cx-role='btn-foreign_elem']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				if(this.bFEMultiple)
				{
					this.jListContainer = this.jFldBlock.find("[cx-role='list-container']");
					this.jList = this.jListContainer.find("[cx-role='list']");
					this.jItemTemplate = this.jFldBlock.find("ul[cx-role='fe-storage'] > li[cx-role='list-item']");
					this.jFldBlock.attr({ "wt-multiple": "1" });
					this.jFldBlock.find("[cx-role='btn-fe-delete']").remove();
				}
				else
				{
					this.jBtnDelete = this.jFldBlock.find("[cx-role='btn-fe-delete']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
					this.jFldValue = this.jFldBlock.find("[cx-role='btn-foreign_elem']");
					this.jFldBlock.find("[cx-role='list-container'], [cx-role='fe-storage']").remove();
				}
				break;
			}
			case "textedit":
			{
				this.jControl = this.jFldBlock.find("[cx-role='textedit-fld']").attr({ "id": this.sUID, "contenteditable": true });
				CKEDITOR.inline( oThis.sUID,
				{
					extraAllowedContent: "a(documentation);abbr[title];code",
					removePlugins: "stylescombo",
					extraPlugins: "cl_bgswitch",
					startupFocus: false,
					fontSize_sizes: this.oPlayer.sRTEFontSizes,
					fontSize_defaultLabel: "Normal",
					colorButton_colors: "001F3F,0074D9,7FDBFF,39CCCC,3D9970,2ECC40,01FF70,FFDC00,FF851B,FF4136,85144B,F012BE,B10DC9,111111,AAAAAA,DDDDDD,FFFFFF"
				});
				CKEDITOR.on("instanceReady", function(oEvt)
				{
					if(oThis.sUID==oEvt.editor.name)
					{
						oEvt.editor.on("change", function (oEvent) { oThis.sValue = oEvent.editor.getData(); oThis.UIEvent.call(oThis, { oElem: this, oEvt: { type: "change" }, oThis: oThis }); });
						oEvt.editor.on("paste", function (oEvent) { oEvent.data.dataValue = TOOLS._Hyphenate({ sText: oEvent.data.dataValue }); });
						oEvt.editor.element.$.onblur = function (oEvent) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: { type: "blur" }, oThis: oThis }); return true; };
					}
				});
				break;
			}
			case "select":
			case "combo":
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']");
				if(this.bParamSet==true)
				{

				}
				else
				{
					for(i=0; i<this.oFld.entries.length; i++)
					{
						this.jControl.append('<option value="' + this.oFld.entries[i].id + '">' + this.oFld.entries[i].name + '</option>');
					}
				}
				this.jControl.on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				break;
			}
			case "list":
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']");
				if(this.bParamSet==true)
				{

				}
				else
				{
					for(i=0; i<this.oFld.entries.length; i++)
					{
						this.jControl.append('<option value="' + this.oFld.entries[i].id + '">' + this.oFld.entries[i].name + '</option>');
					}
				}
				this.jControl.on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				break;
			}
			case "select_to_foreign_elem":
			case "select_to_string":
			{
				this.jControl = this.jFldBlock.find("[cx-role='obj-fld']").on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				if(this.bParamSet)
				{
					this.oObject = this.oDialog.oObject;
					this.sObjectId = this.oDialog.oObject.id;
					this.jBtnCopy = this.jFldBlock.find("[cx-role='btn-copy-params']").prop("disabled", true).on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
				}
				break;
			}
			case "bool":
			{
				this.oControl = new CXCheckBox({ oPlayer: this.oPlayer, sName: this.sUID, jBox: this.jFldBlock }) ;
				this.oControl.Subscribe({ sId: this.sUID, sEvent: "change", fn: oThis.UIEvent, oContext: oThis, oArgs: { oElem: oThis, oThis: oThis, oEvt: { type: "change" } } });
				break;
			}
			case "object":
			{
				this.oControl = new CXParamList({ oPlayer: this.oPlayer, jStorage: this.oPlayer.jStorage, sType: "list", jBlock: this.jFldBlock, sId: this.sUID, bMultipleActionsFld: this.bMultipleActionsFld });
				this.oControl.Subscribe(
				{
					sId: this.sUID,
					sEvent: "appendrequest",
					fn: oThis.UIEvent,
					oContext: oThis,
					oArgs:
					{
						oElem: oThis,
						oThis: oThis,
						oEvt: { type: "appendrequest" }
					}
				});
				this.oControl.Subscribe(
				{
					sId: this.sUID,
					sEvent: "deleterequest",
					fn: oThis.UIEvent,
					oContext: oThis,
					oArgs:
					{
						oElem: oThis,
						oThis: oThis,
						oEvt: { type: "deleterequest" }
					}
				});
				this.oControl.Subscribe(
				{
					sId: this.sUID,
					sEvent: "change",
					fn: oThis.UIEvent,
					oContext: oThis,
					oArgs:
					{
						oElem: oThis,
						oThis: oThis,
						oEvt: { type: "change" }
					}
				});
				this.oControl.Subscribe(
				{
					sId: this.sUID,
					sEvent: "select",
					fn: oThis.UIEvent,
					oContext: oThis,
					oArgs:
					{
						oElem: oThis,
						oThis: oThis,
						oEvt: { type: "select" }
					}
				});
				this.oControl.Subscribe(
				{
					sId: this.sUID,
					sEvent: "reorder",
					fn: oThis.UIEvent,
					oContext: oThis,
					oArgs:
					{
						oElem: oThis,
						oThis: oThis,
						oEvt: { type: "reorder" }
					}
				});
				this.oFlds = {};
				this.oLabels = {};
				break;
			}
			case "color":
			{
				this.jControl = this.jFldBlock.find("[cx-role='param-fld']");
				this.jSample = this.jFldBlock.find("[cx-role='color-sample']");
				this.jControl.on("keyup change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); }).colorpicker({ showOn: "focus", hideButton: true, strings: oThis.oPlayer.sColorPickerConst });
				break;
			}
		}
		if(this.jControl!=null && this.oFld.classes!=null)
		{
			if(Array.isArray(this.oFld.classes))
			{
				this.jControl.addClass(this.oFld.classes.join(" "));
			}
		}
		return this;
	};
	CXFld.prototype.CopyParamSetValues = function (oArgs)
	{
		if(this.sValue!="custom")
		{
			if(this.oPlayer.oStore["web_designs"]!=null)
			{
				if(this.oPlayer.oCurrentWebModeCopy.web_design_id!="")
				{
					var oDesign = this.oPlayer.oStore["web_designs"].oData[this.oPlayer.oCurrentWebModeCopy.web_design_id];
					if(oDesign!=null)
					{
						if(oDesign.paramsets!=null)
						{
							if(oDesign.paramsets[this.sPrefix]!=null)
							{
								if(Object.keys(oDesign.paramsets[this.sPrefix]).length>0)
								{
									var sKey, sParam, sVarName;
									for(sKey in oDesign.paramsets[this.sPrefix])
									{
										if(sKey==this._GetValue())
										{
											if(oDesign.paramsets[this.sPrefix][sKey].params!=null)
											{
												for(sParam in oDesign.paramsets[this.sPrefix][sKey].params)
												{
													sVarName = TOOLS.EncodeVarName({ sText: (this.sPrefix + "." + sParam) });
													if(this.oPage.oFlds[sVarName]!=null)
													{
														this.oPage.oFlds[sVarName].SetValue({ sValue: oDesign.paramsets[this.sPrefix][sKey].params[sParam] });
													}
												}
											}
											this.SetValue({ sValue: "custom" }).FireEvent({ sEvent: "modified" });
											break;
										}
									}
								}
							}
						}
					}
				}
			}

		}
		return this;
	};
	CXFld.prototype.Delete = function (oArgs)
	{
		if(this.oControl!=null)
		{
			delete this.oControl;
			this.oControl = null;
		}
		this.jFldBlock.remove();
		return this;
	};
	CXFld.prototype.DeleteListItem = function (oArgs)
	{
		if(oArgs.sId!=null)
		{
			if(this.oControl!=null)
			{
				var iCnt = -1;
				for(var sKey in this.oListItems)
				{
					iCnt++;
					if(sKey==oArgs.sId)
					{
						break;
					}
				}
				this.oControl.DeleteItem({ sId: oArgs.sId });
				delete this.oListItems[oArgs.sId];
				if(iCnt!=-1 && oArgs.bUserAction==true)
				{
					this.FireEvent({ sEvent: "list_item_deleted", oArgs: { iDeletedItem: iCnt } });
				}
			}
			else if(this.oListItems[oArgs.sId]!=null)
			{
				this.oListItems[oArgs.sId].jItem.remove();
				delete this.oListItems[oArgs.sId];
				this.EnumerateList();
				this.oPlayer.oCurrentSlide.UpdateParams({ oDialog: this.oDialog, oFld: this });
			}
		}
		return this;
	};
	CXFld.prototype.Disable = function (oArgs)
	{
		switch(this.sType)
		{
			case "file":
			{
				break;
			}
			case "edit":
			case "check":
			case "spinner":
			case "dec_spinner":
			case "select":
			case "text":
			case "foreign_elem":
			case "hidden":
			{
				this.jControl.prop("disabled", true);
				break;
			}
			case "textedit":
			{
				this.jControl.removeAttr("contenteditable");
				try
				{
					CKEDITOR.instances[this.sUID].destroy();
				}
				catch(e)
				{
					window.console.log(this.sId + " " + e);
				}
				break;
			}
			case "select":
			case "combo":
			case "select_to_foreign_elem":
			case "select_to_string":
			{
				this.jControl.prop("disable", true);
				break;
			}
		}
		this.bDisabled = true;
		return this;
	};
	CXFld.prototype.Enable = function (oArgs)
	{
		var oThis = this;
		switch(this.sType)
		{
			case "file":
			{
				break;
			}
			case "edit":
			case "check":
			case "spinner":
			case "dec_spinner":
			case "select":
			case "text":
			case "foreign_elem":
			case "hidden":
			{
				this.jControl.prop("disabled", false);
				break;
			}
			case "textedit":
			{
				this.jControl.attr({ "contenteditable": true });
				try
				{
					CKEDITOR.inline( this.sUID,
					{
						extraAllowedContent: "a(documentation);abbr[title];code",
						removePlugins: "stylescombo",
						extraPlugins: "cl_bgswitch",
						startupFocus: false,
						fontSize_sizes: (this.oPlayer.oCurrentModule!=null) ? this.oPlayer.oCurrentModule.sRTEFontSizes : this.oPlayer.sRTEFontSizes,
						fontSize_defaultLabel: this.oPlayer.sRTEFontSizeDefault,
						colorButton_colors: (this.oPlayer.oCurrentModule!=null) ? this.oPlayer.oCurrentModule.sRTEColorString : this.oPlayer.sRTEColorString
					});
					CKEDITOR.on("instanceReady", function(oEvt)
					{
						if(oThis.sUID==oEvt.editor.name)
						{
							oEvt.editor.on("change", function (oEvent) { oThis.sValue = oEvent.editor.getData(); oThis.UIEvent.call(oThis, { oElem: this, oEvt: { type: "change" }, oThis: oThis }); });
							oEvt.editor.on("paste", function (oEvent) { oEvent.data.dataValue = TOOLS._Hyphenate({ sText: oEvent.data.dataValue }); });
							oEvt.editor.element.$.onblur = function (oEvent) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: { type: "blur" }, oThis: oThis }); return true; };
						}
					});
				}
				catch(e)
				{
					window.console.log("RTE Enable " + e);
				}
				break;
			}
			case "select":
			case "combo":
			case "select_to_foreign_elem":
			case "select_to_string":
			{
				this.jControl.prop("disable", false);
				break;
			}
		}
		this.bDisabled = false;
		return this;
	};
	CXFld.prototype.EnumerateList = function (oArgs)
	{
		var jItems = this.jFldList.children();
		var sId;
		for(var i=1; i<=jItems.length; i++)
		{
			sId = jItems[i-1].getAttribute("cx-id");
			this.oListItems[sId].jNumber.html(i);
		}
		return this;
	};
	CXFld.prototype.ExpandListItem = function (oArgs)
	{
		var oThis = this;
		this.iCurItem = 0;
		var iCnt = 0;
		for(var sKey in this.oListItems)
		{
			if(this.oListItems.hasOwnProperty(sKey))
			{
				iCnt++;
				if(this.oListItems[sKey].bOpen)
				{
					this.CollapseListItem({ sId: sKey});
				}
				if(sKey==oArgs.sId)
				{
					this.iCurItem = iCnt;
				}
			}
		}
		this.oListItems[oArgs.sId].jItem.attr({ "cx-state": "active" });
		this.oListItems[oArgs.sId].jBody.slideDown("fast", function () { oThis.oListItems[oArgs.sId].bOpen = true; });
		if(this.xLayoutFld.constructor === Object)
		{
			if(this.xLayoutFld.list!=null)
			{
				var sFldId;
				for(var i=0; i<this.xLayoutFld.list.length; i++)
				{
					sFldId = this.oDialog.oObject.sTemplate + "_" + this.xLayoutFld.list[i].ref;
					if(this.xLayoutFld.list[i].type=="quick")
					{
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.Show().SetValue({ sValue: this.oListItems[oArgs.sId].oFlds[this.xLayoutFld.list[i].ref].sValue });
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oCurrentListItem = this.oListItems[oArgs.sId];
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oParentList = oThis;
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oParentItem = this.oListItems[oArgs.sId];
					}
				}
			}
		}
		oThis.oPlayer.oCurrentSlide.UpdateParams({ oDialog: oThis.oDialog, oFld: oThis, iCurrentItem: this.iCurItem });
		return oThis;
	};
	CXFld.prototype.FillParamSets = function (oArgs)
	{
		this.jControl.find("option[value!='custom']").remove();
		this.bParamSetsAvailable = false;
		if(this.oPlayer.oStore["web_designs"]!=null)
		{
			if(this.oPlayer.oCurrentWebModeCopy.web_design_id!="")
			{
				var oDesign = this.oPlayer.oStore["web_designs"].oData[this.oPlayer.oCurrentWebModeCopy.web_design_id];
				if(oDesign!=null)
				{
					if(oDesign.paramsets!=null)
					{
						if(oDesign.paramsets[this.sPrefix]!=null)
						{
							if(Object.keys(oDesign.paramsets[this.sPrefix]).length>0)
							{
								this.bParamSetsAvailable = true;
								for(var sKey in oDesign.paramsets[this.sPrefix])
								{
									this.jControl.append('<option value="' + sKey + '">' + oDesign.paramsets[this.sPrefix][sKey].name + '</option>');
								}
							}
						}
					}
				}
			}
		}
		return this;
	};
	CXFld.prototype.FillList = function (oArgs)
	{
		var oThis = this;
		var sKey;
		var i;
		for(sKey in oThis.oListItems)
		{
			if(oThis.oListItems.hasOwnProperty(sKey))
			{
				delete oThis.oListItems[sKey];
			}
		}
		if(this.oControl!=null)
		{
			this.oControl.Reset();
		}
		oThis.oListItems = {};
		var sUID;
		var aUIDs = [];
		for(i=0; i<oArgs.aParams.length; i++)
		{
			sUID = TOOLS.ShortID();
			aUIDs.push(sUID);
			oThis.AddListItem({ sUID: sUID, bSuppressEvent: (oArgs.bSuppressEvent==true) });
			for(sKey in oArgs.aParams[i])
			{
				if(this.oListItems[sUID].oFlds[sKey]!=null)
				{
					this.oListItems[sUID].oFlds[sKey].SetValue({ sValue: oArgs.aParams[i][sKey], bSuppressEvent: (oArgs.bSuppressEvent==true) });
				}
			}
		}
		var sIndexFld = this.oFld.name.split(".")[0] + ".__service__selected_item";
		for(i=0; i<this.oDialog.oCurrentOWT.params.length; i++)
		{
			if(this.oDialog.oCurrentOWT.params[i].name==sIndexFld)
			{
				var iValue = parseInt(this.oDialog.oCurrentOWT.params[i].value, 10);
				if(!isNaN(iValue))
				{
					if(iValue>=0 && iValue<aUIDs.length)
					{
						this.oControl.SetValue({ sValue: aUIDs[iValue] });
					}
				}
				break;
			}
		}
		return this;
	};
	CXFld.prototype.GetForeignElemName = function (oArgs)
	{
		var oThis = this;
		this.Load({ sURL: TOOLS.AppendURLParams({ sURL: oThis.oPlayer.oConfig.sRootAPIURL, sParams: ("secid=" + oThis.oPlayer.sSecId) }), sData: "action={'action':'get_web_mode','web_mode_id':'" + this.sCurrentPageId + "','session_token':'" + this.oPlayer.sSessionToken + "'}", oContext: oThis.oPlayer.oPages["desktop"], fnSuccess: oThis.oPlayer.oPages["desktop"].Editor, oSuccessArgs: {} });
		$.ajax(
		{
			type: "POST",
			url: sURL,
			async: true,
			data: sData,
			dataType: "json"
		}).done(function(oData, sStatus, jqXHR)
		{
			if(typeof oData != "object")
			{
				oData = JSON.parse(oData);
			}
			if(oData.error != 0 || oData.name==null)
			{
				oThis.jFldValue.html(oArgs.sId);
			}
			else
			{
				oThis.jFldValue.html(oData.name);
			}
			return true;
		});
		return this;
	};
	CXFld.prototype.Hide = function (oArgs)
	{
		if(this.sType!="hidden" && !this.bFontFld)
		{
			var jTarget = this.jFldBlock;
			if(this.jFldBlock.siblings().length==0)
			{
				jTarget = this.jFldBlock.parent();
			}
			else
			{
				//jTarget = this.jBlock;
			}
			if(oArgs!=null && oArgs.bTransition==true)
			{
				jTarget.slideUp(250);
			}
			else
			{
				jTarget.hide();
			}
		}
		return this;
	};
	CXFld.prototype.Link = function (oArgs)
	{
		return this;
	};
	CXFld.prototype.SelectListItem = function (oArgs)
	{
		var oThis = this;
		var iCurItem = 0;
		var iCnt = 0;
		var i;
		for(i=0; i<this.oControl.aPages.length; i++)
		{
			if(this.oControl.aPages[i].sId==this.oControl.sValue)
			{
				iCnt = i+1;
				break;
			}
		}
		this.oListItems[oArgs.sId].jItem.attr({ "cx-state": "active" });
		this.oListItems[oArgs.sId].jBody.slideDown("fast", function () { oThis.oListItems[oArgs.sId].bOpen = true; });
		if(this.xLayoutFld.constructor === Object)
		{
			if(this.xLayoutFld.list!=null)
			{
				var sFldId;
				for(i=0; i<this.xLayoutFld.list.length; i++)
				{
					sFldId = this.oDialog.oObject.sTemplate + "_" + this.xLayoutFld.list[i].ref;
					if(this.xLayoutFld.list[i].type=="quick")
					{
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.Show().SetValue({ sValue: this.oListItems[oArgs.sId].oFlds[this.xLayoutFld.list[i].ref].sValue });
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oCurrentListItem = this.oListItems[oArgs.sId];
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oParentList = oThis;
						this.oDialog.oPage.oQuickParams.oFlds[sFldId].oFld.oParentItem = this.oListItems[oArgs.sId];
					}
				}
			}
		}
		oThis.oPlayer.oCurrentSlide.UpdateParams({ oDialog: oThis.oDialog, oFld: oThis, iCurrentItem: iCurItem });
		return oThis;
	};
	CXFld.prototype.SetFEName = function (oArgs)
	{
		if(oArgs.oData!=null)
		{
			if(oArgs.oData.error==0)
			{
				if(oArgs.oData.name!=null)
				{
					this.jFldValue.html(oArgs.oData.name);
				}
				else
				{
					this.jFldValue.html(this.jControl.val());
				}
			}
			else
			{
				this.jFldValue.html(this.jControl.val());
			}
		}
		else
		{
			this.jFldValue.html(this.jControl.val());
		}
		return this;
	};
	CXFld.prototype.SetName = function (oArgs)
	{
		var oThis = this;
		var sId = (oArgs.sValue==null) ? (oArgs.aValues!=null ? oArgs.aValues.join(";") : "") : oArgs.sValue;
		$.ajax(
		{
			type: "POST",
			url: TOOLS.AppendURLParams({ sURL: oThis.oPlayer.oConfig.sRootAPIURL, sParams: ("secid=" + oThis.oPlayer.sSecId) }),
			async: true,
			data: "action={'action':'get_fe_name','fe_id':'" + sId + "','session_token':'" + this.oPlayer.sSessionToken + "','multiple':" + (oThis.bFEMultiple ? "1" : "0") + "}",
			dataType: "json"
		}).done(function (oData, sStatus, jqXHR)
		{
			if(typeof oData != "object")
			{
				oData = JSON.parse(oData);
			}
			if(typeof oData != "object")
			{
				alert("GetFE Invalid response");
				return false;
			}
			if(oData.error!=0)
			{
				if(oData.error_text!=null)
				{
					alert("GetFE Error returned: " + oData.error_text);
				}
				else
				{
					alert("GetFE Unknown error: " + oData.error);
				}
				return false;
			}
			if(oArgs.aValues!=null)
			{
				oThis.SetValue({ sValue: oData.values.join(";"), sName: oData.names.join("|||"), bSuppressEvent: true });
			}
			else
			{
				oArgs.jTarget.html(oData.name);
			}
			return true;
		}).fail(function (jqXHR, sStatus, sError)
		{
			alert("Get FE name send error: " + sError);
			return false;
		}).always(function () {});
		return this;
	};
	CXFld.prototype.SetValue = function (oArgs)
	{
		var oThis = this;
		var i;
		if(this.bFontFld)
		{
			var sFontControlName = this._GetFontControlName();
			if(sFontControlName!="")
			{
				var aName = this.oFld.name.split(".");
				if(this.oPage.oFontControls[sFontControlName]!=null)
				{
					if(this.oFld.name.indexOf("_custom")!=-1)
					{
						this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-family-custom", sValue: oArgs.sValue, bSet: true });
					}
					else
					{
						if(aName.length>=2)
						{
							if(aName[1].indexOf("font_family")!=-1)
							{
								this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-family", sValue: oArgs.sValue, bSet: true });
							}
							else if(aName[1].indexOf("font_size")!=-1)
							{
								this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-size", sValue: oArgs.sValue, bSet: true });
							}
							else if(aName[1].indexOf("font_weight")!=-1)
							{
								this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-weight", sValue: oArgs.sValue, bSet: true });
							}
							else if(aName[1].indexOf("font_style")!=-1)
							{
								this.oPage.oFontControls[sFontControlName].SetValue({ sFld: "font-style", sValue: oArgs.sValue, bSet: true });
							}
						}
					}
				}
			}
			return this;
		}
		if(/*this.sType=="list" || */this.sType=="object")
		{
			if(oArgs.sValue!="")
			{
				var aParams = JSON.parse(oArgs.sValue);
				if(oArgs.bDefault!=true)
				{
					if(this.oControl!=null)
					{
						this.oControl.Reset();
					}
					else
					{
						for(var sKey in this.oListItems)
						{
							if(this.oListItems.hasOwnPrpoperty(sKey))
							{
								this.oListItems[sKey].jItem.remove();
								delete this.oListItems[sKey];
							}
						}
					}
					this.FillList({ aParams: aParams, bSuppressEvent: (oArgs.bSuppressEvent==true) });
				}
			}
			else
			{
				this.ClearList();
			}
			return this;
		}
		var sValue = oArgs.sValue;
		if(sValue==null && oArgs.bDefault==true)
		{
			sValue = this.xFld.getAttribute("def");
		}
		switch(this.sType)
		{
			case "mapping":
			{
				if(!this.bMappingFldValue)
				{
					if(sValue=="__substitution__")
					{
						this.jFldBlock.find("[cx-role='obj-fld-value']").show();
						this.jControl.attr({ "cx-value": sValue }).html("").hide();
					}
					else
					{
						if(sValue!="")
						{
							if(oArgs.sName==null)
							{
								this.jControl.attr({ "cx-value": sValue }).html(this._GetCollectionParamName({ sParam: sValue }));
							}
							else
							{
								this.jControl.attr({ "cx-value": sValue }).html(oArgs.sName);
							}
						}
						else
						{
							this.jControl.attr({ "cx-value": "" }).html(sValue);
						}
						this.jFldBlock.find("[cx-role='obj-fld-value']").hide();
						this.jControl.show();
					}
				}
				else
				{
					this.jControl.attr({ "cx-value": sValue }).html(sValue);
				}
				break;
			}
			case "slider":
			{
				this.oControl.SetValue({ sValue: sValue, bSuppressEvent: true });
				break;
			}
			case "file":
			{
				var sFileId;
				if(sValue!="")
				{
					this.jFldEmpty.hide();
					this.jFldValue.show();
					var sURL;
					sFileId = null;
					if(oArgs.oFile!=null)
					{
						this.jFldFileName.html(oArgs.oFile.file_name);
						sURL = oArgs.oFile.url;
						if(oArgs.oFile.type=="img")
						{
							if(sURL.indexOf("download_file.html")==0)
							{
								sURL = "/" + sURL;
							}
						}
						else
						{
							sURL = this.oPlayer.oConfig.sImgURL + "ico-file-" + oArgs.oFile.type + ".svg";
						}
						this.jFldPreview.css({ "background-image": "url(" + sURL + ")" });
						sFileId = sURL.split("file_id=")[1];
					}
					else
					{
						if(sValue.indexOf("download_file.html")==0)
						{
							sFileId = sValue.split("file_id=")[1];
						}
						else
						{
							sFileId = sValue;
						}
						var oFile = this.oPlayer.oStore["files"].oData[sFileId];
						if(oFile!=null)
						{
							if(oFile.type=="img")
							{
								sURL = oFile.url;
							}
							else
							{
								sURL = this.oPlayer.oConfig.sImgURL + "ico-file-" + oFile.type + ".svg";
							}
						}
						else
						{
							sURL = sValue;
						}
						this.jFldPreview.css({ "background-image": "url('" + sURL + "')" });
						if(this.oPlayer.oStore["files"].oData[sFileId]!=null)
						{
							this.jFldFileName.html(this.oPlayer.oStore["files"].oData[sFileId].file_name);
						}
					}
				}
				else
				{
					this.jFldEmpty.show();
					this.jFldValue.hide();
				}

				this.jControl.val(sFileId==null ? sValue: sFileId);
				if(oArgs.bDefault!=true)
				{
					this.UIEvent({ oEvt: { type: "change"}, oElem: this.jControl[0], oThis: this, bSuppressEvent: (oArgs.bSuppressEvent==true) });
				}
				break;
			}
			case "integer":
			case "real":
			case "spinner":
			case "dec_spinner":
			{
				if(oArgs.bSuppressEvent==true)
				{
					this.bIgnoreEvent = true;
				}
				this.jControl.spinner("value", sValue);
				this.bIgnoreEvent = false;
				break;
			}
			case "foreign_elem":
			{
				if(sValue==null)
				{
					sValue = this.bFEMultiple ? "[]" : "";
				}
				if(!this.bFEMultiple && sValue!="" && sValue.indexOf("[")==0 && sValue.indexOf("]")==sValue.length-1)
				{
					var aTmp = JSON.parse(sValue);
					sValue = (aTmp.length==0) ? "" : aTmp[0];
					if(typeof sValue == "object")
					{
						sValue = sValue.__value;
					}
				}
				else if(this.bFEMultiple && sValue!="" && sValue.indexOf("[")!=0 && sValue.indexOf("]")!=sValue.length-1)
				{
					if(sValue.indexOf(";")!=-1)
					{
						sValue = JSON.stringify(sValue.split(";"));
					}
					else
					{
						sValue =  JSON.stringify(new Array(sValue));
					}
				}
				if(oArgs.bSuppressEvent==true)
				{
					this.bIgnoreEvent = true;
				}
				if(this.bFEMultiple)
				{
					this.jList.html("");
					var aValues = (sValue.indexOf("[")==0) ? JSON.parse(sValue) : (sValue!="" ? sValue.split(";") : []);
					var aWTValues = [];
					for(i=0; i<aValues.length; i++)
					{
						if(typeof aValues[i] == "object")
						{
							aWTValues.push(JSON.parse(JSON.stringify(aValues[i])));
							aValues[i] = aWTValues[i].__value;
						}
						else
						{
							aWTValues.push({ __value: aValues[i], comment: "" });
						}
					}
					this.sValue = JSON.stringify(aWTValues);
					this.jControl.val(this.sValue);
					if(aValues.length==0)
					{
						this.jListContainer.hide();
					}
					else
					{
						this.jListContainer.show();
						var aNames = (oArgs.sName!=null && oArgs.sName!="") ? oArgs.sName.split("|||") : [];
						var bSetNames = (aNames.length==0 && aValues.length!=0);
						for(i=0; i<aValues.length; i++)
						{
							if(bSetNames)
							{
								this.jItemTemplate.clone(true).attr({ "wt-id": aValues[i] }).html("...").appendTo(this.jList);
								aNames.push(aValues[i]);
							}
							else
							{
								this.jItemTemplate.clone(true).attr({ "wt-id": aValues[i] }).html(aNames[i]).appendTo(this.jList);
							}
						}
						if(bSetNames)
						{
							this.SetName({ aValues: aNames });
						}
					}
				}
				else
				{
					this.jControl.val(sValue);
					if(oArgs.sName!=null && oArgs.sName!="")
					{
						this.jFldValue.html(oArgs.sName);
					}
					else if(sValue=="")
					{
						this.jFldValue.html(this.oPlayer._GetString({ sId: "foreign-elem-default" }));
					}
					else
					{
						this.jFldValue.html("...");
						this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: "action={'action':'get_fe_name','session_token':'" + this.oPlayer.sSessionToken + "','fe_id':'" + sValue + "'}", oContext: oThis, fnSuccess: oThis.SetFEName, oSuccessArgs: {} });
					}
				}
				this.bIgnoreEvent = false;
				break;
			}
			case "date":
			case "heading":
			case "string":
			case "text":
			case "object":
			case "edit":
			case "hidden":
			{
				if(oArgs.bSuppressEvent==true)
				{
					this.bIgnoreEvent = true;
				}
				this.jControl.val(sValue);
				this.bIgnoreEvent = false;
				break;
			}
			case "list":
			{
				this.jControl.val(sValue.split(";"));
				break;
			}
			case "combo":
			case "select":
			case "select_to_foreign_elem":
			case "select_to_string":
			{
				if(this.bParamSet==true)
				{
					this.FillParamSets();
					this.jControl.val(sValue);
					this.jBtnCopy.prop("disabled", (sValue=="custom"));
				}
				else
				{
					if(this.sView=="btn" || this.sView=="selectbtn")
					{
						this.oControl.SetValue({ sValue: sValue, bSuppressEvent: true });
					}
					else
					{
						this.jControl.val(sValue);
					}
				}
				break;
			}
			case "color":
			{
				if(oArgs.bSuppressEvent==true)
				{
					this.bIgnoreEvent = true;
				}
				this.jControl.val(sValue);
				this.jSample.css({ "background-color": sValue });
				this.bIgnoreEvent = false;
				break;
			}
			case "textedit":
			{
				sValue = sValue.split("&amp;").join("&");
				if(CKEDITOR.instances[this.sUID]!=null)
				{
					CKEDITOR.instances[this.sUID].setData(sValue);
				}
				else
				{
					this.jControl.html(sValue);
				}
				break;
			}
			case "bool":
			case "check":
			{
				var bValue = TOOLS.Refine({ sType: "bool", sValue: sValue });
				if(this.oControl==null)
				{
					this.jControl.prop("checked", bValue);
				}
				else
				{
					this.oControl.SetValue({ bCheck: bValue, bSuppressEvent: true });
				}
				break;
			}

		}
		return this;
	};
	CXFld.prototype.Show = function (oArgs)
	{
		if(this.sType!="hidden" && !this.bFontFld)
		{
			var jTarget = this.jFldBlock;
			if(this.jFldBlock.siblings().length==0)
			{
				jTarget = this.jFldBlock.parent();
			}
			else
			{
				//jTarget = this.jBlock;
			}
			if(oArgs!=null && oArgs.bTransition==true)
			{
				jTarget.slideDown(250);
			}
			else
			{
				jTarget.show();
			}
		}
		return this;
	};
	CXFld.prototype.UIEvent = function (oArgs)
	{
		var oThis = this;
		if(!(oThis instanceof CXFld))
		{
			oThis = oArgs.oThis;
			if(!(oThis instanceof CXFld))
			{
				if(oArgs.oArgs!=null)
				{
					oThis = oArgs.oArgs.oThis;
					if(!(oThis instanceof CXFld))
					{
						return this;
					}
				}
				else
				{
					return this;
				}
			}
		}
		switch(oArgs.oEvt.type)
		{
			case "select": // list select event
			{
				oThis.oCurrentListItem = oThis.oListItems[oThis.oControl.sValue];
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "reorder":
			{
				this.FireEvent({ sEvent: "reordered" });
				break;
			}
			case "appendrequest":
			{
				oThis.AddListItem({ bUserAction: true });
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "deleterequest":
			{
				oThis.DeleteListItem({ sId: oThis.oControl.sItemToDelete, bUserAction: true });
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "click":
			{
				if(!oThis.bDisabled)
				{
					switch(oThis.sType)
					{
						case "select_to_string":
						{
							if(oArgs.oElem.getAttribute("cx-role")=="btn-copy-params")
							{
								oThis.CopyParamSetValues();
							}
							break;
						}
						case "foreign_elem":
						{
							switch(oArgs.oElem.getAttribute("cx-role"))
							{
								case "select-list-item":
								{
									var sOldValue = this._GetValue();
									var sNewValue = oArgs.oElem.getAttribute("wt-id");
									if(sOldValue!=sNewValue)
									{
										this.SetValue({ sValue: sNewValue, sName: $(oArgs.oElem).html() });
										if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
										{
											this.bIgnoreEvent = false;
											oThis.FireEvent({ sEvent: "modified" });
											if(this.bCollectionFld && this.oPage.oMappingFolder!=null)
											{
												this.oPage.oMappingFolder.Update();
											}
											else if(this.bCommonCollectionFld && this.oPage.oCommonMappingFolder!=null)
											{
												this.oPage.oCommonMappingFolder.Update();
											}
										}
									}
									break;
								}
								case "btn-foreign_elem":
								{
									var sCatalog = "";
									if(this.bFEMultiple)
									{
										var aWTValues = JSON.parse(oThis._GetValue());
										oThis.aElems = [];
										for(var i=0; i<aWTValues.length; i++)
										{
											oThis.aElems.push(aWTValues[i].__value);
										}
									}
									else
									{
										oThis.aElems = [ oThis._GetValue() ];
									}
									if(this.bDynamicFill)
									{
										//sCatalog = (oThis.oFld.catalog=="" && oThis.oPlayer.oCurrentWebModeCopy.catalog_name!="") ? oThis.oPlayer.oCurrentWebModeCopy.catalog_name : (oThis.oFld.catalog!="" ? oThis.oFld.catalog : "");
										sCatalog = (oThis.oFld.catalog=="" && oThis.oPlayer.oCurrentWebModeCopy.catalog_name!="") ? oThis.oPlayer.oCurrentWebModeCopy.catalog_name : "";
										this.oDialog.oPage.jSelectContainer.css({ "opacity": "0" }).show();
										if(this.bCommonCollectionFld || this.bCommonActionFld)
										{
											this.oDialog.oPage.UpdateHint({ sHint: "selector", bAjax: true, sCatalog: sCatalog, bAction: this.bCommonActionFld, fn: oThis.UIEvent, oContext: oThis, sValue: oThis._GetValue(), sLabel: this.sLabel }).AdjustHint({ jHint: this.oDialog.oPage.jSelectContainer });
										}
										else if(this.bActionItemFld)
										{
											this.oDialog.oPage.UpdateHint({ sHint: "selector", bAjax: true, sCatalog: sCatalog, bAction: true, fn: oThis.UIEvent, oContext: oThis, sValue: oThis._GetValue(), sLabel: this.sLabel }).AdjustHint({ jHint: this.oDialog.oPage.jSelectContainer });
										}
										else
										{
											this.oDialog.oPage.UpdateHint({ sHint: "selector", aOptions: this.aDynamicOptions, fn: oThis.UIEvent, oContext: oThis, sValue: oThis._GetValue(), sLabel: this.sLabel }).AdjustHint({ jHint: this.oDialog.oPage.jSelectContainer });
										}
									}
									else
									{
										sCatalog = (oThis.oFld.catalog=="" && oThis.oPlayer.oCurrentWebModeCopy.catalog_name!="") ? oThis.oPlayer.oCurrentWebModeCopy.catalog_name : oThis.oFld.catalog;
										xShowSelectDialog(
										{
											"catalog_name": sCatalog,
											"columns_list": "name",
											"multi_select": this.bFEMultiple,
											"xquery_qual": "", //"$elem/type='video'",
											"doc_id": "",
											"title": (oThis.oFld.description!=null ? oThis.oFld.description.split("--")[0] : oThis.oFld.name),
											"selected_object_ids": oThis.aElems.join(";"),
											"elemArray": oThis.aElems
										},
										function(oParams)
										{
											var sValue = oParams.selected_object_ids;
											var sName = oParams.elemNamesArray.length!=0 ? oParams.elemNamesArray.join("|||") : oThis.oPlayer._GetString({ sId: "foreign-elem-default" });
											oThis.SetValue({ sValue: sValue, sName: sName });
											if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
											{
												this.bIgnoreEvent = false;
												if(oThis.aElems.length!=0)
												{
													if(oThis.aElems[0]!=sValue)
													{
														oThis.FireEvent({ sEvent: "modified" });
													}
												}
												else
												{
													oThis.FireEvent({ sEvent: "modified" });
												}
											}
											return true;
										});
									}
									break;
								}
								case "btn-fe-delete":
								{
									if(oThis._GetValue()!="")
									{
										oThis.SetValue({ sValue: "" });
										if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
										{
											this.bIgnoreEvent = false;
											oThis.FireEvent({ sEvent: "modified" });
										}
									}
									break;
								}
							}
							break;
						}
						case "file":
						{
							switch(oArgs.oElem.getAttribute("cx-role"))
							{
								case "btn-clear-img-fld":
								{
									oArgs.oEvt.preventDefault();
									oArgs.oEvt.stopPropagation();
									oThis.SetValue({ sValue: "" });
									break;
								}
								default:
								{
									oThis.sValue = oThis._GetValue();
									var sFileId = null;
									if(oThis.sValue!="" && oThis.sValue.indexOf("file_id")!=-1)
									{
										sFileId = oThis.sValue.split("file_id=")[1];
									}
									oThis.oPlayer.oPages["desktop"].oDialogs["selectfile"].Fill().SetTarget({ oTarget: oThis }).Show({ sSelectedId: sFileId });
									break;
								}
							}
							break;
						}
						case "list":
						case "object":
						{
							switch(oArgs.oElem.getAttribute("cx-role"))
							{
								case "btn-new-item":
								{
									oThis.AddListItem();
									if(oThis.oPlayer.oCurrentSlide!=null)
									{
										oThis.oPlayer.oCurrentSlide.UpdateParams({ oDialog: oThis.oDialog, oFld: oThis, iCurrentItem: Object.keys(oThis.oListItems).length });
									}
									break;
								}
								case "btn-item-delete":
								{
									oThis.DeleteListItem({ sId: oArgs.oElem.getAttribute("cx-id") });
									if(oThis.oPlayer.oCurrentSlide!=null)
									{
										oThis.oPlayer.oCurrentSlide.UpdateParams({ oDialog: oThis.oDialog, oFld: oThis  });
									}
									break;
								}
								case "btn-item-switch":
								{
									var sId = oArgs.oElem.getAttribute("cx-id");
									if(oThis.oListItems[sId].bOpen)
									{
										oThis.CollapseListItem({ sId: sId });
									}
									else
									{
										oThis.ExpandListItem({ sId: sId });
									}
									break;
								}
							}
							break;
						}
					}
				}
				break;
			}
			case "keyup":
			{
				oThis.sValue = oThis._GetValue();
				if(oThis.sType=="color")
				{
					oThis.jSample.css({ "background-color": oThis.sValue });
				}
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "blur":
			{
				if(this.bActionItemParams)
				{
					try
					{
						JSON.parse(this.sValue);
					}
					catch(e)
					{
						alert("Invalid JSON in action params field: " + e);
					}
				}
				// to save rte change
				break;
			}
			case "spinchange":
			case "spinstop":
			{
				oThis.sValue = oThis._GetValue();
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "change":
			case "selectmenuchange":
			{
				oThis.sValue = oThis._GetValue();
				switch(oThis.sType)
				{
					case "select_to_foreign_elem":
					case "select_to_string":
					{
						if(this.bParamSet==true)
						{
							this.SetValue({ sValue: oThis.sValue });
						}
						break;
					}
					case "color":
					{
						oThis.jSample.css({ "background-color": oThis.sValue });
						break;
					}
					// all other types do not need specific actions
				}
				if(oArgs.bSuppressEvent!=true && this.bIgnoreEvent!=true)
				{
					this.bIgnoreEvent = false;
					this.FireEvent({ sEvent: "modified" });
				}
				break;
			}
		}
		return oThis;
	};
	CXFld.prototype.UpdateParamFldValue = function (oArgs)
	{
		this.oFld.value = this.sValue;
		return this;
	};
}
{ // CXFontControl
	window.CXFontControl = function (oArgs)
	{
		WTBaseObject.call(this, oArgs);
		this.oDialog = oArgs.oDialog;
		this.oPage = oArgs.oPage;
		this.oFld = oArgs.oFld;
		this.oParentFld = oArgs.oParentFld;
		this.jBlock = oArgs.jBlock;
		this.sLabel = oArgs.sLabel;
		this.oLinkedFlds = {};
		this.oValues =
		{
			"font-family": "Roboto",
			"font-family-custom": "",
			"font-size": "medium",
			"font-weight": "normal",
			"font-style": "normal"
		};
		this.Constructor();
		return this;
	};
	CXFontControl.prototype = Object.create(WTBaseObject.prototype);
	CXFontControl.prototype.constructor = CXFontControl;
	CXFontControl.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		this.jBody = this.oPlayer.jStorage.find("[cx-template='fld-block-font']").clone(true).removeAttr("cx-template").appendTo(this.jBlock);
		if(this.sLabel==null || this.sLabel=="" || this.sLabel==this.oFld.name)
		{
			this.sLabel = (this.oFld.description!=null && this.oFld.description!="") ? this.oFld.description : this.oFld.name;
		}
		if(this.sLabel.indexOf("--")!=-1)
		{
			var aParts = this.sLabel.split("--");
			if(aParts.length==2)
			{
				this.sLabel = aParts[0];
				this.sTitle = $.trim(aParts[1]);
			}
			else if(aParts.length>2)
			{
				this.sLabel = $.trim(aParts.shift());
				this.sTitle = $.trim(aParts.join("--"));
			}
			else
			{
				this.sTitle = this.sLabel;
			}
		}
		else
		{
			this.sTitle = this.sLabel;
		}
		this.jLabel = this.jBody.find("[cx-role='label-text']").attr({ "title": this.sTitle }).html(this.sLabel);
		this.jFontFamilyFld = this.jBody.find("[cx-role='font-family']").val(this.oValues["font-family"]).on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		this.jFontFamilyCustomRow = this.jBody.find("[cx-role='font-custom']").hide();
		this.jFontFamilyCustomFld = this.jBody.find("[cx-role='font-family-custom']").val(this.oValues["font-family-custom"]).on("keyup", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		this.jFontSizeFld = this.jBody.find("[cx-role='font-size']").val(this.oValues["font-size"]).on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		this.oFontWeight = {};
		this.oFontWeight["thin"] = { jBtn: this.jBody.find("[cx-role='font-weight-thin']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
		this.oFontWeight["normal"] = { jBtn: this.jBody.find("[cx-role='font-weight-normal']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
		this.oFontWeight["semibold"] = { jBtn: this.jBody.find("[cx-role='font-weight-semibold']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
		this.oFontWeight["bold"] = { jBtn: this.jBody.find("[cx-role='font-weight-bold']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
		this.oFontStyle = { jBtn: this.jBody.find("[cx-role='font-style']").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
		this.jFontFamilyValue = this.jBody.find("[cx-role='font-family-value']").val(this.oValues["font-family"]);
		this.jFontFamilyCustomValue = this.jBody.find("[cx-role='font-family-custom-value']").val(this.oValues["font-family-custom"]);
		this.jFontSizeValue = this.jBody.find("[cx-role='font-size-value']").val(this.oValues["font-size"]);
		this.jFontWeightValue = this.jBody.find("[cx-role='font-weight-value']").val(this.oValues["font-weight"]);
		this.jFontStyleValue = this.jBody.find("[cx-role='font-style-value']").val(this.oValues["font-style"]);
		return this;
	};
	CXFontControl.prototype.Hide = function (oArgs)
	{
		this.jBody.hide();
		return this;
	};
	CXFontControl.prototype.SetValue = function (oArgs)
	{
		switch(oArgs.sFld)
		{
			case "font-family":
			{
				this.oValues["font-family"] = oArgs.sValue;
				this.jFontFamilyValue.val(oArgs.sValue);
				if(oArgs.bSet==true)
				{
					this.jFontFamilyFld.val(oArgs.sValue);
				}
				else
				{
					this.oLinkedFlds["font-family"].bIgnoreEvent = false;
					this.oLinkedFlds["font-family"].FireEvent({ sEvent: "modified" });
				}
				if(oArgs.sValue=="Custom")
				{
					this.jFontFamilyCustomRow.show();
				}
				else
				{
					this.jFontFamilyCustomRow.hide();
				}
				switch(oArgs.sValue)
				{
					case "ClearSans":
					case "Inter":
					case "OpenSans":
					case "Oswald":
					case "Roboto":
					{
						this.oFontWeight["thin"].jBtn.prop("disabled", false);
						this.oFontWeight["semibold"].jBtn.prop("disabled", false);
						break;
					}
					default:
					{
						if(this.oValues["font-weight"]=="thin")
						{
							this.SetValue({ sFld: "font-weight", sValue: "normal" });
						}
						if(this.oValues["font-weight"]=="semibold")
						{
							this.SetValue({ sFld: "font-weight", sValue: "bold" });
						}
						this.oFontWeight["thin"].jBtn.prop("disabled", true);
						this.oFontWeight["semibold"].jBtn.prop("disabled", true);
						break;
					}
				}
				break;
			}
			case "font-family-custom":
			{
				this.oValues["font-family-custom"] = oArgs.sValue;
				this.jFontFamilyCustomValue.val(oArgs.sValue);
				if(oArgs.bSet==true)
				{
					this.jFontFamilyCustomFld.val(oArgs.sValue);
				}
				else
				{
					this.oLinkedFlds["font-family-custom"].bIgnoreEvent = false;
					this.oLinkedFlds["font-family-custom"].FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "font-size":
			{
				this.oValues["font-size"] = oArgs.sValue;
				this.jFontSizeValue.val(oArgs.sValue);
				if(oArgs.bSet==true)
				{
					this.jFontSizeFld.val(oArgs.sValue);
				}
				else
				{
					this.oLinkedFlds["font-size"].bIgnoreEvent = false;
					this.oLinkedFlds["font-size"].FireEvent({ sEvent: "modified" });
				}
				break;
			}
			case "font-weight":
			{
				this.oValues["font-weight"] = oArgs.sValue;
				this.jFontWeightValue.val(oArgs.sValue);
				if(!oArgs.bSet)
				{
					this.oLinkedFlds["font-weight"].bIgnoreEvent = false;
					this.oLinkedFlds["font-weight"].FireEvent({ sEvent: "modified" });
				}
				for(var sKey in this.oFontWeight)
				{
					if(sKey==oArgs.sValue)
					{
						this.oFontWeight[sKey].jBtn.attr({ "cx-selected": "1" });
					}
					else
					{
						this.oFontWeight[sKey].jBtn.removeAttr("cx-selected");
					}
				}
				break;
			}
			case "font-style":
			{
				this.oValues["font-style"] = oArgs.sValue;
				this.jFontStyleValue.val(oArgs.sValue);
				if(!oArgs.bSet)
				{
					this.oLinkedFlds["font-style"].bIgnoreEvent = false;
					this.oLinkedFlds["font-style"].FireEvent({ sEvent: "modified" });
				}
				if(oArgs.sValue=="italic")
				{
					this.oFontStyle.jBtn.attr({ "cx-selected": "1" });
				}
				else
				{
					this.oFontStyle.jBtn.removeAttr("cx-selected");
				}
				break;
			}
		}
		return this;
	};
	CXFontControl.prototype.Show = function (oArgs)
	{
		this.jBody.show();
		return this;
	};
	CXFontControl.prototype.UIEvent = function (oArgs)
	{
		var oThis = this;
		var sValue;
		var sRole = oArgs.oElem.getAttribute("cx-role");
		switch(sRole)
		{
			case "font-family":
			{
				sValue = oArgs.oElem.value;
				this.SetValue({ sFld: "font-family", sValue: sValue });
				break;
			}
			case "font-family-custom":
			{
				sValue = oArgs.oElem.value;
				this.SetValue({ sFld: "font-family-custom", sValue: sValue });
				break;
			}
			case "font-size":
			{
				sValue = oArgs.oElem.value;
				this.SetValue({ sFld: "font-size", sValue: sValue });
				break;
			}
			case "font-weight-thin":
			case "font-weight-normal":
			case "font-weight-semibold":
			case "font-weight-bold":
			{
				if(!oArgs.oElem.hasAttribute("disabled"))
				{
					var aParts = sRole.split("-");
					if(!oArgs.oElem.hasAttribute("cx-selected"))
					{
						this.SetValue({ sFld: "font-weight", sValue: aParts[2] });
					}
				}
				break;
			}
			case "font-style":
			{
				if(!oArgs.oElem.hasAttribute("disabled"))
				{
					if(oArgs.oElem.hasAttribute("cx-selected"))
					{
						this.SetValue({ sFld: "font-style", sValue: "normal" });
					}
					else
					{
						this.SetValue({ sFld: "font-style", sValue: "italic" });
					}
				}
				break;
			}
		}
		return this;
	};
}
