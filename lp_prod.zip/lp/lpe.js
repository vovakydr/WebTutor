// 230209
var g_bDebug = false;
var g_bDebugConsole = true;

if(window.FileReader)
{
    // extending FileReader for IE
    if(!FileReader.prototype.readAsBinaryString)
	{
        FileReader.prototype.readAsBinaryString = function(fileData)
		{
            var binary = "";
            var pt = this;
            var reader = new FileReader();
            reader.onload = function(e)
			{
                var bytes = new Uint8Array(reader.result);
                var length = bytes.byteLength;
                for(var i = 0; i<length; i++)
				{
                    binary += String.fromCharCode(bytes[i]);
                }
                pt.content = binary;
                $(pt).trigger("onload");
            };
            reader.readAsArrayBuffer(fileData);
        };
    }
}
if(!Array.prototype.findIndex)
{
	Array.prototype.findIndex = function(predicate)
	{
		if (this == null)
		{
			throw new TypeError('Array.prototype.findIndex called on null or undefined');
		}
		if (typeof predicate !== 'function')
		{
			throw new TypeError('predicate must be a function');
		}
		var list = Object(this);
		var length = list.length >>> 0;
		var thisArg = arguments[1];
		var value;

		for (var i = 0; i < length; i++)
		{
			value = list[i];
			if (predicate.call(thisArg, value, i, list))
			{
				return i;
			}
		}
		return -1;
	};
}

{ // WTBaseObject
    window.WTBaseObject = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jContainer = (oArgs.jContainer != null) ? oArgs.jContainer : this.oPlayer.jContainer;
        this.sId = (oArgs.sId != null) ? oArgs.sId : TOOLS.GUID();
        this.oSubscribers = {};
        return this;
    };
    WTBaseObject.prototype =
	{
        Debug: function(oArgs)
		{
            if(g_bDebug)
			{
                if(g_bDebugConsole && window.console)
				{
                    console.log(this.sType + " " + this.sId + ": " + oArgs.sMsg);
                }
				else
				{
                    alert(this.sType + " " + this.sId + ": " + oArgs.sMsg);
                }
            }
            return this;
        },
        FireEvent: function(oArgs)
		{
            this.Debug({ sMsg: oArgs.sEvent + " fired" });
            for(var sKey in this.oSubscribers)
			{
                if(this.oSubscribers.hasOwnProperty(sKey))
				{
                    for(var sKey2 in this.oSubscribers[sKey])
					{
                        if(this.oSubscribers[sKey].hasOwnProperty(sKey2))
						{
                            if(sKey2 == oArgs.sEvent)
							{
                                for(var i = 0; i<this.oSubscribers[sKey][sKey2].length; i++)
								{
                                    this.Debug({ sMsg: oArgs.sEvent + " - subscriber " + sKey + " - before" });
                                    this.oSubscribers[sKey][sKey2][i].oArgs.oContext = (this.oSubscribers[sKey][sKey2][i].oContext != null) ? this.oSubscribers[sKey][sKey2][i].oContext : this;
                                    this.oSubscribers[sKey][sKey2][i].oArgs.oThis = this;
                                    if(oArgs.oArgs != null)
									{
                                        this.oSubscribers[sKey][sKey2][i].oArgs.oPassedArgs = oArgs.oArgs;
                                    }
                                    this.oSubscribers[sKey][sKey2][i].fn.call(this.oSubscribers[sKey][sKey2][i].oArgs.oContext, this.oSubscribers[sKey][sKey2][i].oArgs);
                                    if(this.oSubscribers[sKey][sKey2][i].bOnce)
									{
                                        this.Unsubscribe({ sSubscriberId: sKey, sEvent: sKey2, fn: this.oSubscribers[sKey][sKey2][i].fn });
                                    }
                                    this.Debug({ sMsg: oArgs.sEvent + " - subscriber " + sKey + " - after" });
                                }
                            }
                        }
                    }
                }
            }
            return this;
        },
        Load: function(oArgs)
		{
            // sURL, sParams, sData, sDataType, sMethod, fnSuccess, oSuccessArgs, fnFailure, oFailureArgs, fnAlways, oAlwaysArgs, oContext
            var oThis = this;
            var sMethod = (oArgs.sMethod == null ? "POST" : oArgs.sMethod);
 			var sURL = TOOLS.AppendURLParams({ sURL: (oArgs.sURL == null ? this.oPlayer.oConfig.sAPIURL : oArgs.sURL), sParams: ("secid=" + oThis.oPlayer.sSecId) });
            if(oArgs.sParams != null)
			{
                sURL = TOOLS.AppendURLParams({ sURL: sURL, sParams: oArgs.sParams });
            }
            var fnSuccess = oArgs.fnSuccess;
            var fnFailure = oArgs.fnFailure;
            var fnAlways = oArgs.fnAlways;
            var sDataType = (oArgs.sDataType == null ? "json" : oArgs.sDataType);
            var oSuccessArgs = (oArgs.oSuccessArgs == null ? {} : oArgs.oSuccessArgs);
            var oFailureArgs = (oArgs.oFailureArgs == null ? {} : oArgs.oFailureArgs);
            var oAlwaysArgs = (oArgs.oAlwaysArgs == null ? {} : oArgs.oAlwaysArgs);
            var oContext = (oArgs.oContext == null ? oThis : oArgs.oContext);
            $.ajax(
			{
                type: sMethod,
                url: sURL,
                async: true,
                data: oArgs.sData,
                dataType: sDataType
            }).done(function(oData, sStatus, jqXHR)
			{
                if(fnSuccess != null)
				{
                    if(sDataType == "json")
					{
                        if(typeof oData != "object")
						{
                            oData = JSON.parse(oData);
                        }
                        if(oData.error != 0)
						{
                            oThis.Debug({ sMsg: oData.error_text });
							alert(oData.error_text);
							if(fnFailure != null)
							{
								oFailureArgs.sError = oData.error_text;
								oFailureArgs.sStatus = sStatus;
								oFailureArgs.jqXHR = jqXHR;
								oArgs.fnFailure.call(oContext, oFailureArgs);
							}
                            return false;
                        }
                    }
                    oSuccessArgs.oData = oData;
                    oSuccessArgs.sStatus = sStatus;
                    oSuccessArgs.jqXHR = jqXHR;
                    fnSuccess.call(oContext, oSuccessArgs);
                    oThis.FireEvent({ sEvent: "loaded" });
                }
				else
				{
                    oThis.Debug({ sMsg: oThis.sId + " LOAD success" });
                }
                return true;
            }).fail(function(jqXHR, sStatus, sError)
			{
                if(fnFailure != null)
				{
                    oFailureArgs.sError = sError;
                    oFailureArgs.sStatus = sStatus;
                    oFailureArgs.jqXHR = jqXHR;
                    oArgs.fnFailure.call(oContext, oFailureArgs);
                }
				else
				{
                    oThis.Debug({ sMsg: (oThis.sId + " LOAD error: " + sError) });
                }
                return false;
            }).always(function()
			{
                if(fnAlways != null)
				{
                    oArgs.fnAlways.call(oContext, oAlwaysArgs);
                }
            });
            return this;
        },
        SetProperty: function(oArgs)
		{
            if(oArgs != null)
			{
                if(oArgs.sProp != null && oArgs.sProp != "")
				{
                    this[oArgs.sProp] = oArgs.vValue;
                }
            }
            return this;
        },
        Subscribe: function(oArgs)
		{
            if(this.oSubscribers[oArgs.sSubscriberId] == null)
			{
                this.oSubscribers[oArgs.sSubscriberId] = {};
            }
            if(this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent] == null)
			{
                this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent] = [];
            }
            for(var i = 0; i<this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent].length; i++)
			{
                if(this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent].fn == oArgs.fn)
				{
                    return this;
                }
            }
            this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent].push({ oContext: oArgs.oContext, fn: oArgs.fn, oArgs: oArgs.oArgs, bOnce: (oArgs.bOnce == true) });
            return this;
        },
        Unsubscribe: function(oArgs)
		{
            for(var i = 0; i<this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent].length; i++)
			{
                if(this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent][i].fn == oArgs.fn)
				{
                    this.oSubscribers[oArgs.sSubscriberId][oArgs.sEvent].splice(i, 1);
                    return this;
                }
            }
            return this;
        }
    };
}
{ // LPE
    window.LPE = function(oArgs)
	{
        WTBaseObject.call(this, { oPlayer: this, jContainer: oArgs.jContainer, sId: oArgs.sId });
        this.sCurrentUserId = oArgs.sCurUserId;
		this.sSecId = oArgs.sSecId;
        this.sType = "PLAYER";
        this.oConfig = {
            nZoneW: 1176,
            sDefaultIconURL: "",
            sLang: "ru",
            sLPURL: "lp/",
            sMode: "simple",
            sRootAPIURL: "lpapi.html"
        };
        this.oConfig.sImgURL = this.oConfig.sLPURL + "img/";
        this.oConfig.sAPIURL = this.oConfig.sLPURL + "lpapi.html";
        this.oConfig.sFileAPIURL = this.oConfig.sLPURL + "cxapi.html";
        this.oConfig.sBlankURL = this.oConfig.sLPURL + "blank.html";
        this.oConfig.sDefaultWidgetIcon = this.oConfig.sImgURL + "some_object.svg";
        this.oConfig.sImgFldPlaceholder = this.oConfig.sImgURL + "img-placeholder.png";
        this.oSettings = null;
        this.oStrings = null;
        this.oPageGroups = {};
        this.oPages = {};
        this.oMenu = {};
        this.oStore = {};
        this.aUsedModes = [];
        this.sRTEFontSizes = "";
		this.sSessionToken = "";
        this.Constructor().Init();
        return this;
    };
    LPE.prototype = Object.create(WTBaseObject.prototype);
    LPE.prototype.constructor = LPE;
    LPE.prototype._GetString = function(oArgs)
	{
        var sString = "";
        if(oArgs.sId != null)
		{
            if(this.oStrings[oArgs.sId] != null)
			{
                sString = this.oStrings[oArgs.sId];
            }
        }
        return sString;
    };
    LPE.prototype.AccessDenied = function(oArgs)
	{
        $("body").children().hide();
        if(oArgs != null) {
            if(oArgs.sMsg != null) {
                this.jAccessDenied.html(oArgs.sMsg);
            }
        }
        this.jAccessDenied.show();
        return this;
    };
    LPE.prototype.CreateTemplatesParamTree = function(oArgs)
	{
        var i;
        var sKey;
        var oCurTemplate;
        var sVarNameEncoded;
        for(sKey in this.oStore["templates"].oData)
		{
            if(this.oStore["templates"].oData.hasOwnProperty(sKey))
			{
                oCurTemplate = this.oStore["templates"].oData[sKey];
				oCurTemplate.bUseFontControl = false;
                if(oCurTemplate.params != null)
				{
                    oCurTemplate.aTree = [];
                    oCurTemplate.oTree = {};
                    // tabs first
                    for(i=0; i<oCurTemplate.params.length; i++)
					{
                        if(typeof oCurTemplate.params[i] == "object")
						{
                            if(oCurTemplate.params[i].type == "folder" && oCurTemplate.params[i].parent_wvar_name == "")
							{
                                if(oCurTemplate.params[i].name.indexOf(".TAB_") != -1) // top level tab found
                                {
                                    oCurTemplate.params[i].sType = "tab";
                                    sVarNameEncoded = TOOLS.EncodeVarName({ sText: oCurTemplate.params[i].name });
                                    oCurTemplate.oTree[sVarNameEncoded] = oCurTemplate.params[i];
                                    oCurTemplate.oTree[sVarNameEncoded].sType = "tab";
                                    oCurTemplate.oTree[sVarNameEncoded].oChildren = {};
                                    oCurTemplate.oTree[sVarNameEncoded].aChildren = [];
                                    oCurTemplate.aTree.push(oCurTemplate.oTree[sVarNameEncoded]);
                                }
                            }
                        }
                    }
                    if(oCurTemplate.aTree.length == 0) // add fake tab
                    {
                        oCurTemplate.oTree["VIEW_AUTOGENERATED"] = {
                            aChildren: [],
                            description: "View",
                            name: "",
                            oChildren: {},
                            sType: "tab"
                        };
                        oCurTemplate.aTree.push(oCurTemplate.oTree["VIEW_AUTOGENERATED"]);
                    }
                    // cleanup bad design - non-tab elements on level 0
                    for(i=0; i<oCurTemplate.params.length; i++)
					{
                        if(typeof oCurTemplate.params[i] == "object")
						{
                            if(oCurTemplate.params[i].parent_wvar_name == "" && oCurTemplate.params[i].sType != "tab")
							{
                                oCurTemplate.params[i].parent_wvar_name = oCurTemplate.aTree[0].name;
                            }
							if(oCurTemplate.params[i].name.indexOf(".__service__use_font_control")!=-1)
							{
								if(oCurTemplate.params[i].value=="true")
								{
									oCurTemplate.bUseFontControl = true;
								}
							}
                        }
                    }
                    for(i=0; i<oCurTemplate.aTree.length; i++) // and... finally... recursion!
                    {
                        this.CreateTemplatesParamTreeBranch({ oCurTemplate: oCurTemplate, oParent: oCurTemplate.aTree[i] });
                    }
                }
            }
        }
        for(sKey in this.oStore["macros"].oData)
		{
            if(this.oStore["macros"].oData.hasOwnProperty(sKey))
			{
                oCurTemplate = this.oStore["macros"].oData[sKey];
				oCurTemplate.bUseFontControl = false;
                if(oCurTemplate.params != null)
				{
                    oCurTemplate.aTree = [];
                    oCurTemplate.oTree = {};
                    // tabs first
                    for(i=0; i<oCurTemplate.params.length; i++)
					{
                        if(typeof oCurTemplate.params[i] == "object")
						{
                            if(oCurTemplate.params[i].type == "folder" && oCurTemplate.params[i].parent_wvar_name == "")
							{
                                if(oCurTemplate.params[i].name.indexOf(".TAB_") != -1) // top level tab found
                                {
                                    oCurTemplate.params[i].sType = "tab";
                                    sVarNameEncoded = TOOLS.EncodeVarName({ sText: oCurTemplate.params[i].name });
                                    oCurTemplate.oTree[sVarNameEncoded] = oCurTemplate.params[i];
                                    oCurTemplate.oTree[sVarNameEncoded].sType = "tab";
                                    oCurTemplate.oTree[sVarNameEncoded].oChildren = {};
                                    oCurTemplate.oTree[sVarNameEncoded].aChildren = [];
                                    oCurTemplate.aTree.push(oCurTemplate.oTree[sVarNameEncoded]);
                                }
                            }
                        }
                    }
                    if(oCurTemplate.aTree.length == 0) // add fake tab
                    {
                        oCurTemplate.oTree["VIEW_AUTOGENERATED"] = {
                            aChildren: [],
                            description: "View",
                            name: "",
                            oChildren: {},
                            sType: "tab"
                        };
                        oCurTemplate.aTree.push(oCurTemplate.oTree["VIEW_AUTOGENERATED"]);
                    }
                    // cleanup bad design - non-tab elements on level 0
                    for(i=0; i<oCurTemplate.params.length; i++)
					{
                        if(typeof oCurTemplate.params[i] == "object")
						{
                            if(oCurTemplate.params[i].parent_wvar_name == "" && oCurTemplate.params[i].sType != "tab")
							{
                                oCurTemplate.params[i].parent_wvar_name = oCurTemplate.aTree[0].name;
                            }
							if(oCurTemplate.params[i].name.indexOf(".__service__use_font_control")!=-1)
							{
								if(oCurTemplate.params[i].value=="true")
								{
									oCurTemplate.bUseFontControl = true;
								}
							}
                        }
                    }
                    for(i=0; i<oCurTemplate.aTree.length; i++) // and... finally... recursion!
                    {
                        this.CreateTemplatesParamTreeBranch({ oCurTemplate: oCurTemplate, oParent: oCurTemplate.aTree[i] });
                    }
                }
            }
        }
        return this;
    };
    LPE.prototype.CreateTemplatesParamTreeBranch = function(oArgs)
	{
        var i;
        var sVarNameEncoded;
        var sParentNameEncoded = TOOLS.EncodeVarName({ sText: oArgs.oParent.name });
        for(i=0; i<oArgs.oCurTemplate.params.length; i++)
		{
            if(typeof oArgs.oCurTemplate.params[i] == "object")
			{
                if(oArgs.oCurTemplate.params[i].parent_wvar_name == oArgs.oParent.name)
				{
                    oArgs.oCurTemplate.params[i].sType = (oArgs.oCurTemplate.params[i].type == "folder" ? "folder" : "param");
                    sVarNameEncoded = TOOLS.EncodeVarName({ sText: oArgs.oCurTemplate.params[i].name });
                    oArgs.oParent.oChildren[sVarNameEncoded] = oArgs.oCurTemplate.params[i];
                    oArgs.oParent.oChildren[sVarNameEncoded].sType = oArgs.oCurTemplate.params[i].sType;
                    oArgs.oParent.oChildren[sVarNameEncoded].oChildren = {};
                    oArgs.oParent.oChildren[sVarNameEncoded].aChildren = [];
                    oArgs.oParent.aChildren.push(oArgs.oParent.oChildren[sVarNameEncoded]);
                    this.CreateTemplatesParamTreeBranch({ oCurTemplate: oArgs.oCurTemplate, oParent: oArgs.oParent.oChildren[sVarNameEncoded] });
                }
            }
        }
        return this;
    };
    LPE.prototype.Constructor = function()
	{
        this.jStorage = this.jContainer.find("[cx-role='storage']");
        this.jAccessDenied = $("[cx-role='access-denied']");
        this.jTopNav = this.jContainer.find("[cx-role='top-nav']");
        this.oLoader = (new CXLoader({ oPlayer: this })).Show();
        this.oMask = (new CXMask({ oPlayer: this }));
        this.oPreview = new CXPreview({ oPlayer: this });
        this.oAPI = new CXAPI({ oPlayer: this });
        this.oAlert = new CXAlert({ oPlayer: this, jContainer: this.jContainer });
		this.oLoader.oLoadingBar.set(1);
        return this;
    };
    LPE.prototype.Init = function()
	{
        this.Subscribe({ sEvent: "language_ready", bOnce: true, sSubscriberId: this.sId, oContext: this, fn: this.Proceed, oArgs: { sStep: "load_settings" } });
        this.Subscribe({ sEvent: "settings_ready", bOnce: true, sSubscriberId: this.sId, oContext: this, fn: this.Proceed, oArgs: { sStep: "init_ui" } });
        this.Subscribe({ sEvent: "ui_ready", bOnce: true, sSubscriberId: this.sId, oContext: this, fn: this.Proceed, oArgs: { sStep: "load_data" } });
        this.Subscribe({ sEvent: "data_ready", bOnce: true, sSubscriberId: this.sId, oContext: this, fn: this.Proceed, oArgs: { sStep: "fill_pages" } });
        this.Subscribe({ sEvent: "pages_ready", bOnce: true, sSubscriberId: this.sId, oContext: this, fn: this.Proceed, oArgs: { sStep: "start" } });

        this.Proceed({ sStep: "load_lang" });
        return this;
    };
    LPE.prototype.Proceed = function(oArgs)
	{
		var oThis = this;
        var sKey;
		var i;
        switch(oArgs.sStep)
		{
            case "load_lang":
			{
				var sCookie = TOOLS.Cookie.Get({ sName: "lp_lang_" + this.sCurrentUserId });
				if(sCookie != undefined)
				{
					this.oConfig.sLang = sCookie;
					this.FireEvent({ sEvent: "language_ready" });
				}
				else
				{
					this.Load({ sData: "action={'action':'get_language'}", fnSuccess: this.Proceed, oSuccessArgs: { sStep: "parse_language" } });
				}
				this.oLoader.oLoadingBar.set(2);
				break;
			}
            case "parse_language":
			{
				if(oArgs.oData.language != null)
				{
					if(oArgs.oData.language.length >= 2)
					{
						this.oConfig.sLang = oArgs.oData.language.substring(0, 2);
					}
				}
				this.oLoader.oLoadingBar.set(4);
				this.FireEvent({ sEvent: "language_ready" });
				break;
			}
            case "load_settings":
			{
				this.Load({ sData: "action={'action':'get_settings','lang':'" + this.oConfig.sLang + "'}", fnSuccess: this.Proceed, oSuccessArgs: { sStep: "parse_settings" } });
				break;
			}
            case "parse_settings":
			{
				if(oArgs.oData.access == null || (oArgs.oData.access != null && oArgs.oData.access.web_mode != true))
				{
					this.oMask.Hide();
					this.AccessDenied();
					return this;
				}
				if(oArgs.oData.object_types != null)
				{
					this.oStore["object_types"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.object_types });
				}
				if(oArgs.oData.settings != null)
				{
					if(Object.keys(oArgs.oData.settings).length == 0)
					{
						this.oMask.Hide();
						this.AccessDenied();
						return this;
					}
					this.oSettings = JSON.parse(JSON.stringify(oArgs.oData.settings));
					this.oStrings = JSON.parse(JSON.stringify(oArgs.oData.strings));
					this.oAccess = JSON.parse(JSON.stringify(oArgs.oData.access));
					this.sRTEFontSizes = this._GetString({ sId: "rte-font-sizes" });
					this.FireEvent({ sEvent: "settings_ready" });
				}
				this.oLoader.oLoadingBar.set(10);
				break;
			}
            case "init_ui":
			{
				this.oUI = new CXUI({ oPlayer: this, jContainer: this.jContainer });
				this.oUI.jLangSelector.val(this.oConfig.sLang);
				this.oMenu["top"].oItems["resources"].oBtn.Disable();
				this.oPages["pages"].oBtns["run-editor"].Disable();
				this.oLoader.oLoadingBar.set(10);
				this.FireEvent({ sEvent: "ui_ready" });
				break;
			}
            case "load_data":
			{
				this.Load({ sURL: this.oConfig.sRootAPIURL, sData: "action={'action':'init_step_1','lang':'" + this.oConfig.sLang + "'}", fnSuccess: this.Proceed, oSuccessArgs: { sStep: "parse_data" } });
				break;
			}
            case "parse_data":
			{
				if(oArgs.oData.session_token != null)
				{
					this.sSessionToken = oArgs.oData.session_token;
				}
				this.oStore["webmodes"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.web_modes });
				if(oArgs.oData.web_designs != null)
				{
					this.oStore["web_designs"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.web_designs });
				}
				if(oArgs.oData.placeholders != null)
				{
					this.oStore["placeholders"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.placeholders });
				}
				else
				{
					this.oConfig.sMode = "simple";
				}
				if(oArgs.oData.used_web_modes != null)
				{
					if(oArgs.oData.used_web_modes.constructor === Array)
					{
						this.aUsedModes = oArgs.oData.used_web_modes.slice();
					}
				}
				if(oArgs.oData.collections != null)
				{
					if(oArgs.oData.collections.constructor === Array)
					{
						this.aCollections = oArgs.oData.collections.slice();
						this.oCollections = {};
						for(i=0; i<this.aCollections.length; i++)
						{
							this.oCollections[this.aCollections[i].id] = this.aCollections[i];
						}
					}
				}
				this.oLoader.oLoadingBar.set(15);
				this.FireEvent({ sEvent: "data_ready" });
				break;
			}
            case "fill_pages":
			{
				this.oPages["pages"].Fill();
				this.Load({ sURL: this.oConfig.sRootAPIURL, sData: "action={'action':'init_step_2','lang':'" + this.oConfig.sLang + "'}", fnSuccess: this.Proceed, oSuccessArgs: { sStep: "parse_data_step_2" } });
				this.oLoader.oLoadingBar.set(20);
				this.FireEvent({ sEvent: "pages_ready" });
				break;
			}
            case "start":
			{
				this.oMenu["top"].Subscribe({ sEvent: "change", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Page, oArgs: {} });
				this.oMenu["top"].Select({ sItemId: "pages" });
				break;
			}
			case "parse_data_step_2":
			{
				this.oLoader.oLoadingBar.set(30);
				setTimeout(function () { oThis.Load({ sURL: TOOLS.AppendURLParams({ sURL: oThis.oConfig.sRootAPIURL, sParams: ((document.location.href.indexOf("flush_templates=1")!=-1) ? "flush_templates=1" : "") }), sData: "action={'action':'init_step_3','lang':'" + oThis.oConfig.sLang + "'}", fnSuccess: oThis.Proceed, oSuccessArgs: { sStep: "parse_data_step_3" } }); }, 25);
				if(oArgs.oData.repositoriums != null)
				{
					this.oStore["repos"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.repositoriums });
					var aFiles = [];
					for(sKey in oArgs.oData.repositoriums)
					{
						if(oArgs.oData.repositoriums[sKey].files != null)
						{
							if(oArgs.oData.repositoriums[sKey].files.constructor === Array)
							{
								for(var i = 0; i<oArgs.oData.repositoriums[sKey].files.length; i++)
								{
									oArgs.oData.repositoriums[sKey].files[i].repo_id = sKey;
									aFiles.push(oArgs.oData.repositoriums[sKey].files[i]);
								}
							}
						}
					}
					this.oStore["files"] = new CXDataStore({ oPlayer: this, oData: aFiles });
				}
				if(oArgs.oData.file_types != null)
				{
					this.oStore["file_types"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.file_types });
				}
				this.oPages["resources"].Fill();
				this.oMenu["top"].oItems["resources"].oBtn.Enable();
				break;
			}
 			case "parse_data_step_3":
			{
				this.oLoader.oLoadingBar.set(40);
				this.oStore["macros"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.macros });
				this.oLoader.oLoadingBar.set(43);
				this.oStore["templates"] = new CXDataStore({ oPlayer: this, oData: oArgs.oData.templates });
				this.oLoader.oLoadingBar.set(48);
				this.CreateTemplatesParamTree();
				this.oLoader.oLoadingBar.set(50);
				setTimeout(function () { oThis.oPages["desktop"].Fill(); }, 50);
				this.oLoader.oLoadingBar.set(100);
				this.oPages["pages"].oBtns["run-editor"].Enable();
				this.oLoader.Hide();
				break;
			}
       }
        return this;
    };
    LPE.prototype.Page = function(oArgs)
	{
        this.oPages[oArgs.oThis.aSelected[0]].Show();
        return this;
    };
}

{ // CXLoader
    window.CXLoader = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jContainer = this.oPlayer.jContainer;
        this.sId = TOOLS.GUID();
        this.jMask = null;
        this.jMaskLoader = null;
        this.Constructor();
        return this;
    };
    CXLoader.prototype.Constructor = function(oArgs)
	{
        if(this.jMask == null)
		{
            this.jMask = this.jContainer.find("[cx-role='loader']");
        }
        if(this.jMaskLoader == null)
		{
            this.jMaskLoader = this.jMask.find("[cx-role='mask-loader']");
			this.oLoadingBar = new ldBar(this.jMaskLoader[0]);
			this.oLoadingBar.set(0);
		}
        return this;
    };
    CXLoader.prototype.Hide = function(oArgs)
	{
        this.jMask.fadeOut(250);
        return this;
    };
    CXLoader.prototype.Show = function(oArgs)
	{
        this.jMask.show();
        return this;
    };
}
{ // CXMask
    window.CXMask = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jContainer = this.oPlayer.jContainer;
        this.sId = TOOLS.GUID();
        this.jMask = null;
        this.jMaskLoader = null;
        this.jMaskCurtain = null;
        this.bOn = false;
        this.Constructor();
        return this;
    };
    CXMask.prototype.Constructor = function(oArgs)
	{
        if(this.jMask == null)
		{
            this.jMask = this.jContainer.find("[cx-role='mask']");
        }
        if(this.jMaskLoader == null)
		{
            this.jMaskLoader = this.jMask.find("[cx-role='mask-loader']");
        }
        if(this.jMaskCurtain == null)
		{
            this.jMaskCurtain = this.jMask.find("[cx-role='mask-curtain']");
        }
		this.oLoadingBar = new ldBar(this.jMaskLoader[0]);
        return this;
    };
    CXMask.prototype.Hide = function(oArgs)
	{
        if(this.jMaskCurtain.is(":visible"))
		{
            this.jMaskLoader.hide();
            this.jMaskCurtain.fadeOut(1000);
            this.jMask.fadeOut(1000);
        }
		else
		{
            this.jMask.hide();
        }
        this.bOn = false;
        return this;
    };
    CXMask.prototype.Show = function(oArgs)
	{
		if(oArgs==null)
		{
			oArgs = {};
		}
        var iWH = $(window).height();
        var iDH = this.jContainer.height();
        if(iDH > iWH) {
            iWH = iDH;
        }
        this.jMask.height(iWH).show();
        if(oArgs.bDark == true)
		{
            this.jMask.attr({ "wt-skin": "dark" });
        }
		else
		{
			this.jMask.removeAttr("wt-skin");
		}
        if(oArgs.bCurtain == true)
		{
            this.jMaskCurtain.show();
        }
        if(oArgs.bPlain == true)
		{
            this.jMaskLoader.hide();
        }
		else
		{
            this.jMaskLoader.show();
        }
        if(oArgs.z != null)
		{
            this.jMask.css({ "z-index": oArgs.z });
        }
		else
		{
            this.jMask.css({ "z-index": "" });
        }
        this.bOn = true;
        return this;
    };
}
{ // CXUI
    window.CXUI = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.Constructor();
        return this;
    };
    CXUI.prototype = Object.create(WTBaseObject.prototype);
    CXUI.prototype.constructor = CXUI;
    CXUI.prototype.Constructor = function()
	{
        var oThis = this;
        this.jLangSelector = this.jContainer.find("[cx-role='lang-select']").on("change", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, sAction: "lang-select" }); });
        // strings and titles
        this.jContainer.find("[cx-string]").each(function() { this.innerHTML = oThis.oPlayer._GetString({ sId: this.getAttribute("cx-string") }); });
        this.jContainer.find("[cx-title]").each(function() { this.setAttribute("title", oThis.oPlayer._GetString({ sId: this.getAttribute("cx-title") })); });

        var aPageGroups = [];
        var aPageGroupsToRemove = [];
        var aPages = [];
        var aPagesToRemove = [];
        var jPageGroup;
        var jPage;
        var i;
        var j;
        // cleanup unused pages and groups
        this.jContainer.find("[cx-page-group]").each(function() { aPageGroupsToRemove.push(this.getAttribute("cx-page-group")); });
        for(i=0; i<this.oPlayer.oSettings.pagegroups.length; i++)
		{
            jPageGroup = this.jContainer.find("[cx-page-group='" + this.oPlayer.oSettings.pagegroups[i].id + "']");
            if(jPageGroup.length != 0)
			{
                this.oPlayer.oPageGroups[this.oPlayer.oSettings.pagegroups[i].id] = new CXPageGroup({ oPlayer: this.oPlayer, sId: this.oPlayer.oSettings.pagegroups[i].id, oItem: this.oPlayer.oSettings.pagegroups[i], jContainer: jPageGroup });
                aPageGroups.push(this.oPlayer.oSettings.pagegroups[i].id);
                aPages = [];
                aPagesToRemove = [];
                jPageGroup.find("[cx-page]").each(function()
				{
					aPagesToRemove.push(this.getAttribute("cx-page"));
				});
                for(j=0; j<this.oPlayer.oSettings.pagegroups[i].pages.length; j++)
				{
                    jPage = jPageGroup.find("[cx-page='" + this.oPlayer.oSettings.pagegroups[i].pages[j].id + "']");
                    if(jPage.length != 0)
					{
                        this.oPlayer.oPages[this.oPlayer.oSettings.pagegroups[i].pages[j].id] = new CXPage({ oPlayer: this.oPlayer, sId: this.oPlayer.oSettings.pagegroups[i].pages[j].id, oItem: this.oPlayer.oSettings.pagegroups[i].pages[j], jContainer: jPage, oPageGroup: this.oPlayer.oPageGroups[this.oPlayer.oSettings.pagegroups[i].id] });
                        aPages.push(this.oPlayer.oSettings.pagegroups[i].pages[j].id);
                    }
					else
					{
                        this.oPlayer.oSettings.pagegroups[i].pages[j].INVALID = true;
                    }
                }
                if(aPagesToRemove.length != aPages.length)
				{
                    for(j=0; j<aPages.length; j++)
					{
                        aPagesToRemove.splice($.inArray(aPages[j], aPagesToRemove), 1);
                    }
                    for(j=0; j<aPagesToRemove.length; j++)
					{
                        jPageGroup.find("[cx-page='" + aPagesToRemove[j] + "']").remove();
                    }
                }
            }
			else
			{
                this.oPlayer.oSettings.pagegroups[i].INVALID = true;
            }
        }
        if(aPageGroupsToRemove.length != aPageGroups.length)
		{
            for(i=0; i<aPageGroups.length; i++)
			{
                aPageGroupsToRemove.splice($.inArray(aPageGroups[i], aPageGroupsToRemove), 1);
            }
            for(i=0; i<aPageGroupsToRemove.length; i++)
			{
                this.jContainer.find("[cx-page-group='" + aPageGroupsToRemove[i] + "']").remove();
            }
        }
        // menus
        aPageGroups = [];
        for(i=0; i<this.oPlayer.oSettings.pagegroups.length; i++)
		{
            aPageGroups.push({ sId: this.oPlayer.oSettings.pagegroups[i].id, aItems: [] });
            for(j=0; j<this.oPlayer.oSettings.pagegroups[i].pages.length; j++)
			{
                aPageGroups[i].aItems.push({ sId: this.oPlayer.oSettings.pagegroups[i].pages[j].id, sType: this.oPlayer.oSettings.pagegroups[i].pages[j].type, sName: (this.oPlayer.oSettings.pagegroups[i].pages[j].name != "" ? this.oPlayer.oSettings.pagegroups[i].pages[j].name : this.oPlayer._GetString({ sId: this.oPlayer.oSettings.pagegroups[i].pages[j].string })) });
            }
        }
        this.oPlayer.oMenu["top"] = new CXMenu({ oPlayer: this.oPlayer, sId: "top", sType: "top", jContainer: this.oPlayer.jNav, aGroups: aPageGroups });
        return this;
    };
    CXUI.prototype.UIEvent = function(oArgs)
	{
        if(oArgs != null)
		{
            if(oArgs.oElem != null)
			{
                switch(oArgs.oElem.getAttribute("cx-role"))
				{
                    case "lang-select":
					{
						var sLang = $(oArgs.oElem).val();
						TOOLS.Cookie.Set({ sName: "lp_lang_" + this.oPlayer.sCurrentUserId, sValue: sLang, oProps: { path: "/", domain: document.location.hostname, expires: 2592000 } });
						if(sLang != this.oPlayer.oConfig.sLang)
						{
							document.location.reload();
						}
						break;
					}
                }
            }
        }
        return this;
    };
}
{ // CXPageGroup
    window.CXPageGroup = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.bVisible = false;
        this.oPages = {};
        this.Constructor();
        return this;
    };
    CXPageGroup.prototype = Object.create(WTBaseObject.prototype);
    CXPageGroup.prototype.constructor = CXPageGroup;
    CXPageGroup.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        return this;
    };
    CXPageGroup.prototype.Hide = function(oArgs)
	{
        this.jContainer.hide();
        this.bVisible = false;
        return this;
    };
    CXPageGroup.prototype.Show = function(oArgs)
	{
        var sKey;
        for(sKey in this.oPlayer.oPageGroups)
		{
            if(this.oPlayer.oPageGroups.hasOwnProperty(sKey))
			{
                if(sKey != this.sId)
				{
                    this.oPlayer.oPageGroups[sKey].Hide();
                }
				else
				{
                    this.jContainer.show();
                    this.bVisible = true;
                }
            }
        }
        return this;
    };
}
{ // CXPage
    window.CXPage = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oBtns = {};
        this.oDialogs = {};
        this.oFlds = {};
        this.bVisible = false;
        this.oList = null;
        this.oCurrentObjectDialog = null;
		this.oBuilders = {};
        this.Constructor();
        return this;
    };
    CXPage.prototype = Object.create(WTBaseObject.prototype);
    CXPage.prototype.constructor = CXPage;
    CXPage.prototype._CleanupBeforeSend = function(oArgs)
	{
        var i, j, k, l;
        var oToSave = oArgs.oToClean;

        delete oToSave.web_mode.error;
        delete oToSave.web_mode.error_text;
        delete oToSave.web_mode._sortname;
        delete oToSave.web_mode.url;
        delete oToSave.web_mode.modification_date;
        delete oToSave.web_mode.creation_date;
        if(oToSave.web_mode.collections != null)
		{
            delete oToSave.web_mode.collections;
        }
        if(oToSave.web_mode.all_collections != null)
		{
            delete oToSave.web_mode.all_collections;
        }
        if(oToSave.web_mode.remote_actions != null)
		{
            delete oToSave.web_mode.remote_actions;
        }
        if(oToSave.web_mode.all_actions != null)
		{
            delete oToSave.web_mode.all_actions;
        }
        if(oToSave.web_mode.object_fields != null)
		{
            delete oToSave.web_mode.object_fields;
        }
        if(oToSave.web_mode.user_fields != null)
		{
            delete oToSave.web_mode.user_fields;
        }
        if(oToSave.web_mode.context != null)
		{
            delete oToSave.web_mode.context;
        }
        if(oToSave.web_mode.env != null)
		{
            delete oToSave.web_mode.env;
        }
        if(oToSave.web_mode.doc_fields != null)
		{
            delete oToSave.web_mode.doc_fields;
        }

        if(oToSave.web_mode.zones != null)
		{
            if(oArgs.bCleanZones)
			{
                oToSave.web_mode.zones = [];
            }
			else
			{
                for(i=0; i<oToSave.web_mode.zones.length; i++)
				{
                    if(oToSave.web_mode.zones[i].name == "main")
					{
                        for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
						{
                            if(oToSave.web_mode.zones[i].templates[j] == null)
							{
                                continue;
                            }
                            delete oToSave.web_mode.zones[i].templates[j].name;
                            delete oToSave.web_mode.zones[i].templates[j].url;
                            if(oToSave.web_mode.zones[i].templates[j].templates != null)
							{
                                for(k=0; k<oToSave.web_mode.zones[i].templates[j].templates.length; k++)
								{
                                    delete oToSave.web_mode.zones[i].templates[j].templates[k]._sortname;
                                    delete oToSave.web_mode.zones[i].templates[j].templates[k].url;
                                    if(oArgs.bNoParams)
									{
                                        delete oToSave.web_mode.zones[i].templates[j].templates[k].params;
                                    }
									else
									{
                                        if(oToSave.web_mode.zones[i].templates[j].templates[k].params != null)
										{
                                            for(l = 0; l < oToSave.web_mode.zones[i].templates[j].templates[k].params.length; l++)
											{
                                                delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].catalog;
                                                delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].entries;
                                                delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].description;
                                                delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].view;
                                            }
                                        }
                                    }
                                }
                            }
                            if(oArgs.bNoParams)
							{
                                delete oToSave.web_mode.zones[i].templates[j].params;
                            }
							else
							{
                                if(oToSave.web_mode.zones[i].templates[j].params != null)
								{
                                    for(l = 0; l < oToSave.web_mode.zones[i].templates[j].params.length; l++)
									{
                                        delete oToSave.web_mode.zones[i].templates[j].params[l].catalog;
                                        delete oToSave.web_mode.zones[i].templates[j].params[l].entries;
                                        delete oToSave.web_mode.zones[i].templates[j].params[l].description;
                                        delete oToSave.web_mode.zones[i].templates[j].params[l].view;
                                    }
                                }
                            }
                        }
                        var aTmp = [];
                        for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
						{
                            if(oToSave.web_mode.zones[i].templates[j] != null)
							{
                                aTmp.push(oToSave.web_mode.zones[i].templates[j]);
                            }
                        }
                        oToSave.web_mode.zones[i].templates = JSON.parse(JSON.stringify(aTmp));
                    }
                }
            }
        }
        return oToSave;
    };
    CXPage.prototype._Validate = function(oArgs)
	{
        var oThis = this;
        var bAllMet = true;
        var i, j, k;
        var re;
		var bCopyMode = (oArgs!=null && oArgs.bCopyMode==true);
        this.jCard.find("[cx-validation]").each(function(iIdx)
		{
            var sValue = $(this).val();
            if(!(oThis.sCurrentUserId == "" && this.getAttribute("cx-role") == "password"))
			{
                var aChecks = this.getAttribute("cx-validation").split(";");
                var sCheck;
                var bYes = true;
                for(i=0; i<aChecks.length; i++)
				{
                    sCheck = $.trim(aChecks[i]);
                    switch(sCheck)
					{
                        case "empty":
						{
							bYes = bYes && (sValue.length != 0);
							break;
						}
                        case "alphanumeric":
						{
							re = /^[a-zA-Z0-9!@#$&()\\-`\-.+,/\"]*$/gi;
							bYes = bYes && (re.test(sValue));
							break;
						}
						case "shortset":
						{
							re = /^[a-zA-Z0-9-_.]*$/gi;
							bYes = bYes && (re.test(sValue));
							break;
						}
                        case "email":
						{
							re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
							bYes = bYes && (re.test(sValue.toLowerCase()));
							break;
						}
                        case "number":
						{
							bYes = bYes && (typeof + sValue == "number");
							break;
						}
						default:
						{
							if(sCheck.indexOf("unique") == 0)
							{
								if(sValue != "")
								{
									if(oThis.sCurrentPageId == "" || bCopyMode || (oThis.sCurrentPageId != "" && sValue != oThis.oList.oItems[oThis.sCurrentPageId].oItem[this.getAttribute("name")]))
									{
										if(sValue.length != 0)
										{
											var aPairs = sCheck.split("|");
											var aChunks;
											var sStore = "";
											var sFld = "";
											var aArray = null;
											var aArrayNameParts;
											for(j = 1; j<aPairs.length; j++)
											{
												aChunks = aPairs[j].split("=");
												if(aChunks[0] == "store")
												{
													sStore = aChunks[1];
												}
												else if(aChunks[0] == "fld")
												{
													sFld = aChunks[1];
												}
												else if(aChunks[0] == "array")
												{
													aArrayNameParts = aChunks[1].split(".");
													aArray = oThis;
													for(k=0; k<aArrayNameParts.length; k++)
													{
														aArray = aArray[aArrayNameParts[k]];
													}
												}
											}
											if(sStore != "" && sFld != "")
											{
												for(var sKey in oThis.oPlayer.oStore[sStore].oData)
												{
													if(bCopyMode || sKey!=oThis.sCurrentPageId )
													{
														if(oThis.oPlayer.oStore[sStore].oData[sKey][sFld] == sValue)
														{
															bYes = false;
															break;
														}
													}
												}
											}
											else if(aArray != null)
											{
												if(aArray.constructor === Array)
												{
													if($.inArray(sValue, aArray) != -1)
													{
														bYes = false;
													}
												}
											}
										}
									}
								}
							}
							else
							{
								if(sCheck.indexOf("length") != -1)
								{
									var aParts = sCheck.split("-");
									if(aParts.length > 1)
									{
										var iLength = parseInt(aParts[1], 10);
										if(!isNaN(iLength))
										{
											bYes = bYes && (sValue.length >= iLength);
										}
									}
								}
							}
							break;
						}
                    }
                }
                if(bYes)
				{
                    this.removeAttribute("cx-invalid");
                    if(this.hasAttribute("cx-selectmenu"))
					{
                        $(this).siblings("[role='combobox']").removeAttr("cx-invalid");
                    }
                }
				else
				{
                    this.setAttribute("cx-invalid", "1");
                    if(this.hasAttribute("cx-selectmenu"))
					{
                        $(this).siblings("[role='combobox']").attr({ "cx-invalid": "1" });
                    }
                }
                bAllMet = bAllMet && bYes;
            }
        });
        return bAllMet;
    };
    CXPage.prototype.AdjustHint = function(oArgs)
	{
		var oThis = this;
		var jHint = (oArgs==null ? this.jHintContainer : oArgs.jHint);
		var nL = this.jSlideBlock.width() - jHint.outerWidth(true);
		var nH = this.jSlideBlock.height();
		var nT = this.jNavLeft.offset().top + this.jNavLeft.outerHeight(true);
		this.oPlayer.oMask.Show({ bPlain: true, bDark: true });
		this.oPlayer.oMask.jMask.one("click", function () { oThis.HideHint(); });
		jHint.appendTo("body").css({ "left": nL + "px", "top": nT + "px", "height": nH + "px" }).animate({ "opacity": 1 }, 250);
		return this;
	};
    CXPage.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jPage = this.jContainer;
        this.jBody = this.jPage.children("[cx-role='page-body']");
		this.jNavLeft = this.jPage.find("[cx-role='panel-left'] [cx-role='page-nav']");
        this.jNav = this.jPage.find("[cx-role='panel-right'] [cx-role='page-nav']");
        this.jPanel = this.jPage.find("[cx-role='panel-right']");
        this.jPage.find("[cx-btn]").each(function(i)
		{
            var sId = this.getAttribute("cx-btn");
            oThis.oBtns[sId] = new CXBtn({ oPlayer: oThis.oPlayer, jContainer: oThis.jPage, jBtn: $(this), fn: oThis.UIEvent, oArgs: { oContext: oThis } });
        });
        this.sFilterValue = "";
        switch(this.sId)
		{
            case "pages":
			{
				if(!this.oPlayer.oAccess.bEdit)
				{
					this.oBtns["new-page"].jBtn.remove();
					this.oBtns["pages-edit"].jBtn.remove();
					this.oBtns["run-editor"].jBtn.remove();
				}
				else
				{
					if(!this.oPlayer.oAccess.bCreate)
					{
						this.oBtns["new-page"].jBtn.remove();
					}
					if(!this.oPlayer.oAccess.bDelete)
					{
						this.oBtns["pages-delete"].jBtn.remove();
					}
				}
				this.oSearch = new CXSearch({ oPlayer: this.oPlayer, oPage: this, oBtn: this.oBtns["search"], jBox: this.jPage.find("[cx-role='search-box']") });
				this.oIsStd = new CXCheckBox({ oPlayer: this.oPlayer, sName: "is_std", jBox: this.jPage.find("[cx-role='fld-is-std'] [cx-role='checkbox']"), sValueChecked: false });
				this.jDesignFilter = this.jPage.find("[cx-role='design-filter']");
				this.jPagesList = this.jBody.find("[cx-role='list-body']");
				this.jPageItemTemplate = this.oPlayer.jStorage.find("[cx-template='item-page']");
				this.jNoneSelected = this.jBody.find("[cx-role='nothing-selected']").css({ "display": "flex" });
				this.jFilter = this.jPage.find("[cx-role='filter-selector']").selectmenu({ change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
				this.jCard = this.jBody.find("[cx-role='page-card']").hide();
				this.jForm = this.jCard.find("form");
				this.jPageData = this.jCard.find("[cx-role='page-properties']");
				this.jFldPageId = this.jCard.find("[cx-role='page-id']");
				this.jFldPageName = this.jCard.find("[cx-role='page-name']").on("keyup", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
				this.jPageNameValue = this.jCard.find("[cx-role='page-name-value']");
				this.jPageCodeBlock = this.jCard.find("[cx-role='fld-code']");
				this.jFldPageCode = this.jCard.find("[cx-role='page-code']").on("keyup", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
				this.jPageCodeValue = this.jCard.find("[cx-role='page-code-value']");
				if(this.oPlayer.oConfig.sMode != "simple")
				{
					this.jFldPagePlaceholder = this.jCard.find("[cx-role='page-placeholder']").attr({ "cx-selectmenu": "1" }).selectmenu({ classes: { "ui-selectmenu-button": "cx-selectmenu-button" }, change: function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); } });
					this.jFldPagePlaceholderValue = this.jCard.find("[cx-role='page-placeholder-value']");
					this.jPagePlaceholderBlock = this.jCard.find("[cx-role='fld-placeholder']");
				}
				else
				{
					this.jCard.find("[cx-role='fld-placeholder']").remove();
				}
				this.jPageModifiedBlock = this.jCard.find("[cx-role='fld-modified']");
				this.jPageModifiedValue = this.jCard.find("[cx-role='page-modified-value']");
				this.jPageObjectFldBlock = this.jCard.find("[cx-role='fld-object-type']");
				this.jPageObjectFld = this.jPageObjectFldBlock.find("[cx-role='object-type-fld']");
				this.jDesignBlock = this.jCard.find("[cx-role='fld-design']");
				this.jDesignFld = this.jCard.find("[cx-role='design-fld']");
				this.jAnonymousBlock = this.jCard.find("[cx-role='fld-anonymous']");
				this.jFldAnonymous = this.jAnonymousBlock.find("[cx-role='anonymous']").on("keyup", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
				this.jAnonymousEditable = this.jAnonymousBlock.find("[cx-role='anonymous-editable']").hide();
				this.jAnonymousValues = this.jAnonymousBlock.find("[cx-role='anonymous-values']");
				this.jAnonymousValueTrue = this.jAnonymousBlock.find("[cx-role='anonymous-value-true']").hide();
				this.jAnonymousValueFalse = this.jAnonymousBlock.find("[cx-role='anonymous-value-false']");
				this.oAnonymousCheckBox = new CXCheckBox({ oPlayer: this.oPlayer, sName: "anonymous", jBox: this.jAnonymousBlock.find("[cx-role='checkbox']"), sValueChecked: "1" });
				this.oAnonymousCheckBox.Subscribe({ sId: "anonymous", sEvent: "change", fn: oThis.UIEvent, oContext: oThis, oArgs: { oElem: oThis.jFldAnonymous[0], oThis: oThis, oEvt: { type: "change" } } });
				this.jMandatoryMarks = this.jCard.find("[cx-role='mandatory']");
				this.jCopyModeBlock = this.jCard.find("[cx-role='copy-block']");
				this.jMandatoryWarning = this.jCard.find("[cx-role='mandatory-warning']");
				this.jCopyWarning = this.jCard.find("[cx-role='copy-warning']");
				this.jIsStdWarning = this.jCard.find("[cx-role='is-std-warning']");
				this.jIsStdAllowedWarning = this.jCard.find("[cx-role='is-std-allowed-warning']");
				this.jMsgAlreadyOpen = this.jNav.find("[cx-role='msg-already-open']");
				this.oItems = {};
				this.aSearchTargets = ["name"];
				break;
			}
            case "resources":
			{
				if(!this.oPlayer.oAccess.bEdit) {
					this.oBtns["new-resource"].jBtn.remove();
					this.oBtns["resources-edit"].jBtn.remove();
				} else {
					if(!this.oPlayer.oAccess.bCreate) {
						this.oBtns["new-resource"].jBtn.remove();
					}
					if(!this.oPlayer.oAccess.bDelete) {
						this.oBtns["resources-delete"].jBtn.remove();
					}
				}
				this.oSearch = new CXSearch({ oPlayer: this.oPlayer, oPage: this, oBtn: this.oBtns["search"], jBox: this.jPage.find("[cx-role='search-box']") });
				this.jResourceList = this.jBody.find("[cx-role='list-body']");
				this.jResourceItemTemplate = this.oPlayer.jStorage.find("[cx-template='item-resource']");
				this.jNoneSelected = this.jBody.find("[cx-role='nothing-selected']").css({ "display": "flex" });
				this.jFilter = this.jPage.find("[cx-role='filter-selector']").selectmenu({ classes: { "ui-selectmenu-menu": "cx-resources-menu" }, change: function(e) { oThis.UIEvent({ oElem: this, oEvt: e, oThis: oThis }); } });
				this.jCard = this.jBody.find("[cx-role='resource-card']").hide();
				this.jForm = this.jCard.find("form");
				this.jPageData = this.jCard.find("[cx-role='page-resource-basic']");
				this.jResourceId = this.jCard.find("[cx-role='form-resource-id']");
				this.jInitialRepoId = this.jCard.find("[cx-role='form-initial-repo-id']");
				this.jResourceAction = this.jCard.find("[cx-role='form-action']");
				this.jResourceTags = this.jCard.find("[cx-role='resource-tags']").on("keyup", function(e, ui) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
				this.jResourceFolder = this.jCard.find("[cx-role='resource-folder']").selectmenu({ classes: { "ui-selectmenu-menu": "cx-resources-menu" }, change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
				this.jResourceFolderValue = this.jCard.find("[cx-role='resource-folder-value']");
				this.jResourceNameBlock = this.jCard.find("[cx-role='fld-name']");
				this.jResourceName = this.jCard.find("[cx-role='resource-name']");
				this.jResourceNameValue = this.jCard.find("[cx-role='resource-name-value']");
				this.jResourceFileNameValue = this.jCard.find("[cx-role='resource-filename-value']");
				this.jResourceTagsValue = this.jCard.find("[cx-role='resource-tags-value']");
				this.jResourceTypeBlock = this.jCard.find("[cx-role='fld-type']");
				this.jResourceSizeBlock = this.jCard.find("[cx-role='fld-size']");
				this.jResourceModifiedBlock = this.jCard.find("[cx-role='fld-modified']");
				this.jResourceTypeValue = this.jCard.find("[cx-role='resource-type-value']");
				this.jResourceSizeValue = this.jCard.find("[cx-role='resource-size-value']");
				this.jResourceModifiedValue = this.jCard.find("[cx-role='resource-modified-value']");
				this.jMandatoryMarks = this.jCard.find("[cx-role='mandatory']");
				this.jMandatoryWarning = this.jCard.find("[cx-role='mandatory-warning']");
				this.jIcon = this.jCard.find("[cx-role='icon']");
				this.jIconImg = this.jIcon.find("[cx-role='icon-img']");
				this.jImgFld = this.jCard.find("[cx-role='resource-img']").on("change", function(e, ui) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
				this.jImgFldInstruction = this.jIcon.find("[cx-role='img-fld-instruction']");
				this.jImgBtn = this.jCard.find("[cx-role='module-img-btn']");
				this.jStatsList = this.jCard.find("[cx-role='stats-list']");
				this.jStatsTable = this.jCard.find("[cx-role='stats-table-body']");
				this.jNoStats = this.jCard.find("[cx-role='no-stats-yet']");
				// s.tachkov
				this.jResourceTempLink = this.jBody.find("[cx-role='a-download-resource']");
				this.jResourceStatus = this.jCard.find("[cx-role='resource-status']").selectmenu();
				this.jResourceStatusValue = this.jCard.find("[cx-role='resource-status-value']");
				// / s.tachkov
				this.oItems = {};
				this.aSearchTargets = ["name"];

				// TODO: / a.rakhimzhanov

				//			this.oResourceTags = new CXTagList({ oPlayer: this.oPlayer, jPage: this.jPage, jCard: this.jCard, sTypeObject: "files" });

				// FIXME: / Rakhimhznaov.A
				break;
			}
            case "desktop":
			{
				this.jPageTitle = this.jPage.find("[cx-role='editor-title']");
				this.jSlideBlock = this.jBody.find("[cx-role='slide-block']");
				this.jSlideContainer = this.jBody.find("[cx-role='slide-container']");
				this.jViewContainer = this.jBody.find("[cx-role='view-container']");
				this.jSlide = this.jSlideContainer.find("[cx-role='slide']");
				this.jContextBlock = this.jBody.find("[cx-role='context-block']");
				this.jContextTitle = this.jContextBlock.find("[cx-role='context-title']");
				this.jContextSwitch = this.jContextBlock.find("[cx-role='context-switch']");
				this.jContextBody = this.jContextBlock.find("[cx-role='context-body']");
				this.jContextNothingSelected = this.jContextBlock.find("[cx-role='nothing-selected']");
				this.jContextNoParams = this.jContextBlock.find("[cx-role='no-params']");
				this.jContextContextTitle = this.jContextBlock.find("[cx-role='context-title']");
				this.oDialogs["selectfile"] = new CXDialog({ oPlayer: oThis.oPlayer, oPage: this, jContainer: oThis.oPlayer.jContainer, sId: "selectfile", sType: "select-file" });
				this.jTestObjectContainer = this.jPage.find("[cx-role='test-object-container']");
				this.jTestObjectValue = this.jPage.find("[cx-role='test-object-value']");
				this.jHintContainer = this.jPage.find("[cx-role='hint-container']").hide();
				this.jRuleBuilderContainer = this.jPage.find("[cx-role='rule-builder-container']").hide();
				this.jBtnHintUser = this.jHintContainer.find("[cx-role='btn-test-user-hint']");
				this.jBtnHintObject = this.jHintContainer.find("[cx-role='btn-test-object-hint']");
				this.jBtnHintContext = this.jHintContainer.find("[cx-role='btn-test-context-hint']");
				this.jBtnHintEnv = this.jHintContainer.find("[cx-role='btn-test-env-hint']");
				this.jBtnHintDoc = this.jHintContainer.find("[cx-role='btn-test-doc-hint']");
				this.jBtnHintLocal = this.jHintContainer.find("[cx-role='btn-test-local-hint']");
				this.jHintContainer.find("[cx-role='btn-hint-close']").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
				this.jHintList = this.jHintContainer.find("[cx-role='hint-list']");
				this.jHintListItemTemplate = this.oPlayer.jStorage.find("[cx-template='hint-list-item']");
				this.jSelectContainer = this.jPage.find("[cx-role='select-container']").hide();
				this.jSelectContainer.find("[cx-role='btn-hint-close']").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
				this.jSelectHeader = this.jSelectContainer.find("[cx-role='select-header']");
				this.jSelectList = this.jSelectContainer.find("[cx-role='select-list']");
				this.jSelectThrobber = this.jSelectContainer.find("[cx-role='select-throbber']");
				this.jSelectNoData = this.jSelectContainer.find("[cx-role='select-no-data']");
				this.jSelectError = this.jSelectContainer.find("[cx-role='select-error']");
				this.jSelectFilterFld = this.jSelectContainer.find("[cx-role='select-filter-fld']").on("keyup", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
				this.jSelectListItemTemplate = this.oPlayer.jStorage.find("[cx-template='select-list-item']");
				this.oBuilders["rule"] = new CXBuilder({ oPlayer: this.oPlayer, oPage: this, sType: "rule", jContainer: this.jSlideBlock });
				this.oBuilders["map"] = new CXBuilder({ oPlayer: this.oPlayer, oPage: this, sType: "map", jContainer: this.jSlideBlock });
				break;
			}
        }
        return this;
    };
    CXPage.prototype.Disable = function(oArgs)
	{
        this.jPanel.removeAttr("cx-state");
        switch(this.sId)
		{
            case "pages":
			{
				this.jFldPageName.prop("disabled", true).hide();
				this.jPageNameValue.show();
				//this.jPageCodeBlock.show();
				this.jFldPageCode.prop("disabled", true).hide();
				this.jPageObjectFld.selectmenu("disable");
				this.jPageObjectFldBlock.show();
				this.jAnonymousBlock.show();
				this.jDesignBlock.show();
				this.jDesignFld.selectmenu("disable");
				this.jAnonymousEditable.hide();
				this.jAnonymousValues.show();
				this.jPageCodeValue.show();
				if(this.oPlayer.oConfig.sMode != "simple")
				{
					this.jFldPagePlaceholder.selectmenu("widget").hide();
					this.jFldPagePlaceholderValue.show();
				}
				this.jPageModifiedBlock.show();
				this.jMandatoryMarks.hide();
				this.jMandatoryWarning.hide();
				this.jIsStdWarning.hide();
				this.jIsStdAllowedWarning.hide();
				this.jCopyWarning.hide();
				this.jCopyModeBlock.show();
				this.jCard.find("[cx-invalid]").removeAttr("cx-invalid");
				this.jFilter.selectmenu("enable");
				this.oBtns[this.sId + "-delete"].Hide();
				this.oBtns[this.sId + "-edit"].Show().Enable();
				this.oBtns[this.sId + "-submit"].Hide();
				this.oBtns[this.sId + "-copy"].Hide();
				this.oBtns[this.sId + "-cancel"].Hide();
				if(this.sCurrentPageId == this.oPlayer.sCurrentPageId)
				{
					this.jMsgAlreadyOpen.show();
					this.oBtns["run-editor"].Hide();
				}
				else
				{
					this.oBtns["run-editor"].Show();
					this.jMsgAlreadyOpen.hide();
				}
				break;
			}
			case "resources":
			{
				this.jResourceName.hide();
				this.jResourceNameValue.show();
				this.jResourceFolder.selectmenu("disable").selectmenu("widget").hide();
				this.jResourceFolderValue.show();
				this.jResourceTags.hide();
				this.jResourceTagsValue.show();
				this.jResourceTypeBlock.show();
				this.jResourceSizeBlock.show();
				this.jResourceModifiedValue.show();
				this.jMandatoryMarks.hide();
				this.jMandatoryWarning.hide();
				this.jCard.find("[cx-invalid]").removeAttr("cx-invalid");
				this.jIcon.attr({ "cx-state": "disabled" });
				this.jImgFld.prop("disabled", true);
				this.jImgFldInstruction.hide();
				this.oBtns[this.sId + "-delete"].Hide();
				this.oBtns[this.sId + "-edit"].Show().Enable();
				this.oBtns[this.sId + "-submit"].Hide();
				this.oBtns[this.sId + "-cancel"].Hide();
				this.oBtns["download-resource"].Show();
				this.jResourceStatus.selectmenu("disable").selectmenu("widget").hide();
				this.jResourceStatusValue.show();
				break;
			}
        }
        this.bDisabled = true;
        return this;
    };
    CXPage.prototype.DisableTemplateBtns = function(oArgs)
	{
        this.oBtns["template-submit"].Disable();
        this.oBtns["template-cancel"].Disable();
        return this;
    };
    CXPage.prototype.Display = function(oArgs)
	{
        var oThis = this;
        switch(this.sId)
		{
            case "pages":
			{
				this.jIsStdWarning.hide();
				this.jIsStdAllowedWarning.hide();
				if(oArgs.bEmpty)
				{
					this.sCurrentPageId = "";
					this.jNav.hide();
					this.jNoneSelected.show();
					this.jCard.css({ "display": "none" });
					this.oBtns["new-page"].Enable();
					this.oBtns[this.sId + "-submit"].Hide();
					this.oBtns[this.sId + "-copy"].Hide();
					this.oBtns[this.sId + "-cancel"].Hide();
					this.oBtns[this.sId + "-edit"].Show().Disable();
					this.oBtns[this.sId + "-delete"].Hide();
					this.oBtns["run-editor"].Hide();
					this.jFilter.selectmenu("enable");
					this.oSearch.Enable();
				}
				else
				{
					this.sCurrentPageId = oArgs.sId;
					this.jNav.show();
					this.jNoneSelected.hide();
					this.jCard.css({ "display": "flex" });
					this.jFldPageId.val(this.sCurrentPageId);
					if(oArgs.sId == "")
					{
						this.jFldPageName.val("");
						this.jPageNameValue.html("");
						this.jFldPageCode.val("");
						this.jFldAnonymous.val("0");
						this.jPageObjectFld.val("").selectmenu("refresh");
						this.jDesignFld.val("").selectmenu("refresh");
						this.oAnonymousCheckBox.SetValue({ bCheck: false });
						this.jPageCodeValue.html("");
						if(this.oPlayer.oConfig.sMode != "simple")
						{
							this.jFldPagePlaceholder.val("").selectmenu("refresh");
						}
						this.jPageModifiedValue.html("");
						this.jAnonymousEditable.hide();
						this.jAnonymousValueTrue.hide();
						this.jAnonymousValueFalse.show();
						this.jPageData.css({ "display": "flex" });
						this.oBtns["new-page"].Disable();
						this.oBtns[this.sId + "-submit"].Disable();
						this.Enable();
					}
					else
					{
						var oCurStoreItem = this.oPlayer.oStore.webmodes.oData[oArgs.sId];
						this.jFldPageName.val(oCurStoreItem.name);
						this.jPageNameValue.html(oCurStoreItem.name);
						this.jFldPageCode.val(oCurStoreItem.code);
						this.jPageCodeValue.html(oCurStoreItem.code);
						this.jPageObjectFld.val(oCurStoreItem.catalog_name).selectmenu("refresh");
						this.jDesignFld.val(oCurStoreItem.web_design_id).selectmenu("refresh");
						this.jAnonymousEditable.hide();
						if(oCurStoreItem.enable_anonymous_access)
						{
							this.oAnonymousCheckBox.SetValue({ bCheck: true });
							this.jAnonymousValueTrue.show();
							this.jAnonymousValueFalse.hide();
						}
						else
						{
							this.oAnonymousCheckBox.SetValue({ bCheck: false });
							this.jAnonymousValueTrue.hide();
							this.jAnonymousValueFalse.show();
						}
						if(this.oPlayer.oConfig.sMode != "simple")
						{
							this.jFldPagePlaceholder.val(oCurStoreItem.placeholder_id).selectmenu("refresh");
							this.jFldPagePlaceholderValue.html(this.jFldPagePlaceholder[0].selectedOptions[0].text);
						}
						this.jPageModifiedValue.html(TOOLS.DateStringFromISO8601({ sISODate: oCurStoreItem.modification_date, sFormat: "dd.mm.yy" }));

/*						this.jFldPageName.val(this.oList.oItems[oArgs.sId].oItem.name);
						this.jPageNameValue.html(this.oList.oItems[oArgs.sId].oItem.name);
						this.jFldPageCode.val(this.oList.oItems[oArgs.sId].oItem.code);
						this.jPageCodeValue.html(this.oList.oItems[oArgs.sId].oItem.code);
						this.jPageObjectFld.val(this.oList.oItems[oArgs.sId].oItem.catalog_name).selectmenu("refresh");
						this.jDesignFld.val(this.oList.oItems[oArgs.sId].oItem.web_design_id).selectmenu("refresh");
						this.jAnonymousEditable.hide();
						if(this.oList.oItems[oArgs.sId].oItem.enable_anonymous_access)
						{
							this.oAnonymousCheckBox.SetValue({ bCheck: true });
							this.jAnonymousValueTrue.show();
							this.jAnonymousValueFalse.hide();
						}
						else
						{
							this.oAnonymousCheckBox.SetValue({ bCheck: false });
							this.jAnonymousValueTrue.hide();
							this.jAnonymousValueFalse.show();
						}
						if(this.oPlayer.oConfig.sMode != "simple")
						{
							this.jFldPagePlaceholder.val(this.oList.oItems[oArgs.sId].oItem.placeholder_id).selectmenu("refresh");
							this.jFldPagePlaceholderValue.html(this.jFldPagePlaceholder[0].selectedOptions[0].text);
						}
						this.jPageModifiedValue.html(TOOLS.DateStringFromISO8601({ sISODate: this.oList.oItems[oArgs.sId].oItem.modification_date, sFormat: "dd.mm.yy" }));*/
						this.jPageData.css({ "display": "flex" });
						this.oBtns[this.sId + "-submit"].Enable();
						this.oBtns[this.sId + "-copy"].Hide();
						this.oBtns["new-page"].Enable();
						this.Disable();
						if(oCurStoreItem.is_std==true)
						{
							if(oCurStoreItem.content_access!=true)
							{
								this.oBtns[this.sId + "-edit"].Hide();
								this.oBtns["run-editor"].Hide();
								this.jIsStdWarning.show();
							}
							else
							{
								this.oBtns[this.sId + "-edit"].Show();
								this.oBtns["run-editor"].Show();
								this.jIsStdAllowedWarning.show();
							}
						}
						else
						{
							this.oBtns[this.sId + "-edit"].Show();
							this.oBtns["run-editor"].Show();
						}
					}
				}
				break;
			}
            case "resources":
			{
				if(oArgs.bEmpty)
				{
					this.sCurrentModuleId = "";
					this.jNav.hide();
					this.jNoneSelected.show();
					this.jCard.css({ "display": "none" });
					this.oBtns["new-resource"].Enable();
					this.oBtns[this.sId + "-submit"].Hide();
					this.oBtns[this.sId + "-cancel"].Hide();
					this.oBtns[this.sId + "-edit"].Show().Disable();
					this.oBtns[this.sId + "-delete"].Hide();
					this.oBtns["download-resource"].Hide();
					this.jFilter.selectmenu("enable");
					this.oSearch.Enable();
				}
				else
				{
					this.sCurrentResourceId = oArgs.sId;
					this.jNav.show();
					this.jNoneSelected.hide();
					this.jCard.css({ "display": "flex" });
					if(oArgs.sId == "")
					{
						this.jResourceId.val("");
						this.jInitialRepoId.val("");
						this.jResourceAction.val("");
						this.jResourceName.val("");
						this.jResourceNameValue.html("");
						this.jResourceFileNameValue.html("");
						this.jResourceTags.val("");
						this.jResourceTagsValue.html("");
						this.jResourceFolder.val("").selectmenu("refresh");
						this.jResourceFolderValue.html("");
						this.jResourceTypeBlock.hide();
						this.jResourceSizeBlock.hide();
						this.jResourceModifiedBlock.hide();
						this.jIconImg.attr({ "src": this.oPlayer.oConfig.sImgFldPlaceholder, "wt-src": "none" });
						this.jPageData.css({ "display": "flex" });
						this.jResourceStatus.val("plan").selectmenu("refresh");
						this.jResourceStatusValue.html(this.oPlayer._GetString({ sId: "option-resource-status-plan" }));
						this.oBtns["resource-basic"].Show().Select();
						this.Enable();
					}
					else
					{
						this.jResourceId.val(this.sCurrentResourceId);
						this.jInitialRepoId.val(this.oList.oItems[oArgs.sId].oItem.repo_id);
						this.jResourceAction.val("");
						this.jResourceName.val(this.oList.oItems[oArgs.sId].oItem.name);
						this.jResourceNameValue.html(this.oList.oItems[oArgs.sId].oItem.name);
						this.jResourceFileNameValue.html(this.oList.oItems[oArgs.sId].oItem.file_name);
						this.jResourceTags.val(this.oList.oItems[oArgs.sId].oItem.tags);
						this.jResourceTagsValue.html(this.oList.oItems[oArgs.sId].oItem.tags);
						this.jResourceFolder.val(this.oList.oItems[oArgs.sId].oItem.repo_id).selectmenu("refresh");
						this.jResourceFolderValue.html(this.oPlayer.oStore["repos"].oData[this.oList.oItems[oArgs.sId].oItem.repo_id].name);
						this.jResourceTypeValue.html(this.oPlayer.oStore["file_types"].oData[this.oList.oItems[oArgs.sId].oItem.type].name);

						this.jResourceStatus.val(this.oList.oItems[oArgs.sId].oItem.status).selectmenu("refresh");
						this.jResourceStatusValue.html(this.oPlayer._GetString({ sId: "option-resource-status-" + this.oList.oItems[oArgs.sId].oItem.status }));
						var sSize = this.oList.oItems[oArgs.sId].oItem.size;
						if(sSize == null)
						{
							sSize = "-";
						}
						else
						{
							var nSize = parseInt(sSize, 10);
							if(!isNaN(nSize))
							{
								if(nSize > 1048576)
								{
									sSize = Math.round(nSize / 1048576) + "MB";
								}
								else if(nSize > 1024)
								{
									sSize = Math.round(nSize / 1024) + "kB";
								}
								else
								{
									sSize = nSize + "B";
								}
							}
						}
						this.jResourceSizeValue.html(sSize);
						this.jResourceModifiedValue.html(TOOLS.DateStringFromISO8601({ sISODate: this.oList.oItems[oArgs.sId].oItem.modified, sFormat: "dd.mm.yy" }));
						var sIconURL = this.oList.oItems[oArgs.sId].oItem.url;
						if(this.oList.oItems[oArgs.sId].oItem.type == "img")
						{
							if(sIconURL == null || sIconURL == "")
							{
								sIconURL = this.oPlayer.oConfig.sImgFldPlaceholder;
								this.jIconImg.attr({ "wt-src": "none" });
							}
							else if(sIconURL.charAt(0) != "/")
							{
								sIconURL = "/" + sIconURL;
								this.jIconImg.removeAttr("wt-src");
							}
						}
						else
						{
							sIconURL = this.oPlayer.oConfig.sImgURL + "ico-file-" + this.oList.oItems[oArgs.sId].oItem.type + ".svg";
							this.jIconImg.removeAttr("wt-src");
						}
						this.jIconImg.removeAttr("wt-src").attr({ "src": sIconURL });
						this.jPageData.css({ "display": "flex" });
						this.oBtns["resource-basic"].Show().Select();
						this.Disable();
					}
				}
				break;
			}
        }
        return this;
    };
    CXPage.prototype.Editor = function(oArgs)
	{
        var i;
        // delete all service info
        delete oArgs.oData.action_completed;
        delete oArgs.oData.error;
        delete oArgs.oData.error_text;
        // sort templates array by weight/name
        for(i=0; i<oArgs.oData.zones.length; i++)
		{
            oArgs.oData.zones[i].templates.sort(function(a, b)
			{
                if(a.weight > b.weight)
				{
                    return -1;
                }
                if(a.weight < b.weight)
				{
                    return 1;
                }
                if(a.weight == b.weight)
				{
                    if(a.name > b.name)
					{
                        return -1;
                    }
                    if(a.name < b.name)
					{
                        return 1;
                    }
                    return 0;
                }
                return 0;
            });
        }
        // now we can update stores
        this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: oArgs.oData.id, oItem: oArgs.oData });
        this.oPlayer.oCurrentWebMode = JSON.parse(JSON.stringify(oArgs.oData));
        if(this.oPlayer.oCurrentWebMode.catalog_name != null && this.oPlayer.oCurrentWebMode.catalog_name != "")
		{
            this.jTestObjectContainer.show();
			this.jBtnHintObject.removeAttr("cx-no-data").show();
			this.jBtnHintContext.removeAttr("cx-no-data").show();
            if(this.oPlayer.oCurrentWebMode.sample_object_id != null && this.oPlayer.oCurrentWebMode.sample_object_id != "")
			{
                if(this.oPlayer.oCurrentWebMode.sample_object_title != null && this.oPlayer.oCurrentWebMode.sample_object_title != "")
				{
					this.jTestObjectValue.html(this.oPlayer.oCurrentWebMode.sample_object_title);
                }
				else
				{
                    this.jTestObjectValue.html(this.oPlayer.oCurrentWebMode.sample_object_id);
                }
            }
			else
			{
                this.jTestObjectValue.html(this.oPlayer._GetString({ sId: "test-object-not-selected" }));
            }
        }
		else
		{
            this.jTestObjectContainer.hide();
			this.jBtnHintObject.attr({ "cx-no-data": "1" }).hide();
			this.jBtnHintContext.attr({ "cx-no-data": "1" }).hide();
        }
        this.jPageTitle.html(this.oPlayer.oCurrentWebMode.name);
        if(this.oPlayer.oCurrentWebMode.catalog_name == null)
		{
            this.oPlayer.oCurrentWebMode.catalog_name = "";
        }
        this.oPlayer.oMenu["top"].Show({ sItemId: "desktop" }).Select({ sItemId: "desktop" });
        this.oPlayer.aLoading = [];
        for(i=0; i<oArgs.oData.zones.length; i++)
		{
            for(var j = 0; j<oArgs.oData.zones[i].templates.length; j++)
			{
                if(this.oTemplateDialogs[oArgs.oData.zones[i].templates[j].id] != null)
				{
                    this.oTemplateDialogs[oArgs.oData.zones[i].templates[j].id].Show();
                }
                if(this.oPlayer.bLockParamUpdate)
				{
                    this.oPlayer.aLoading.push(oArgs.oData.zones[i].templates[j].override_template_id);
                }
            }
        }
        this.oPlayer.oCurrentWebModeCopy = JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebMode)); // copy for edit purposes
        this.oEditor.Fill(oArgs);
        return this;
    };
    CXPage.prototype.Enable = function(oArgs)
	{
        this.jPanel.attr({ "cx-state": "edit" });
        switch(this.sId)
		{
            case "pages":
			{
				var bCopyMode = (oArgs!=null && oArgs.bCopyMode==true);
				this.jCopyModeBlock.hide();
				var bIsStd = false;
				if(this.sCurrentPageId != "")
				{
					var oItem = this.oList.oItems[this.sCurrentPageId].oItem;
					if(bCopyMode)
					{
						this.jFldPageName.prop("disabled", false).val(this.oList.oItems[this.sCurrentPageId].oItem.name).show();
						this.jFldPageCode.prop("disabled", false).val(this.oList.oItems[this.sCurrentPageId].oItem.code).show();
						this.jPageCodeValue.hide();
					}
					else
					{
						this.jFldPageName.prop("disabled", false).val(this.oList.oItems[this.sCurrentPageId].oItem.name).show();
						this.jFldPageCode.prop("disabled", false).val(this.oList.oItems[this.sCurrentPageId].oItem.code).show();
						this.jPageCodeValue.hide();
						if(this.oPlayer.oConfig.sMode != "simple")
						{
							this.jFldPagePlaceholder.val(this.oList.oItems[this.sCurrentPageId].oItem.placeholder_id).selectmenu("refresh").selectmenu("widget").show();
						}
						if(this.sCurrentPageId == this.oPlayer.sCurrentPageId)
						{
							this.oBtns[this.sId + "-delete"].Hide();
							this.jMsgAlreadyOpen.show();
						}
						else
						{
							this.oBtns[this.sId + "-delete"].Show().Enable();
							this.jMsgAlreadyOpen.hide();
						}
					}
				}
				else
				{
					this.jFldPageName.prop("disabled", false).val("").show();
					this.jFldPageCode.prop("disabled", false).val("").show();
					this.jPageCodeValue.hide();
					if(this.oPlayer.oConfig.sMode != "simple")
					{
						this.jFldPagePlaceholder.val("").selectmenu("refresh").selectmenu("widget").show();
					}

					this.oBtns[this.sId + "-delete"].Hide();
					this.jMsgAlreadyOpen.hide();
				}
				this.jPageNameValue.hide();
				if(this.oPlayer.oConfig.sMode != "simple")
				{
					this.jFldPagePlaceholderValue.hide();
				}
				this.jPageModifiedBlock.hide();
				if(bCopyMode)
				{
					this.jPageObjectFldBlock.hide();
					this.jDesignBlock.hide();
					this.jAnonymousBlock.hide();
					this.jMandatoryMarks.show();
					this.jIsStdWarning.hide();
					this.jIsStdAllowedWarning.hide();
					this.jCopyWarning.show();
					this.jFilter.selectmenu("disable");
					this.oBtns[this.sId + "-edit"].Hide();
					this.oBtns[this.sId + "-submit"].Hide();
					this.oBtns[this.sId + "-copy"].Show();
					this.oBtns[this.sId + "-cancel"].Show();
					this.oBtns["run-editor"].Hide();
					this.SubmitState({ bCopyMode: bCopyMode });
				}
				else
				{
					this.jPageObjectFldBlock.show();
					this.jPageObjectFld.selectmenu("enable");
					if(this.jDesignFld.val()=="") // user cannot change design once selected
					{
						this.jDesignBlock.show();
						this.jDesignFld.selectmenu("enable");
					}
					else
					{
						this.jDesignBlock.hide();
					}
					this.jAnonymousBlock.show();
					this.jAnonymousEditable.show();
					this.jAnonymousValues.hide();
					this.jMandatoryMarks.show();
					this.jMandatoryWarning.show();
					this.jFilter.selectmenu("disable");
					this.oBtns[this.sId + "-edit"].Hide();
					this.oBtns[this.sId + "-copy"].Hide();
					this.oBtns[this.sId + "-submit"].Show();
					this.oBtns[this.sId + "-cancel"].Show();
					this.oBtns["run-editor"].Hide();
					this.SubmitState();
				}
				break;
			}
			case "resources":
			{
				this.jResourceName.show();
				this.jResourceNameValue.hide();
				this.jResourceFolder.selectmenu("enable").selectmenu("widget").show();
				this.jResourceFolderValue.hide();
				this.jResourceTags.show();
				this.jResourceTagsValue.hide();
				this.jResourceTypeBlock.hide();
				this.jResourceSizeBlock.hide();
				this.jResourceModifiedBlock.hide();
				this.jMandatoryMarks.show();
				this.jMandatoryWarning.show();

				/*this.jResourceDesc.prop("disabled", false);
				this.jResourceDesc.next('.cke_textarea_inline').show();
				this.jResourceDescValue.hide();*/

				this.jIcon.removeAttr("cx-state");
				this.jImgFld.prop("disabled", false);
				if(this.jIconImg[0].hasAttribute("wt-src"))
				{
					this.jImgFldInstruction.show();
					// this.jImgDeleteBtn.hide();
				}
				else
				{
					this.jImgFldInstruction.hide();
					// this.jImgDeleteBtn.show();
				}
				if(this.sCurrentResourceId != "")
				{
					this.oBtns[this.sId + "-delete"].Show().Enable();
				}
				else
				{
					this.oBtns[this.sId + "-delete"].Hide();
				}
				this.oBtns[this.sId + "-edit"].Hide();
				this.oBtns[this.sId + "-submit"].Show();
				this.oBtns[this.sId + "-cancel"].Show();
				this.oBtns["download-resource"].Hide();
				this.jResourceStatus.selectmenu("enable").selectmenu("widget").show();
				this.jResourceStatusValue.hide();
				this.SubmitState();
				break;
			}
        }
        this.bDisabled = false;
        return this;
    };
    CXPage.prototype.EnableTemplateBtns = function(oArgs)
	{
        this.oBtns["template-submit"].Show().Enable();
        this.oBtns["template-cancel"].Show().Enable();
        return this;
    };
    CXPage.prototype.Fill = function(oArgs)
	{
        var oThis = this;
        var sKey;
        var i;
        switch(oThis.sId)
		{
            case "pages":
			{
				if(this.oPlayer.oStore["object_types"] != null)
				{
					for(i=0; i<this.oPlayer.oStore["object_types"].aData.length; i++)
					{
						this.jPageObjectFld.append('<option value="' + this.oPlayer.oStore["object_types"].aData[i].id + '">' + this.oPlayer.oStore["object_types"].aData[i].name + '</option>');
					}
					this.jPageObjectFld.selectmenu(
					{
						classes: { "ui-selectmenu-open": "cx-selectmenu-open-object", "ui-selectmenu-button": "cx-selectmenu-object" },
						position: { my: "right top", at: "right bottom", collision: "none" },
						change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); }
					});
				}
				if(this.oPlayer.oStore["web_designs"] != null)
				{
					for(i=0; i<this.oPlayer.oStore["web_designs"].aData.length; i++)
					{
						this.jDesignFld.append('<option value="' + this.oPlayer.oStore["web_designs"].aData[i].id + '">' + this.oPlayer.oStore["web_designs"].aData[i].name + '</option>');
						this.jDesignFilter.append('<option value="' + this.oPlayer.oStore["web_designs"].aData[i].id + '">' + this.oPlayer.oStore["web_designs"].aData[i].name + '</option>');
					}
					this.jDesignFld.selectmenu(
					{
						classes: { "ui-selectmenu-open": "cx-selectmenu-open-object", "ui-selectmenu-button": "cx-selectmenu-object" },
						position: { my: "right top", at: "right bottom", collision: "none" },
						change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); }
					});
					this.jDesignFilter.selectmenu(
					{
						classes: { "ui-selectmenu-open": "cx-selectmenu-open-object", "ui-selectmenu-button": "cx-selectmenu-object" },
						position: { my: "right top", at: "right bottom", collision: "none" },
						change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); }
					});
				}
				this.oList = (new CXList({ oPlayer: this.oPlayer, oPage: this, sType: "webmodes", jContainer: this.jBody, bSingle: true })).Fill({ oItems: this.oPlayer.oStore["webmodes"].oData });
				this.oIsStd.Subscribe({ sEvent: "change", bOnce: false, sSubscriberId: this.oList.sId, oContext: this.oList, fn: this.oList.Filter, oArgs: { sType: "filter", bIsStd: true } });

				this.oList.oBtns["sort-1"].Click();
				this.oPlayer.oStore["webmodes"].Subscribe({ sEvent: "item_appended", bOnce: false, sSubscriberId: this.oList.sId, oContext: this.oList, fn: this.oList.Update, oArgs: {} });
				this.oPlayer.oStore["webmodes"].Subscribe({ sEvent: "item_updated", bOnce: false, sSubscriberId: this.oList.sId, oContext: this.oList, fn: this.oList.Update, oArgs: {} });
				this.oPlayer.oStore["webmodes"].Subscribe({ sEvent: "item_deleted", bOnce: false, sSubscriberId: this.oList.sId, oContext: this.oList, fn: this.oList.Update, oArgs: {} });
				if(this.oPlayer.oConfig.sMode != "simple")
				{
					for(sKey in this.oPlayer.oStore["placeholders"].oData)
					{
						if(this.oPlayer.oStore["placeholders"].oData.hasOwnProperty(sKey))
						{
							this.jFldPagePlaceholder.append('<option value="' + sKey + '">' + this.oPlayer.oStore["placeholders"].oData[sKey].name + '</option>');
						}
					}
					this.jFldPagePlaceholder.selectmenu("refresh");
				}
				break;
			}
            case "resources":
			{
				this.oRepoMine = {};
				for(sKey in oThis.oPlayer.oStore["repos"].oData)
				{
					if(oThis.oPlayer.oStore["repos"].oData[sKey].person_id == this.oPlayer.sCurrentUserId || sKey == "0")
					{
						this.oRepoMine[sKey] = oThis.oPlayer.oStore["repos"].oData[sKey];
					}
				}
				this.oList = new CXList({ oPlayer: this.oPlayer, oPage: this, sType: "resource", jContainer: this.jBody, bSingle: true }).Fill({ oItems: this.oRepoMine });
				this.oList.oBtns["sort-1"].Click();
				var aFilterValues = [];
				for(sKey in oThis.oPlayer.oStore["repos"].oData)
				{
					if(sKey == "0")
					{
						this.jFilter.append('<option value="' + sKey + '">' + oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) + ' (' + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ')</option>');
						this.jResourceFolder.append('<option value="' + sKey + '">' + oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) + '</option>');
					}
					else
					{
						if(this.oRepoMine[sKey] != null)
						{
							aFilterValues.push({ sId: sKey, sName: oThis.oPlayer.oStore["repos"].oData[sKey].name + " (" + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ")" });
						}
					}
				}
				aFilterValues.sort(function(oElem1, oElem2)
				{
					if(oElem1.sName.toLowerCase() > oElem2.sName.toLowerCase())
					{
						return 1;
					}
					if(oElem1.sName.toLowerCase < oElem2.sName.toLowerCase())
					{
						return -1;
					}
					return 0;
				});
				for(i=0; i<aFilterValues.length; i++)
				{
					this.jFilter.append('<option value="' + aFilterValues[i].sId + '">&#128194; ' + aFilterValues[i].sName + '</option>');
					this.jResourceFolder.append('<option value="' + aFilterValues[i].sId + '">&#128194; ' + aFilterValues[i].sName + '</option>');
				}
				this.jFilter.selectmenu("refresh");
				this.jResourceFolder.selectmenu("refresh");
				break;
			}
            case "desktop":
			{
				if(this.oPlayer.sCurrentPageId == null)
				{
					this.oTemplateDialogs = {};
					this.oProm = {};
					//var iCnt = 1;
					for(sKey in this.oPlayer.oStore["macros"].oData)
					{
						if(this.oPlayer.oStore["macros"].oData.hasOwnProperty(sKey))
						{
							oThis.oTemplateDialogs[sKey] = (new CXObjectDialog({ oPlayer: oThis.oPlayer, oPage: oThis, oObject: oThis.oPlayer.oStore["macros"].oData[sKey], sId: sKey, jContainer: oThis.jContainer.find("[cx-role='panel-right']") })).Hide();
							//oThis.oProm[sKey] =  new Promise(function (fnResolve, fnReject) { oThis.oTemplateDialogs[sKey] = (new CXObjectDialog({ oPlayer: oThis.oPlayer, oPage: oThis, oObject: oThis.oPlayer.oStore["macros"].oData[sKey], sId: sKey, jContainer: oThis.jContainer.find("[cx-role='panel-right']") })).Hide(); fnResolve(iCnt); });
							//iCnt++;
						}
					}
					for(sKey in this.oPlayer.oStore["templates"].oData)
					{
						if(this.oPlayer.oStore["templates"].oData.hasOwnProperty(sKey))
						{
							oThis.oTemplateDialogs[sKey] = (new CXObjectDialog({ oPlayer: oThis.oPlayer, oPage: oThis, oObject: oThis.oPlayer.oStore["templates"].oData[sKey], sId: sKey, jContainer: oThis.jContainer.find("[cx-role='panel-right']") })).Hide();
							//oThis.oProm[sKey] =  new Promise(function (fnResolve, fnReject) { oThis.oTemplateDialogs[sKey] = (new CXObjectDialog({ oPlayer: oThis.oPlayer, oPage: oThis, oObject: oThis.oPlayer.oStore["templates"].oData[sKey], sId: sKey, jContainer: oThis.jContainer.find("[cx-role='panel-right']") })).Hide(); fnResolve(iCnt); });
							//iCnt++;
						}
					}
					this.oDialogs["objects"] = new CXDialog({ oPlayer: oThis.oPlayer, oPage: oThis, jContainer: oThis.oPlayer.jContainer, sId: "objects", sType: "objects" }).Fill();
					this.oDialogs["settings"] = new CXDialog({ oPlayer: oThis.oPlayer, oPage: oThis, jContainer: oThis.oPlayer.jContainer, sId: "settings", sType: "settings" }).Fill();
				}
				this.oEditor = new CXEditor({ oPlayer: this.oPlayer, oPage: this, jContainer: this.jSlideBlock });
				break;
			}
        }
        return this;
    };
    CXPage.prototype.FilterHint = function(oArgs)
	{
		var oThis = this;
		if(oArgs.sValue=="")
		{
			this.jSelectList.children("[cx-role='select-list-item']").show();
		}
		else
		{
			var sValue = oArgs.sValue.toLowerCase();
			this.jSelectList.children("[cx-role='select-list-item']").each(function ()
			{
				var jThis = $(this);
				if(jThis.html().toLowerCase().indexOf(sValue)!=-1)
				{
					jThis.show();
				}
				else
				{
					jThis.hide();
				}
			});
		}
		return this;
	};
    CXPage.prototype.Hide = function(oArgs)
	{
        this.jPage.hide();
        this.bVisible = false;
        return this;
    };
    CXPage.prototype.HideHint = function(oArgs)
	{
		var oThis = this;
		if(this.jHintContainer.is(":visible"))
		{
			this.jHintContainer.hide();
		}
		if(this.jSelectContainer.is(":visible"))
		{
			this.jSelectContainer.hide();
		}
		if(this.oPlayer.oMask.jMask.is(":visible"))
		{
			this.oPlayer.oMask.Hide();
		}
		return this;
	};
    CXPage.prototype.ModifyView = function(oArgs)
	{
        switch(this.sId)
		{
            case "desktop":
			{
				switch(oArgs.sTarget)
				{
					case "btn-add-item":
					{
						switch(oArgs.sAction)
						{
							case "reset":
							{
								this.oBtns["add-slide"].jBtn.css({ "margin-top": "0" });
								break;
							}
						}
						break;
					}
					case "context":
					{
						switch(oArgs.sAction)
						{
							case "disable":
							{
								this.jContextNothingSelected.show();
								this.jContextContextTitle.hide();
								break;
							}
							case "enable":
							{
								this.jContextNothingSelected.hide();
								this.jContextContextTitle.show();
								break;
							}
						}
						break;
					}
				}
				break;
			}
        }
        return this;
    };
    CXPage.prototype.SaveSettings = function(oArgs)
	{
		if(this.oPlayer.oCurrentWebMode != null)
		{
			var oToSave =
			{
				action: "save_web_mode_structure",
				web_mode_id: this.oPlayer.oCurrentWebModeCopy.id,
				web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
			};
			this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true, bCleanZones: true })))), oContext: this.oEditor, fnSuccess: this.oEditor.UpdateAll, oSuccessArgs: { bTestObjectChanged: true } });
		}
		return this;
	};
    CXPage.prototype.Show = function(oArgs)
	{
        for(var sKey in this.oPlayer.oPages)
		{
            if(this.oPlayer.oPages.hasOwnProperty(sKey))
			{
                if(sKey != this.sId)
				{
                    if(this.oPlayer.oPages[sKey].jPage.is(":visible"))
					{
                        this.oPlayer.oPages[sKey].Hide();
                    }
                }
            }
        }
        this.jPage.css({ "display": "flex" });
        this.bVisible = true;
        this.oPlayer.sCurrentPage = this.sId;
        this.FireEvent({ sEvent: "shown" });
        return this;
    };
    CXPage.prototype.SubmitState = function(oArgs)
	{
		var bCopyMode = (oArgs!=null && oArgs.bCopyMode==true);
		if(bCopyMode)
		{
			if(this._Validate({ bCopyMode: true }))
			{
				this.oBtns[this.sId + "-copy"].Enable();
			}
			else
			{
				this.oBtns[this.sId + "-copy"].Disable();
			}
		}
		else
		{
			if(this._Validate())
			{
				this.oBtns[this.sId + "-submit"].Enable();
			}
			else
			{
				this.oBtns[this.sId + "-submit"].Disable();
			}
		}
        return this;
    };
    CXPage.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        var sValidation;
        var oToSave;
        switch(oArgs.oEvt.type)
		{
            case "keyup":
			{
				if(oArgs.oElem.getAttribute("cx-role")=="select-filter-fld")
				{
					this.FilterHint({ sValue: oArgs.oElem.value });
					break;
				}
				sValidation = oArgs.oElem.getAttribute("cx-validation");
				if(sValidation != null && sValidation != "")
				{
					this.SubmitState({ bCopyMode: this.jCopyWarning.is(":visible") });
				}
				break;
			}
            case "selectmenuchange":
			{
				switch(oArgs.oElem.getAttribute("cx-role"))
				{
					case "design-filter":
					{
						this.oList.Filter({ sType: "filter", bDesign: true, sValue: $(oArgs.oElem).val() });
						break;
					}
					case "filter-selector":
					{
						this.sFilterValue = $(oArgs.oElem).val();
						this.oList.Filter({ sType: "filter", sValue: oThis.sFilterValue });
						break;
					}
					case "object-type-fld":
					{
						break;
					}
					case "design-fld":
					{
						break;
					}
					default:
					{ // validation
						sValidation = oArgs.oElem.getAttribute("cx-validation");
						if(sValidation != null && sValidation != "")
						{
							this.SubmitState();
						}
						break;
					}
				}
				break;
			}
            case "change":
			{
				switch(oArgs.oElem.getAttribute("cx-role"))
				{
					case "anonymous":
					{
						var sValue = this.oAnonymousCheckBox._GetValue();
						if(sValue != "1")
						{
							this.jFldAnonymous.val("0");
							if(this.sCurrentPageId != "")
							{
								this.oList.oItems[this.sCurrentPageId].oItem.enable_anonymous_access = false;
							}
						}
						else
						{
							this.jFldAnonymous.val("1");
							if(this.sCurrentPageId != "")
							{
								this.oList.oItems[this.sCurrentPageId].oItem.enable_anonymous_access = true;
							}
						}
						this.SubmitState();
						break;
					}
					case "resource-img":
					{
						var oFile;
						var oReader;
						var bImage = false;
						var sType;
						for(var i = 0; i<oArgs.oElem.files.length; i++)
						{
							oFile = oArgs.oElem.files[i];
							oThis.jResourceFileNameValue.html(oFile.name);
							sType = sType = "text";
							bImage = !!oFile.type.match(/image.*/);
							if(bImage)
							{
								sType = "img";
							}
							else if(!!oFile.type.match(/msword/) || (!!oFile.type.match(/wordprocessingml/) && !!oFile.type.match(/document/)))
							{
								sType = "doc";
							}
							else if(!!oFile.type.match(/excel/) || (!!oFile.type.match(/spreadsheetml/) && !!oFile.type.match(/sheet/)))
							{
								sType = "xls";
							}
							else if(!!oFile.type.match(/powerpoint/) || (!!oFile.type.match(/presentationml/) && !!oFile.type.match(/presentation/)))
							{
								sType = "ppt";
							}
							else if(!!oFile.type.match(/application/) && !!oFile.type.match(/pdf/))
							{
								sType = "pdf";
							}
							else if(!!oFile.type.match(/video/))
							{
								sType = "video";
							}
							else if(!!oFile.type.match(/audio/))
							{
								sType = "audio";
							}
							else if(!!oFile.type.match(/audio/))
							{
								sType = "audio";
							}
							else if((!!oFile.type.match(/application/) && !!oFile.type.match(/zip/)) || (!!oFile.type.match(/application/) && !!oFile.type.match(/rar/)) || (!!oFile.type.match(/application/) && !!oFile.type.match(/7z/)) || (!!oFile.type.match(/application/) && !!oFile.type.match(/tar/)))
							{
								sType = "pdf";
							}
							if(window.FileReader)
							{
								oReader = new FileReader();
								oReader.onloadend = function(e)
								{
									if(bImage)
									{
										oThis.jIconImg.attr({ "src": e.target.result });
									}
									else
									{
										oThis.jIconImg.attr({ "src": oThis.oPlayer.oConfig.sImgURL + "ico-file-" + sType + ".svg" });
									}
								};
								if(bImage)
								{
									oReader.readAsDataURL(oFile);
								}
								else
								{
									oReader.readAsBinaryString(oFile);
								}
							}
						}
						sValidation = oArgs.oElem.getAttribute("cx-validation");
						if(sValidation != null && sValidation != "")
						{
							this.SubmitState();
						}
						break;
					}
				}
				break;
			}
            case "click":
			{
				switch(oArgs.oElem.getAttribute("cx-role"))
				{
					case "new-page":
					{
						if(this.oPlayer.oAccess.bEdit && this.oPlayer.oAccess.bCreate)
						{
							this.Display({ sId: "" }).Enable();
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-create" }));
						}
						break;
					}
					case "add-slide":
					{
						this.oDialogs["objects"].Show();
						break;
					}
					case "page-edit":
					{
						if(this.oPlayer.oAccess.bEdit)
						{
							this.Enable();
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-edit" }));
						}
						break;
					}
					case "page-cancel":
					{
						if(this.oList.aSelectedItems.length != 0)
						{
							this.Display({ sId: this.oList.aSelectedItems[0] }).Disable();
						}
						else
						{
							this.Display({ bEmpty: true });
						}
						break;
					}
					case "page-submit":
					{
						oToSave =
						{
							action: "save_web_mode_structure",
							web_mode_id: this.sCurrentPageId,
							web_mode: {}
						};
						if(this.sCurrentPageId != "")
						{
							oToSave.web_mode = JSON.parse(JSON.stringify(this.oPlayer.oStore["webmodes"].oData[this.sCurrentPageId]));
							delete oToSave.web_mode._sortname;
							delete oToSave.web_mode.modification_date;
							delete oToSave.web_mode.url;
						}
						else
						{
							oToSave.web_mode = { id: "" };
						}
						oToSave.web_mode.code = this.jFldPageCode.val();
						oToSave.web_mode.name = this.jFldPageName.val();
						oToSave.web_mode.enable_anonymous_access = (this.jFldAnonymous.val() == "1");
						oToSave.web_mode.catalog_name = this.jPageObjectFld.val();
						oToSave.web_mode.web_design_id = this.jDesignFld.val();
						if(this.oPlayer.oConfig.sMode != "simple")
						{
							oToSave.web_mode.placeholder_id = this.jFldPagePlaceholder.val();
						}
						this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bParseResponse: true } });
						break;
					}
					case "page-copy-mode":
					{
						this.Enable({ bCopyMode: true });
						break;
					}
					case "page-copy":
					{
						oToSave =
						{
							action: "copy_web_mode",
							web_mode_id: this.sCurrentPageId,
							web_mode: {}
						};
						oToSave.web_mode.code = this.jFldPageCode.val();
						oToSave.web_mode.name = this.jFldPageName.val();
						this.oBtns[this.sId + "-copy"].Disable();
						this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(oToSave))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bPageCopy: true } });
						break;
					}
					case "page-delete":
					{
						if(this.oPlayer.oAccess.bEdit && this.oPlayer.oAccess.bDelete)
						{
							oToSave =
							{
								action: "delete_web_mode",
								web_mode_id: this.sCurrentPageId
							};
							sAlertText = oThis.oPlayer._GetString({ sId: "cx-confirm-text-delete-page" }).split("%1").join(oThis.oPlayer.oStore["webmodes"].oData[this.sCurrentPageId].name);
							oThis.oPlayer.oAlert.Show(
							{
								sTitle: oThis.oPlayer._GetString({ sId: "cx-confirm-title-delete-page" }),
								sText: sAlertText,
								bDisplayCancel: true,
								oOKContext: oThis,
								fnOK: oThis.Load,
								oArgsOK: { sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(oToSave))) + "&object_id=" + this.sCurrentPageId, oContext: this, fnSuccess: this.Update, oSuccessArgs: { bParseResponse: true } }
							});
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-delete" }));
						}
						break;
					}
					case "run-editor":
					{
						if(this.oPlayer.oAccess.bEdit)
						{
							this.oPlayer.sCurrentPageId = this.sCurrentPageId;
							this.oPlayer.bLockParamUpdate = true;
							this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: "action={'action':'get_web_mode','web_mode_id':'" + this.sCurrentPageId + "','session_token':'" + this.oPlayer.sSessionToken + "'}", oContext: oThis.oPlayer.oPages["desktop"], fnSuccess: oThis.oPlayer.oPages["desktop"].Editor, oSuccessArgs: {} });
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-edit" }));
						}
						break;
					}
					case "new-resource":
					{
						if(this.oPlayer.oAccess.bEdit && this.oPlayer.oAccess.bCreate)
						{
							this.Display({ sId: "" });
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-create" }));
						}
						break;
					}
					case "resource-edit":
					{
						if(this.oPlayer.oAccess.bEdit)
						{
							this.Enable();
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-edit" }));
						}
						break;
					}
					case "resource-submit":
					{
						if(oThis.sCurrentResourceId == "")
						{
							oThis.sLastAction = "create_resource";
							oThis.oPlayer.oAPI.Create({ oPage: oThis, sTarget: "resource", jForm: oThis.jForm });
						}
						else
						{
							oThis.sLastAction = "update_resource";
							oThis.oPlayer.oAPI.Update({ oPage: oThis, sTarget: "resource", jForm: oThis.jForm });
						}
						break;
					}
					case "resource-cancel":
					{
						if(this.sCurrentResourceId == "")
						{
							if(this.oList.aSelectedItems.length == 1)
							{
								this.Display({ sId: this.oList.aSelectedItems[0] });
							}
							else
							{
								this.Display({ bEmpty: true });
							}
						}
						else
						{
							this.Display({ sId: this.sCurrentResourceId });
						}
						break;
					}
					case "resource-delete":
					{
						if(this.oPlayer.oAccess.bEdit && this.oPlayer.oAccess.bDelete)
						{
							var oFormData = new FormData();
							oFormData.append("action", "delete_resource");
							oFormData.append("repo_id", oThis.oPlayer.oStore["files"].oData[oThis.sCurrentResourceId].repo_id);
							oFormData.append("resource_id", oThis.sCurrentResourceId);
							sAlertText = oThis.oPlayer._GetString({ sId: "cx-confirm-text-delete-resource" }).split("%1").join(oThis.oPlayer.oStore["files"].oData[oThis.sCurrentResourceId].name);
							oThis.sLastAction = "delete_resource";
							oThis.oPlayer.oAlert.Show({ sTitle: oThis.oPlayer._GetString({ sId: "cx-confirm-title-delete-resource" }), sText: sAlertText, bDisplayCancel: true, oOKContext: oThis.oPlayer.oAPI, fnOK: oThis.oPlayer.oAPI.Delete, oArgsOK: { oFormData: oFormData, sTarget: "resource", fn: oThis.Update, oArgs: { oThis: oThis } } });
						}
						else
						{
							alert(this.oPlayer._GetString({ sId: "user-cannot-delete" }));
						}
						break;
					}
					case "resource-download":
					{
						var sFileUrl = this.oList.oItems[this.sCurrentResourceId].oItem.url;
						oThis.jResourceTempLink.attr({ "href": window.location.protocol + "//" + window.location.host + (/"^\/"/.test(sFileUrl) ? sFileUrl : "/" + sFileUrl), "download": "download" });
						oThis.jResourceTempLink[0].click();
						break;
					}
					case "template-submit":
					{
						this.oEditor.Save();
						break;
					}
					case "template-cancel":
					{
						this.oCurrentObjectDialog.Revert();
						break;
					}
					case "preview-desktop":
					{
						var sURL = this.oPlayer.oCurrentWebModeCopy.url;
						if(this.oPlayer.oCurrentWebModeCopy.sample_object_id != null && this.oPlayer.oCurrentWebModeCopy.sample_object_id != "") // sample object is the same in mode and copy
						{
							sURL += "/object_id/" + this.oPlayer.oCurrentWebModeCopy.sample_object_id;
						}
						sURL += "/lpe_preview/1";
						this.oPlayer.oPreview.Show({ sType: "desktop", sURL: sURL });
						break;
					}
					case "module-settings":
					{
						this.oDialogs["settings"].Show();
						break;
					}
					case "btn-hint-flds":
					{
						if(this.jHintContainer.is(":visible"))
						{
							this.jHintContainer.hide();
						}
						else
						{
							if(!this.jHintContainer[0].hasAttribute("cx-state"))
							{
								this.UpdateHint({ sType: "user" });
							}
							else
							{
								var sState = this.jHintContainer.attr("cx-state");
								if((sState=="object" && this.jBtnHintObject[0].hasAttribute("cx-no-data")) || (sState=="context" && this.jBtnHintContext[0].hasAttribute("cx-no-data")))
								{
									this.UpdateHint({ sType: "user" });
								}
							}
							this.jHintContainer.css({ "opacity": "0" }).show();
							this.AdjustHint();
						}
						break;
					}
					case "btn-test-local-hint":
					{
						this.UpdateHint({ sType: "local" });
						break;
					}
					case "btn-test-doc-hint":
					{
						this.UpdateHint({ sType: "doc" });
						break;
					}
					case "btn-test-object-hint":
					{
						this.UpdateHint({ sType: "object" });
						break;
					}
					case "btn-test-env-hint":
					{
						this.UpdateHint({ sType: "env" });
						break;
					}
					case "btn-test-user-hint":
					{
						this.UpdateHint({ sType: "user" });
						break;
					}
					case "btn-test-context-hint":
					{
						this.UpdateHint({ sType: "context" });
						break;
					}
					case "btn-hint-close":
					{
						this.HideHint();
						break;
					}
					case "hint-list-item":
					{
						var jCell = $(oArgs.oElem).find("[cx-role='hint-item-name']");
						var sText = jCell.text();
						$("#WT_copytarget").val(sText).focus().select();
						try
						{
							document.execCommand("copy");
							bOK = true;
						}
						catch (e)
						{
							alert(e);
						}
						if(bOK)
						{
							jCell.attr({ "cx-title": jCell.attr("title") }).tooltip(
							{
								classes:
								{
									"ui-tooltip": "cx-copy-tooltip"
								},
								position:
								{
									my: "left bottom",
									at: "left top-2",
									collision: "none"
								},
								content: this.oPlayer._GetString({ sId: "copied" }) + sText
							}).tooltip("open");
							jCell.attr({ "title": jCell.attr("cx-title") });
							setTimeout(function() { try { jCell.tooltip("destroy"); } catch(e) {} }, 2000);
						}
						break;
					}
				}
				break;
			}
        }
        return oThis;
    };
    CXPage.prototype.Update = function(oArgs)
	{
        var oThis = this;
        var sAlertTitle = "";
        var sAlertText = "";
        var sId;
        var sRepoId;
        var sRepoName;
        var sSelected;
        var i, j, k;
        switch(this.sId)
		{
            case "pages":
			{
				switch(oArgs.oData.action_completed)
				{
					case "copy_web_mode":
					case "save_web_mode_structure":
					{
						if(typeof oArgs.oData.web_mode == "object")
						{
							sId = oArgs.oData.web_mode.id;
							if(oArgs.oData.web_mode.modification_date == null)
							{
								oArgs.oData.web_mode.modification_date = (new Date()).toISOString();
							}
							// define disposable subscribers to this update
							this.oList.Subscribe({ sEvent: "list_updated", bOnce: true, sSubscriberId: TOOLS.GUID(), oContext: this.oList, fn: this.oList.Sort, oArgs: { bCurrentState: true } });
							this.oList.Subscribe({ sEvent: "list_updated", bOnce: true, sSubscriberId: TOOLS.GUID(), oContext: this.oList, fn: this.oList.Select, oArgs: { sId: sId } });
							this.oList.Subscribe({ sEvent: "list_updated", bOnce: true, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.Display, oArgs: { sId: sId } });
							this.oList.Subscribe({ sEvent: "list_updated", bOnce: true, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.Disable, oArgs: {} });
							// and fire
							if(this.oPlayer.oStore["webmodes"].oData[sId] != null)
							{
								this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: sId, oItem: oArgs.oData.web_mode, bByFld: true });
							}
							else
							{
								this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: sId, oItem: oArgs.oData.web_mode });
							}
						}
						break;
					}
					case "delete_web_mode":
					{
						sId = oArgs.oData.web_mode_id;
						if(this.oPlayer.oStore["webmodes"].oData[sId] != null)
						{
							this.oList.Subscribe({ sEvent: "list_updated", bOnce: true, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.Display, oArgs: { bEmpty: true } });
							this.oPlayer.oStore["webmodes"].Delete({ sId: sId });
						}
						break;
					}
				}
				break;
			}
            case "resources":
			{
				if(oArgs.oData.error == 0)
				{
					if(oArgs.oData.last != null)
					{
						if(oArgs.oData.last.update != null)
						{
							for(i=0; i<oArgs.oData.last.update.length; i++)
							{
								if(oArgs.oData.last.update[i].target == "resource")
								{
									switch(oArgs.oData.last.update[i].result)
									{
										case "created":
										{
											sRepoId = oArgs.oData.last.update[i].repo_id;
											for(j=0; j<oArgs.oData.last.update[i].ids.length; j++)
											{
												sId = oArgs.oData.last.update[i].ids[j];
												for(k=0; k<oArgs.oData.repositoriums[sRepoId].files.length; k++)
												{
													if(sId == oArgs.oData.repositoriums[sRepoId].files[k].id)
													{
														oThis.oPlayer.oStore["repos"].oData[sRepoId].files.push(JSON.parse(JSON.stringify(oArgs.oData.repositoriums[sRepoId].files[k])));
														oThis.oPlayer.oStore["repos"].oData[sRepoId].files[oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length - 1].repo_id = sRepoId;
														oThis.oPlayer.oStore["files"].UpdateSingleItem({ sId: sId, oItem: oArgs.oData.repositoriums[sRepoId].files[k] });
														oThis.oPlayer.oStore["files"].oData[sId].repo_id = sRepoId;
														oThis.oPlayer.oPages["resources"].oList.Append({ sId: oArgs.oData.last.update[i].ids[j], bPrepend: true, sRepoId: sRepoId, oItem: oThis.oPlayer.oStore["repos"].oData[sRepoId].files[oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length - 1] });
														oThis.oPlayer.oPages["resources"].oList.Select({ sId: oArgs.oData.last.update[i].ids[j] });
														oThis.Display({ sId: oArgs.oData.last.update[i].ids[j] });
														break;
													}
												}
											}
											sSelected = oThis.jFilter.val();
											oThis.jFilter.children("option[value='" + sSelected + "']").prop("selected", false);
											sRepoName = (sRepoId == "0") ? oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) : oThis.oPlayer.oStore["repos"].oData[sRepoId].name;
											oThis.jFilter.children("option[value='" + sRepoId + "']").html("&#128194; " + sRepoName + " (" + oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length + ")").prop("selected", true);
											oThis.jFilter.selectmenu("refresh");
											if(sSelected != sRepoId)
											{
												oThis.oList.Filter({ sType: "filter", sValue: sRepoId });
											}
											oThis.oPlayer.oPages["resources"].oList.Sort({ bCurrentState: true });
											break;
										}
										case "updated":
										{
											var sInitialRepoId = oArgs.oData.last.update[i].initial_repo_id;
											sRepoId = oArgs.oData.last.update[i].repo_id;
											for(j=0; j<oArgs.oData.last.update[i].ids.length; j++)
											{
												sId = oArgs.oData.last.update[i].ids[j];
												if(sInitialRepoId != sRepoId)
												{
													var iIdxToRemove = -1;
													for(k=0; k<oThis.oPlayer.oStore["repos"].oData[sInitialRepoId].files.length; k++)
													{
														if(sId == oThis.oPlayer.oStore["repos"].oData[sInitialRepoId].files[k].id)
														{
															iIdxToRemove = k;
															break;
														}
													}
													if(iIdxToRemove != -1)
													{
														oThis.oPlayer.oStore["files"].Delete({ sId: sId });
														oThis.oPlayer.oStore["repos"].oData[sInitialRepoId].files.splice(iIdxToRemove, 1);
														if(oThis.oPlayer.oPages["resources"].oList.oItems[sId] != null)
														{
															oThis.oPlayer.oPages["resources"].oList.Remove({ sId: sId });
														}
													}
													for(k=0; k<oArgs.oData.repositoriums[sRepoId].files.length; k++)
													{
														if(sId == oArgs.oData.repositoriums[sRepoId].files[k].id)
														{
															oThis.oPlayer.oStore["repos"].oData[sRepoId].files.push(JSON.parse(JSON.stringify(oArgs.oData.repositoriums[sRepoId].files[k])));
															oThis.oPlayer.oStore["repos"].oData[sRepoId].files[oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length - 1].repo_id = sRepoId;
															oThis.oPlayer.oStore["files"].UpdateSingleItem({ sId: sId, oItem: oArgs.oData.repositoriums[sRepoId].files[k] });
															if(oThis.oPlayer.oPages["courses"] != null)
															{
																oThis.oPlayer.oPages["courses"].oDialogs["selectmodule"].oResourceList.oItems[sId].oItem = oThis.oPlayer.oStore["files"].oData[sId];
															}
															oThis.oPlayer.oPages["resources"].oList.Append({ sId: oArgs.oData.last.update[i].ids[j], bPrepend: true, sRepoId: sRepoId, oItem: oThis.oPlayer.oStore["repos"].oData[sRepoId].files[oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length - 1] });
															oThis.oPlayer.oPages["resources"].oList.oItems[sId].Select();
															oThis.Display({ sId: sId });
														}
													}
													sSelected = oThis.jFilter.val();
													oThis.jFilter.children("option[value='" + sSelected + "']").prop("selected", false);
													var sInitialRepoName = (sInitialRepoId == "0") ? oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) : oThis.oPlayer.oStore["repos"].oData[sInitialRepoId].name;
													sRepoName = (sRepoId == "0") ? oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) : oThis.oPlayer.oStore["repos"].oData[sRepoId].name;
													oThis.jFilter.children("option[value='" + sInitialRepoId + "']").html(sInitialRepoName + " (" + oThis.oPlayer.oStore["repos"].oData[sInitialRepoId].files.length + ")");
													oThis.jFilter.children("option[value='" + sRepoId + "']").html(sRepoName + " (" + oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length + ")").prop("selected", true);
													oThis.jFilter.selectmenu("refresh");
													if(sSelected != sRepoId)
													{
														oThis.oList.Filter({ sType: "filter", sValue: sRepoId });
													}
												}
												else
												{
													for(k=0; k<oArgs.oData.repositoriums[sRepoId].files.length; k++)
													{
														sId = oArgs.oData.last.update[i].ids[j];
														if(sId == oArgs.oData.repositoriums[sRepoId].files[k].id)
														{
															oArgs.oData.repositoriums[sRepoId].files[k].repo_id = sRepoId;
															for(var l = 0; l < oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length; l++)
															{
																if(oThis.oPlayer.oStore["repos"].oData[sRepoId].files[l].id == sId)
																{
																	if(oArgs.oData.repositoriums[sRepoId].files[k].type == "img")
																	{
																		oArgs.oData.repositoriums[sRepoId].files[k].icon_url = oArgs.oData.repositoriums[sRepoId].files[k].url;
																	}
																	else
																	{
																		oArgs.oData.repositoriums[sRepoId].files[k].icon_url = this.oPlayer.oConfig.sImgURL + "ico-file-" + oArgs.oData.repositoriums[sRepoId].files[k].type + ".svg";
																	}
																	oThis.oPlayer.oStore["repos"].oData[sRepoId].files[l] = JSON.parse(JSON.stringify(oArgs.oData.repositoriums[sRepoId].files[k]));
																	oThis.oPlayer.oStore["files"].UpdateSingleItem({ sId: sId, oItem: oArgs.oData.repositoriums[sRepoId].files[k] });
																	if(oThis.oPlayer.oPages["courses"] != null)
																	{
																		oThis.oPlayer.oPages["courses"].oDialogs["selectmodule"].oResourceList.oItems[sId].oItem = oThis.oPlayer.oStore["files"].oData[sId];
																	}
																	oThis.oPlayer.oPages["resources"].oList.oItems[sId].oItem = oThis.oPlayer.oStore["repos"].oData[sRepoId].files[l];
																	break;
																}
															}
															oThis.oPlayer.oPages["resources"].oList.oItems[sId].Update().Select();
															oThis.Display({ sId: sId });
														}
													}
													sSelected = oThis.jFilter.val();
													if(sSelected != sRepoId)
													{
														oThis.jFilter.children("option[value='" + sSelected + "']").prop("selected", false);
													}
													sRepoName = (sRepoId == "0") ? oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) : oThis.oPlayer.oStore["repos"].oData[sRepoId].name;
													oThis.jFilter.children("option[value='" + sRepoId + "']").html(sRepoName + " (" + oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length + ")").prop("selected", true);
													oThis.jFilter.selectmenu("refresh");
													if(sSelected != sRepoId)
													{
														oThis.oList.Filter({ sType: "filter", sValue: sRepoId });
													}
												}
											}
											break;
										}
										case "deleted":
										{
											sRepoId = oArgs.oData.last.update[i].repo_id;
											for(j=0; j<oArgs.oData.last.update[i].ids.length; j++)
											{
												for(k=0; k<oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length; k++)
												{
													if(oArgs.oData.last.update[i].ids[j] == oThis.oPlayer.oStore["repos"].oData[sRepoId].files[k].id)
													{
														oThis.oPlayer.oStore["files"].Delete({ sId: oArgs.oData.last.update[i].ids[j] });
														oThis.oPlayer.oStore["repos"].oData[sRepoId].files.splice(k, 1);
														if(oThis.oPlayer.oPages["resources"].oList.oItems[oArgs.oData.last.update[i].ids[j]] != null)
														{
															oThis.oPlayer.oPages["resources"].oList.Remove({ sId: oArgs.oData.last.update[i].ids[j] });
															oThis.Display({ bEmpty: true });
														}
													}
												}
											}
											sSelected = oThis.jFilter.val();
											oThis.jFilter.children("option[value='" + sSelected + "']").prop("selected", false);
											sRepoName = (sRepoId == "0") ? oThis.oPlayer._GetString({ sId: "option-orphaned-resources" }) : oThis.oPlayer.oStore["repos"].oData[sRepoId].name;
											oThis.jFilter.children("option[value='" + sRepoId + "']").html(sRepoName + " (" + oThis.oPlayer.oStore["repos"].oData[sRepoId].files.length + ")").prop("selected", true);
											oThis.jFilter.selectmenu("refresh");
											if(sSelected != sRepoId)
											{
												oThis.oList.Filter({ sType: "filter", sValue: sRepoId });
											}
											break;
										}
									}
								}
								if(oArgs.oData.last.update[i].target == "repo") {
									switch(oArgs.oData.last.update[i].result) {
										case "updated":
											{
												break;
											}
									}
								}
							}
						}
					}
				}
				oThis.oPlayer.oMask.Hide();
				oThis.sLastAction = "";
				break;
			}
            case "desktop":
			{
				switch(oArgs.sType)
				{
					case "template_params":
					{
						if(this.oTemplateDialogs[oArgs.sTemplateId] != null)
						{
							this.oTemplateDialogs[oArgs.sTemplateId].Show().Update({ oOWT: oArgs.oOWT });
						}
						break;
					}
				}
				break;
			}
        }
        return this;
    };
    CXPage.prototype.UpdateHint = function(oArgs)
	{
        var oThis = this;
 		var jRow;
		var i, j;
		var bHasResult;
		if(oArgs.sHint=="selector")
		{
			var jSelectedItem;
			this.jSelectNoData.hide();
			this.jSelectError.hide();
			if(oArgs.bAfterLoad==true)
			{
				var sSelectedValue = this.jSelectList.attr("wt-value");
				this.jSelectNoData.show();
				if(oArgs.oData!=null)
				{
					if(oArgs.oData.error!=0)
					{
						this.jSelectNoData.hide();
						this.jSelectError.html("ERROR " + oArgs.oData.error + " " + oArgs.oData.error_text).show();
					}
					else
					{
						if(oArgs.oData.collections!=null)
						{
							if(Array.isArray(oArgs.oData.collections))
							{
								if(oArgs.oData.collections.length>0)
								{
									this.jSelectNoData.hide();
									this.oPlayer.oCurrentWebModeCopy.all_collections = [];
								}
								for(i=0; i<oArgs.oData.collections.length; i++)
								{
									this.oPlayer.oCurrentWebModeCopy.all_collections.push(JSON.parse(JSON.stringify(oArgs.oData.collections[i])));
									bHasResult = false;
									if(oArgs.oData.collections[i].result_fields!=null)
									{
										if(Array.isArray(oArgs.oData.collections[i].result_fields))
										{
											if(oArgs.oData.collections[i].result_fields.length>0)
											{
												bHasResult = true;
											}
										}
									}
									this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": oArgs.oData.collections[i].id, "wt-selected": (sSelectedValue==oArgs.oData.collections[i].id ? "1" : "0"), "wt-has-result": (bHasResult ? "1" : "0") }).html(oArgs.oData.collections[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
								}
							}
						}
						else if(oArgs.oData.actions!=null)
						{
							if(Array.isArray(oArgs.oData.actions))
							{
								if(oArgs.oData.actions.length>0)
								{
									this.jSelectNoData.hide();
									this.oPlayer.oCurrentWebModeCopy.all_actions = [];
								}
								for(i=0; i<oArgs.oData.actions.length; i++)
								{
									this.oPlayer.oCurrentWebModeCopy.all_actions.push(JSON.parse(JSON.stringify(oArgs.oData.actions[i])));
									this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": oArgs.oData.actions[i].id, "wt-selected": (sSelectedValue==oArgs.oData.actions[i].id ? "1" : "0") }).html(oArgs.oData.actions[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
								}
							}
						}
					}
				}
				jSelectedItem = this.jSelectList.children("[wt-selected='1']");
				if(jSelectedItem.length!=0)
				{
					setTimeout(function () { jSelectedItem[0].scrollIntoView(true); }, 100);
				}
				this.jSelectThrobber.hide();
			}
			else
			{
				this.jSelectList.attr({ "wt-value": oArgs.sValue });
				this.jSelectHeader.html((oArgs.sLabel!=null && oArgs.sLabel!="") ? oArgs.sLabel : this.oPlayer._GetString({ sId: "select-header" }));
				this.jSelectFilterFld.val("");
				this.jSelectList.html("");
				if(oArgs.bAjax==true && oArgs.sCatalog!=null)
				{
					if(oArgs.bAction==true)
					{
						if(this.oPlayer.oCurrentWebModeCopy.all_actions!=null)
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.all_actions.length; i++)
							{
								this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": this.oPlayer.oCurrentWebModeCopy.all_actions[i].id, "wt-selected": (oArgs.sValue==this.oPlayer.oCurrentWebModeCopy.all_actions[i].id ? "1" : "0") }).html(this.oPlayer.oCurrentWebModeCopy.all_actions[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
							}
							jSelectedItem = this.jSelectList.children("[wt-selected='1']");
							if(jSelectedItem.length!=0)
							{
								setTimeout(function () { jSelectedItem[0].scrollIntoView(true); }, 100);
							}
						}
						else
						{
							this.jSelectThrobber.show();
							this.Load(
							{
								sURL: this.oPlayer.oConfig.sRootAPIURL,
								sData: "action={'action':'get_action_list','catalog_name':'" + oArgs.sCatalog + "'}",
								oContext: this,
								fnSuccess: this.UpdateHint,
								oSuccessArgs: { sHint: "selector", bAfterLoad: true, oContext: oArgs.oContext, fn: oArgs.fn },
								fnFailure: function () { oThis.jSelectThrobber.hide(); }
							});
						}
					}
					else
					{
						if(this.oPlayer.oCurrentWebModeCopy.all_collections!=null)
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.all_collections.length; i++)
							{
								bHasResult = false;
								if(this.oPlayer.oCurrentWebModeCopy.all_collections[i].result_fields!=null)
								{
									if(Array.isArray(this.oPlayer.oCurrentWebModeCopy.all_collections[i].result_fields))
									{
										if(this.oPlayer.oCurrentWebModeCopy.all_collections[i].result_fields.length>0)
										{
											bHasResult = true;
										}
									}
								}
								this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": this.oPlayer.oCurrentWebModeCopy.all_collections[i].id, "wt-selected": (oArgs.sValue==this.oPlayer.oCurrentWebModeCopy.all_collections[i].id ? "1" : "0"), "wt-has-result": (bHasResult ? "1" : "0") }).html(this.oPlayer.oCurrentWebModeCopy.all_collections[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
							}
							jSelectedItem = this.jSelectList.children("[wt-selected='1']");
							if(jSelectedItem.length!=0)
							{
								setTimeout(function () { jSelectedItem[0].scrollIntoView(true); }, 100);
							}
						}
						else if(this.oPlayer.aCollections!=null)
						{
							for(i=0; i<this.oPlayer.aCollections.length; i++)
							{
								bHasResult = false;
								if(this.oPlayer.aCollections[i].result_fields!=null)
								{
									if(Array.isArray(this.oPlayer.aCollections[i].result_fields))
									{
										if(this.oPlayer.aCollections[i].result_fields.length>0)
										{
											bHasResult = true;
										}
									}
								}
								this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": this.oPlayer.aCollections[i].id, "wt-selected": (oArgs.sValue==this.oPlayer.aCollections[i].id ? "1" : "0"), "wt-has-result": (bHasResult ? "1" : "0") }).html(this.oPlayer.aCollections[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
							}
							jSelectedItem = this.jSelectList.children("[wt-selected='1']");
							if(jSelectedItem.length!=0)
							{
								setTimeout(function () { jSelectedItem[0].scrollIntoView(true); }, 100);
							}
						}
						else
						{
							this.jSelectThrobber.show();
							this.Load(
							{
								sURL: this.oPlayer.oConfig.sRootAPIURL,
								sData: "action={'action':'get_collection_list','catalog_name':'" + oArgs.sCatalog + "'}",
								oContext: this,
								fnSuccess: this.UpdateHint,
								oSuccessArgs: { sHint: "selector", bAfterLoad: true, oContext: oArgs.oContext, fn: oArgs.fn },
								fnFailure: function () { oThis.jSelectThrobber.hide(); }
							});
						}
					}
				}
				else if(oArgs.bAjax!=true && oArgs.aOptions!=null)
				{
					for(i=0; i<oArgs.aOptions.length; i++)
					{
						this.jSelectListItemTemplate.clone(true).removeAttr("cx-template").attr({ "wt-idx": i, "wt-id": oArgs.aOptions[i].id, "wt-selected": (oArgs.sValue==oArgs.aOptions[i].id ? "1" : "0") }).html(oArgs.aOptions[i].name).on("click", function (e) { oArgs.fn.call(oArgs.oContext, { oElem: this, oEvt: e }); oThis.HideHint(); }).appendTo(this.jSelectList);
					}
					jSelectedItem = this.jSelectList.children("[wt-selected='1']");
					if(jSelectedItem.length!=0)
					{
						setTimeout(function () { jSelectedItem[0].scrollIntoView(true); }, 100);
					}
				}
			}
		}
		else
		{
			this.jHintList.html("");
			this.jHintContainer.find("[cx-btn='hint']").prop("disabled", false);
			switch(oArgs.sType)
			{
				case "local":
				{
					this.jHintContainer.attr({ "cx-state": "local" });
					this.jBtnHintLocal.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.wvars!=null)
					{
						if(Array.isArray(this.oPlayer.oCurrentWebModeCopy.wvars))
						{
							if(this.oPlayer.oCurrentWebModeCopy.wvars.length>0)
							{
								for(j=this.oPlayer.oCurrentWebModeCopy.wvars.length-1; j>=0; j--)
								{
									if(this.oPlayer.oCurrentWebModeCopy.wvars[j].name=="webmode.local_vars")
									{
										var sVars = $.trim(this.oPlayer.oCurrentWebModeCopy.wvars[j].value);
										if(sVars!="")
										{
											sVars = TOOLS.Base64.Decode({ sString: sVars });
											try
											{
												aVars = JSON.parse(sVars);
											}
											catch(e) {}
											if(Array.isArray(aVars))
											{
												for(i=0; i<aVars.length; i++)
												{
													jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
													jRow.find("[cx-role='hint-item-name']").html("{{LOCAL." + aVars[i].id + "}}");
													jRow.find("[cx-role='hint-item-type']").html(aVars[i].type);
													jRow.find("[cx-role='hint-item-title']").html(aVars[i].title);
												}
											}
										}
										break;
									}
								}
							}
						}
					}
					break;
				}
				case "doc":
				{
					this.jHintContainer.attr({ "cx-state": "doc" });
					this.jBtnHintDoc.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.doc_fields != null)
					{
						if(typeof this.oPlayer.oCurrentWebModeCopy.doc_fields == "object")
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.doc_fields.length; i++)
							{
								jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
								jRow.find("[cx-role='hint-item-name']").html("{{curDoc." + this.oPlayer.oCurrentWebModeCopy.doc_fields[i].name + "}}");
								jRow.find("[cx-role='hint-item-type']").html(this.oPlayer.oCurrentWebModeCopy.doc_fields[i].type);
								jRow.find("[cx-role='hint-item-title']").html(this.oPlayer.oCurrentWebModeCopy.doc_fields[i].title);
							}
						}
					}
					break;
				}
				case "env":
				{
					this.jHintContainer.attr({ "cx-state": "env" });
					this.jBtnHintEnv.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.env != null)
					{
						if(typeof this.oPlayer.oCurrentWebModeCopy.env == "object")
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.env.length; i++)
							{
								jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
								jRow.find("[cx-role='hint-item-name']").html("{{curEnv." + this.oPlayer.oCurrentWebModeCopy.env[i].name + "}}");
								jRow.find("[cx-role='hint-item-type']").html(this.oPlayer.oCurrentWebModeCopy.env[i].type);
								jRow.find("[cx-role='hint-item-title']").html(this.oPlayer.oCurrentWebModeCopy.env[i].title);
							}
						}
					}
					break;
				}
				case "object":
				{
					this.jHintContainer.attr({ "cx-state": "object" });
					this.jBtnHintObject.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.object_fields != null)
					{
						if(typeof this.oPlayer.oCurrentWebModeCopy.object_fields == "object")
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.object_fields.length; i++)
							{
								jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
								jRow.find("[cx-role='hint-item-name']").html("{{curObject." + this.oPlayer.oCurrentWebModeCopy.object_fields[i].name + "}}");
								jRow.find("[cx-role='hint-item-type']").html(this.oPlayer.oCurrentWebModeCopy.object_fields[i].type);
								jRow.find("[cx-role='hint-item-title']").html(this.oPlayer.oCurrentWebModeCopy.object_fields[i].title);
							}
						}
					}
					break;
				}
				case "context":
				{
					this.jHintContainer.attr({ "cx-state": "context" });
					this.jBtnHintContext.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.context != null)
					{
						if(typeof this.oPlayer.oCurrentWebModeCopy.context == "object")
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.context.length; i++)
							{
								jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
								jRow.find("[cx-role='hint-item-name']").html("{{curContext." + this.oPlayer.oCurrentWebModeCopy.context[i].name + "}}");
								jRow.find("[cx-role='hint-item-type']").html(this.oPlayer.oCurrentWebModeCopy.context[i].type);
								jRow.find("[cx-role='hint-item-title']").html(this.oPlayer.oCurrentWebModeCopy.context[i].title);
							}
						}
					}
					break;
				}
				case "user":
				{
					this.jHintContainer.attr({ "cx-state": "user" });
					this.jBtnHintUser.prop("disabled", true);
					if(this.oPlayer.oCurrentWebModeCopy.user_fields != null)
					{
						if(typeof this.oPlayer.oCurrentWebModeCopy.user_fields == "object")
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.user_fields.length; i++)
							{
								jRow = this.jHintListItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jHintList).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
								jRow.find("[cx-role='hint-item-name']").html("{{curUser." + this.oPlayer.oCurrentWebModeCopy.user_fields[i].name + "}}");
								jRow.find("[cx-role='hint-item-type']").html(this.oPlayer.oCurrentWebModeCopy.user_fields[i].type);
								jRow.find("[cx-role='hint-item-title']").html(this.oPlayer.oCurrentWebModeCopy.user_fields[i].title);
							}
						}
					}
					break;
				}
			}
		}
		return this;
    };
}
{ // CXBuilder
    window.CXBuilder = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
		this.oPage = oArgs.oPage;
		this.sType = oArgs.sType;
		this.oRule = {};
		this.aCollectionFlds = [];
		this.oSrc = null;
		this.oFolder = null;
		this.sCollectionId = "";
		this.oSelectedCollection = null;
		this.oOWT = null;
        this.Constructor();
        return this;
    };
    CXBuilder.prototype = Object.create(WTBaseObject.prototype);
    CXBuilder.prototype.constructor = CXBuilder;
	CXBuilder.prototype.AppendCondition = function (oArgs)
	{
		var oThis = this;
		var sId = TOOLS.ShortID();
		var jRoot = null;
		var j;
		if(oArgs!=null)
		{
			if(oArgs.jRoot!=null)
			{
				jRoot = oArgs.jRoot;
			}
			else if(oArgs.sParentId!=null)
			{
				if(this.oGroups[oArgs.sParentId]!=null)
				{
					jRoot = this.oGroups[oArgs.sParentId].jRoot;
				}
			}
		}
		if(jRoot!=null)
		{
			this.oConditions[sId] =
			{
				jElem: this.jConditionTemplate.clone(true).removeAttr("cx-template").attr({ "cx-item-id": sId }).appendTo(jRoot),
				sId: sId,
				sParentId: (oArgs==null ? "" : oArgs.sParentId),
				oCond: oArgs.oCondition
			};
			this.oConditions[sId].jAreaSelector = this.oConditions[sId].jElem.find("[cx-role='area-selector']").attr({ "cx-item-id": sId });
			if(this.oRule.type=="hide")
			{
				if(this.oPlayer.oCurrentWebModeCopy.user_fields==null || (this.oPlayer.oCurrentWebModeCopy.user_fields!=null && this.oPlayer.oCurrentWebModeCopy.user_fields.length==0))
				{
					this.oConditions[sId].jAreaSelector.children("option[value='curUser']").remove();
				}
				if(this.oPlayer.oCurrentWebModeCopy.object_fields==null || (this.oPlayer.oCurrentWebModeCopy.object_fields!=null && this.oPlayer.oCurrentWebModeCopy.object_fields.length==0))
				{
					this.oConditions[sId].jAreaSelector.children("option[value='curObject']").remove();
				}
				/*if(this.oPlayer.oCurrentWebModeCopy.context==null || (this.oPlayer.oCurrentWebModeCopy.context!=null && this.oPlayer.oCurrentWebModeCopy.context.length==0))
				{
					this.oConditions[sId].jAreaSelector.children("option[value='curContext']").remove();
				}*/
				if(this.oPlayer.oCurrentWebModeCopy.env==null || (this.oPlayer.oCurrentWebModeCopy.env!=null && this.oPlayer.oCurrentWebModeCopy.env.length==0))
				{
					this.oConditions[sId].jAreaSelector.children("option[value='curEnv']").remove();
				}
				if(this.oPlayer.oCurrentWebModeCopy.doc_fields==null || (this.oPlayer.oCurrentWebModeCopy.doc_fields!=null && this.oPlayer.oCurrentWebModeCopy.doc_fields.length==0))
				{
					this.oConditions[sId].jAreaSelector.children("option[value='curDoc']").remove();
				}
				this.oConditions[sId].jAreaSelector.children("option[value='LOCAL']").remove();
			}
			else if(this.oRule.type=="link")
			{
				this.oConditions[sId].jAreaSelector.children("option[value='curUser']").remove();
				this.oConditions[sId].jAreaSelector.children("option[value='curObject']").remove();
				//this.oConditions[sId].jAreaSelector.children("option[value='curContext']").remove();
				this.oConditions[sId].jAreaSelector.children("option[value='curEnv']").remove();
				this.oConditions[sId].jAreaSelector.children("option[value='curDoc']").remove();
			}
			this.oConditions[sId].jAreaSelector.on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
			this.oConditions[sId].jPropertyName = this.oConditions[sId].jElem.find("[cx-role='property-name']").attr({ "cx-item-id": sId }).on("focus keyup", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
			this.oConditions[sId].jOperatorSelector = this.oConditions[sId].jElem.find("[cx-role='operator-selector']").attr({ "cx-item-id": sId }).on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
			this.oConditions[sId].jAllOptions = this.oConditions[sId].jOperatorSelector.find("option");
			this.oConditions[sId].jBooleanOptions = this.oConditions[sId].jOperatorSelector.find("option[cx-option-boolean]");
			this.oConditions[sId].jStringOptions = this.oConditions[sId].jOperatorSelector.find("option[cx-option-string]");
			this.oConditions[sId].jNumericOptions = this.oConditions[sId].jOperatorSelector.find("option[cx-option-numeric]");
			this.oConditions[sId].jPropertyValue = this.oConditions[sId].jElem.find("[cx-role='property-value']").attr({ "cx-item-id": sId }).on("keyup", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
			this.oConditions[sId].jElem.find("[cx-btn]").attr({ "cx-item-id": sId }).on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });

			if(oArgs.oCondition!=null)
			{
				if(oArgs.oCondition.top_elem!=null)
				{
					this.oConditions[sId].jAreaSelector.val(oArgs.oCondition.top_elem);
				}
				this.UIEvent({ oElem: this.oConditions[sId].jAreaSelector[0], oEvt: { type: "change" } });
				if(oArgs.oCondition.field!=null)
				{
					this.oConditions[sId].jPropertyName.val(oArgs.oCondition.field);
				}
				switch(oArgs.oCondition.type)
				{
					case "bool":
					{
						//this.oConditions[sId].jBooleanOptions.show();
						break;
					}
					case "integer":
					case "real":
					case "date":
					{
						//this.oConditions[sId].jNumericOptions.show();
						break;
					}
					default:
					{
						//this.oConditions[sId].jStringOptions.show();
						break;
					}
				}
				if(oArgs.oCondition.option_type!=null)
				{
					this.oConditions[sId].jOperatorSelector.val(oArgs.oCondition.option_type);
				}
				else
				{
					this.oConditions[sId].jOperatorSelector.val("eq");
				}
				if(oArgs.oCondition.value!=null)
				{
					this.oConditions[sId].jPropertyValue.val(oArgs.oCondition.value);
				}
			}
			else
			{
				this.UIEvent({ oElem: this.oConditions[sId].jAreaSelector[0], oEvt: { type: "change" } });
				switch(this.oConditions[sId].type)
				{
					case "bool":
					{
						//this.oConditions[sId].jBooleanOptions.show();
						break;
					}
					case "integer":
					case "real":
					case "date":
					{
						//this.oConditions[sId].jNumericOptions.show();
						break;
					}
					default:
					{
						//this.oConditions[sId].jStringOptions.show();
						break;
					}
				}
			}
			if(this.oConditions[sId].sParentId!="")
			{
				if(this.oGroups[this.oConditions[sId].sParentId]!=null)
				{
					this.oGroups[this.oConditions[sId].sParentId].aChildren.push(sId);
				}
			}
		}
		return this;
	};
	CXBuilder.prototype.AppendGroup = function (oArgs)
	{
		var oThis = this;
		var sId = TOOLS.ShortID();
		var jRoot = this.jRoot;
		if(oArgs!=null)
		{
			if(oArgs.sId!=null)
			{
				sId = oArgs.sId;
			}
			if(oArgs.jRoot!=null)
			{
				jRoot = oArgs.jRoot;
			}
			else if(oArgs.sParentId!=null)
			{
				if(this.oGroups[oArgs.sParentId]!=null)
				{
					jRoot = this.oGroups[oArgs.sParentId].jRoot;
				}
			}
		}
		this.oGroups[sId] =
		{
			jElem: this.jGroupTemplate.clone(true).removeAttr("cx-template").attr({ "cx-group-id": sId }).appendTo(jRoot),
			sId: sId,
			sParentId: (oArgs==null ? "" : oArgs.sParentId),
			aChildren: []
		};
		this.oGroups[sId].jRoot = this.oGroups[sId].jElem.find("[cx-role='condition-group-body']");
		this.oGroups[sId].jElem.find("[cx-btn]").attr({ "cx-group-id": sId }).on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		this.oGroups[sId].jBtnOperator = this.oGroups[sId].jElem.find("[cx-role='group-operator']");
		if(this.oGroups[sId].sParentId!="")
		{
			if(this.oGroups[this.oGroups[sId].sParentId]!=null)
			{
				this.oGroups[this.oGroups[sId].sParentId].aChildren.push(sId);
			}
		}
		return this;
	};
	CXBuilder.prototype.AppendLink = function (oArgs)
	{
		var oThis = this;
		var sId = TOOLS.ShortID();
		var jRoot = this.jRoot;
		var j,k;
		this.jLinkContainer = this.jLinkTemplate.clone(true).removeAttr("cx-template").attr({ "cx-link-id": sId }).appendTo(jRoot);
		this.jLinkRoot = this.jLinkContainer.find("[cx-role='rule-link-list']");
		var aTemplates = JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy.zones[0].templates)).sort(function (oElem1, oElem2)
		{
			if(oElem1.weight>oElem2.weight)
			{
				return 1;
			}
			if(oElem1.weight<oElem2.weight)
			{
				return -1;
			}
			return 0;
		});
		for(j=0; j<aTemplates.length; j++)
		{
			this.jLinkSrcTemplate.clone(true).removeAttr("cx-template").attr({ "cx-template-id": aTemplates[j].override_template_id, "cx-current": ((aTemplates[j].override_template_id!=this.oPage.oCurrentObjectDialog.oCurrentOWT.override_template_id) ? "0" : "1") }).html(aTemplates[j].weight + " " + aTemplates[j].name).appendTo(this.jLinkRoot);
			if(aTemplates[j].templates!=null)
			{
				for(k=0; k<aTemplates[j].templates.length; k++)
				{
					this.jLinkSrcTemplate.clone(true).removeAttr("cx-template").attr({ "cx-child": "1", "cx-template-id": aTemplates[j].templates[k].override_template_id, "cx-current": ((aTemplates[j].templates[k].override_template_id!=this.oPage.oCurrentObjectDialog.oCurrentOWT.override_template_id) ? "0" : "1") }).html(aTemplates[j].weight + "-" + aTemplates[j].templates[k].weight + " " + aTemplates[j].templates[k].name).appendTo(this.jLinkRoot);
				}
			}
		}
		this.jLinkRoot.selectable({ cancel: "[cx-current='1']", selected: function (e, ui) { oThis.UIEvent.call(oThis, { oElem: ui, oEvt: e }); } });
		if(this.oRule.source_template_id!="")
		{
			this.jLinkRoot.find("[cx-template-id='" + this.oRule.source_template_id + "']").addClass("ui-selecting");
			this.jLinkRoot.data("uiSelectable")._mouseStop(null);
		}
		return this;
	};
	CXBuilder.prototype.Constructor = function (oArgs)
	{
		var oThis = this;
		this.jDialog = this.oPlayer.jStorage.find("[cx-template='builder-" + this.sType + "']").clone(true).removeAttr("cx-template").appendTo(this.jContainer);
		this.jTopContainer = this.jDialog.find("[cx-role='top-container']");
		this.jHeader = this.jTopContainer.find("[cx-role='header']");
		this.jBody = this.jDialog.find("[cx-role='body-container']");
		this.jDialog.find("[cx-btn]").on("click", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		switch(this.sType)
		{
			case "rule":
			{
				this.oGroups = {};
				this.oConditions = {};
				this.jGroupTemplate = this.oPlayer.jStorage.find("[cx-template='rule-group']");
				this.jConditionTemplate = this.oPlayer.jStorage.find("[cx-template='rule-condition']");
				this.jLinkTemplate = this.oPlayer.jStorage.find("[cx-template='rule-link']");
				this.jLinkSrcTemplate = this.oPlayer.jStorage.find("[cx-template='rule-link-src']");
				this.jActionSelector = this.jBody.find("[cx-role='action-selector']").on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
				this.jLinkSelector = this.jBody.find("[cx-role='link-selector']").on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
				this.jRoot = this.jBody.find("[cx-role='rule-root']");
				this.oRule.type = this.jActionSelector.val();
				this.Reset().Fill();
				break;
			}
			case "map":
			{
				this.oFlds = {};
				this.jItemTemplate = this.oPlayer.jStorage.find("[cx-template='map-item']");
				this.jCollectionName = this.jBody.find("[cx-role='collection-name']");
				this.jRoot = this.jBody.find("[cx-role='map-root']");
				this.Reset().Fill();
				break;
			}
		}
		return this;
	};
	CXBuilder.prototype.DeleteCondition = function (oArgs)
	{
		if(oArgs.sId!=null)
		{
			if(this.oConditions[oArgs.sId]!=null)
			{
				this.oConditions[oArgs.sId].jElem.remove();
				delete this.oConditions[oArgs.sId];
			}
		}
		return this;
	};
	CXBuilder.prototype.DeleteGroup = function (oArgs)
	{
		var sKey;
		if(oArgs.sId!=null)
		{
			if(this.oGroups[oArgs.sId]!=null)
			{
				for(sKey in this.oConditions)
				{
					if(this.oConditions[sKey].sParentId==oArgs.sId)
					{
						this.DeleteCondition({ sId: sKey });
					}
				}
				this.oGroups[oArgs.sId].jElem.remove();
				delete this.oGroups[oArgs.sId];
			}
		}
		return this;
	};
	CXBuilder.prototype.Fill = function (oArgs)
	{
		switch(this.sType)
		{
			case "rule":
			{
				this.AppendGroup({ jRoot: this.jRoot, sId: this.oRule.id }); // group level 0
				switch(this.oRule.type)
				{
					case "local_hide":
					case "local_show":
					case "link":
					case "hide":
					{
						var i, j;
						var sGroupId;
						var sOp = "AND";
						if(this.oRule.id!=null && this.oRule.conditions!=null)
						{
							for(i=0; i<this.oRule.conditions.length; i++)
							{
								if(this.oRule.conditions[i].bracket=="(") // start of new group
								{
									sGroupId = TOOLS.ShortID();
									this.AppendGroup({ sId: sGroupId, sParentId: this.oRule.id }); // group level 1
									this.SetGroupOperator({ sGroupId: sGroupId, sOp: this.oRule.conditions[i].and_or });
									this.AppendCondition({ sParentId: sGroupId, oCondition: this.oRule.conditions[i] });
									do
									{
										i++;
										if(i<this.oRule.conditions.length)
										{
											this.AppendCondition({ sParentId: sGroupId, oCondition: this.oRule.conditions[i] });
											if(this.oRule.conditions[i].bracket==")")
											{
												sOp = this.oRule.conditions[i].and_or;
												break;
											}
										}
									}
									while(i<this.oRule.conditions.length);
								}
								else
								{
									this.AppendCondition({ sParentId: this.oRule.id, oCondition: this.oRule.conditions[i] });
								}
								if(i==this.oRule.conditions.length-1)
								{
									sOp = this.oRule.conditions[i].and_or.toUpperCase();
								}
							}

							this.SetGroupOperator({ sGroupId: this.oRule.id, sOp: sOp });
						}
						break;
					}
				}
				break;
			}
			case "map":
			{
				break;
			}
		}
		return this;
	};
	CXBuilder.prototype.Hide = function (oArgs)
	{
		this.oPlayer.oMask.Hide();
		this.jDialog.hide();
		return this;
	};
	CXBuilder.prototype.ToggleOperator = function (oArgs)
	{
		if(oArgs.oElem.getAttribute("cx-state")=="AND")
		{
			oArgs.oElem.setAttribute("cx-state", "OR");
		}
		else
		{
			oArgs.oElem.setAttribute("cx-state", "AND");
		}
		return this;
	};
	CXBuilder.prototype.Reset = function (oArgs)
	{
		this.jRoot.html("");
		this.oRule.source_template_id = "";
		switch(this.sType)
		{
			case "rule":
			{
				this.oRule.conditions = [];
				break;
			}
			case "map":
			{
				this.sCollectionId = "";
				break;
			}
		}
		return this;
	};
	CXBuilder.prototype.SetGroupOperator = function (oArgs)
	{
		this.oGroups[oArgs.sGroupId].jBtnOperator.attr({ "cx-state": oArgs.sOp.toUpperCase() });
		return this;
	};
    CXBuilder.prototype.Show = function(oArgs)
	{
		var oThis = this;
		this.jDialog.appendTo("body").css({ "opacity": 0 }).show();
		var nL = this.oPage.jSlideBlock.width() - this.jDialog.outerWidth(true);
		var nH = this.oPage.jSlideBlock.height();
		var nT = this.oPage.jNavLeft.offset().top + this.oPage.jNavLeft.outerHeight(true);
		this.oPlayer.oMask.Show({ bPlain: true, bDark: true });
		this.oPlayer.oMask.jMask.one("click", function () { oThis.Hide(); });
		this.jDialog.appendTo("body").css({ "left": nL + "px", "top": nT + "px", "height": nH + "px" }).animate({ "opacity": 1 }, 250);
		return this;
	};
    CXBuilder.prototype.SubmitMap = function (oArgs)
	{
		var sName, sValueName;
		var sCurTemplateName = (this.oFolder.aMappingFlds.length>0) ? this.oFolder.aMappingFlds[0].name.split(".")[0] : "N/A";
		for(var sKey in this.oFlds)
		{
			if(sKey.indexOf(sCurTemplateName)==0)
			{
				sName = TOOLS.EncodeVarName({ sText: this.oFolder.aMappingFlds[ this.oFlds[sKey].iIdx ].name });
				if(this.oFolder.oPage.oFlds[sName]!=null)
				{
					this.oFolder.oPage.oFlds[sName].SetValue({ sValue: this.oFlds[sKey].jFld.val(), sName: this.oFlds[sKey].jFld[0].options[this.oFlds[sKey].jFld[0].selectedIndex].text });
					this.oPage.oEditor._GetParam({ aParams: this.oOWT.params, sName: this.oFolder.aMappingFlds[ this.oFlds[sKey].iIdx ].name, bObject: true }).value = this.oFlds[sKey].jFld.val();
				}
				sValueName = TOOLS.EncodeVarName({ sText: this.oFolder.aMappingValueFlds[ this.oFlds[sKey].iIdxValue ].name });
				if(this.oFolder.oPage.oFlds[sValueName]!=null)
				{
					this.oFolder.oPage.oFlds[sValueName].SetValue({ sValue: this.oFlds[sKey].jFldValue.val() });
					this.oPage.oEditor._GetParam({ aParams: this.oOWT.params, sName: this.oFolder.aMappingValueFlds[ this.oFlds[sKey].iIdxValue ].name, bObject: true }).value = this.oFlds[sKey].jFldValue.val();
				}
			}
		}
		return this;
	};
	CXBuilder.prototype.UIEvent = function(oArgs)
	{
		if(oArgs.oEvt.type=="selectableselected")
		{
			this.oRule.source_template_id = oArgs.oElem.selected.getAttribute("cx-template-id");
			return this;
		}
		var sRole = oArgs.oElem.getAttribute("cx-role");
		var sId;
		var oThis = this;
		switch(sRole)
		{
			case "action-selector":
			{
				if(this.oRule.conditions.length!=0)
				{
					if(!confirm(this.oPlayer._GetString({ sId: "confirm-action-change" })))
					{
						oArgs.oElem.value = this.oRule.type;
						return this;
					}
				}
				this.oRule.type = oArgs.oElem.value;
				this.oRule.conditions = [];
				this.Update({ bActionChanged: true });
				break;
			}
			case "link-selector":
			{
				this.Update({ bLinkChanged: true });
				break;
			}
			case "map-fld":
			{
				if(oArgs.oElem.value=="__substitution__")
				{
					this.jRoot.find("[cx-name='" + oArgs.oElem.getAttribute("cx-name") + "-value']").prop("disabled", false);
				}
				else
				{
					this.jRoot.find("[cx-name='" + oArgs.oElem.getAttribute("cx-name") + "-value']").prop("disabled", true);
				}
				break;
			}
			case "rule-apply":
			{
				this.UpdateRule();
				this.oSrc.Apply({ oRule: this.oRule });
				this.Hide();
				break;
			}
			case "map-apply":
			{
				this.SubmitMap().Hide();
				this.oFolder.oPage.UpdateModified();
				break;
			}
			case "rule-cancel":
			case "map-cancel":
			case "btn-close":
			{
				this.Hide();
				break;
			}
			case "group-add":
			{
				this.AppendGroup({ sParentId: oArgs.oElem.getAttribute("cx-group-id") });
				break;
			}
			case "condition-add":
			{
				this.AppendCondition({ sParentId: oArgs.oElem.getAttribute("cx-group-id") });
				break;
			}
			case "group-delete":
			{
				this.DeleteGroup({ sId: oArgs.oElem.getAttribute("cx-group-id") });
				break;
			}
			case "condition-delete":
			{
				this.DeleteCondition({ sId: oArgs.oElem.getAttribute("cx-item-id") });
				break;
			}
			case "group-operator":
			{
				this.ToggleOperator(oArgs);
				break;
			}
			case "area-selector":
			{
				sId = oArgs.oElem.getAttribute("cx-item-id");
				//this.oConditions[sId].jAllOptions.hide();
				if(this.oConditions[sId]!=null)
				{
					var aHints = [];
					this.oConditions[sId].oHints = {};
					var i,j;
					switch($(oArgs.oElem).val())
					{
						case "curUser":
						{
							for(i=0; i<this.oPlayer.oCurrentWebModeCopy.user_fields.length; i++)
							{
								aHints.push({ label: this.oPlayer.oCurrentWebModeCopy.user_fields[i].id, title: this.oPlayer.oCurrentWebModeCopy.user_fields[i].title });
								this.oConditions[sId].oHints[this.oPlayer.oCurrentWebModeCopy.user_fields[i].id] = this.oPlayer.oCurrentWebModeCopy.user_fields[i];
							}
							break;
						}
						case "curObject":
						{
							if(this.oPlayer.oCurrentWebModeCopy.object_fields!=null)
							{
								for(i=0; i<this.oPlayer.oCurrentWebModeCopy.object_fields.length; i++)
								{
									aHints.push({ label: this.oPlayer.oCurrentWebModeCopy.object_fields[i].id, title: this.oPlayer.oCurrentWebModeCopy.object_fields[i].title });
									this.oConditions[sId].oHints[this.oPlayer.oCurrentWebModeCopy.object_fields[i].id] = this.oPlayer.oCurrentWebModeCopy.object_fields[i];
								}
							}
							break;
						}
						case "curContext":
						{
							if(this.oPlayer.oCurrentWebModeCopy.context!=null)
							{
								for(i=0; i<this.oPlayer.oCurrentWebModeCopy.context.length; i++)
								{
									aHints.push({ label: this.oPlayer.oCurrentWebModeCopy.context[i].id, title: this.oPlayer.oCurrentWebModeCopy.context[i].title });
									this.oConditions[sId].oHints[this.oPlayer.oCurrentWebModeCopy.context[i].id] = this.oPlayer.oCurrentWebModeCopy.context[i];
								}
							}
							break;
						}
						case "curEnv":
						{
							if(this.oPlayer.oCurrentWebModeCopy.env!=null)
							{
								for(i=0; i<this.oPlayer.oCurrentWebModeCopy.env.length; i++)
								{
									aHints.push({ label: this.oPlayer.oCurrentWebModeCopy.env[i].id, title: this.oPlayer.oCurrentWebModeCopy.env[i].title });
									this.oConditions[sId].oHints[this.oPlayer.oCurrentWebModeCopy.env[i].id] = this.oPlayer.oCurrentWebModeCopy.env[i];
								}
							}
							break;
						}
						case "curDoc":
						{
							if(this.oPlayer.oCurrentWebModeCopy.doc_fields!=null)
							{
								for(i=0; i<this.oPlayer.oCurrentWebModeCopy.doc_fields.length; i++)
								{
									aHints.push({ label: this.oPlayer.oCurrentWebModeCopy.doc_fields[i].id, title: this.oPlayer.oCurrentWebModeCopy.doc_fields[i].title });
									this.oConditions[sId].oHints[this.oPlayer.oCurrentWebModeCopy.doc_fields[i].id] = this.oPlayer.oCurrentWebModeCopy.doc_fields[i];
								}
							}
							break;
						}
						case "LOCAL":
						{
							if(this.oPlayer.oCurrentWebModeCopy.wvars!=null)
							{
								for(j=this.oPlayer.oCurrentWebModeCopy.wvars.length-1; j>=0; j--)
								{
									if(this.oPlayer.oCurrentWebModeCopy.wvars[j].name=="webmode.local_vars")
									{
										var sVars = $.trim(this.oPlayer.oCurrentWebModeCopy.wvars[j].value);
										if(sVars!="")
										{
											sVars = TOOLS.Base64.Decode({ sString: sVars });
											var aVars = [];
											try
											{
												aVars = JSON.parse(sVars);
											}
											catch(e) {}
											if(Array.isArray(aVars))
											{
												for(i=0; i<aVars.length; i++)
												{
													aHints.push({ label: aVars[i].id, title: (aVars[i].title==null ? "" : aVars[i].title) });
													this.oConditions[sId].oHints[aVars[i].id] = aVars[i];
												}
											}
										}
										break;
									}
								}
							}
							break;
						}
					}
					this.oConditions[sId].jPropertyName.val("").autocomplete(
					{
						classes: { "ui-autocomplete": "cx-autocomplete-list", "ui-menu-item": "cx-autocomplete-item" },
						minLength: 0,
						source: aHints,
						focus: function( event, ui )
						{
						  oThis.oConditions[sId].jPropertyName.val( ui.item.label );
						  return false;
						},
						select: function( event, ui )
						{
						  oThis.oConditions[sId].jPropertyName.val( ui.item.label );
						  oThis.oConditions[sId].jPropertyName.attr({ "title": ui.item.title });
						  oThis.oConditions[sId].jPropertyValue.attr({ "cx-value-type": oThis.oConditions[sId].oHints[ui.item.label].type });
						  //oThis.oConditions[sId].jAllOptions.hide();
						  switch(oThis.oConditions[sId].oHints[ui.item.label].type)
						  {
							case "bool":
							{
								//oThis.oConditions[sId].jBooleanOptions.show();
								break;
							}
							case "integer":
							case "real":
							case "date":
							{
								//oThis.oConditions[sId].jNumericOptions.show();
								break;
							}
							default:
							{
								//oThis.oConditions[sId].jStringOptions.show();
								break;
							}
						  }
						  oThis.oConditions[sId].type = oThis.oConditions[sId].oHints[ui.item.label].type;
						  oThis.oConditions[sId].jOperatorSelector.val("eq");
						  return false;
						},
						open: function (event, ui)
						{
							var iWH = window.innerHeight || document.documentElement.clientHeight;
							var jMenu = $(this).autocomplete("instance").menu.activeMenu;
							var iMH = jMenu.height();
							if((iWH-iMH)<jMenu.position().top)
							{
								$(this).autocomplete("option", "position", { my : "left top", at: "left bottom" });
							}
						},
						close: function (event, ui)
						{
							$(this).autocomplete("option", "position", { my : "left bottom", at: "left top" });
						}
					}).autocomplete( "instance" )._renderItem = function( ul, item )
					{
						return $( "<li cx-role='autocomplete-item'>" ).append( "<div><span cx-role='ac-item-name'>" + item.label + "</span> - " + item.title + "</div>" ).appendTo( ul );
					 };
					this.oConditions[sId].jPropertyValue.val("");
				}
				break;
			}
		}
		return this;
	};
    CXBuilder.prototype.Update = function(oArgs)
	{
		var i,j;
		var oThis = this;
		if(oArgs.bAfterLoad==true)
		{
			if(oArgs.oData!=null)
			{
				if(oArgs.oData.error==0)
				{
					if(oArgs.oData.collections!=null)
					{
						if(Array.isArray(oArgs.oData.collections))
						{
							if(oArgs.oData.collections.length>0)
							{
								this.oPlayer.oCurrentWebModeCopy.all_collections = [];
							}
							for(i=0; i<oArgs.oData.collections.length; i++)
							{
								this.oPlayer.oCurrentWebModeCopy.all_collections.push(JSON.parse(JSON.stringify(oArgs.oData.collections[i])));
							}
						}
					}
				}
			}
		}
		switch(this.sType)
		{
			case "rule":
			{
				if(oArgs.oSrc!=null)
				{
					this.oSrc = oArgs.oSrc;
				}
				if(oArgs.oData!=null)
				{
					var aConditions = oArgs.oData.web_mode.template_links;
					for(i=0; i<oArgs.oData.web_mode.template_links.length; i++)
					{
						if(oArgs.oData.web_mode.template_links[i].id==oArgs.sRuleId)
						{
							this.oRule = JSON.parse(JSON.stringify(oArgs.oData.web_mode.template_links[i]));
						}
					}
				}
				else if(oArgs.oRule!=null)
				{
					this.oRule = JSON.parse(JSON.stringify(oArgs.oRule));
				}
				this.jRoot.html("");
				this.jActionSelector.val(this.oRule.type);

				if(this.oPlayer.oCurrentWebModeCopy.wvars==null || (this.oPlayer.oCurrentWebModeCopy.wvars!=null && this.oPlayer.oCurrentWebModeCopy.wvars.length==0))
				{
					this.jLinkSelector.children("option[value='local']").remove();
				}
				else
				{
					if(Array.isArray(this.oPlayer.oCurrentWebModeCopy.wvars))
					{
						var bLocal = false;
						for(j=this.oPlayer.oCurrentWebModeCopy.wvars.length-1; j>=0; j--)
						{
							if(this.oPlayer.oCurrentWebModeCopy.wvars[j].name=="webmode.local_vars")
							{
								var sVars = $.trim(this.oPlayer.oCurrentWebModeCopy.wvars[j].value);
								if(sVars!="")
								{
									sVars = TOOLS.Base64.Decode({ sString: sVars });
									var aVars = [];
									try
									{
										aVars = JSON.parse(sVars);
									}
									catch(e) {}
									if(Array.isArray(aVars))
									{
										bLocal = (aVars.length>0);
									}
								}
								break;
							}
						}
						if(!bLocal)
						{
							this.jLinkSelector.children("option[value='local']").remove();
						}
					}
					else
					{
						this.jLinkSelector.children("option[value='local']").remove();
					}
				}

				switch(this.oRule.type)
				{
					case "link":
					{
						this.jLinkSelector.show();
						if(this.oRule.source_template_id=="" && !oArgs.bLinkChanged)
						{
							this.jLinkSelector.val("local");
						}
						if(this.jLinkSelector.val()=="local")
						{
							this.Fill();
						}
						else
						{
							this.AppendLink({ jRoot: this.jRoot, sId: this.oRule.id }); // src template always single
						}
						break;
					}
					case "local_show":
					case "local_hide":
					{
						this.jLinkSelector.hide();
						this.Fill();
						break;
					}
					case "hide":
					{
						this.jLinkSelector.hide();
						this.Fill();
						break;
					}
				}
				break;
			}
			case "map":
			{
				this.Reset();
				this.oFolder = oArgs.oFolder;
				this.sCollectionId = this.oFolder.oCollectionFld._GetValue();
				var oCollection = null;
				if(this.oPlayer.oCurrentWebModeCopy.collections != null)
				{
					for(i=0; i<this.oPlayer.oCurrentWebModeCopy.collections.length; i++)
					{
						if(this.oPlayer.oCurrentWebModeCopy.collections[i].id == this.sCollectionId)
						{
							oCollection = this.oPlayer.oCurrentWebModeCopy.collections[i];
							break;
						}
					}
				}
				if(oCollection==null)
				{
					if(this.oPlayer.oCurrentWebModeCopy.all_collections != null)
					{
						for(i=0; i<this.oPlayer.oCurrentWebModeCopy.all_collections.length; i++)
						{
							if(this.oPlayer.oCurrentWebModeCopy.all_collections[i].id == this.sCollectionId)
							{
								oCollection = this.oPlayer.oCurrentWebModeCopy.all_collections[i];
								break;
							}
						}
					}
					else if(this.oPlayer.oCollections != null)
					{
						oCollection = this.oPlayer.oCollections[this.sCollectionId];
						if(oCollection==null)
						{
							for(i=0; i<this.oPlayer.aCollections.length; i++)
							{
								if(this.oPlayer.aCollections[i].id == this.sCollectionId)
								{
									oCollection = this.oPlayer.aCollections[i];
									break;
								}
							}
						}
					}
					else
					{
						oArgs.bAfterLoad = true;
						this.Load(
						{
							sURL: this.oPlayer.oConfig.sRootAPIURL,
							sData: "action={'action':'get_collection_list','catalog_name':''}",
							oContext: this,
							fnSuccess: this.Update,
							oSuccessArgs: oArgs
						});
					}
				}
				if(oCollection==null)
				{
					break;
				}
				this.oSelectedCollection = oCollection;
				this.jCollectionName.html(this.oSelectedCollection.name);
				this.oOWT = this.oPage.oEditor._GetOWTCopy({ sId: this.oFolder.oDialog.sCurrentOWTId });
				var aParts;
				var sName, sValueName, sValue;
				for(i=0; i<this.oFolder.aMappingFlds.length; i++)
				{
					sName = TOOLS.EncodeVarName({ sText: this.oFolder.aMappingFlds[i].name });
					this.oFlds[sName] =
					{
						iIdx: i,
						jItem: this.jItemTemplate.clone(true).removeAttr("cx-template").appendTo(this.jRoot)
					};
					sValueName = this.oFolder.aMappingFlds[i].name + "__value";
					for(j=0; j<this.oFolder.aMappingValueFlds.length; j++)
					{
						if(this.oFolder.aMappingValueFlds[j].name==sValueName)
						{
							this.oFlds[sName].iIdxValue = j;
							break;
						}
					}
					this.oFlds[sName].sLabel = (this.oFolder.aMappingFlds[i].description!=null && this.oFolder.aMappingFlds[i].description!="") ? this.oFolder.aMappingFlds[i].description : this.oFolder.aMappingFlds[i].name;
					if(this.oFlds[sName].sLabel.indexOf("--")!=-1)
					{
						aParts = this.oFlds[sName].sLabel.split("--");
						if(aParts.length==2)
						{
							this.oFlds[sName].sLabel = aParts[0];
							this.oFlds[sName].sTitle = $.trim(aParts[1]);
						}
						else if(aParts.length>2)
						{
							this.oFlds[sName].sLabel = $.trim(aParts.shift());
							this.oFlds[sName].sTitle = $.trim(aParts.join("--"));
						}
						else
						{
							this.oFlds[sName].sTitle = this.oFlds[sName].sLabel;
						}
					}
					else
					{
						this.oFlds[sName].sTitle = this.oFlds[sName].sLabel;
					}
					this.oFlds[sName].jItem.find("[cx-role='map-fld-label']").attr({ "title": this.oFlds[sName].sTitle }).html(this.oFlds[sName].sLabel);
					this.oFlds[sName].jFld = this.oFlds[sName].jItem.find("[cx-role='map-fld']").attr({ "cx-name": this.oFolder.aMappingFlds[i].name });
					if(this.oSelectedCollection!=null)
					{
						for(j=0; j<this.oSelectedCollection.result_fields.length; j++)
						{
							this.oFlds[sName].jFld.append('<option value="' + this.oSelectedCollection.result_fields[j].name + '">' + this.oSelectedCollection.result_fields[j].title + '</option>');
						}
					}
					if(this.oFolder.oPage.oFlds[sName]!=null)
					{
						sValue = this.oPage.oEditor._GetParam({aParams: this.oOWT.params, sName: this.oFolder.aMappingFlds[i].name });
						if(this.oFlds[sName].jFld.find("option[value='" + sValue + "']").length!=0)
						{
							this.oFlds[sName].jFld.val( sValue );
						}
						else
						{
							this.oFlds[sName].jFld.val("");
						}
					}
					this.oFlds[sName].jFld.on("change", function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
					this.oFlds[sName].jFldValue = this.oFlds[sName].jItem.find("[cx-role='map-fld-value']").attr({ "cx-name": this.oFolder.aMappingFlds[i].name + "-value" });
					this.oFlds[sName].jFldValue.val( this.oPage.oEditor._GetParam({aParams: this.oOWT.params, sName: sValueName }) );
					if(this.oFlds[sName].jFld.val()=="__substitution__")
					{
						this.oFlds[sName].jFldValue.prop("disabled", false);
					}
					else
					{
						this.oFlds[sName].jFldValue.prop("disabled", true);
					}
				}
				break;
			}
		}
		return this;
	};
    CXBuilder.prototype.UpdateRule = function(oArgs)
	{
		var i, j;
		var oNewRule;
		var sMainOp, sCondId, sCondOp;
		switch(this.oRule.type)
		{
			case "hide":
			case "local_show":
			case "local_hide":
			{
				oNewRule = { id: this.oRule.id, source_template_id: "", target_template_id: this.oRule.target_template_id, type: this.oRule.type, conditions: [] };
				sMainOp = this.oGroups[this.oRule.id].jBtnOperator.attr("cx-state").toLowerCase();
				for(i=0; i<this.oGroups[this.oRule.id].aChildren.length; i++)
				{
					if(this.oGroups[this.oGroups[this.oRule.id].aChildren[i]]!=null)
					{
						for(j=0; j<this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length; j++)
						{
							if(j==0)
							{
								sCondOp = this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].jBtnOperator.attr("cx-state").toLowerCase();
							}
							sCondId = this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren[j];
							if(this.oConditions[sCondId]!=null)
							{
								oNewRule.conditions.push({
									and_or: ((j==this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length-1) ? sMainOp : sCondOp),
									bracket: (j==0 ? "(" : (j==this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length-1) ? ")" : ""),
									field: this.oConditions[sCondId].jPropertyName.val(),
									is_custom_field: false,
									is_multiple: false,
									option_type: this.oConditions[sCondId].jOperatorSelector.val(),
									title: "",
									top_elem: this.oConditions[sCondId].jAreaSelector.val(),
									type: this.oConditions[sCondId].type,
									value: this.oConditions[sCondId].jPropertyValue.val(),
								});
							}
						}
					}
					else if(this.oConditions[this.oGroups[this.oRule.id].aChildren[i]]!=null)
					{
						sCondId = this.oGroups[this.oRule.id].aChildren[i];
						oNewRule.conditions.push({
							and_or: sMainOp,
							bracket: "",
							field: this.oConditions[sCondId].jPropertyName.val(),
							is_custom_field: false,
							is_multiple: false,
							option_type: this.oConditions[sCondId].jOperatorSelector.val(),
							title: "",
							top_elem: this.oConditions[sCondId].jAreaSelector.val(),
							type: this.oConditions[sCondId].type,
							value: this.oConditions[sCondId].jPropertyValue.val(),
						});
					}
				}
				this.oRule = oNewRule;
				break;
			}
			case "link":
			{
				if(this.jLinkSelector.val()=="local")
				{
					oNewRule = { id: this.oRule.id, source_template_id: "", target_template_id: this.oRule.target_template_id, type: this.oRule.type, conditions: [] };
					sMainOp = this.oGroups[this.oRule.id].jBtnOperator.attr("cx-state").toLowerCase();
					for(i=0; i<this.oGroups[this.oRule.id].aChildren.length; i++)
					{
						if(this.oGroups[this.oGroups[this.oRule.id].aChildren[i]]!=null)
						{
							for(j=0; j<this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length; j++)
							{
								if(j==0)
								{
									sCondOp = this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].jBtnOperator.attr("cx-state").toLowerCase();
								}
								sCondId = this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren[j];
								if(this.oConditions[sCondId]!=null)
								{
									oNewRule.conditions.push({
										and_or: ((j==this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length-1) ? sMainOp : sCondOp),
										bracket: (j==0 ? "(" : (j==this.oGroups[this.oGroups[this.oRule.id].aChildren[i]].aChildren.length-1) ? ")" : ""),
										field: this.oConditions[sCondId].jPropertyName.val(),
										is_custom_field: false,
										is_multiple: false,
										option_type: this.oConditions[sCondId].jOperatorSelector.val(),
										title: "",
										top_elem: this.oConditions[sCondId].jAreaSelector.val(),
										type: this.oConditions[sCondId].type,
										value: this.oConditions[sCondId].jPropertyValue.val(),
									});
								}
							}
						}
						else if(this.oConditions[this.oGroups[this.oRule.id].aChildren[i]]!=null)
						{
							sCondId = this.oGroups[this.oRule.id].aChildren[i];
							oNewRule.conditions.push({
								and_or: sMainOp,
								bracket: "",
								field: this.oConditions[sCondId].jPropertyName.val(),
								is_custom_field: false,
								is_multiple: false,
								option_type: this.oConditions[sCondId].jOperatorSelector.val(),
								title: "",
								top_elem: this.oConditions[sCondId].jAreaSelector.val(),
								type: this.oConditions[sCondId].type,
								value: this.oConditions[sCondId].jPropertyValue.val(),
							});
						}
					}
					this.oRule = oNewRule;
				}
				break;
			}
		}
		return this;
	};
}
{ // CXPreview
    window.CXPreview = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.oBtns = {};
        this.sType = "";
        this.Constructor();
        return this;
    };
    CXPreview.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jMask = this.oPlayer.jContainer.find("[cx-role='preview-mask']");
        this.jContainer = this.oPlayer.jContainer.find("[cx-role='preview-container']");
        this.jContainerDesktop = this.jContainer.find("[cx-role='wrapper-desktop']");
        this.jFrameDesktop = this.jContainerDesktop.find("[cx-role='preview-frame-desktop']");
        this.oBtns["close"] = { jBtn: this.jContainer.find("[cx-role='preview-close']").on("click", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this, oThis: oThis }); }) };
        return this;
    };
    CXPreview.prototype.Hide = function(oArgs)
	{
        this.jFrameDesktop[0].setAttribute("src", this.oPlayer.oConfig.sBlankURL);
        this.sType = "";
        this.jContainer.hide();
        this.jMask.hide();
        return this;
    };
    CXPreview.prototype.Open = function(oArgs)
	{
        switch(oArgs.sType)
		{
            case "desktop":
			{
				this.jContainerDesktop.show();
				this.jFrameDesktop[0].setAttribute("src", oArgs.sURL);
				break;
			}
        }
        this.sType = oArgs.sType;
        return this;
    };
    CXPreview.prototype.Show = function(oArgs)
	{
        this.jMask.show();
        this.jContainer.css({ "display": "flex" });
        this.Open(oArgs);
        return this;
    };
    CXPreview.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXPreview))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXPreview))
			{
                return this;
            }
        }
        switch(oArgs.oElem.getAttribute("cx-role"))
		{
            case "preview-close":
			{
				oThis.Hide();
				break;
			}
        }
        return this;
    };
}
{ // CXSearch
    window.CXSearch = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oPage = oArgs.oPage;
        this.jBox = oArgs.jBox;
        this.oBtn = oArgs.oBtn;
        this.sValue = "";
        this.Constructor();
        return this;
    };
    CXSearch.prototype = Object.create(WTBaseObject.prototype);
    CXSearch.prototype.constructor = CXSearch;
    CXSearch.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jFld = this.jBox.find("[cx-role='search-fld']").on("focus blur keyup", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, oThis: oThis }); });
        this.jEmpty = this.jBox.find("[cx-role='search-empty']");
        return this;
    };
    CXSearch.prototype.Disable = function(oArgs)
	{
        this.jFld.prop("disabled", true);
        this.jEmpty.hide();
        return this;
    };
    CXSearch.prototype.Enable = function(oArgs)
	{
        this.jFld.prop("disabled", false);
        if(this.jFld.val() == "")
		{
            this.jEmpty.show();
        }
        return this;
    };
    CXSearch.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXSearch))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXSearch))
			{
                oThis = oArgs.oArgs.oThis;
            }
            if(!(oThis instanceof CXSearch))
			{
                return null;
            }
        }
        oThis.sValue = oThis.jFld.val();
        switch(oArgs.oEvt.type)
		{
            case "focus":
			{
				oThis.jEmpty.hide();
				break;
			}
            case "blur":
			{
				if(oThis.sValue == "")
				{
					oThis.jEmpty.show();
					oThis.oBtn.Disable();
				}
				break;
			}
            case "keyup":
			{
				if(oThis.sValue != "")
				{
					oThis.jEmpty.hide();
					oThis.oBtn.Enable();
				}
				else
				{
					oThis.oBtn.Disable();
				}
				oThis.oPage.oList.Filter({ sType: "search" });
				break;
			}
        }
        return oThis;
    };
}
{ // CXWebMode
    window.CXWebMode = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.Constructor();
        return this;
    };
    CXWebMode.prototype = Object.create(WTBaseObject.prototype);
    CXWebMode.prototype.constructor = CXWebMode;
    CXWebMode.prototype.Constructor = function()
	{
        var oThis = this;
        return this;
    };
}
{ // CXMenu
    window.CXMenu = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.sType = oArgs.sType;
        this.aSourceGroups = oArgs.aGroups;
        this.oGroups = {};
        this.oItems = {};
        this.bVisible = false;
        this.sSelectedGroupId = "";
        this.aSelected = [];
        this.Constructor();
        return this;
    };
    CXMenu.prototype = Object.create(WTBaseObject.prototype);
    CXMenu.prototype.constructor = CXMenu;
    CXMenu.prototype.Constructor = function()
	{
        var oThis = this;
        this.jMenuGroupTemplate = this.oPlayer.jStorage.find("[cx-template='" + this.sType + "-menu-group-template']");
        this.jMenuItemTemplate = this.oPlayer.jStorage.find("[cx-template='" + this.sType + "-menu-item-template']");
        this.jList = this.jContainer.find("[cx-role='" + this.sType + "-menu-list']");
        var sGroupId;
        var sItemId;
        for(var i = 0; i<this.aSourceGroups.length; i++)
		{
            sGroupId = this.aSourceGroups[i].sId;
            this.oGroups[sGroupId] = { sId: sGroupId, jItem: this.jMenuGroupTemplate.clone(true).attr({ "cx-id": sGroupId }).appendTo(this.jList), oItems: {} };
            this.oGroups[sGroupId].jList = this.oGroups[sGroupId].jItem.find("[cx-role='" + this.sType + "-menu-group-list']");
            for(var j = 0; j<this.aSourceGroups[i].aItems.length; j++)
			{
                sItemId = this.aSourceGroups[i].aItems[j].sId;
                this.oGroups[sGroupId].oItems[sItemId] = this.oItems[sItemId] = { sId: sItemId, sType: this.aSourceGroups[i].aItems[j].sType, oGroup: this.oGroups[sGroupId], jItem: this.jMenuItemTemplate.clone(true).attr({ "cx-group-id": sGroupId, "cx-id": sItemId }).appendTo(this.oGroups[sGroupId].jList) };
                this.oItems[sItemId].jBtn = this.oItems[sItemId].jItem.find("[cx-btn]").attr({ "cx-group-id": sGroupId, "cx-id": sItemId });
                this.oItems[sItemId].jBtn.find("[cx-role='btn-text']").html(this.aSourceGroups[i].aItems[j].sName);
				if(sItemId!="resources")
				{
					this.oItems[sItemId].jBtn.find("[cx-role='wait-throbber']").remove();
				}
				this.oItems[sItemId].oBtn = new CXBtn({ oPlayer: this.oPlayer, sId: sItemId, jContainer: this.oItems[sItemId].jItem, jBtn: this.oItems[sItemId].jBtn, fn: oThis.UIEvent, oArgs: { oContext: oThis } });
                if(this.oItems[sItemId].sType == "editor")
				{
                    this.oItems[sItemId].jItem.hide();
                    this.oItems[sItemId].bVisible = false;
                }
				else
				{
                    this.oItems[sItemId].bVisible = true;
                }
            }

            this.oGroups[sGroupId].bVisible = true;
        }
        return this;
    };
    CXMenu.prototype.Hide = function(oArgs)
	{
        if(oArgs == null)
		{
            if(this.bVisible)
			{
                this.jList.hide();
                this.bVisible = false;
            }
        }
		else
		{
            if(oArgs.sGroupId != null)
			{
                if(this.oGroups[oArgs.sGroupId] != null)
				{
                    this.oGroups[oArgs.sGroupId].jItem.hide();
                    this.oGroups[oArgs.sGroupId].bVisible = false;
                }
            }
			else if(oArgs.sItemId != null)
			{
                if(this.oItems[oArgs.sItemId] != null)
				{
                    this.oItems[oArgs.sItemId].jItem.hide();
                    this.oItems[oArgs.sItemId].bVisible = false;
                }
            }
        }
        return this;
    };
    CXMenu.prototype.Select = function(oArgs)
	{
        if(oArgs != null)
		{
            var sKey;
            if(oArgs.sGroupId != null)
			{
                if(this.oGroups[oArgs.sGroupId] != null)
				{
                    for(sKey in this.oGroups)
					{
                        if(sKey == oArgs.sGroupId)
						{
                            this.Show({ sGroupId: oArgs.sItemId });
                            this.sSelectedGroupId = oArgs.sGroupId;
                        }
						else if(this.oGroups[sKey].bVisible)
						{
                            this.Hide({ sGroupId: sKey });
                        }
                    }
                }
            }
			else if(oArgs.sItemId != null)
			{
                if(this.oItems[oArgs.sItemId] != null)
				{
                    this.oItems[oArgs.sItemId].jItem.show();
                    this.oItems[oArgs.sItemId].bVisible = true;
                    var iIdx;
                    for(sKey in this.oItems[oArgs.sItemId].oGroup.oItems)
					{
                        if(sKey != oArgs.sItemId)
						{
                            iIdx = $.inArray(sKey, this.aSelected);
                            if(iIdx != -1)
							{
                                this.oItems[sKey].oGroup.oItems[sKey].oBtn.Unselect();
                                this.aSelected.splice(iIdx, 1);
                            }
                        }
                    }
                    if($.inArray(oArgs.sItemId, this.aSelected) == -1)
					{
                        this.aSelected.push(oArgs.sItemId);
                        this.oItems[oArgs.sItemId].oBtn.Select();
                    }
                    if(oArgs.bJustSelect != true && this.oItems[oArgs.sItemId].oGroup.sId != this.sSelectedGroupId)
					{
                        this.Select({ sGroupId: this.oItems[oArgs.sItemId].oGroup.sId });
                    }
                    this.FireEvent({ sEvent: "change" });
                }
            }
        }
        return this;
    };
    CXMenu.prototype.Show = function(oArgs)
	{
        if(oArgs == null)
		{
            if(!this.bVisible)
			{
                this.jList.show();
                this.bVisible = true;
            }
        }
		else
		{
            if(oArgs.sGroupId != null)
			{
                if(this.oGroups[oArgs.sGroupId] != null)
				{
                    this.oGroups[oArgs.sGroupId].jItem.show();
                    this.oGroups[oArgs.sGroupId].bVisible = true;
                }
            }
			else if(oArgs.sItemId != null)
			{
                if(this.oItems[oArgs.sItemId] != null)
				{
                    this.oItems[oArgs.sItemId].jItem.show();
                    this.oItems[oArgs.sItemId].bVisible = true;
                }
            }
        }
        return this;
    };
    CXMenu.prototype.UIEvent = function(oArgs)
	{
        if(oArgs != null)
		{
            if(oArgs.oElem != null)
			{
                var sGroupId = oArgs.oElem.getAttribute("cx-group-id");
                var sItemId = oArgs.oElem.getAttribute("cx-id");
                this.Select({ sItemId: sItemId });
            }
        }
        return this;
    };
    CXMenu.prototype.Unselect = function(oArgs)
	{
        if(oArgs != null)
		{
            var sKey;
            if(oArgs.sGroupId != null)
			{
                if(this.oGroups[oArgs.sGroupId] != null)
				{
                    for(sKey in this.oGroups)
					{
                        if(sKey == oArgs.sItemId)
						{
                            this.Show({ sGroupId: oArgs.sItemId });
                            this.sSelectedGroupId = oArgs.sGroupId;
                        }
						else if(this.oGroups[sKey].bVisible)
						{
                            this.Hide({ sGroupId: sKey });
                        }
                    }
                }
            }
			else if(oArgs.sItemId != null)
			{
                if(this.oItems[oArgs.sItemId] != null)
				{
                    this.oItems[oArgs.sItemId].jItem.show();
                    this.oItems[oArgs.sItemId].bVisible = true;
                }
            }
        }
        return this;
    };
}
{ // CXDataStore
    window.CXDataStore = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);

        this.oInitialData = oArgs.oData;
        this.oData = {};
        this.aData = [];
        this.sLastAppendedItemId = "";
        this.sLastDeletedItemId = "";
        this.sLastUpdatedItemId = "";
        this.Constructor();
        return this;
    };
    CXDataStore.prototype = Object.create(WTBaseObject.prototype);
    CXDataStore.prototype.constructor = CXDataStore;
    CXDataStore.prototype._Contains = function(oArgs)
	{
        return (this.oData[oArgs.sId] != null);
    };
    CXDataStore.prototype.Append = function(oArgs)
	{
        if(this.oData[oArgs.sId] == null)
		{
            this.oData[oArgs.sId] = JSON.parse(JSON.stringify(oArgs.oItem));
            if(this.oData[oArgs.sId].id == null)
			{
                this.oData[oArgs.sId].id = oArgs.sId;
            }
            if(this.oData[oArgs.sId].name == null && this.oData[oArgs.sId].fullname != null)
			{
                this.oData[oArgs.sId].name = this.oData[oArgs.sId].fullname;
            }
            this.oData[oArgs.sId]._sortname = this.oData[oArgs.sId].name.toLowerCase();
            if(this.oData[oArgs.sId].icon_url != null)
			{
                if(this.oData[oArgs.sId].icon_url.indexOf("download_file.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("_=") == -1)
				{
                    this.oData[oArgs.sId].icon_url += "&_=" + Math.random();
                }
                if(this.oData[oArgs.sId].icon_url.indexOf("person_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
				{
                    this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                }
                if(this.oData[oArgs.sId].icon_url.indexOf("resource_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
				{
                    this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                }
            }
            if(oArgs.bSuppressEvent != true) {
                this.Sort().FireEvent({ sEvent: "item_appended" });
            }
        }
        return this;
    };
    CXDataStore.prototype.Constructor = function(oArgs)
	{
        if(this.oInitialData.constructor === Array)
		{
            for(var i = 0; i<this.oInitialData.length; i++)
			{
                this.oData[this.oInitialData[i].id] = JSON.parse(JSON.stringify(this.oInitialData[i]));
            }
        }
		else
		{
            this.oData = JSON.parse(JSON.stringify(this.oInitialData));
        }
        for(var sKey in this.oData)
		{
            if(this.oData.hasOwnProperty(sKey))
			{
                if(this.oData[sKey].id == null)
				{
                    this.oData[sKey].id = sKey;
                }
                if(this.oData[sKey].name == null && this.oData[sKey].fullname != null)
				{
                    this.oData[sKey].name = this.oData[sKey].fullname;
                }
                if(this.oData[sKey].icon_url != null)
				{
                    if(this.oData[sKey].icon_url.indexOf("download_file.html?") != -1 && this.oData[sKey].icon_url.indexOf("_=") == -1)
					{
                        this.oData[sKey].icon_url += "&_=" + Math.random();
                    }
                    if(this.oData[sKey].icon_url.indexOf("person_icon.html?") != -1 && this.oData[sKey].icon_url.indexOf("type=") == -1)
					{
                        this.oData[sKey].icon_url += "&type=200x200&_=" + Math.random();
                    }
                    if(this.oData[sKey].icon_url.indexOf("resource_icon.html?") != -1 && this.oData[sKey].icon_url.indexOf("type=") == -1)
					{
                        this.oData[sKey].icon_url += "&type=200x200&_=" + Math.random();
                    }
                }
                this.oData[sKey]._sortname = this.oData[sKey].name.toLowerCase();
                this.aData.push(this.oData[sKey]);
            }
        }
        this.Sort().FireEvent({ sEvent: "store_created" });
        return this;
    };
    CXDataStore.prototype.Delete = function(oArgs)
	{
        if(this.oData[oArgs.sId] != null)
		{
            var iIdx = -1;
            for(var i = 0; i<this.aData.length; i++)
			{
                if(this.aData[i].id == oArgs.sId)
				{
                    iIdx = i;
                    break;
                }
            }
            if(iIdx != -1)
			{
                this.aData.splice(iIdx, 1);
            }
            delete this.oData[oArgs.sId];
            if(oArgs.bSuppressEvent != true)
			{
                this.FireEvent({ sEvent: "item_deleted" });
            }
        }
        return this;
    };
    CXDataStore.prototype.Sort = function(oArgs)
	{
        this.aData.sort(function(elem1, elem2)
		{
			if(elem1._sortname > elem2._sortname)
			{
				return 1;
			}
			if(elem1._sortname < elem2._sortname)
			{
				return -1;
			}
			return 0;
		});
        return this;
    };
    CXDataStore.prototype.Update = function(oArgs)
	{
        var bAdded = false;
        var sKey;
        for(sKey in oArgs.oData)
		{
            if(oArgs.oData.hasOwnProperty(sKey))
			{
                this.UpdateSingleItem({ sId: sKey, bSuppressEvent: true });
            }
        }
        var aToDelete = [];
        for(sKey in this.oData)
		{
            if(this.oData.hasOwnProperty(sKey))
			{
                if(oArgs.oData[sKey] == null)
				{
                    aToDelete.push(sKey);
                }
            }
        }
        for(var i = 0; i<aToDelete.length; i++)
		{
            this.Delete({ sId: aToDelete[i], bSuppressEvent: true });
        }
        if(oArgs.bSuppressEvent != true)
		{
            this.Sort().FireEvent({ sEvent: "store_updated" });
        }
        return this;
    };
    CXDataStore.prototype.UpdateSingleItem = function(oArgs)
	{
        if(this.oData[oArgs.sId] == null)
		{
            this.Append(oArgs);
        }
		else
		{
            if(oArgs.bByFld == true)
			{
                var oTmp = JSON.parse(JSON.stringify(oArgs.oItem));
                for(var sKey in oTmp)
				{
                    if(oTmp.hasOwnProperty(sKey))
					{
                        this.oData[oArgs.sId][sKey] = oTmp[sKey];
                    }
                }
                if(oTmp.name == null && oTmp.fullname != null)
				{
                    this.oData[oArgs.sId].name = this.oData[oArgs.sId].fullname;
                }
                if(oTmp.icon_url != null)
				{
                    if(this.oData[oArgs.sId].icon_url.indexOf("download_file.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("_=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&_=" + Math.random();
                    }
                    if(this.oData[oArgs.sId].icon_url.indexOf("person_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                    }
                    if(this.oData[oArgs.sId].icon_url.indexOf("resource_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                    }
                }
            }
			else
			{
                this.oData[oArgs.sId] = JSON.parse(JSON.stringify(oArgs.oItem));
                if(this.oData[oArgs.sId].id == null)
				{
                    this.oData[oArgs.sId].id = oArgs.sId;
                }
                if(this.oData[oArgs.sId].name == null && this.oData[oArgs.sId].fullname != null)
				{
                    this.oData[oArgs.sId].name = this.oData[oArgs.sId].fullname;
                }
                if(this.oData[oArgs.sId].icon_url != null)
				{
                    if(this.oData[oArgs.sId].icon_url.indexOf("download_file.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("_=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&_=" + Math.random();
                    }
                    if(this.oData[oArgs.sId].icon_url.indexOf("person_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                    }
                    if(this.oData[oArgs.sId].icon_url.indexOf("resource_icon.html?") != -1 && this.oData[oArgs.sId].icon_url.indexOf("type=") == -1)
					{
                        this.oData[oArgs.sId].icon_url += "&type=200x200&_=" + Math.random();
                    }
                }
            }
            this.oData[oArgs.sId]._sortname = this.oData[oArgs.sId].name.toLowerCase();
            this.sLastUpdatedItemId = oArgs.sId;
            if(oArgs.bSuppressEvent != true)
			{
                this.Sort().FireEvent({ sEvent: "item_updated" });
            }
        }
        return this;
    };
}
{ // CXList
    window.CXList = function(oArgs)
	{
        WTBaseObject.call(this, { oPlayer: oArgs.oPlayer, jContainer: oArgs.jContainer, sId: oArgs.sId });
        this.oPage = oArgs.oPage;
        this.sType = oArgs.sType;
        this.bSingle = (oArgs.bSingle == true);
        this.oItems = {};
        this.oBtns = {};
        this.aItemOrder = [];
        this.aSelectedItems = [];
        this.oCurrentSorting = {};
        this.oDataSrc = null;
        this.Constructor();
        return this;
    };
    CXList.prototype = Object.create(WTBaseObject.prototype);
    CXList.prototype.constructor = CXList;
    CXList.prototype.Append = function(oArgs)
	{
        if(oArgs.sId != null && oArgs.oItem != null)
		{
            if(this.sType == "resource")
			{
                if(oArgs.sRepoId != null)
				{
                    if(oArgs.oItem.type == "img")
					{
                        oArgs.oItem.icon_url = oArgs.oItem.url;
                    }
					else
					{
                        oArgs.oItem.icon_url = this.oPlayer.oConfig.sImgURL + "ico-file-" + oArgs.oItem.type + ".svg";
                    }
                    this.oItems[oArgs.sId] = new CXListItem({ oPlayer: this.oPlayer, oPage: this.oPage, oList: this, sId: oArgs.sId, sRepoId: oArgs.sRepoId, oItem: oArgs.oItem, bPrepend: (oArgs.bPrepend == true) });
                    this.aItemOrder.push(oArgs.sId);
                }
            }
			else
			{
                this.oItems[oArgs.sId] = new CXListItem({ oPlayer: this.oPlayer, oPage: this.oPage, oList: this, sId: oArgs.sId, oItem: oArgs.oItem, bPrepend: (oArgs.bPrepend == true) });
            }
        }
        return this;
    };
    CXList.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jItemTemplate = this.oPlayer.jStorage.find("[cx-template='item-" + this.sType + "']");
        this.jHeader = this.jContainer.find("[cx-role='list-header']");
        this.jList = this.jContainer.find("[cx-role='list-body']").attr({ "cx-type": this.oPage.sId });
		this.jListTotalValue = this.oPage.jContainer.find("[cx-role='total-value']");
		this.jListFilteredValue = this.oPage.jContainer.find("[cx-role='filtered-value']");
        if(this.oPage.sId=="pages")
		{
			this.oFilter = { bIsStd: false, sDesignId: "ALL" };
		}
		this.jHeader.find("[cx-btn]").each(function()
		{
            var sId = this.getAttribute("cx-btn");
            oThis.oBtns[sId] = new CXBtn({ oPlayer: oThis.oPlayer, jContainer: oThis.jContainer, jBtn: $(this), fn: oThis.UIEvent, oArgs: { oThis: oThis } });
        });
        return this;
    };
    CXList.prototype.Fill = function(oArgs)
	{
        var sKey;
        this.oDataSrc = oArgs.oItems;
        if(this.sType == "resource")
		{
            for(sKey in oArgs.oItems)
			{
                if(oArgs.oItems.hasOwnProperty(sKey))
				{
                    for(var i = 0; i<oArgs.oItems[sKey].files.length; i++)
					{
                        oArgs.oItems[sKey].files[i].repo_id = sKey;
                        if(oArgs.oItems[sKey].files[i].type == "img")
						{
                            oArgs.oItems[sKey].files[i].icon_url = oArgs.oItems[sKey].files[i].url;
                        }
						else
						{
                            oArgs.oItems[sKey].files[i].icon_url = this.oPlayer.oConfig.sImgURL + "ico-file-" + oArgs.oItems[sKey].files[i].type + ".svg";
                        }
                        this.oItems[oArgs.oItems[sKey].files[i].id] = new CXListItem({ oPlayer: this.oPlayer, oPage: this.oPage, oList: this, sId: oArgs.oItems[sKey].files[i].id, sRepoId: sKey, oItem: oArgs.oItems[sKey].files[i] });
                        this.aItemOrder.push(oArgs.oItems[sKey].files[i].id);
                    }
                }
            }
			this.Filter({ sType: "filter", sValue: "ALL" });
        }
		else
		{
            for(sKey in this.oDataSrc)
			{
                if(this.oDataSrc.hasOwnProperty(sKey))
				{
                    this.oItems[sKey] = new CXListItem({ oPlayer: this.oPlayer, oPage: this.oPage, oList: this, sId: sKey, oItem: this.oDataSrc[sKey] });
                    this.aItemOrder.push(sKey);
                }
            }
			this.Filter({ sType: "filter" });
        }
        return this;
    };
    CXList.prototype.Filter = function(oArgs)
	{
        var sKey;
		var i;
        switch(oArgs.sType)
		{
            case "search":
			{
				var sValue = this.oPage.oSearch.sValue.toLowerCase();
				if(sValue == "")
				{
					for(sKey in this.oItems)
					{
						if(this.oItems.hasOwnProperty(sKey))
						{
							this.oItems[sKey].jElem.removeAttr("cx-search-met").removeAttr("cx-search-not-met");
						}
					}
				}
				else
				{
					for(sKey in this.oItems)
					{
						if(this.oItems.hasOwnProperty(sKey))
						{
							if(this.oItems[sKey].jElem[0].hasAttribute("cx-search-met"))
							{
								this.oItems[sKey].jElem.removeAttr("cx-search-met");
							}
							if(this.oItems[sKey].jElem[0].hasAttribute("cx-search-not-met"))
							{
								this.oItems[sKey].jElem.removeAttr("cx-search-not-met");
							}
							for(var i = 0; i<this.oPage.aSearchTargets.length; i++)
							{
								if(!this.oItems[sKey].jElem[0].hasAttribute("cx-search-met"))
								{
									if(this.oItems[sKey].oColumns[this.oPage.aSearchTargets[i]].sText.indexOf(sValue) == -1)
									{
										this.oItems[sKey].jElem.attr({ "cx-search-not-met": "1" });
									}
									else
									{
										this.oItems[sKey].jElem.attr({ "cx-search-met": "1" });
										if(this.oItems[sKey].jElem[0].hasAttribute("cx-search-not-met"))
										{
											this.oItems[sKey].jElem.removeAttr("cx-search-not-met");
										}
									}
								}
							}
						}
					}
				}
				break;
			}
            case "filter":
			{
				switch(this.oPage.sId)
				{
					case "pages":
					{
						if(oArgs.bIsStd)
						{
							this.oFilter.bIsStd = (oArgs.oThis!=null) ? oArgs.oThis.bChecked==true : false;
						}
						if(oArgs.bDesign)
						{
							this.oFilter.sDesignId = (oArgs.sValue!=null) ? oArgs.sValue : "ALL";
						}
						var aMet = [];
						var aNotMet = [];
						for(sKey in this.oItems)
						{
							if(this.oItems.hasOwnProperty(sKey))
							{
								this.oItems[sKey].jElem.removeAttr("cx-filter-met");
								this.oItems[sKey].jElem.removeAttr("cx-filter-not-met");
								if(this.oItems[sKey].oItem.is_std==false || this.oItems[sKey].oItem.is_std==this.oFilter.bIsStd)
								{
									if(this.oFilter.sDesignId=="ALL" || this.oItems[sKey].oItem.web_design_id==this.oFilter.sDesignId)
									{
										aMet.push(sKey);
									}
									else
									{
										aNotMet.push(sKey);
									}
								}
								else
								{
									aNotMet.push(sKey);
								}
							}
						}
						for(i=0; i<aMet.length; i++)
						{
							this.oItems[aMet[i]].jElem.attr({ "cx-filter-met": "1" });
						}
						for(i=0; i<aNotMet.length; i++)
						{
							this.oItems[aNotMet[i]].jElem.attr({ "cx-filter-not-met": "1" });
						}
						break;
					}
					case "resources":
					{
						for(sKey in this.oItems)
						{
							if(this.oItems.hasOwnProperty(sKey))
							{
								this.oItems[sKey].jElem.removeAttr("cx-filter-met");
								this.oItems[sKey].jElem.removeAttr("cx-filter-not-met");
								if(oArgs.sValue == "ALL" || this.oItems[sKey].oItem.repo_id == oArgs.sValue)
								{
									this.oItems[sKey].jElem.attr({ "cx-filter-met": "1" });
								}
								else
								{
									this.oItems[sKey].jElem.attr({ "cx-filter-not-met": "1" });
								}
							}
						}
						if(this.aSelectedItems.length != 0)
						{
							if(this.oItems[this.aSelectedItems[0]].jElem.attr("cx-filter-not-met") == "1")
							{
								this.oItems[this.aSelectedItems[0]].Unselect();
								this.oPage.Display({ bEmpty: true });
							}
						}
						break;
					}
				}
				break;
			}
        }
		this.jListTotalValue.html(this.jList.children().length);
		var iFilterMet = this.jList.children("[cx-filter-met]").length;
		var iFilterNotMet = this.jList.children("[cx-filter-not-met]").length;
		var iSearchMet = this.jList.children("[cx-search-met]").length;
		var iSearchNotMet = this.jList.children("[cx-search-not-met]").length;
		if(iFilterMet==0 && iFilterNotMet==0 && iSearchMet==0 && iSearchNotMet==0)
		{
			this.jListFilteredValue.html(this.jList.children().length);
		}
		else if(iSearchMet==0 && iSearchNotMet==0)
		{
			this.jListFilteredValue.html(iFilterMet);
		}
 		else
		{
			this.jListFilteredValue.html(iSearchMet);
		}
       return this;
    };
    CXList.prototype.Remove = function(oArgs)
	{
        if(oArgs.sId != null && this.oItems[oArgs.sId] != null)
		{
            this.aItemOrder.splice($.inArray(oArgs.sId, this.aItemOrder), 1);
            this.oItems[oArgs.sId].Remove();
            delete this.oItems[oArgs.sId];
        }
        return this;
    };
    CXList.prototype.Scroll = function(oArgs)
	{
        if(typeof this.oItems[oArgs.sId].jElem[0].scrollIntoViewIfNeeded == "function")
		{
            this.oItems[oArgs.sId].jElem[0].scrollIntoViewIfNeeded();
        }
		else
		{
            this.oItems[oArgs.sId].jElem[0].scrollIntoView(true);
        }
        return this;
    };
    CXList.prototype.Select = function(oArgs)
	{
        if(oArgs != null && oArgs.sId != null)
		{
            if(this.oItems[oArgs.sId] != null)
			{
                if(!this.oItems[oArgs.sId].bSelected)
				{
                    this.oItems[oArgs.sId].Select();
                }
            }
        }
        return this;
    };
    CXList.prototype.Sort = function(oArgs)
	{
        var oThis = this;
        var i;
        var sKey;
        var aToSort;
        if(oArgs.bCurrentState == true)
		{
            aToSort = [];
            for(sKey in this.oItems)
			{
                if(this.oItems.hasOwnProperty(sKey))
				{
                    aToSort.push(this.oItems[sKey]);
                }
            }
            aToSort.sort(function(oItem1, oItem2)
			{
				if(oItem1.oColumns[oThis.oCurrentSorting.sTarget].sText > oItem2.oColumns[oThis.oCurrentSorting.sTarget].sText)
				{
					return 1;
				}
				if(oItem1.oColumns[oThis.oCurrentSorting.sTarget].sText < oItem2.oColumns[oThis.oCurrentSorting.sTarget].sText)
				{
					return -1;
				}
				return 0;
			});
            if(this.oCurrentSorting.sNextState == "descending")
			{
                aToSort.reverse();
            }
            for(i=0; i<aToSort.length; i++)
			{
                aToSort[i].jElem.appendTo(this.jList);
            }
        }
		else
		{
            var sTarget = oArgs.oElem.getAttribute("cx-target");
            var sCurrentState = oArgs.oElem.getAttribute("cx-state");
            var sNextState = ((sCurrentState == "none") ? "ascending" : ((sCurrentState == "ascending") ? "descending" : "none"));
            if(sCurrentState == "descending")
			{
                for(i=0; i<this.aItemOrder.length; i++)
				{
                    this.oItems[this.aItemOrder[i]].jElem.appendTo(this.jList);
                }
            }
			else
			{
                for(sKey in this.oBtns)
				{
                    if(this.oBtns[sKey].jBtn[0] != oArgs.oElem)
					{
                        if(this.oBtns[sKey].jBtn.attr("cx-action") == "sort")
						{
                            this.oBtns[sKey].jBtn.attr({ "cx-state": "none" });
                        }
                    }
                }
                aToSort = [];
                for(sKey in this.oItems)
				{
                    if(this.oItems.hasOwnProperty(sKey))
					{
                        aToSort.push(this.oItems[sKey]);
                    }
                }
                aToSort.sort(function(oItem1, oItem2)
				{
					if(oItem1.oColumns[sTarget].sText > oItem2.oColumns[sTarget].sText)
					{
						return 1;
					}
					if(oItem1.oColumns[sTarget].sText < oItem2.oColumns[sTarget].sText)
					{
						return -1;
					}
					return 0;
				});
                if(sNextState == "descending")
				{
                    aToSort.reverse();
                }
                for(i=0; i<aToSort.length; i++)
				{
                    aToSort[i].jElem.appendTo(this.jList);
                }
            }
            oArgs.oElem.setAttribute("cx-state", sNextState);
            this.oCurrentSorting = { sTarget: sTarget, sState: sNextState };
        }
        return this;
    };
    CXList.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXList))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXList))
			{
                oThis = oArgs.oArgs.oThis;
            }
            if(!(oThis instanceof CXList))
			{
                return null;
            }
        }
        switch(oArgs.oElem.getAttribute("cx-action"))
		{
            case "sort":
			{
				oThis.Sort(oArgs);
				break;
			}
        }
        return oThis;
    };
    CXList.prototype.Update = function(oArgs)
	{
        var sKey;
        if(Object.keys(this.oDataSrc).length != Object.keys(this.oItems).length)
		{
            if(Object.keys(this.oDataSrc).length > Object.keys(this.oItems).length)
			{ // append
                for(sKey in this.oDataSrc)
				{
                    if(this.oItems[sKey] == null)
					{
                        this.oItems[sKey] = new CXListItem({ oPlayer: this.oPlayer, oPage: this.oPage, oList: this, sId: sKey, oItem: this.oDataSrc[sKey] });
                        this.aItemOrder.push(sKey);
                    }
                }
            }
			else
			{ // delete
                for(sKey in this.oItems)
				{
                    if(this.oDataSrc[sKey] == null)
					{
                        this.oItems[sKey].Remove();
                        delete this.oItems[sKey];
                    }
                }
            }
        }
		else
		{
            for(sKey in this.oDataSrc)
			{
                if(this.oDataSrc.hasOwnProperty(sKey))
				{
                    this.oItems[sKey].Update();
                }
            }
        }
		this.jListTotalValue.html(this.jList.children().length);
		var iFilterMet = this.jList.children("[cx-filter-met]").length;
		var iFilterNotMet = this.jList.children("[cx-filter-not-met]").length;
		var iSearchMet = this.jList.children("[cx-search-met]").length;
		var iSearchNotMet = this.jList.children("[cx-search-not-met]").length;
		if(iFilterMet==0 && iFilterNotMet==0 && iSearchMet==0 && iSearchNotMet==0)
		{
			this.jListFilteredValue.html(this.jList.children().length);
		}
		else if(iSearchMet==0 && iSearchNotMet==0)
		{
			this.jListFilteredValue.html(iFilterMet);
		}
 		else
		{
			this.jListFilteredValue.html(iSearchMet);
		}
        this.FireEvent({ sEvent: "list_updated" });
        return this;
    };
}
{ // CXListItem
    window.CXListItem = function(oArgs)
	{
        WTBaseObject.call(this, { oPlayer: oArgs.oPlayer, jContainer: oArgs.jContainer, sId: oArgs.sId });
        this.oPage = oArgs.oPage;
        this.oList = oArgs.oList;
        this.sId = oArgs.sId;
        this.sRepoId = oArgs.sRepoId;
        this.oItem = oArgs.oItem;
        this.jParent = this.oList.jList;
        this.bPrepend = (oArgs.bPrepend == true);
        this.jTemplate = this.oList.jItemTemplate;
        this.bVisible = false;
        this.bSelected = false;
        this.oColumns = {};
        this.Constructor();
        return this;
    };
    CXListItem.prototype = Object.create(WTBaseObject.prototype);
    CXListItem.prototype.constructor = CXListItem;
    CXListItem.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jElem = this.jTemplate.clone(true).removeAttr("cx-template").attr({ "cx-id": this.sId });
        if(this.bPrepend)
		{
            this.jElem.prependTo(this.jParent);
        }
		else
		{
            this.jElem.appendTo(this.jParent);
        }
        if(oThis.oItem.is_dismiss != null)
		{
            if(TOOLS.Refine({ sType: "bool", sValue: oThis.oItem.is_dismiss }))
			{
                this.jElem.attr({ "cx-limited": "1" });
            }
        }
        if(oThis.oItem.is_default != null)
		{
            if(TOOLS.Refine({ sType: "bool", sValue: oThis.oItem.is_default }))
			{
                this.jElem.attr({ "cx-limited": "1" });
            }
        }
        if(oThis.oItem.is_std != null)
		{
            if(TOOLS.Refine({ sType: "bool", sValue: oThis.oItem.is_std }))
			{
                this.jElem.attr({ "cx-std": "1" });
            }
        }
        this.jElem.find("[cx-col]").each(function()
		{
            var sId = this.getAttribute("cx-col");
            oThis.oColumns[sId] = { jElem: $(this) };
            switch(sId)
			{
                case "icon":
				{
					var sIconURL = oThis.oItem.icon_url;
					if(sIconURL == null)
					{
						if(oThis.oItem.resource_id != null)
						{
							sIconURL = "/download_file.html?file_id=" + oThis.oItem.resource_id;
						}
						else
						{
							sIconURL = "";
						}
					}
					if(sIconURL.charAt(0) != "/" && sIconURL.indexOf("img/") != 0)
					{
						sIconURL = "/" + sIconURL;
					}
					if(sIconURL == "/")
					{
						sIconURL = oThis.oPlayer.oConfig.sDefaultIconURL;
					}
					if(sIconURL != null && sIconURL != "")
					{
						oThis.oColumns[sId].jElem.css({ "background-image": "url(" + sIconURL + ")" });
					}
					break;
				}
                case "checkbox":
				{
					if(oThis.oList.bSingle)
					{
						oThis.oColumns[sId].jElem.hide();
					}
					oThis.oColumns[sId].jElem.val(oThis.sId);
					break;
				}
                case "courses":
				{
					oThis.oColumns[sId].jElem.html(oThis.oItem[sId].length);
					oThis.oColumns[sId].sText = oThis.oItem[sId].length;
					break;
				}
                case "type":
				{
					oThis.oColumns[sId].jElem.html(oThis.oPlayer.oStore["file_types"].oData[oThis.oItem[sId]].name);
					oThis.oColumns[sId].sText = oThis.oPlayer.oStore["file_types"].oData[oThis.oItem[sId]]._sortname;
					break;
				}
                default:
				{
					var sType = ((oThis.oItem[sId]!=null) ? (typeof oThis.oItem[sId]) : "undefined");
					if(sType != "undefined")
					{
						var sValue = (sType == "object") ? oThis.oItem[sId].date : oThis.oItem[sId];
						if(sType == "string")
						{
							if(sValue.indexOf("-") != -1 && sValue.indexOf("T") != -1 && sValue.indexOf(":") != -1)
							{
								sValue = TOOLS.DateStringFromISO8601({ sISODate: sValue, sFormat: "dd.mm.yy" });
								sType = "date";
							}
						}
						oThis.oColumns[sId].jElem.html(sValue);
						oThis.oColumns[sId].sText = (sType == "number") ? sValue : (sType == "date" ? oThis.oItem[sId] : sValue.toLowerCase());
					}
					break;
				}
            }
        });
        this.oCheckBox = new CXCheckBox({ oPlayer: this.oPlayer, sName: this.oList.sId, jBox: this.jElem.find("[cx-role='checkbox']"), sValueChecked: this.sId });
        this.bVisible = true;
        this.jElem.children("[cx-role!='item-select-block']").on("click", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
        this.jElem.children("[cx-role='item-select-block']").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
        return this;
    };
    CXListItem.prototype.Hide = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXListItem))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXListItem))
			{
                oThis = oArgs.oArgs.oThis;
            }
            if(!(oThis instanceof CXListItem))
			{
                return this;
            }
        }
        oThis.jElem.hide();
        oThis.bVisible = false;
        return oThis;
    };
    CXListItem.prototype.Remove = function(oArgs)
	{
        var oThis = this;
        oThis.jElem.remove();
        if($.inArray(oThis.sId, oThis.oList.aSelectedItems) != -1)
		{
            oThis.oList.aSelectedItems.splice($.inArray(oThis.sId, oThis.oList.aSelectedItems), 1);
        }
        return oThis;
    };
    CXListItem.prototype.Select = function(oArgs)
	{
        var oThis = this;
        this.jElem.attr({ "cx-state": "selected" });
        this.oCheckBox.SetValue({ bCheck: true });
        if($.inArray(this.sId, this.oList.aSelectedItems) == -1)
		{
            while(this.oList.aSelectedItems.length > 0)
			{
                this.oList.oItems[this.oList.aSelectedItems[0]].Unselect();
            }
            this.oList.aSelectedItems.push(this.sId);
            this.oList.FireEvent({ sEvent: "select" });
        }
        this.bSelected = true;
        this.oList.Scroll({ sId: this.sId });
        return oThis;
    };
    CXListItem.prototype.Show = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXListItem))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXListItem))
			{
                oThis = oArgs.oArgs.oThis;
            }
            if(!(oThis instanceof CXListItem))
			{
                return this;
            }
        }
        oThis.jElem.css({ "display": "flex" });
        oThis.bVisible = true;
        return oThis;
    };
    CXListItem.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        oArgs.oEvt.preventDefault();
        oArgs.oEvt.stopPropagation();
        oArgs.oEvt.stopImmediatePropagation();
        if(!oThis.oList.bSingle && (oArgs.oEvt.ctrlKey || oArgs.oEvt.shiftKey || oArgs.oElem.getAttribute("cx-role") == "item-select-block"))
		{
            if($.inArray(oThis.sId, oThis.oList.aSelectedItems) == -1)
			{
                oThis.Select();
            }
			else
			{
                oThis.Unselect();
            }
            if(oThis.oList.aSelectedItems.length > 1)
			{
                oThis.oPage.GroupOperations();
            }
			else if(oThis.oList.aSelectedItems.length == 1)
			{
                oThis.oPage.Display({ sId: oThis.oList.aSelectedItems[0] });
            }
			else
			{
                oThis.oPage.Display({ bEmpty: true });
            }
        }
		else
		{
            if($.inArray(oThis.sId, oThis.oList.aSelectedItems) == -1)
			{
                for(var i = 0; i<oThis.oList.aSelectedItems.length; i++)
				{
                    oThis.oList.oItems[oThis.oList.aSelectedItems[i]].Unselect();
                }
                oThis.Select();
                oThis.oPage.Display({ sId: oThis.sId });
            }
			else
			{
                oThis.Unselect();
                oThis.oPage.Display({ bEmpty: true });
            }
        }
        return oThis;
    };
    CXListItem.prototype.Unselect = function(oArgs)
	{
        var oThis = this;
        oThis.jElem.attr({ "cx-state": "idle" });
        oThis.oCheckBox.SetValue({ bCheck: false });
        if($.inArray(oThis.sId, oThis.oList.aSelectedItems) != -1)
		{
            oThis.oList.aSelectedItems.splice($.inArray(oThis.sId, oThis.oList.aSelectedItems), 1);
            oThis.oList.FireEvent({ sEvent: "unselect" });
        }
        oThis.bSelected = false;
        return oThis;
    };
    CXListItem.prototype.Update = function(oArgs)
	{
        var oThis = this;
        if(oThis.oItem.is_dismiss != null)
		{
            if(TOOLS.Refine({ sType: "bool", sValue: oThis.oItem.is_dismiss }))
			{
                this.jElem.attr({ "cx-limited": "1" });
            }
			else
			{
                this.jElem.removeAttr("cx-limited");
            }
        }
		else
		{
            this.jElem.removeAttr("cx-limited");
        }
        if(oThis.oItem.is_default != null)
		{
            if(TOOLS.Refine({ sType: "bool", sValue: oThis.oItem.is_default }))
			{
                this.jElem.attr({ "cx-limited": "1" });
            }
        }
        for(var sKey in this.oColumns)
		{
            if(this.oColumns.hasOwnProperty(sKey))
			{
                switch(sKey)
				{
                    case "icon":
					{
						var sIconURL = oThis.oItem.icon_url;
						if(sIconURL == null)
						{
							if(oThis.oItem.resource_id != null) {
								sIconURL = "/download_file.html?file_id=" + oThis.oItem.resource_id;
							} else {
								sIconURL = "";
							}
						}
						if(sIconURL.charAt(0) != "/" && sIconURL.indexOf("img/") != 0)
						{
							sIconURL = "/" + sIconURL;
						}
						if(sIconURL == "/")
						{
							sIconURL = oThis.oPlayer.oConfig.sDefaultIconURL;
						}
						if(sIconURL != null && sIconURL != "")
						{
							if((sIconURL.indexOf("person_icon.html?") != -1 || sIconURL.indexOf("resource_icon.html?") != -1 || sIconURL.indexOf("download_file.html?") != -1) && sIconURL.indexOf("&type=") == -1)
							{
								sIconURL += "&type=200x200&_=" + Math.random();
							}
							oThis.oColumns[sKey].jElem.css({ "background-image": "url(" + sIconURL + ")" });
						}
						break;
					}
                    case "checkbox":
					{
						oThis.oColumns[sKey].jElem.val(oThis.sKey);
						break;
					}
                    case "courses":
					{
						oThis.oColumns[sKey].jElem.html(oThis.oItem[sKey].length);
						oThis.oColumns[sKey].sText = oThis.oItem[sKey].length;
						break;
					}
                    case "type":
					{
						oThis.oColumns[sKey].jElem.html(oThis.oPlayer._GetString({ sKey: "file-type-" + oThis.oItem[sKey] }));
						oThis.oColumns[sKey].sText = oThis.oItem[sKey];
						break;
					}
                    default:
					{
						var sType = typeof oThis.oItem[sKey];
						var sValue = (sType == "object") ? oThis.oItem[sKey].date : oThis.oItem[sKey];
						if(sType == "string")
						{
							if(sValue.indexOf("-") != -1 && sValue.indexOf("T") != -1 && sValue.indexOf(":") != -1)
							{
								sValue = TOOLS.DateStringFromISO8601({ sISODate: sValue, sFormat: "dd.mm.yy" });
								sType = "date";
							}
						}
						oThis.oColumns[sKey].jElem.html(sValue);
						oThis.oColumns[sKey].sText = (sType == "number") ? sValue : (sType == "date" ? oThis.oItem[sKey] : sValue.toLowerCase());
						break;
					}
                }
            }
        }
        return this;
    };
}
{ // CXObjectDialog
    window.CXObjectDialog = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oObject = oArgs.oObject;
        this.oPage = oArgs.oPage;
        this.aDialogPages = [];
        this.oBtns = {};
		this.oServiceFlds = {};
        this.Constructor();
        return this;
    };
    CXObjectDialog.prototype = Object.create(WTBaseObject.prototype);
    CXObjectDialog.prototype.constructor = CXObjectDialog;
    CXObjectDialog.prototype._GetParamByName = function(oArgs)
	{
		var i;
		var sKey;
        var oParam = null;
		for(i=0; i<oArgs.oOWT.params.length; i++)
		{
			if(oArgs.oOWT.params[i].name == oArgs.sFldName)
			{
				oParam = oArgs.oOWT.params[i];
				break;
			}
		}
        return oParam;
    };
    CXObjectDialog.prototype.AppendParams = function(oArgs)
	{
        var oThis = this;
        return this;
    };
    CXObjectDialog.prototype.ApplyNewValue = function(oArgs)
	{
        var oThis = this;
        var oParam = this._GetParamByName(oArgs);
        if(oParam != null)
		{
            if(oParam.type == "object" && oArgs.sValue != null)
			{
                oParam.value = oArgs.sValue;
            }
			else
			{
                var oFld = oArgs.oFld;
                var aUsedParamNames = [];
                var aNewParams = [];
                var oChildParams;
                var sParentWVarName;
                var sKey;
                var i, j;
                if(oFld != null)
				{
                    switch(oFld.sType)
					{
                        case "foreign_elem":
						{
							oParam.value = oFld._GetValue();
							if(oFld.bCommonCollectionFld && oFld.oChildParamFlds != null)
							{
								sParentWVarName = oParam.name;
								oChildParams = oFld.oChildParamFlds;
								if(oChildParams != null)
								{
									j = 0;
									for(i=0; i<oArgs.oOWT.params.length; i++)
									{
										aUsedParamNames.push(oArgs.oOWT.params[i].name);
									}
									for(sKey in oChildParams)
									{
										if(oChildParams.hasOwnProperty(sKey))
										{
											iIdx = $.inArray(TOOLS.DecodeVarName({ sText: sKey }), aUsedParamNames);
											if(iIdx==-1)
											{
												j++;
												aNewParams.push(
												{
													name: oChildParams[sKey].oFld.name,
													value: oChildParams[sKey]._GetValue({ bString: true }),
													type: oChildParams[sKey].oFld.type,
													parent_wvar_name: sParentWVarName,
													position: j
												});
											}
											else
											{
												oArgs.oOWT.params[iIdx].value = oChildParams[sKey]._GetValue({ bString: true });
											}
										}
									}
								}
							}
							break;
						}
                        case "select_to_foreign_elem":
						{
							oParam.value = oFld._GetValue({ bString: true });
							if(oFld.oChildParamFlds != null)
							{
								sParentWVarName = oParam.name;
								oChildParams = oFld.oChildParamFlds;
								if(oChildParams != null)
								{
									j = 0;
									for(i=0; i<oArgs.oOWT.params.length; i++)
									{
										aUsedParamNames.push(oArgs.oOWT.params[i].name);
									}
									for(sKey in oChildParams)
									{
										if(oChildParams.hasOwnProperty(sKey))
										{
											iIdx = $.inArray(TOOLS.DecodeVarName({ sText: sKey }), aUsedParamNames);
											if(iIdx == -1)
											{
												j++;
												oChildParams[sKey].oParentFld = oFld;
												aNewParams.push(
												{
													name: oChildParams[sKey].oFld.name,
													value: oChildParams[sKey]._GetValue({ bString: true }),
													type: oChildParams[sKey].oFld.type,
													parent_wvar_name: sParentWVarName,
													position: j
												});
											}
											else
											{
												oArgs.oOWT.params[iIdx].value = oChildParams[sKey]._GetValue({ bString: true });
											}
										}
									}
								}
							}
							break;
						}
                        case "folder":
						{
							break;
						}
                        default:
						{
							if(oArgs.bList)
							{
								oParam.value = oFld.oParentList._GetValue();
							}
							else
							{
								oParam.value = oFld._GetValue({ bString: true });
							}
							break;
						}
                    }
					if(oFld.sId.indexOf("remote_action_type")!=-1)
					{
						var sPrefix = oFld.sId.split(".")[0];
						for(i=0; i<this.aDialogPages.length; i++)
						{
							if(this.aDialogPages[i].oActionParamsFolder!=null)
							{
								this.aDialogPages[i].UpdateDynamic(
								{
									bFldModified: true,
									oThis: ((oFld.sValue=="common") ? this.aDialogPages[i].oFlds[sPrefix + "%46remote_action_common"] : this.aDialogPages[i].oFlds[sPrefix + "%46__remote_action__"]),
									oContext: this.aDialogPages[i],
									sFldName: sPrefix + "." + ((oFld.sValue=="common") ? "remote_action_common" : "__remote_action__")
								});
								break;
							}
						}
						if(oFld.sValue=="common")
						{

						}
						else if(oFld.sValue=="object")
						{

						}
					}
                }
                for(i=0; i<aNewParams.length; i++)
				{
                    oArgs.oOWT.params.push(JSON.parse(JSON.stringify(aNewParams[i])));
                }
            }
        }
        return this;
    };
    CXObjectDialog.prototype.Constructor = function(oArgs)
	{
        var i = 0;
        this.jTitle = this.jContainer.find("[cx-role='context-title']");
        this.jTitleText = this.jTitle.find("[cx-role='context-title-text']");
        this.jTabContainer = this.jContainer.find("[cx-role='context-switch']");
        this.jBody = this.jContainer.find("[cx-role='context-body']");
        this.jTabPageContainer = this.jBody.find("[cx-role='tab-body']");
        if(this.oObject.aTree != null)
		{
            this.aDialogTabs = [];
            for(i=0; i<this.oObject.aTree.length; i++)
			{
                this.aDialogTabs.push(new CXDialogTab({ oPlayer: this.oPlayer, jContainer: this.jTabContainer, oObject: this.oObject, oDialog: this, iTab: i }));
            }
            this.aDialogTabs.push(new CXDialogTab({ oPlayer: this.oPlayer, jContainer: this.jTabContainer, oObject: this.oObject, sType: "rules", oDialog: this, iTab: i }));
        }
        this.aDialogPages = [(new CXDialogPage({ oPlayer: this.oPlayer, oObject: this.oObject, oDialog: this, iPage: 0 }))];
        this.oBtns = {
            "submit": this.oPage.oBtns["template-submit"],
            "cancel": this.oPage.oBtns["template-cancel"]
        };
        this.AppendParams();
		this.FireEvent({ sEvent: "dialog_ready" });
        return this;
    };
    CXObjectDialog.prototype.DisableBtns = function(oArgs)
	{
        this.oPage.DisableTemplateBtns();
        return this;
    };
    CXObjectDialog.prototype.EnableBtns = function(oArgs)
	{
        this.oPage.EnableTemplateBtns();
        return this;
    };
    CXObjectDialog.prototype.Fill = function(oArgs)
	{
        return this;
    };
    CXObjectDialog.prototype.Filter = function(oArgs)
	{
        var i, j;
        for(i=0; i<this.aDialogTabs.length; i++)
		{
            if(oArgs.iTab == i)
			{
                this.aDialogTabs[i].Select();
                if(this.aDialogTabs[i].sType == "rules")
				{
                    this.aDialogPages[0].jRules.show();
                    for(j=0; j<this.aDialogPages[0].aTabBlocks.length; j++)
					{
                        this.aDialogPages[0].aTabBlocks[j].hide();
                    }
                }
				else
				{
                    this.aDialogPages[0].jRules.hide();
                    for(j=0; j<this.aDialogPages[0].aTabBlocks.length; j++)
					{
                        if(oArgs.iTab == j)
						{
                            this.aDialogPages[0].aTabBlocks[j].show();
                        }
						else
						{
                            this.aDialogPages[0].aTabBlocks[j].hide();
                        }
                    }
                }
            }
			else
			{
                this.aDialogTabs[i].Unselect();
            }
        }
        this.aDialogPages[0].ApplyConditions({ iTab: oArgs.iTab });
        return this;
    };
    CXObjectDialog.prototype.Hide = function(oArgs)
	{
        var i = 0;
        for(i=0; i<this.aDialogPages.length; i++)
		{
            this.aDialogPages[i].Hide();
        }
        if(this.aDialogTabs != null)
		{
            for(i=0; i<this.aDialogTabs.length; i++)
			{
                this.aDialogTabs[i].Unselect().Hide();
            }
        }
        this.oPage.oCurrentObjectDialog = null;
        return this;
    };
    CXObjectDialog.prototype.Revert = function(oArgs)
	{
        this.Update({ oOWT: this.oCurrentOWT });
        return this;
    };
    CXObjectDialog.prototype.Select = function(oArgs)
	{
        var iCnt = this.oObject.aDialogPages.length - 1;
        while (this.oObject.aDialogPages[iCnt] != null)
		{
            if(iCnt != 0)
			{
                this.oObject.aDialogPages[iCnt].jTabPage.hide();
            }
            iCnt--;
        }
        this.oObject.aDialogPages[0].jTab.find("[cx-role='tab-text']").click();
        return this;
    };
    CXObjectDialog.prototype.Show = function(oArgs)
	{
        var i, j;
        this.jTitle.show();
        this.jTitleText.html(this.oObject.name);
        this.DisableBtns();
        for(var sKey in this.oPage.oTemplateDialogs)
		{
            if(this.oPage.oTemplateDialogs.hasOwnProperty(sKey))
			{
                for(i=0; i<this.oPage.oTemplateDialogs[sKey].aDialogPages.length; i++)
				{
                    if(this.sId != sKey)
					{
                        this.oPage.oTemplateDialogs[sKey].aDialogPages[i].Hide();
                        for(j=0; j<this.oPage.oTemplateDialogs[sKey].aDialogTabs.length; j++)
						{
                            this.oPage.oTemplateDialogs[sKey].aDialogTabs[j].Hide();
                        }
                    }
                }
            }
        }
        var bHasParameters = false;
        for(i=0; i<this.aDialogPages.length; i++)
		{
            this.aDialogPages[i].Show();
            if(Object.keys(this.aDialogPages[i].oFlds).length != 0)
			{
                bHasParameters = true;
            }
        }
        this.oPage.jContextNothingSelected.hide();
        if(bHasParameters)
		{
            this.oPage.jContextNoParams.hide();
        }
		else
		{
            this.oPage.jContextNoParams.show();
        }
        if(this.aDialogTabs != null)
		{
            for(i=0; i<this.aDialogTabs.length; i++)
			{
                this.aDialogTabs[i].Show();
            }
            this.aDialogTabs[0].Select();
        }
        this.oPage.oCurrentObjectDialog = this;
        return this;
    };
    CXObjectDialog.prototype.Update = function(oArgs)
	{
        var i, sKey, sKey2;
        if(oArgs == null)
		{
            return this;
        }
        if(oArgs.oOWT != null)
		{
            this.oCurrentOWT = oArgs.oOWT;
            this.sCurrentOWTId = oArgs.oOWT.override_template_id;
            for(var i = 0; i<this.aDialogPages.length; i++)
			{
                this.aDialogPages[i].Update({ oOWT: oArgs.oOWT, bSuppressEvent: true }).ApplyConditions().UpdateAllDynamic();
            }
            this.DisableBtns();
        }
		else if(oArgs.bFldModified == true)
		{
            var sEncodedFldName = TOOLS.EncodeVarName({ sText: oArgs.sFldName });
            if(this.oPlayer.aLoading.length == 0)
			{
                if(oArgs.oThis.bIsDynamicParam && oArgs.oThis.oParamFld!=null) // write dynamic params into corresponding fld
				{
					var sParamValue = oArgs.oThis.oParamFld._GetValue();
					var oParamValue = {};
					try { oParamValue = JSON.parse(sParamValue); } catch(e) {}
					if(oParamValue.sId!=null && oParamValue.aParams!=null)
					{
						for(i=0; i<oParamValue.aParams.length; i++)
						{
							if(oParamValue.aParams[i].name==oArgs.oThis.sId)
							{
								oParamValue.aParams[i].value = oArgs.oThis._GetValue();
								this._GetParamByName({ oOWT: this.oCurrentOWT, sFldName: oArgs.oThis.sId }).value = oArgs.oThis._GetValue();
								break;
							}
						}
						oArgs.oThis.oParamFld.SetValue({ sValue: JSON.stringify(oParamValue), bSuppressEvent: true });
					}
				}
				else
				{
					if(this.aDialogPages[0].oFlds[sEncodedFldName] != null)
					{
						if(this.aDialogPages[0].oFlds[sEncodedFldName].sType == "object")
						{
							var aNewValues = [];
							var oRecord = {};
							for(i=0; i<this.aDialogPages[0].oFlds[sEncodedFldName].oControl.aPages.length; i++)
							{
								sKey = this.aDialogPages[0].oFlds[sEncodedFldName].oControl.aPages[i].sId;
								oRecord = {};
								for(sKey2 in this.aDialogPages[0].oFlds[sEncodedFldName].oListItems[sKey].oFlds)
								{
									oRecord[sKey2] = this.aDialogPages[0].oFlds[sEncodedFldName].oListItems[sKey].oFlds[sKey2]._GetValue({ bString: true });
								}
								aNewValues.push(JSON.parse(JSON.stringify(oRecord)));
							}
							this.aDialogPages[0].oFlds[sEncodedFldName].sValue = JSON.stringify(aNewValues);
							this.ApplyNewValue({ oOWT: this.oCurrentOWT, sFldName: oArgs.sFldName, oFld: oArgs.oThis, sValue: JSON.stringify(aNewValues) });
						}
						else
						{
							this.ApplyNewValue({ oOWT: this.oCurrentOWT, sFldName: oArgs.sFldName, oFld: oArgs.oThis });
						}
					}
					else if(oArgs.oThis.oParentFld!=null)
					{
						for(sKey in oArgs.oThis.oParentFld.oChildParamFlds)
						{
							if(sKey==sEncodedFldName)
							{
								this.ApplyNewValue({ oOWT: this.oCurrentOWT, sFldName: oArgs.sFldName, oParentFld: oArgs.oThis.oParentFld, oFld: oArgs.oThis });
							}
						}
					}
					else if(oArgs.oThis.oParentList!=null)
					{
						this.ApplyNewValue({ oOWT: this.oCurrentOWT, bList: true, sFldName: oArgs.sFldName, oParentList: oArgs.oThis.oParentList, oFld: oArgs.oThis });
					}
				}
		    }
			if(!oArgs.oThis.bIsDynamicParam)
			{
				this.aDialogPages[0].ApplyConditionsBySource({ sSource: oArgs.sFldName });
			}

            if(this.aDialogPages[0].oFlds[sEncodedFldName] != null) // collection param flds are in oChildFlds of fld - we don't care
            {
                if(this.aDialogPages[0].oFlds[sEncodedFldName].sType == "object") // set service fld value for list
                {
					var sItemFld = oArgs.sFldName.split(".")[0] + ".__service__selected_item";
                    var sItemFldName = TOOLS.EncodeVarName({ sText: sItemFld });
                    if(this.aDialogPages[0].oFlds[sItemFldName] != null)
					{
                        this.aDialogPages[0].oFlds[sItemFldName].SetValue({ sValue: this.aDialogPages[0].oFlds[sEncodedFldName]._GetIndex() });
						this.ApplyNewValue({ oOWT: this.oCurrentOWT, sFldName: sItemFld, oFld: this.aDialogPages[0].oFlds[sItemFldName] });
                    }
                }
            }
            this.EnableBtns();
        }
        return this;
    };
}
{ // CXDialogTab
    window.CXDialogTab = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oDialog = oArgs.oDialog;
        this.oObject = oArgs.oObject;
        this.iTab = oArgs.iTab;
        this.sType = oArgs.sType != null ? oArgs.sType : "object";
        this.bSelected = false;
        this.aFldNames = [];
        this.Constructor();
        return this;
    };
    CXDialogTab.prototype = Object.create(WTBaseObject.prototype);
    CXDialogTab.prototype.constructor = CXDialogTab;
    CXDialogTab.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        if(this.sType == "rules")
		{
            this.oTab = {};
            this.jBtn = this.oPlayer.jStorage.find("[cx-template='dialog-tab-btn']").clone(true).removeAttr("cx-template").attr({ "cx-template": this.oObject.id, "cx-tab": this.oTab.name, "cx-tab-idx": this.iTab, "title": "Rules" }).on("click", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); }).appendTo(this.jContainer);
            this.jBtn.find("[cx-role='btn-text']").html( this.oPlayer._GetString({ sId: "tab-rules" }) );
        }
		else
		{
            this.oTab = this.oObject.aTree[this.iTab];
            this.jBtn = this.oPlayer.jStorage.find("[cx-template='dialog-tab-btn']").clone(true).removeAttr("cx-template").attr({ "cx-template": this.oObject.id, "cx-tab": this.oTab.name, "cx-tab-idx": this.iTab, "title": this.oTab.description }).on("click", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); }).appendTo(this.jContainer);
            this.jBtn.find("[cx-role='btn-text']").html(this.oTab.description);
            this.Hide();
        }
        this.Hide();
        return this;
    };
    CXDialogTab.prototype.Hide = function(oArgs)
	{
        this.jBtn.hide();
        return this;
    };
    CXDialogTab.prototype.Select = function(oArgs)
	{
        this.bSelected = true;
        this.jBtn.attr({ "cx-state": "selected" });
        return this;
    };
    CXDialogTab.prototype.Show = function(oArgs)
	{
        this.jBtn.show();
        return this;
    };
    CXDialogTab.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        this.oDialog.Filter({ iTab: this.iTab });
        return this;
    };
    CXDialogTab.prototype.Unselect = function(oArgs)
	{
        this.bSelected = false;
        this.jBtn.removeAttr("cx-state");
        return this;
    };
}
{ // CXFolder
    window.CXFolder = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oDialog = oArgs.oDialog;
        this.oPage = oArgs.oPage;
        this.iTab = oArgs.iTab;
        this.oParam = oArgs.oParam;
        this.oObject = oArgs.oObject;
        this.bCollapsed = false;
        this.sType = "folder";
        this.Constructor();
        return this;
    };
    CXFolder.prototype = Object.create(WTBaseObject.prototype);
    CXFolder.prototype.constructor = CXFolder;
    CXFolder.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
		var sKey;
        this.jFolder = this.oPlayer.jStorage.find("[cx-template='dialog-folder']").clone(true).removeAttr("cx-template").attr({ "cx-object-id": this.oObject.id, "cx-tab-id": this.iTab }).appendTo(this.jContainer);
        this.jFolder.find("[cx-role='dialog-folder-title']").html(this.oParam.description);
        this.jBtn = this.jFolder.find("[cx-role='dialog-folder-btn']").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
        this.jBody = this.jFolder.find("[cx-role='dialog-folder-body']");
		if(this.oParam.name.indexOf("_MAPPING")!=-1)
		{
			this.jFolder.attr({ "cx-mapping": "1" });
			this.bMappingFolder = true;
			this.oMappingFlds = {};
			this.aMappingFlds = [];
			this.oMappingValueFlds = {};
			this.aMappingValueFlds = [];
			this.oCollectionFld = null;
			if(this.oParam.name.indexOf("_COMMON")!=-1)
			{
				this.jFolder.attr({ "cx-common": "1" });
				this.bCommonMappingFld = true;
				for(sKey in this.oPage.oFlds)
				{
					if(sKey.indexOf("collection_common")!=-1)
					{
						this.oCollectionFld = this.oPage.oFlds[sKey];
						break;
					}
				}
			}
			else
			{
				for(sKey in this.oPage.oFlds)
				{
					if(sKey.indexOf("__collection__")!=-1)
					{
						this.oCollectionFld = this.oPage.oFlds[sKey];
						break;
					}
				}
			}
			this.oHeader = this.oPlayer.jStorage.find("[cx-template='map-header']").clone(true).removeAttr("cx-template").attr({ "cx-object-id": this.oObject.id }).appendTo(this.jBody);
			this.oHeader.find("[cx-btn]").attr({ "cx-object-id": this.oObject.id }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
		}
        return this;
    };
    CXFolder.prototype.Hide = function(oArgs)
	{
        var oThis = this;
        if(oArgs != null && oArgs.bTransition == true)
		{
            this.jFolder.slideUp(250, function() { oThis.bVisible = false; });
        }
		else
		{
            this.jFolder.hide();
            this.bVisible = false;
        }
        return this;
    };
    CXFolder.prototype.Show = function(oArgs)
	{
        var oThis = this;
        if(oArgs != null && oArgs.bTransition == true)
		{
            this.jFolder.slideDown(250, function() { oThis.bVisible = true; });
        }
		else
		{
            this.jFolder.show();
            this.bVisible = true;
        }
        return this;
    };
    CXFolder.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
		if(oArgs.oElem.getAttribute("cx-role")=="map-edit")
		{
			this.oDialog.oPage.oBuilders["map"].Update({ oFolder: this }).Show();
		}
		else
		{
			if(this.bCollapsed)
			{
				this.jFolder.attr({ "cx-state": "expanded" });
				this.jBody.slideDown(250, function() { oThis.bCollapsed = false; });
			}
			else
			{
				this.jFolder.attr({ "cx-state": "collapsed" });
				this.jBody.slideUp(250, function() { oThis.bCollapsed = true; });
			}
		}
		return this;
    };
    CXFolder.prototype.Update = function(oArgs)
	{
        var oThis = this;
		var i;
		for(i=0; i<this.aMappingFlds.length; i++)
		{
			this.oPage.oFlds[TOOLS.EncodeVarName({ sText: this.aMappingFlds[i].name })].SetValue({ sValue: "", sName: "" });
		}
		for(i=0; i<this.aMappingValueFlds.length; i++)
		{
			this.oPage.oFlds[TOOLS.EncodeVarName({ sText: this.aMappingValueFlds[i].name })].SetValue({ sValue: "", sName: "" });
		}
        return this;
    };
}
{ // CXDialogPage
    window.CXDialogPage = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oObject = oArgs.oObject;
        this.oDialog = oArgs.oDialog;
        this.iPage = oArgs.iPage;
        this.oFlds = {};
		this.oFontControls = {};
        this.oLabels = {};
        this.oCollectionParamsFolder = null;
        this.oActionParamsFolder = null;
		this.oCommonCollectionParamsFolder = null;
		this.oCommonMappingFolder = null;
        this.aConditions = [];
        this.aRules = [];
        this.oConditionsBySource = {};
        this.oConditionsByTarget = {};
        this.Constructor();
        return this;
    };
    CXDialogPage.prototype = Object.create(WTBaseObject.prototype);
    CXDialogPage.prototype.constructor = CXDialogPage;
    CXDialogPage.prototype._EvalCondition = function(oArgs)
	{
        var sFldName;
        var oSourceFld = this.oFlds[oArgs.oCondition.sSource];
        var oTargetFld = this.oFlds[oArgs.oCondition.sTarget];
        var bResult = true;
        switch(oArgs.oCondition.sType)
		{
            case "bool":
			{
				switch(oArgs.oCondition.sOp)
				{
					case "eq":
					{
						bResult = (oArgs.oCondition.bValue == oSourceFld._GetValue());
						break;
					}
					case "neq":
					{
						bResult = (oArgs.oCondition.bValue != oSourceFld._GetValue());
						break;
					}
				}
				break;
			}
            case "integer":
            case "real":
			{
				switch(oArgs.oCondition.sOp)
				{
					case "eq":
					{
						bResult = (oArgs.oCondition.nValue == oSourceFld._GetValue());
						break;
					}
					case "neq":
					{
						bResult = (oArgs.oCondition.nValue != oSourceFld._GetValue());
						break;
					}
					case "lt":
					{
						bResult = (oArgs.oCondition.nValue > oSourceFld._GetValue());
						break;
					}
					case "lte":
					{
						bResult = (oArgs.oCondition.nValue >= oSourceFld._GetValue());
						break;
					}
					case "gt":
					{
						bResult = (oArgs.oCondition.nValue < oSourceFld._GetValue());
						break;
					}
					case "gte":
					{
						bResult = (oArgs.oCondition.nValue <= oSourceFld._GetValue());
						break;
					}
				}
				break;
			}
            case "string":
			{
				switch(oArgs.oCondition.sOp)
				{
					case "eq":
					{
						bResult = (oSourceFld._GetValue() == oArgs.oCondition.sValue);
						break;
					}
					case "neq":
					{
						bResult = (oSourceFld._GetValue() != oArgs.oCondition.sValue);
						break;
					}
					case "cn":
					{
						bResult = ((oSourceFld._GetValue()).indexOf(oArgs.oCondition.sValue) != -1);
						break;
					}
					case "ncn":
					{
						bResult = ((oSourceFld._GetValue()).indexOf(oArgs.oCondition.sValue) == -1);
						break;
					}
				}
				break;
			}
        }
        return bResult;
    };
    CXDialogPage.prototype._SortByPosition = function(oElem1, oElem2)
	{
		if(typeof oElem1.position != "number")
		{
			oElem1.position = parseInt(oElem1.position,10);
		}
		if(typeof oElem2.position != "number")
		{
			oElem2.position = parseInt(oElem2.position,10);
		}
        if(oElem1.position > oElem2.position)
		{
            return 1;
        }
        if(oElem1.position < oElem2.position)
		{
            return -1;
        }
        return 0;
    };
    CXDialogPage.prototype.ApplyConditions = function(oArgs)
	{
        var sKey;
        if(oArgs == null) // initial - by each target
        {
            for(sKey in this.oConditionsByTarget)
			{
                if(this.oConditionsByTarget.hasOwnProperty(sKey))
				{
                    this.ApplyConditionsByTarget({ sTarget: sKey });
                }
            }
        }
		else if(oArgs.iTab != null)
		{
            for(sKey in this.oConditionsByTarget)
			{
                if(this.oConditionsByTarget.hasOwnProperty(sKey) && ($.inArray(sKey, this.oDialog.aDialogTabs[oArgs.iTab].aFldNames) != -1))
				{
                    this.ApplyConditionsByTarget({ sTarget: sKey });
                }
            }
        }
        return this;
    };
    CXDialogPage.prototype.ApplyConditionsByTarget = function(oArgs)
	{
        var i;
        var oOps = { "and": "&&", "or": "||" };
        var bFinal = true;

        if(oArgs.sTarget != null)
		{
            var sFldName = (oArgs.sTarget.indexOf("%46") == -1 ? TOOLS.EncodeVarName({ sText: oArgs.sTarget }) : oArgs.sTarget); // some calls may be unencoded
			if(!this.oFlds[sFldName].bMappingFld) // mapping flds has own rules
			{
				if(this.oConditionsByTarget[sFldName] != null)
				{
					if(this.oConditionsByTarget[sFldName].length != 0)
					{
						var aResults = [];
						for(i=0; i<this.oConditionsByTarget[sFldName].length; i++)
						{
							aResults.push({ bValue: this._EvalCondition({ oCondition: this.oConditionsByTarget[sFldName][i] }), sNextOp: ((i == this.oConditionsByTarget[sFldName].length - 1) ? "" : oOps[this.oConditionsByTarget[sFldName][i].sNextOp]) });
						}
						var sFinalString = "";
						for(i=0; i<aResults.length; i++)
						{
							sFinalString += aResults[i].bValue + " " + aResults[i].sNextOp + " ";
						}
						sFinalString = $.trim(sFinalString);
						bFinal = eval(sFinalString);
						if(bFinal)
						{
							if(this.oObject.bUseFontControl && this.oFontControls[sFldName]!=null)
							{
								this.oFontControls[sFldName].Show();
							}
							else
							{
								this.oFlds[sFldName].Show();
							}
						}
						else
						{
							if(this.oObject.bUseFontControl && this.oFontControls[sFldName]!=null)
							{
								this.oFontControls[sFldName].Hide();
							}
							else
							{
								this.oFlds[sFldName].Hide();
							}
						}
					}
				}
			}
		}
        return this;
    };
    CXDialogPage.prototype.ApplyConditionsBySource = function(oArgs)
	{
        if(oArgs.sSource != null)
		{
            var sFldName = (oArgs.sSource.indexOf("%46") == -1 ? TOOLS.EncodeVarName({ sText: oArgs.sSource }) : oArgs.sSource); // some calls may be unencoded
            if(this.oConditionsBySource[sFldName] != null)
			{
                if(this.oConditionsBySource[sFldName].length != 0)
				{
                    for(var i = 0; i<this.oConditionsBySource[sFldName].length; i++)
					{
                        this.ApplyConditionsByTarget({ sTarget: this.oConditionsBySource[sFldName][i].sTarget });
                    }
                }
            }
        }
        return this;
    };
    CXDialogPage.prototype.Constructor = function(oArgs)
	{
        this.jTabPage = this.oPlayer.jStorage.find("[cx-template='tab-page']").clone(true).removeAttr("cx-template").attr({ "id": this.oObject.id + "_" + this.iPage, "cx-id": this.oObject.id }).appendTo(this.oDialog.jTabPageContainer);
        this.jParamBlockTemplate = this.oPlayer.jStorage.find("[cx-template='param-block']");
        this.jParamRowTemplate = this.oPlayer.jStorage.find("[cx-template='param-row-template']");
        this.jParamColumnTemplate = this.oPlayer.jStorage.find("[cx-template='param-column-template']");
        this.jParamLabelTemplate = this.oPlayer.jStorage.find("[cx-template='param-label']");
        this.jParamHRTemplate = this.oPlayer.jStorage.find("[cx-template='param-hr']");
        this.jBlockTemplate = this.oPlayer.jStorage.find("[cx-template='fld-block']");
        this.oFldTemplates = {};
        this.Layout().ParseConditions();
        return this;
    };
    CXDialogPage.prototype.DeleteRule = function(oArgs)
	{
        var iIdx = oArgs.iIdx;
		var sRuleId = this.aRules[iIdx].oRule.id;
		var iToDelete = -1;
		for(var i=0; i<this.oPlayer.oCurrentWebModeCopy.template_links.length; i++)
		{
			if(this.oPlayer.oCurrentWebModeCopy.template_links[i].id==sRuleId)
			{
				iToDelete = i;
				break;
			}
		}
		if(iToDelete!=-1)
		{

			this.aRules[iIdx].jItem.remove();
			delete this.aRules[iIdx].oRule;
			delete this.aRules[iIdx];
			this.aRules.splice(iIdx, 1);
			this.oPlayer.oCurrentWebModeCopy.template_links.splice(iToDelete, 1);
			var oToSave =
			{
				action: "save_web_mode_structure",
				web_mode_id: this.oPlayer.oCurrentWebModeCopy.id,
				web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
			};
			this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this.oPlayer.oPages["desktop"]._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true, bCleanZones: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bAfterSave: true } });
		}
		return this;
    };
    CXDialogPage.prototype.Hide = function(oArgs)
	{
        this.jTabPage.hide();
        return this;
    };
    CXDialogPage.prototype.FillBlock = function(oArgs)
	{
        var i, j;
        var oParam;
        var sVarNameEncoded;
        var jFldBlock;
        var sGUID;
        var aParams = oArgs.aLevel;
        aParams.sort(this._SortByPosition);
		// assuming macro blocks have list on 0 level only !
        for(i=0; i<aParams.length; i++)
		{
            oParam = aParams[i];
            sVarNameEncoded = TOOLS.EncodeVarName({ sText: oParam.name });
            if(oParam.sType == "folder")
			{
                this.oFlds[sVarNameEncoded] = new CXFolder({ oPlayer: this.oPlayer, jContainer: oArgs.jBlock, oObject: this.oObject, oDialog: this.oDialog, oPage: this, iTab: oArgs.iTab, oParam: oParam, sId: oParam.name });
                this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                if(oParam.aChildren != null && oParam.aChildren.length != 0)
				{
                    this.FillFolder({ iTab: oArgs.iTab, oFolder: this.oFlds[sVarNameEncoded], aLevel: oParam.aChildren });
                }

            }
			else
			{
                sGUID = TOOLS.GUID();
				if(this.oObject.bUseFontControl && oParam.name.indexOf("font_family")!=-1 && oParam.name.indexOf("_custom")==-1)
				{
					this.oFontControls[sVarNameEncoded] = new CXFontControl({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oParam, jBlock: oArgs.jBlock, sId: oParam.name, sLabel: oParam.name, oParentFld: oArgs.oParentFld });
				}
                this.oFlds[sVarNameEncoded] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oParam, jBlock: oArgs.jBlock, sId: oParam.name, sLabel: oParam.name, oParentFld: oArgs.oParentFld, oFolder: oArgs.oFolder });
                this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: sGUID, oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oParam.name } });
                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oParam.name } });
                if(this.oFlds[sVarNameEncoded].sType == "object" && this.oFlds[sVarNameEncoded].sId == "macro_stack_horizontal.columns")
				{
                    this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_appended", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
                    this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_deleted", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
				}
                if(this.oFlds[sVarNameEncoded].sType == "object" && (this.oFlds[sVarNameEncoded].sId == "macro_stack_horizontal.columns" || this.oFlds[sVarNameEncoded].sId == "macro_tabs.items"))
				{
                    this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "reordered", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.ReorderZones, oArgs: { sFldName: aParams[i].name } });
				}
                if(oParam.aChildren != null && oParam.aChildren.length != 0)
				{
                    oParam.aChildren.sort(this._SortByPosition);
                    for(j=0; j<oParam.aChildren.length; j++)
					{
                        sVarNameEncoded = TOOLS.EncodeVarName({ sText: oParam.aChildren[j].name });
                        if(this.oFlds[sVarNameEncoded] != null)
						{
                            continue;
                        }
                        if(oParam.aChildren[j].sType == "folder")
						{
                            this.oFlds[sVarNameEncoded] = new CXFolder({ oPlayer: this.oPlayer, jContainer: oArgs.jBlock, oObject: this.oObject, oDialog: this.oDialog, oPage: this, iTab: oArgs.iTab, oParam: oParam.aChildren[j], sId: oParam.aChildren[j].name });
                            this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                            if(oParam.aChildren[j].aChildren != null && oParam.aChildren[j].aChildren.length != 0)
							{
                                this.FillFolder({ iTab: oArgs.iTab, oFolder: this.oFlds[sVarNameEncoded], aLevel: oParam.aChildren[j].aChildren });
                            }
                        }
						else
						{
                            sGUID = TOOLS.GUID();
                            this.oFlds[sVarNameEncoded] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oParam.aChildren[j], jBlock: oArgs.jBlock, sId: oParam.aChildren[j].name, sLabel: oParam.aChildren[j].name, oParentFld: this.oFlds[sVarNameEncoded] });
                            this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                            this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: sGUID, oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oParam.aChildren[j].name } });
                            this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oParam.aChildren[j].name } });
                            if(this.oFlds[sVarNameEncoded].sType == "object" && this.oFlds[sVarNameEncoded].sId == "macro_stack_horizontal.columns")
							{
                                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_appended", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
                                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_deleted", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
                            }
                            if(oParam.aChildren[j].aChildren != null && oParam.aChildren[j].aChildren.length != 0)
							{
                                jFldBlock = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(oArgs.jBlock);
                                this.FillBlock({ jBlock: jFldBlock, aLevel: oParam.aChildren[j].aChildren, iTab: oArgs.iTab, oParentFld: this.oFlds[sVarNameEncoded] });
                            }
                        }
                    }
                }
            }
            if(oArgs.iLevel == 0)
			{
                this.oFlds[sVarNameEncoded].iTab = oArgs.iTab;
                this.oFlds[sVarNameEncoded].iLevel = 0;
                this.oFlds[sVarNameEncoded].jBlock = oArgs.jBlock;
            }
        }
        return this;
    };
    CXDialogPage.prototype.FillFolder = function(oArgs)
	{
        var i;
        var aParams = oArgs.aLevel;
        aParams.sort(this._SortByPosition);
        var sVarNameEncoded;
        var jFldBlock;
        var sGUID;
        for(i=0; i<aParams.length; i++)
		{
            sVarNameEncoded = TOOLS.EncodeVarName({ sText: aParams[i].name });
            if(this.oFlds[sVarNameEncoded] != null)
			{
                continue;
            }
            if(aParams[i].sType == "folder")
			{
                this.oFlds[sVarNameEncoded] = new CXFolder({ oPlayer: this.oPlayer, jContainer: oArgs.oFolder.jBody, oObject: this.oObject, oDialog: this.oDialog, oPage: this, iTab: oArgs.iTab, oParam: aParams[i], sId: aParams[i].name });
                this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                this.FillFolder({ iTab: oArgs.iTab, oFolder: this.oFlds[sVarNameEncoded], aLevel: aParams[i].aChildren });
                if(aParams[i].name.indexOf(".FOLDER_COLLECTION_PARAMS") != -1)
				{
					this.oCollectionParamsFolder = this.oFlds[sVarNameEncoded];
                }
                else if(aParams[i].name.indexOf(".FOLDER_MAPPING") != -1)
				{
                    this.oMappingFolder = this.oFlds[sVarNameEncoded];
                }
                else if(aParams[i].name.indexOf(".FOLDER_COMMON_COLLECTION") != -1)
				{
                    this.oCommonCollectionParamsFolder = this.oFlds[sVarNameEncoded];
                }
                else if(aParams[i].name.indexOf(".FOLDER_COMMON_MAPPING") != -1)
				{
                    this.oCommonMappingFolder = this.oFlds[sVarNameEncoded];
                }
                else if(aParams[i].name.indexOf(".FOLDER_ACTION_PARAMS") != -1)
				{
                    this.oActionParamsFolder = this.oFlds[sVarNameEncoded];
                }
            }
			else
			{
                sGUID = TOOLS.GUID();
				jFldBlock = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(oArgs.oFolder.jBody);
 				if(this.oObject.bUseFontControl && aParams[i].name.indexOf("font_family")!=-1 && aParams[i].name.indexOf("_custom")==-1)
				{
					this.oFontControls[sVarNameEncoded] = new CXFontControl({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: aParams[i], jBlock: jFldBlock, sId: aParams[i].name, sLabel: aParams[i].name });
				}
                this.oFlds[sVarNameEncoded] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: aParams[i], jBlock: jFldBlock, sId: aParams[i].name, sLabel: aParams[i].name, oFolder: oArgs.oFolder });
                this.oDialog.aDialogTabs[oArgs.iTab].aFldNames.push(sVarNameEncoded);
                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: sGUID, oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: aParams[i].name } });
                this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: aParams[i].name } });
                if(this.oFlds[sVarNameEncoded].sType == "object" && this.oFlds[sVarNameEncoded].sId == "macro_stack_horizontal.columns")
				{
                    this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_appended", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
                    this.oFlds[sVarNameEncoded].Subscribe({ sEvent: "list_item_deleted", bOnce: false, sSubscriberId: sGUID, oContext: this, fn: this.UpdateColumns, oArgs: { sFldName: aParams[i].name } });
                }
                if(aParams[i].aChildren != null && aParams[i].aChildren.length != 0)
				{
                    this.FillBlock({ jBlock: jFldBlock, aLevel: aParams[i].aChildren, iTab: oArgs.iTab, oParentFld: this.oFlds[sVarNameEncoded], oFolder: oArgs.oFolder });
                }
			}
        }
        return this;
    };
    CXDialogPage.prototype.Layout = function(oArgs)
	{
        var oThis = this;
        var i, j;
        var sVarNameEncoded;
        var jFldBlock;
        this.aTabBlocks = [];
        if(this.oObject.aTree != null)
		{
            for(i=0; i<this.oObject.aTree.length; i++)
			{
                this.aTabBlocks.push($(document.createElement("div")).attr({ "cx-tab-page": i }).appendTo(this.jTabPage));
                this.oObject.aTree[i].aChildren.sort(this._SortByPosition);
                for(j=0; j<this.oObject.aTree[i].aChildren.length; j++)
				{
                    sVarNameEncoded = TOOLS.EncodeVarName({ sText: this.oObject.aTree[i].aChildren[j].name });
                    if(this.oObject.aTree[i].aChildren[j].type == "folder")
					{
                        this.oFlds[sVarNameEncoded] = new CXFolder({ oPlayer: this.oPlayer, jContainer: this.aTabBlocks[i], oObject: this.oObject, oDialog: this.oDialog, oPage: this, iTab: i, oParam: this.oObject.aTree[i].aChildren[j], sId: this.oObject.aTree[i].aChildren[j].name });
                        this.oFlds[sVarNameEncoded].iLevel = 0;
                        this.oDialog.aDialogTabs[i].aFldNames.push(sVarNameEncoded);
                        this.FillFolder({ iTab: i, iLevel: 0, oFolder: this.oFlds[sVarNameEncoded], aLevel: this.oObject.aTree[i].aChildren[j].aChildren });
                        if(this.oObject.aTree[i].aChildren[j].name.indexOf(".FOLDER_COLLECTION_PARAMS") != -1)
						{
                            this.oCollectionParamsFolder = this.oFlds[sVarNameEncoded];
                        }
                        else if(this.oObject.aTree[i].aChildren[j].name.indexOf(".FOLDER_MAPPING") != -1)
						{
                            this.oMappingFolder = this.oFlds[sVarNameEncoded];
                        }
                        else if(this.oObject.aTree[i].aChildren[j].name.indexOf(".FOLDER_COMMON_COLLECTION") != -1)
						{
                            this.oCommonCollectionParamsFolder = this.oFlds[sVarNameEncoded];
                        }
                        else if(this.oObject.aTree[i].aChildren[j].name.indexOf(".FOLDER_COMMON_MAPPING") != -1)
						{
                            this.oCommonMappingFolder = this.oFlds[sVarNameEncoded];
                        }
                        else if(this.oObject.aTree[i].aChildren[j].name.indexOf(".FOLDER_ACTION_PARAMS") != -1)
						{
                            this.oActionParamsFolder = this.oFlds[sVarNameEncoded];
                        }
                    }
					else
					{
                        jFldBlock = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.aTabBlocks[i]);
                        this.FillBlock({ iTab: i, iLevel: 0, jBlock: jFldBlock, aLevel: [this.oObject.aTree[i].aChildren[j]] });
                    }
                }
            }
        }
        this.jRules = this.oPlayer.jStorage.find("[cx-template='tab-page-rules']").clone(true).removeAttr("cx-template").appendTo(this.jTabPage);
        this.jNoRules = this.jRules.find("[cx-role='no-rules-yet']");
        this.jRulesList = this.jRules.find("[cx-role='rules-list']");
        this.jBtnRuleAdd = this.jRules.find("[cx-role='rule-add']").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
        return this;
    };
    CXDialogPage.prototype.LoadAction = function(oArgs)
	{
		var oThis = this;
		if(oArgs.sActionId!=null)
		{
			this.Load(
			{
				sURL: this.oPlayer.oConfig.sRootAPIURL,
				sData: "action={'action':'get_action','object_id':'" + oArgs.sActionId + "'}",
				oContext: this,
				fnSuccess: this.UpdateActionParams,
				oSuccessArgs: { bAfterSave: true, oFld: oArgs.oFld, oContext: oThis }
			});
		}
		return this;
	};
    CXDialogPage.prototype.LoadCollection = function(oArgs)
	{
		var oThis = this;
		if(oArgs.sCollectionId!=null)
		{
			this.Load(
			{
				sURL: this.oPlayer.oConfig.sRootAPIURL,
				sData: "action={'action':'get_collection','object_id':'" + oArgs.sCollectionId + "'}",
				oContext: this,
				fnSuccess: this.UpdateCollectionParams,
				oSuccessArgs: { bAfterSave: true, oFld: oArgs.oFld, oContext: oThis }
			});
		}
		return this;
	};
    CXDialogPage.prototype.ParseConditions = function(oArgs)
	{
        var i, j;
        var oCondition;
        for(i=0; i<this.oObject.params.length; i++)
		{
            if(this.oObject.params[i].view != null)
			{
                if(this.oObject.params[i].view.conditions != null)
				{
                    for(j=0; j<this.oObject.params[i].view.conditions.length; j++)
					{
                        oCondition =
						{
                            sTarget: TOOLS.EncodeVarName({ sText: this.oObject.params[i].name }),
                            sSource: TOOLS.EncodeVarName({ sText: this.oObject.params[i].view.conditions[j].wvar_name }),
                            sOp: this.oObject.params[i].view.conditions[j].option_type,
                            sNextOp: this.oObject.params[i].view.conditions[j].and_or
                        };
						try
						{
							switch(this.oFlds[oCondition.sSource].sType)
							{
								case "bool":
								{
									oCondition.sType = "bool";
									oCondition.bValue = TOOLS.Refine({ sValue: this.oObject.params[i].view.conditions[j].value, sType: "bool" });
									break;
								}
								case "integer":
								{
									oCondition.sType = "integer";
									oCondition.nValue = parseInt(this.oObject.params[i].view.conditions[j].value, 10);
									if(isNaN(oCondition.nValue))
									{
										oCondition.nValue = 0;
									}
									break;
								}
								case "real":
								{
									oCondition.sType = "real";
									oCondition.nValue = parseFloat(this.oObject.params[i].view.conditions[j].value);
									if(isNaN(oCondition.iValue))
									{
										oCondition.nValue = 0;
									}
									break;
								}
								default:
								{
									oCondition.sType = "string";
									oCondition.sValue = this.oObject.params[i].view.conditions[j].value;
									break;
								}
							}
						}
						catch(e)
						{
							console.log(this.oObject.params[i].name);
						}
						this.aConditions.push(JSON.parse(JSON.stringify(oCondition)));
                        if(this.oConditionsBySource[oCondition.sSource] == null)
						{
                            this.oConditionsBySource[oCondition.sSource] = [];
                        }
                        this.oConditionsBySource[oCondition.sSource].push(this.aConditions[this.aConditions.length - 1]);
                        if(this.oConditionsByTarget[oCondition.sTarget] == null)
						{
                            this.oConditionsByTarget[oCondition.sTarget] = [];
                        }
                        this.oConditionsByTarget[oCondition.sTarget].push(this.aConditions[this.aConditions.length - 1]);
                    }
                }
            }
        }
        return this;
    };
    CXDialogPage.prototype.ReorderZones = function(oArgs)
	{
		if(oArgs.oThis.oControl.aReorder!=null)
		{
			if(Array.isArray(oArgs.oThis.oControl.aReorder))
			{
				if(oArgs.oThis.oControl.aReorder.length==2)
				{
					for(var sKey in this.oFlds)
					{
						if(sKey.indexOf("__service__zones")!=-1)
						{
							var aOrder = JSON.parse( this.oFlds[sKey]._GetValue() );
							aOrder[oArgs.oThis.oControl.aReorder[1]] = aOrder.splice(oArgs.oThis.oControl.aReorder[0], 1, aOrder[oArgs.oThis.oControl.aReorder[1]])[0];
							this.oFlds[sKey].SetValue({ sValue: JSON.stringify(aOrder), bSuppressEvent: true });
							for(var i=0; i<oArgs.oThis.oDialog.oCurrentOWT.params.length; i++)
							{
								if(oArgs.oThis.oDialog.oCurrentOWT.params[i].name.indexOf("__service__zones")!=-1)
								{
									oArgs.oThis.oDialog.oCurrentOWT.params[i].value = this.oFlds[sKey]._GetValue();
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
        return this;
    };
    CXDialogPage.prototype.Show = function(oArgs)
	{
        this.jTabPage.show();
        this.oDialog.Filter({ iTab: 0 });
        return this;
    };
    CXDialogPage.prototype.UIEvent = function(oArgs)
	{
        switch(oArgs.oElem.getAttribute("cx-role"))
		{
            case "rule-add":
			{
				var iIdx = this.aRules.length;
				var sRuleId = TOOLS.ShortID();
				var oRule =
				{
					id: sRuleId,
					source_template_id: "",
					target_template_id: this.oDialog.oCurrentOWT.override_template_id,
					type: "hide",
					conditions: []
				};
				this.oPlayer.oCurrentWebModeCopy.template_links.push(oRule);
				this.aRules.push(new CXRule({ oPlayer: this.oPlayer, oParent: this, iIdx: iIdx, jContainer: this.jRulesList, oRule: this.oPlayer.oCurrentWebModeCopy.template_links[this.oPlayer.oCurrentWebModeCopy.template_links.length - 1] }));
				this.jRulesList.show();
				this.jNoRules.hide();
				var oToSave =
				{
					action: "save_web_mode_structure",
					web_mode_id: this.oPlayer.oCurrentWebModeCopy.id,
					web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
				};
				this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this.oPlayer.oPages["desktop"]._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true, bCleanZones: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bRuleAdded: true, sRuleId: sRuleId } });
				break;
			}
        }
        return this;
    };
    CXDialogPage.prototype.Update = function(oArgs)
	{
        var i, j, k;
        var sKey;
		var sVarNameEncoded;
        if(oArgs.oOWT != null)
		{
            this.oDialog.oPage.oEditor.bStateLocked = true;
            var oFld;
 			var oSelectedCollection;
			var oSelectedAction;
			if(oArgs.oOWT.params == null)
			{
                if(this.oPlayer.oStore["templates"].oData[oArgs.oOWT.id] != null)
				{
                    oArgs.oOWT.params = JSON.parse(JSON.stringify(this.oPlayer.oStore["templates"].oData[oArgs.oOWT.id].params));
                }
				else if(this.oPlayer.oStore["macros"].oData[oArgs.oOWT.id] != null)
				{
                    oArgs.oOWT.params = JSON.parse(JSON.stringify(this.oPlayer.oStore["macros"].oData[oArgs.oOWT.id].params));
                }
            }
            if(oArgs.oOWT.params != null)
			{
                for(i=0; i<oArgs.oOWT.params.length; i++)
				{
                    sVarNameEncoded = TOOLS.EncodeVarName({ sText: oArgs.oOWT.params[i].name });
                    oFld = this.oFlds[sVarNameEncoded];
                    if(oFld != null)
					{
                        if(oFld.bDynamicFill && !(oFld.bMappingFld || oFld.bMappingFldValue))
						{
							if(oFld.sType == "select_to_foreign_elem")
							{
                                oFld.jControl.find("option[value!='']").remove();
                                if(oFld.bActionFld && this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
								{
                                    for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
									{
                                        oFld.jControl.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id + '">' + this.oPlayer.oCurrentWebModeCopy.remote_actions[j].name + '</option');
                                    }
                                }
								else if(oFld.bCollectionFld && this.oPlayer.oCurrentWebModeCopy.collections != null)
								{
                                    for(j=0; j<this.oPlayer.oCurrentWebModeCopy.collections.length; j++)
									{
                                        oFld.jControl.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.collections[j].id + '">' + this.oPlayer.oCurrentWebModeCopy.collections[j].name + '</option');
                                    }
                                }
                            }
							if(oFld.sType == "foreign_elem")
							{
								if(oFld.bActionFld && this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
								{
									oFld.aDynamicOptions = this.oPlayer.oCurrentWebModeCopy.remote_actions;
								}
								else if(oFld.bCollectionFld && this.oPlayer.oCurrentWebModeCopy.collections != null)
								{
									oFld.aDynamicOptions = this.oPlayer.oCurrentWebModeCopy.collections;
								}
							}
                        }
                        switch(oFld.sType)
						{
                            case "select_to_string":
							{
								if(oFld.bParamSet==true)
								{
									oFld.SetValue({ sValue: oArgs.oOWT.params[i].value, bSuppressEvent: (oArgs.bSuppressEvent == true) });
								}
								break;
							}
							case "select_to_foreign_elem":
							{
								var sChildParamId;
								var aChildParamNames = [];
								var iCnt = 0;
								var sFldLabel;
								oFld.SetValue({ sValue: oArgs.oOWT.params[i].value, bSuppressEvent: (oArgs.bSuppressEvent == true) });
								if(oFld.bCollectionFld && !oFld.bCommonCollectionFld)
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										oSelectedCollection = null;
										if(this.oPlayer.oCurrentWebModeCopy.collections != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.collections.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.collections[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedCollection = this.oPlayer.oCurrentWebModeCopy.collections[j];
													break;
												}
											}
										}
										if(oSelectedCollection!=null)
										{
											this.UpdateCollectionChildren({ oFld: oFld, oCollection: oSelectedCollection });
											//this.UpdateMappingFlds({ oFld: oFld, oCollection: oSelectedCollection });
										}
										else
										{
											this.UpdateCollectionChildren({ oFld: oFld });
											//this.UpdateMappingFlds({ oFld: oFld });
										}
									}
									else
									{
										//this.UpdateMappingFlds({ oFld: oFld });
									}
								}
								else if(oFld.bActionFld)
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										oSelectedAction = null;
										if(this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedAction = this.oPlayer.oCurrentWebModeCopy.remote_actions[j];
													break;
												}
											}
										}
										if(oFld.oChildParamFlds != null)
										{
											for(sKey in oFld.oChildParamFlds)
											{
												if(oFld.oChildParamFlds.hasOwnProperty(sKey))
												{
													oFld.oChildParamFlds[sKey].Delete();
													delete oFld.oChildParamFlds[sKey];
												}
											}
										}
										oFld.oChildParamFlds = {};
										this.oActionParamsFolder.jBody.html("");
										if(oSelectedAction != null)
										{
											if(oSelectedAction.wvars != null)
											{
												for(k=0; k<oSelectedAction.wvars.length; k++)
												{
													if(oSelectedAction.wvars[k].silent==true)
													{
														continue;
													}
													aChildParamNames.push(oSelectedAction.wvars[k].name);
													sChildParamId = TOOLS.EncodeVarName({ sText: oSelectedAction.wvars[k].name });
													sFldLabel = (oSelectedAction.wvars[k].desc != null && oSelectedAction.wvars[k].desc != "") ? oSelectedAction.wvars[k].desc : oSelectedAction.wvars[k].name;
													oFld.oChildParamFlds[sChildParamId] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oSelectedAction.wvars[k], jBlock: this.oActionParamsFolder.jBody, sId: oSelectedAction.wvars[k].name, sLabel: sFldLabel, oParentFld: oFld });
													oFld.oChildParamFlds[sChildParamId].oParentFld = oFld;
													oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oSelectedAction.wvars[k].name } });
													oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oSelectedAction.wvars[k].name } });
												}
												for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
												{
													if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
													{
														oFld.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
														iCnt++;
														if(iCnt >= aChildParamNames.length)
														{
															break;
														}
													}
												}
											}
										}
									}
								}
								break;
							}
                            case "foreign_elem":
							{
								if(oFld.bCollectionFld && !oFld.bCommonCollectionFld)
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										oSelectedCollection = null;
										if(this.oPlayer.oCurrentWebModeCopy.collections != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.collections.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.collections[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedCollection = this.oPlayer.oCurrentWebModeCopy.collections[j];
													break;
												}
											}
										}
										if(oSelectedCollection!=null)
										{
											this.UpdateCollectionChildren({ oFld: oFld, oCollection: oSelectedCollection });
											//this.UpdateMappingFlds({ oFld: oFld, oCollection: oSelectedCollection });
										}
										else
										{
											this.UpdateCollectionChildren({ oFld: oFld });
											//this.UpdateMappingFlds({ oFld: oFld });
										}
									}
									else
									{
										//this.UpdateMappingFlds({ oFld: oFld });
									}
								}
								else if(oFld.bCommonCollectionFld)
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										var oSelectedCommonCollection = null;
										if(this.oPlayer.oCurrentWebModeCopy.collections != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.collections.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.collections[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedCommonCollection = this.oPlayer.oCurrentWebModeCopy.collections[j];
													break;
												}
											}
										}
										if(oSelectedCommonCollection==null && this.oPlayer.oCurrentWebModeCopy.common_collections != null)
										{
											oSelectedCommonCollection = this.oPlayer.oCurrentWebModeCopy.common_collections[oArgs.oOWT.params[i].value];
										}
										if(oSelectedCommonCollection==null)
										{ // load collection
											if(this.oPlayer.oCurrentWebModeCopy.common_collections==null)
											{
												this.oPlayer.oCurrentWebModeCopy.common_collections = {};
											}
											this.LoadCollection({ sCollectionId: oArgs.oOWT.params[i].value, oFld: oFld });
										}
										else
										{ // fill values
											this.UpdateCollectionChildren({ oFld: oFld, oCollection: oSelectedCommonCollection });
											//this.UpdateMappingFlds({ oFld: oFld, oCollection: oSelectedCommonCollection });
										}
									}
									else
									{
										this.UpdateCollectionChildren({ oFld: oFld });
										//this.UpdateMappingFlds({ oFld: oFld });
									}
								}
								else if(oFld.bActionFld && oFld.oParentFld._GetValue()=="object")
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										oSelectedAction = null;
										if(this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedAction = this.oPlayer.oCurrentWebModeCopy.remote_actions[j];
													break;
												}
											}
										}
										if(oSelectedAction!=null)
										{
											this.UpdateActionChildren({ oFld: oFld, oAction: oSelectedAction });
										}
										else
										{
											this.UpdateActionChildren({ oFld: oFld });
										}
									}
									else
									{
										this.UpdateActionChildren({ oFld: oFld });
									}
								}
								else if(oFld.bCommonActionFld && oFld.oParentFld._GetValue()=="common")
								{
									if(oArgs.oOWT.params[i].value != "")
									{
										oSelectedAction = null;
										if(this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
										{
											for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
											{
												if(this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id == oArgs.oOWT.params[i].value)
												{
													oSelectedAction = this.oPlayer.oCurrentWebModeCopy.remote_actions[j];
													break;
												}
											}
										}
										if(oSelectedAction==null && this.oPlayer.oCurrentWebModeCopy.common_actions != null)
										{
											oSelectedAction = this.oPlayer.oCurrentWebModeCopy.common_actions[oArgs.oOWT.params[i].value];
										}
										if(oSelectedAction==null)
										{ // load action
											if(this.oPlayer.oCurrentWebModeCopy.common_actions==null)
											{
												this.oPlayer.oCurrentWebModeCopy.common_actions = {};
											}
											this.LoadAction({ sActionId: oArgs.oOWT.params[i].value, oFld: oFld });
										}
										else
										{ // fill values
											this.UpdateActionChildren({ oFld: oFld, oAction: oSelectedAction });
										}
									}
									else
									{
										this.UpdateActionChildren({ oFld: oFld });
									}
								}
								if(oArgs.oOWT.params[i].title != null)
								{
									oFld.SetValue({ sValue: oArgs.oOWT.params[i].value, sName: oArgs.oOWT.params[i].title, bSuppressEvent: (oArgs.bSuppressEvent == true) });
								}
								else
								{
									oFld.SetValue({ sValue: oArgs.oOWT.params[i].value, bSuppressEvent: (oArgs.bSuppressEvent == true) });
								}
								break;
							}
                            case "folder":
							{
								break;
							}
                            default:
							{
								oFld.SetValue({ sValue: oArgs.oOWT.params[i].value, bSuppressEvent: (oArgs.bSuppressEvent == true) });
								break;
							}
                        }
                    }
                }
            }
            this.jRulesList.html("").hide();
            this.jNoRules.show();
            this.aRules = [];
            if(this.oPlayer.oCurrentWebModeCopy.template_links != null)
			{
                var bHasRules = false;
                var iIdx = 0;
                var iIdx2 = 0;
                for(i=0; i<this.oPlayer.oCurrentWebModeCopy.template_links.length; i++)
				{
                    if(this.oPlayer.oCurrentWebModeCopy.template_links[i].target_template_id == oArgs.oOWT.override_template_id)
					{
                        this.aRules.push(new CXRule({ oPlayer: this.oPlayer, oParent: this, iIdx: iIdx, jContainer: this.jRulesList, oRule: this.oPlayer.oCurrentWebModeCopy.template_links[i] }));
                        bHasRules = true;
                        iIdx++;
                    }
                }
                if(bHasRules)
				{
                    this.jRulesList.show();
                    this.jNoRules.hide();
                }
            }
            this.oDialog.oPage.oEditor.bStateLocked = false;
        }
		else if(oArgs.bParentSwitched == true)
		{
            if(oArgs.oFld._GetValue() == true)
			{
                for(j=0; j<oArgs.oFld.aChildren.length; j++)
				{
                    this.oFlds[oArgs.oFld.aChildren[j]].Show({ bTransition: true });
                }
            }
			else
			{
                for(j=0; j<oArgs.oFld.aChildren.length; j++)
				{
                    this.oFlds[oArgs.oFld.aChildren[j]].Hide({ bTransition: true });
                }
            }
        }
        else if(oArgs.bRuleAdded==true)
		{
			for(i=0; i<this.aRules.length; i++)
			{
				if(this.aRules[i].oRule.id==oArgs.sRuleId)
				{
					oArgs.oSrc = this.aRules[i];
					break;
				}
			}
			this.oDialog.oPage.oBuilders["rule"].Update(oArgs).Show();
		}
		return this;
    };
    CXDialogPage.prototype.UpdateAllDynamic = function(oArgs)
	{
		var sPart = "";
		for(var sKey in this.oFlds)
		{
			if(sPart=="")
			{
				if(sKey.indexOf("%46")!=-1)
				{
					sPart = sKey.split("%46")[0];
				}
			}
			if((this.oFlds[sKey].bCollectionFld && this.oFlds[sPart + "%46collection_type"]._GetValue=="object") || (this.oFlds[sKey].bCommonCollectionFld && this.oFlds[sPart + "%46collection_type"]._GetValue=="common") || (this.oFlds[sKey].bActionFld && this.oFlds[sKey].oParentFld._GetValue()=="object") || (this.oFlds[sKey].bCommonActionFld && this.oFlds[sKey].oParentFld._GetValue()=="common"))
			{
				this.UpdateDynamic({ oThis: this.oFlds[sKey], bFldModified: true, oContext: this });
			}
/*			if((this.oFlds[sKey].bCollectionFld && this.oFlds[sKey].oParentFld._GetValue()=="object") || (this.oFlds[sKey].bCommonCollectionFld && this.oFlds[sKey].oParentFld._GetValue()=="common") || (this.oFlds[sKey].bActionFld && this.oFlds[sKey].oParentFld._GetValue()=="object") || (this.oFlds[sKey].bCommonActionFld && this.oFlds[sKey].oParentFld._GetValue()=="common"))
			{
				this.UpdateDynamic({ oThis: this.oFlds[sKey], bFldModified: true, oContext: this });
			}*/
		}
        return this;
    };
    CXDialogPage.prototype.UpdateActionChildren = function(oArgs)
	{
		function _RemoveParam(oA)
		{
			for(var i=0; i<oA.oOWT.params.length; i++)
			{
				if(oA.sParam==oA.oOWT.params[i].name && oA.sParent==oA.oOWT.params[i].parent_wvar_name)
				{
					oA.oOWT.params.splice(i,1);
					break;
				}
			}
			return true;
		}
		function _AppendParam(oA)
		{
			var bExists = false;
			for(var i=0; i<oA.oOWT.params.length; i++)
			{
				if(oA.oFld.sId==oA.oOWT.params[i].name && oA.oFld.oParentFld.sId==oA.oOWT.params[i].parent_wvar_name)
				{
					bExists = true;
					break;
				}
			}
			if(!bExists)
			{
				oA.oOWT.params.push(
				{
				   name: oA.oFld.sId,
				   value: oA.oFld._GetValue({ bString: true }),
				   type: oA.oFld.sType,
				   parent_wvar_name: oA.oFld.oParentFld.sId,
				   position: oA.iPosition
				});
			}
			return true;
		}
        var k;
		var sChildParamId;
		var aChildParamNames = [];
		var iCnt = 0;
		var sFldLabel;
		var oFolder = this.oActionParamsFolder;
		oFolder.jBody.html("");
		var aToDelete = [];
		if(oArgs.oFld.oChildParamFlds != null)
		{
			for(var sKey in oArgs.oFld.oChildParamFlds)
			{
				if(oArgs.oFld.oChildParamFlds.hasOwnProperty(sKey))
				{
					oArgs.oFld.oChildParamFlds[sKey].Delete();
					delete oArgs.oFld.oChildParamFlds[sKey];
					aToDelete.push(sKey);
				}
			}
		}
		oArgs.oFld.oChildParamFlds = {};
		if(oArgs.oAction!=null)
		{
			if(oArgs.oAction.wvars != null)
			{
				var aActualParams = [];
				for(k=0; k<oArgs.oAction.wvars.length; k++)
				{
					if(oArgs.oAction.wvars[k].silent==true)
					{
						continue;
					}
					aActualParams.push(oArgs.oAction.wvars[k].name);
				}
				for(k=0; k<aToDelete.length; k++) //remove params from previously selected collection
				{
					if($.inArray(aToDelete[k], aActualParams)==-1)
					{
						_RemoveParam({ oOWT: this.oDialog.oCurrentOWT, sParam: aToDelete[k], sParent: oArgs.oFld.sId });
					}
				}
				for(k=0; k<oArgs.oAction.wvars.length; k++)
				{
					if(oArgs.oAction.wvars[k].silent==true)
					{
						continue;
					}
					aChildParamNames.push(oArgs.oAction.wvars[k].name);
					sChildParamId = TOOLS.EncodeVarName({ sText: oArgs.oAction.wvars[k].name });
					sFldLabel = (oArgs.oAction.wvars[k].desc != null && oArgs.oAction.wvars[k].desc != "") ? oArgs.oAction.wvars[k].desc : oArgs.oAction.wvars[k].name;
					oArgs.oFld.oChildParamFlds[sChildParamId] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oArgs.oAction.wvars[k], jBlock: oFolder.jBody, sId: oArgs.oAction.wvars[k].name, sLabel: sFldLabel, oParentFld: oArgs.oFld });
					oArgs.oFld.oChildParamFlds[sChildParamId].oParentFld = oArgs.oFld;
					_AppendParam({ oOWT: this.oDialog.oCurrentOWT, oFld: oArgs.oFld.oChildParamFlds[sChildParamId], iPosition: (k+1) });
					oArgs.oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oArgs.oAction.wvars[k].name } });
					oArgs.oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oArgs.oAction.wvars[k].name } });
				}
				// if we have values - set value
				for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
				{
					if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
					{
						oArgs.oFld.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
						iCnt++;
						if(iCnt >= aChildParamNames.length)
						{
							break;
						}
					}
				}
			}
		}
		return this;
    };
	CXDialogPage.prototype.UpdateActionParams = function(oArgs)
	{
		var oThis = this;
		var i;
		var sKey;
		var sErrorMsg;
		var sVarNameEncoded;
		var oActionFld;
		var jOptions;
		if(oArgs.bAfterSave==true)
		{
			if(oArgs.oData==null)
			{
				alert("ERROR obtaining action data");
			}
			else
			{
				if(oArgs.oData.error!=0)
				{
					sErrorMsg = "ERROR obtaining action. ";
					if(oArgs.oData.error_text!=null && oArgs.oData.error_text!="")
					{
						sErrorMsg += oArgs.oData.error_text;
					}
					alert(sErrorMsg);
				}
				else
				{
					if(oArgs.oData.action==null)
					{
						alert("ERROR server response has no action data");
					}
					else
					{
						sVarNameEncoded = TOOLS.EncodeVarName({ sText: oArgs.oFld.sId });
						oActionFld = oArgs.oContext.oFlds[sVarNameEncoded];
						if(oActionFld==null)
						{
							alert("ERROR getting action field");
						}
						else
						{
							if(this.oPlayer.oCurrentWebModeCopy.common_actions==null)
							{
								this.oPlayer.oCurrentWebModeCopy.common_actions = {};
							}
							if(this.oPlayer.oCurrentWebModeCopy.common_actions[oArgs.oData.action.id]==null)
							{
								this.oPlayer.oCurrentWebModeCopy.common_actions[oArgs.oData.action.id] = JSON.parse(JSON.stringify(oArgs.oData.action));
							}
							this.UpdateActionChildren({ oFld: oActionFld, oAction: this.oPlayer.oCurrentWebModeCopy.common_actions[oArgs.oData.action.id] });
						}
					}
				}
			}
		}
		else
		{
			var sActionId = oArgs.oThis._GetValue();
			if(sActionId=="")
			{
				// clear all
			}
			else
			{ // request collection params
				var oToSend =
				{
					action: "get_action",
					object_id: sActionId
				};
				this.Load(
				{
					sURL: this.oPlayer.oConfig.sRootAPIURL,
					sData: "action=" + encodeURIComponent(JSON.stringify(oToSend)),
					oContext: this,
					fnSuccess: this.UpdateActionParams,
					oSuccessArgs: { bAfterSave: true, oFld: oArgs.oThis, oContext: oArgs.oContext }
				});
			}
        }
        return this;
    };
    CXDialogPage.prototype.UpdateCollection = function(oArgs)
	{
		this.Warning();
		this.oCommonCollectionParamsFolder.jFolder.removeAttr("cx-hide");
		this.oCollectionParamsFolder.jFolder.removeAttr("cx-hide");
		if(this.oMappingFolder!=null)
		{
			this.oMappingFolder.jFolder.removeAttr("cx-hide");
		}
		if(this.oCommonMappingFolder!=null)
		{
			this.oCommonMappingFolder.jFolder.removeAttr("cx-hide");
		}
		var sTName = oArgs.oThis.sId.split(".")[0];
		var sValue = oArgs.oThis._GetValue();
		var sCollectionId;
		if(sValue=="common")
		{
			sCollectionId = this.oFlds[sTName + "%46collection_common"]._GetValue();
			if(sCollectionId!="")
			{
				if(this.oPlayer.oCurrentWebModeCopy.common_collections!=null)
				{
					this.Warning();
					if(this.oPlayer.oCurrentWebModeCopy.common_collections[sCollectionId]!=null)
					{
						if(this.oPlayer.oCurrentWebModeCopy.common_collections[sCollectionId].result_fields==null || this.oPlayer.oCurrentWebModeCopy.common_collections[sCollectionId].result_fields.length==0)
						{
							this.oCommonCollectionParamsFolder.jFolder.attr({ "cx-hide": "1" });
							if(this.oCommonMappingFolder!=null)
							{
								this.oCommonMappingFolder.jFolder.attr({ "cx-hide": "1" });
							}
							this.Warning({ sType: "no-result", jBefore: this.oCommonCollectionParamsFolder.jFolder });
						}
						else
						{
							this.oCommonCollectionParamsFolder.jFolder.removeAttr("cx-hide");
							if(this.oCommonMappingFolder!=null)
							{
								this.oCommonMappingFolder.jFolder.removeAttr("cx-hide");
							}
						}
					}
					else
					{
						this.oCommonCollectionParamsFolder.jFolder.attr({ "cx-hide": "1" });
						if(this.oCommonMappingFolder!=null)
						{
							this.oCommonMappingFolder.jFolder.attr({ "cx-hide": "1" });
						}
						this.Warning({ sType: "not-ready", jBefore: this.oCommonCollectionParamsFolder.jFolder });
					}
				}
			}
		}
		else if(sValue=="object")
		{
			sCollectionId = this.oFlds[sTName + "%46__collection__"]._GetValue();
			if(sCollectionId!="")
			{
				if(this.oPlayer.oCurrentWebModeCopy.collections!=null)
				{
					var oSelectedCollection = null;
					for(var i=0; i<this.oPlayer.oCurrentWebModeCopy.collections.length; i++)
					{
						if(this.oPlayer.oCurrentWebModeCopy.collections[i].id==sCollectionId)
						{
							oSelectedCollection = this.oPlayer.oCurrentWebModeCopy.collections[i];
							break;
						}
					}
					this.Warning();
					if(oSelectedCollection!=null)
					{
						if(oSelectedCollection.result_fields==null || oSelectedCollection.result_fields.length==0)
						{
							this.oCollectionParamsFolder.jFolder.attr({ "cx-hide": "1" });
							if(this.oMappingFolder!=null)
							{
								this.oMappingFolder.jFolder.attr({ "cx-hide": "1" });
							}
							this.Warning({ sType: "no-result", jBefore: this.oCollectionParamsFolder.jFolder });
						}
						else
						{
							this.oCollectionParamsFolder.jFolder.removeAttr("cx-hide");
							if(this.oMappingFolder!=null)
							{
								this.oMappingFolder.jFolder.removeAttr("cx-hide");
							}
						}
					}
					else
					{
						this.oCollectionParamsFolder.jFolder.attr({ "cx-hide": "1" });
						if(this.oMappingFolder!=null)
						{
							this.oMappingFolder.jFolder.attr({ "cx-hide": "1" });
						}
						this.Warning({ sType: "not-ready", jBefore: this.oCollectionParamsFolder.jFolder });
					}
				}
			}
		}
		return this;
    };
    CXDialogPage.prototype.UpdateCollectionChildren = function(oArgs)
	{
		function _RemoveParam(oA)
		{
			for(var i=0; i<oA.oOWT.params.length; i++)
			{
				if(oA.sParam==oA.oOWT.params[i].name && oA.sParent==oA.oOWT.params[i].parent_wvar_name)
				{
					oA.oOWT.params.splice(i,1);
					break;
				}
			}
			return true;
		}
		function _AppendParam(oA)
		{
			var bExists = false;
			for(var i=0; i<oA.oOWT.params.length; i++)
			{
				if(oA.oFld.sId==oA.oOWT.params[i].name && oA.oFld.oParentFld.sId==oA.oOWT.params[i].parent_wvar_name)
				{
					bExists = true;
					break;
				}
			}
			if(!bExists)
			{
				oA.oOWT.params.push(
				{
				   name: oA.oFld.sId,
				   value: oA.oFld._GetValue({ bString: true }),
				   type: oA.oFld.sType,
				   parent_wvar_name: oA.oFld.oParentFld.sId,
				   position: oA.iPosition
				});
			}
			return true;
		}
        var k;
		var sChildParamId;
		var aChildParamNames = [];
		var iCnt = 0;
		var sFldLabel;
		var oFolder = (oArgs.oFld.bCommonCollectionFld ? this.oCommonCollectionParamsFolder : this.oCollectionParamsFolder);
		oFolder.jBody.html("");
		var aToDelete = [];
		if(oArgs.oFld.oChildParamFlds != null)
		{
			for(var sKey in oArgs.oFld.oChildParamFlds)
			{
				if(oArgs.oFld.oChildParamFlds.hasOwnProperty(sKey))
				{
					oArgs.oFld.oChildParamFlds[sKey].Delete();
					delete oArgs.oFld.oChildParamFlds[sKey];
					aToDelete.push(sKey);
				}
			}
		}
		oArgs.oFld.oChildParamFlds = {};
		if(oArgs.oCollection!=null)
		{
			if(oArgs.oCollection.wvars != null)
			{
				var aActualParams = [];
				for(k=0; k<oArgs.oCollection.wvars.length; k++)
				{
					if(oArgs.oCollection.wvars[k].silent==true)
					{
						continue;
					}
					aActualParams.push(oArgs.oCollection.wvars[k].name);
				}
				for(k=0; k<aToDelete.length; k++) //remove params from previously selected collection
				{
					if($.inArray(aToDelete[k], aActualParams)==-1)
					{
						_RemoveParam({ oOWT: this.oDialog.oCurrentOWT, sParam: aToDelete[k], sParent: oArgs.oFld.sId });
					}
				}
				for(k=0; k<oArgs.oCollection.wvars.length; k++)
				{
					if(oArgs.oCollection.wvars[k].silent==true)
					{
						continue;
					}
					aChildParamNames.push(oArgs.oCollection.wvars[k].name);
					sChildParamId = TOOLS.EncodeVarName({ sText: oArgs.oCollection.wvars[k].name });
					sFldLabel = (oArgs.oCollection.wvars[k].desc != null && oArgs.oCollection.wvars[k].desc != "") ? oArgs.oCollection.wvars[k].desc : oArgs.oCollection.wvars[k].name;
					oArgs.oFld.oChildParamFlds[sChildParamId] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oArgs.oCollection.wvars[k], jBlock: oFolder.jBody, sId: oArgs.oCollection.wvars[k].name, sLabel: sFldLabel, oParentFld: oArgs.oFld });
					oArgs.oFld.oChildParamFlds[sChildParamId].oParentFld = oArgs.oFld;
					_AppendParam({ oOWT: this.oDialog.oCurrentOWT, oFld: oArgs.oFld.oChildParamFlds[sChildParamId], iPosition: (k+1) });
					oArgs.oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oArgs.oCollection.wvars[k].name } });
					oArgs.oFld.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oArgs.oCollection.wvars[k].name } });
				}
				// if we have values - set value
				for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
				{
					if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
					{
						oArgs.oFld.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
						iCnt++;
						if(iCnt >= aChildParamNames.length)
						{
							break;
						}
					}
				}
			}
		}
        return this;
    };
    CXDialogPage.prototype.UpdateCollectionParams = function(oArgs)
	{
		var oThis = this;
		var i;
		var sKey;
		var sErrorMsg;
		var sVarNameEncoded;
		var oCollectionFld;
		var jOptions;
		if(oArgs.bAfterSave==true)
		{
			if(oArgs.oData==null)
			{
				alert("ERROR obtaining collection data");
			}
			else
			{
				if(oArgs.oData.error!=0)
				{
					sErrorMsg = "ERROR obtaining collection. ";
					if(oArgs.oData.error_text!=null && oArgs.oData.error_text!="")
					{
						sErrorMsg += oArgs.oData.error_text;
					}
					alert(sErrorMsg);
				}
				else
				{
					if(oArgs.oData.collection==null)
					{
						alert("ERROR server response has no collection data");
					}
					else
					{
						sVarNameEncoded = TOOLS.EncodeVarName({ sText: oArgs.oFld.sId });
						oCollectionFld = oArgs.oContext.oFlds[sVarNameEncoded];
						if(oCollectionFld==null)
						{
							alert("ERROR getting collection field");
						}
						else
						{
							if(this.oPlayer.oCurrentWebModeCopy.common_collections==null)
							{
								this.oPlayer.oCurrentWebModeCopy.common_collections = {};
							}
							if(this.oPlayer.oCurrentWebModeCopy.common_collections[oArgs.oData.collection.id]==null)
							{
								this.oPlayer.oCurrentWebModeCopy.common_collections[oArgs.oData.collection.id] = JSON.parse(JSON.stringify(oArgs.oData.collection));
							}
							this.UpdateCollectionChildren({ oFld: oCollectionFld, oCollection: this.oPlayer.oCurrentWebModeCopy.common_collections[oArgs.oData.collection.id] });
							//this.UpdateMappingFlds({ oFld: oCollectionFld, oCollection: this.oPlayer.oCurrentWebModeCopy.common_collections[oArgs.oData.collection.id] });
						}
					}
				}
			}
		}
		else
		{
			var sCollectionId = oArgs.oThis._GetValue();
			if(sCollectionId=="")
			{
				// clear all
			}
			else
			{ // request collection params
				var oToSend =
				{
					action: "get_collection",
					object_id: sCollectionId
				};
				this.Load(
				{
					sURL: this.oPlayer.oConfig.sRootAPIURL,
					sData: "action=" + encodeURIComponent(JSON.stringify(oToSend)),
					oContext: this,
					fnSuccess: this.UpdateCollectionParams,
					oSuccessArgs: { bAfterSave: true, oFld: oArgs.oThis, oContext: oArgs.oContext }
				});
			}
		}
        return this;
    };
	CXDialogPage.prototype.UpdateColumns = function(oArgs)
	{
        if(this.oPlayer.aLoading.length == 0)
		{
            this.oDialog.oPage.oEditor.UpdateColumns(oArgs);
        }
        return this;
    };
    CXDialogPage.prototype.UpdateDynamic = function(oArgs)
	{
		if(oArgs.bFldModified == true)
		{
			var j, k, m;
			var sKey;
			var sChildParamId;
			var aChildParamNames = [];
			var iCnt = 0;
			var sFldLabel;
			var oSelectedAction = null;
			var oSelectedCollection = null;
			var aMappingFlds = [];
            var sNewValue = oArgs.oThis._GetValue();
			var oChildObject = { sId: sNewValue, aParams: [] };
			var sParamFldName = oArgs.oThis.sId.split(".")[0] + ".";
			var sEncodedParamFldName;
			var oParamFld, oActionItemParams;
			var bChildParamFldFound = false;
            if(oArgs.oThis.bDynamicFill && oArgs.oThis.sType == "foreign_elem")
			{
                if(oArgs.oThis.bActionItemFld)
				{
					oActionItemParams = {};
					oParamFld = oArgs.oThis.oParentItem.oFlds["__remote_action_item_params__"];
					if(this.oPlayer.oCurrentWebModeCopy.all_actions != null)
					{
						for(j=0; j<this.oPlayer.oCurrentWebModeCopy.all_actions.length; j++)
						{
							if(this.oPlayer.oCurrentWebModeCopy.all_actions[j].id==sNewValue)
							{
								oSelectedAction = this.oPlayer.oCurrentWebModeCopy.all_actions[j];
								break;
							}
						}
					}
					if(oSelectedAction!=null)
					{
						if(oSelectedAction.wvars != null)
						{
							for(j=0; j<oSelectedAction.wvars.length; j++)
							{
								if(oSelectedAction.wvars[j].silent==true)
								{
									continue;
								}
								oActionItemParams[ TOOLS.EncodeVarName({ sText: oSelectedAction.wvars[j].name }) ] = { name: oSelectedAction.wvars[j].name, type: oSelectedAction.wvars[j].type, value: oSelectedAction.wvars[j].value };
							}
						}
					}
					oParamFld.SetValue({ sValue: JSON.stringify(oActionItemParams) });
				}
				else
				{
					if(oArgs.oThis.oChildParamFlds != null) // delete existing children
					{
						for(sKey in oArgs.oThis.oChildParamFlds)
						{
							if(oArgs.oThis.oChildParamFlds.hasOwnProperty(sKey))
							{
								oArgs.oThis.oChildParamFlds[sKey].Delete();
								delete oArgs.oThis.oChildParamFlds[sKey];
							}
						}
					}
					oArgs.oThis.oChildParamFlds = {};
					if(oArgs.oThis.bCollectionFld)
					{
						this.oCollectionParamsFolder.jBody.html("");
						for(sKey in this.oFlds)
						{
							if(this.oFlds[sKey].bMappingFld == true)
							{
								aMappingFlds.push(this.oFlds[sKey]);
							}
						}
						for(j=0; j<aMappingFlds.length; j++)
						{
							if(aMappingFlds[j].bMappingFldValue)
							{
								aMappingFlds[j].SetValue({ sValue: "", bSuppressEvent: true });
							}
							else
							{
								aMappingFlds[j].jControl.find("option[value!=''][value!='__substitution__']").remove();
							}
						}
						if(sNewValue != "")
						{
							if(!oArgs.oThis.bCommonCollectionFld)
							{
								sParamFldName += "__service__collection_params";
								if(this.oPlayer.oCurrentWebModeCopy.collections != null)
								{
									for(j=0; j<this.oPlayer.oCurrentWebModeCopy.collections.length; j++)
									{
										if(this.oPlayer.oCurrentWebModeCopy.collections[j].id == sNewValue)
										{
											oSelectedCollection = this.oPlayer.oCurrentWebModeCopy.collections[j];
										}
									}
								}
							}
							else if(oArgs.oThis.bCommonCollectionFld)
							{
								sParamFldName += "__service__common_collection_params";
								if(this.oPlayer.oCurrentWebModeCopy.all_collections != null)
								{
									for(j=0; j<this.oPlayer.oCurrentWebModeCopy.all_collections.length; j++)
									{
										if(this.oPlayer.oCurrentWebModeCopy.all_collections[j].id == sNewValue)
										{
											oSelectedCollection = this.oPlayer.oCurrentWebModeCopy.all_collections[j];
										}
									}
								}
							}
							if(oSelectedCollection != null)
							{
								if(oSelectedCollection.wvars != null)
								{
									sEncodedParamFldName = TOOLS.EncodeVarName({ sText: sParamFldName });
									oParamFld = oArgs.oContext.oFlds[sEncodedParamFldName];
									bChildParamFldFound = (oParamFld!=null);
									aChildParamNames = [];
									for(k=0; k<oSelectedCollection.wvars.length; k++)
									{
										if(oSelectedCollection.wvars[k].silent==true)
										{
											continue;
										}
										oChildObject.aParams.push({ name: oSelectedCollection.wvars[k].name, value: oSelectedCollection.wvars[k].value });
										aChildParamNames.push(oSelectedCollection.wvars[k].name);
										sChildParamId = TOOLS.EncodeVarName({ sText: oSelectedCollection.wvars[k].name });
										sFldLabel = (oSelectedCollection.wvars[k].desc != null && oSelectedCollection.wvars[k].desc != "") ? oSelectedCollection.wvars[k].desc : oSelectedCollection.wvars[k].name;
										oArgs.oThis.oChildParamFlds[sChildParamId] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oSelectedCollection.wvars[k], jBlock: this.oCollectionParamsFolder.jBody, sId: oSelectedCollection.wvars[k].name, sLabel: sFldLabel, oParentFld: oArgs.oThis });
										oArgs.oThis.oChildParamFlds[sChildParamId].bIsDynamicParam = true;
										if(bChildParamFldFound)
										{
											oArgs.oThis.oChildParamFlds[sChildParamId].oParamFld = oParamFld;
											oArgs.oThis.oChildParamFlds[sChildParamId].oParentDynamic = oArgs.oThis;
										}
										oArgs.oThis.oChildParamFlds[sChildParamId].oParentFld = this.oCollectionParamsFolder;
										oArgs.oThis.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oSelectedCollection.wvars[k].name } });
										oArgs.oThis.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oSelectedCollection.wvars[k].name } });
									}
									if(bChildParamFldFound)
									{
										var sParamFldValue = oParamFld._GetValue();
										if(sParamFldValue!="")
										{
											var oParamFromFld = { sId: "x" };
											try	{ oParamFromFld = JSON.parse(sParamFldValue); }	catch(e) {}
											if(oParamFromFld.sId==sNewValue) // ok, params for selected action
											{
												for(k=0; k<oParamFromFld.aParams.length; k++)
												{
													oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: oParamFromFld.aParams[k].name })].SetValue({ sValue: oParamFromFld.aParams[k].value, bSuppressEvent: true });
												}
												oChildObject = JSON.parse(JSON.stringify(oParamFromFld));
											}
											else if(oParamFromFld.sId=="x") // write values from flds or defaults
											{
												iCnt = 0;
												for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
												{
													if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
													{
														oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
														for(m=0; m<oChildObject.aParams.length; m++)
														{
															if(oChildObject.aParams[m].name==this.oDialog.oCurrentOWT.params[k].name)
															{
																oChildObject.aParams[m].value = this.oDialog.oCurrentOWT.params[k].value;
																break;
															}
														}
														iCnt++;
														if(iCnt >= aChildParamNames.length)
														{
															break;
														}
													}
												}
											}
											/*else if(oParamFromFld.sId!="") // write defaults, no action required */
											oParamFld.SetValue({ sValue: JSON.stringify(oChildObject), bSuppressEvent: true });
										}
										else
										{
											// fill from old child params
											iCnt = 0;
											for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
											{
												if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
												{
													oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
													for(m=0; m<oChildObject.aParams.length; m++)
													{
														if(oChildObject.aParams[m].name==this.oDialog.oCurrentOWT.params[k].name)
														{
															oChildObject.aParams[m].value = this.oDialog.oCurrentOWT.params[k].value;
															break;
														}
													}
													iCnt++;
													if(iCnt >= aChildParamNames.length)
													{
														break;
													}
												}
											}
											oParamFld.SetValue({ sValue: JSON.stringify(oChildObject), bSuppressEvent: true });
										}
									}
									else
									{
										// widget still uses old tech, no param fld
										iCnt = 0;
										for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
										{
											if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
											{
												oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
												iCnt++;
												if(iCnt >= aChildParamNames.length)
												{
													break;
												}
											}
										}
									}
								}
								if(oSelectedCollection.result_fields != null)
								{
									for(j=0; j<aMappingFlds.length; j++)
									{
										for(k=0; k<oSelectedCollection.result_fields.length; k++)
										{
											aMappingFlds[j].jControl.append('<option value="' + oSelectedCollection.result_fields[k].name + '">' + oSelectedCollection.result_fields[k].title + '</option>');
										}
									}
								}
							}
						}
						var oParam;
						var sMapValue;
						for(j=0; j<aMappingFlds.length; j++)
						{
							oParam = this.oDialog._GetParamByName({ oOWT: this.oDialog.oCurrentOWT, sFldName: aMappingFlds[j].sId });
							if(oParam!=null)
							{
								sMapValue = oParam.value;
								if(sMapValue!=null)
								{
									aMappingFlds[j].SetValue({ sValue: oParam.value, bSuppressEvent: true });
								}
							}
							if(aMappingFlds[j].bMappingFldValue)
							{
								continue;
							}
						   // aMappingFlds[j].jControl.selectmenu("refresh");
						}

					}
					else if(oArgs.oThis.bActionFld || oArgs.oThis.bCommonActionFld)
					{
						this.oActionParamsFolder.jBody.html("");
						if(sNewValue != "")
						{
							if(oArgs.oThis.bActionFld && oArgs.oThis.oParentFld._GetValue()=="object")
							{
								sParamFldName += "__service__remote_action_params";
								if(this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
								{
									for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
									{
										if(this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id == sNewValue)
										{
											oSelectedAction = this.oPlayer.oCurrentWebModeCopy.remote_actions[j];
											break;
										}
									}
								}
							}
							if(oArgs.oThis.bCommonActionFld && oArgs.oThis.oParentFld._GetValue()=="common")
							{
								sParamFldName += "__service__common_remote_action_params";
								if(this.oPlayer.oCurrentWebModeCopy.remote_actions != null)
								{
									for(j=0; j<this.oPlayer.oCurrentWebModeCopy.remote_actions.length; j++)
									{
										if(this.oPlayer.oCurrentWebModeCopy.remote_actions[j].id == sNewValue)
										{
											oSelectedAction = this.oPlayer.oCurrentWebModeCopy.remote_actions[j];
											break;
										}
									}
								}
								if(oSelectedAction==null && this.oPlayer.oCurrentWebModeCopy.all_actions != null)
								{
									if(this.oPlayer.oCurrentWebModeCopy.all_actions[sNewValue]!=null)
									{
										oSelectedAction = this.oPlayer.oCurrentWebModeCopy.all_actions[sNewValue];
									}
								}
							}
							if(oSelectedAction==null)
							{
								this.UpdateActionParams(oArgs);
							}
							else
							{
								if(oSelectedAction.wvars != null)
								{
									sEncodedParamFldName = TOOLS.EncodeVarName({ sText: sParamFldName });
									oParamFld = oArgs.oContext.oFlds[sEncodedParamFldName];
									bChildParamFldFound = (oParamFld!=null);
									aChildParamNames = [];
									for(k=0; k<oSelectedAction.wvars.length; k++)
									{
										if(oSelectedAction.wvars[k].silent==true)
										{
											continue;
										}
										oChildObject.aParams.push({ name: oSelectedAction.wvars[k].name, value: oSelectedAction.wvars[k].value });
										aChildParamNames.push(oSelectedAction.wvars[k].name);
										sChildParamId = TOOLS.EncodeVarName({ sText: oSelectedAction.wvars[k].name });
										sFldLabel = (oSelectedAction.wvars[k].desc != null && oSelectedAction.wvars[k].desc != "") ? oSelectedAction.wvars[k].desc : oSelectedAction.wvars[k].name;
										oArgs.oThis.oChildParamFlds[sChildParamId] = new CXFld({ oPlayer: this.oPlayer, oDialog: this.oDialog, oPage: this, oFld: oSelectedAction.wvars[k], jBlock: this.oActionParamsFolder.jBody, sId: oSelectedAction.wvars[k].name, sLabel: oSelectedAction.wvars[k].name, oParentFld: oArgs.oThis });
										oArgs.oThis.oChildParamFlds[sChildParamId].bIsDynamicParam = true;
										if(bChildParamFldFound)
										{
											oArgs.oThis.oChildParamFlds[sChildParamId].oParamFld = oParamFld;
											oArgs.oThis.oChildParamFlds[sChildParamId].oParentDynamic = oArgs.oThis;
										}
										oArgs.oThis.oChildParamFlds[sChildParamId].SetValue({ sValue: oSelectedAction.wvars[k].value, bSuppressEvent: true });
										oArgs.oThis.oChildParamFlds[sChildParamId].oParentFld = this.oActionParamsFolder;
										oArgs.oThis.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this.oDialog, fn: this.oDialog.Update, oArgs: { bFldModified: true, sFldName: oSelectedAction.wvars[k].name } });
										oArgs.oThis.oChildParamFlds[sChildParamId].Subscribe({ sEvent: "modified", bOnce: false, sSubscriberId: TOOLS.GUID(), oContext: this, fn: this.UpdateModified, oArgs: { sFldName: oSelectedAction.wvars[k].name } });
									}
									iCnt = 0;
									if(bChildParamFldFound)
									{
										var sParamFldValue = oParamFld._GetValue();
										if(sParamFldValue!="")
										{
											var oParamFromFld = { sId: "x" };
											try	{ oParamFromFld = JSON.parse(sParamFldValue); }	catch(e) {}
											if(oParamFromFld.sId==sNewValue) // ok, params for selected action
											{
												for(k=0; k<oParamFromFld.aParams.length; k++)
												{
													oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: oParamFromFld.aParams[k].name })].SetValue({ sValue: oParamFromFld.aParams[k].value, bSuppressEvent: true });
												}
												oChildObject = JSON.parse(JSON.stringify(oParamFromFld));
											}
											else if(oParamFromFld.sId=="x") // write values from flds or defaults
											{
												iCnt = 0;
												for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
												{
													if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
													{
														oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
														for(m=0; m<oChildObject.aParams.length; m++)
														{
															if(oChildObject.aParams[m].name==this.oDialog.oCurrentOWT.params[k].name)
															{
																oChildObject.aParams[m].value = this.oDialog.oCurrentOWT.params[k].value;
																break;
															}
														}
														iCnt++;
														if(iCnt >= aChildParamNames.length)
														{
															break;
														}
													}
												}
											}
											/*else if(oParamFromFld.sId!="") // write defaults, no action required */
											oParamFld.SetValue({ sValue: JSON.stringify(oChildObject), bSuppressEvent: true });
										}
										else
										{
											// fill from old child params
											iCnt = 0;
											for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
											{
												if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
												{
													oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
													for(m=0; m<oChildObject.aParams.length; m++)
													{
														if(oChildObject.aParams[m].name==this.oDialog.oCurrentOWT.params[k].name)
														{
															oChildObject.aParams[m].value = this.oDialog.oCurrentOWT.params[k].value;
															break;
														}
													}
													iCnt++;
													if(iCnt >= aChildParamNames.length)
													{
														break;
													}
												}
											}
											oParamFld.SetValue({ sValue: JSON.stringify(oChildObject), bSuppressEvent: true });
										}
									}
									else
									{
										// widget still uses old tech, no param fld
										iCnt = 0;
										for(k = this.oDialog.oCurrentOWT.params.length - 1; k >= 0; k--)
										{
											if($.inArray(this.oDialog.oCurrentOWT.params[k].name, aChildParamNames) != -1)
											{
												oArgs.oThis.oChildParamFlds[TOOLS.EncodeVarName({ sText: this.oDialog.oCurrentOWT.params[k].name })].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value });
												iCnt++;
												if(iCnt >= aChildParamNames.length)
												{
													break;
												}
											}
										}
									}
								}
							}
						}
						else
						{
							// cleanup param fld?
						}
					}
				}
			}
        }
        return this;
    };
    CXDialogPage.prototype.UpdateMapping = function(oArgs)
	{
        if(oArgs.bFldModified == true)
		{
            if(oArgs.oThis.bDynamicFill && oArgs.oThis.sType == "select_to_string") {}
        }
        return this;
    };
    CXDialogPage.prototype.UpdateMappingFld = function(oArgs)
	{
        if(!oArgs.oFld.bMappingFldValue)
		{
			oArgs.oFld.jControl.find("option[value!=''][value!='__substitution__']").remove();
			if(oArgs.oCollection!=null)
			{
				for(var i=0; i<oArgs.oCollection.result_fields.length; i++)
				{
					oArgs.oFld.jControl.append('<option value="' + oArgs.oCollection.result_fields[i].name + '">' + oArgs.oCollection.result_fields[i].title + '</option>');
				}
			}
		//	oArgs.oFld.jControl.selectmenu("refresh");
		}
		return this;
    };
    CXDialogPage.prototype.UpdateMappingFlds = function(oArgs)
	{
		if((oArgs.oFld.bCollectionFld && this.oMappingFolder==null) || (oArgs.oFld.bCommonCollectionFld && this.oCommonMappingFolder==null))
		{
			return this;
		}
		var j,k;
		var aMappingFlds = [];
		var bCommon = oArgs.oFld.bCommonCollectionFld;
		var jBefore = bCommon ? this.oCommonCollectionParamsFolder.jFolder : this.oCollectionParamsFolder.jFolder;
		var jFolder = [];
		if(bCommon && this.oCommonMappingFolder!=null)
		{
			jFolder = this.oCommonMappingFolder.jFolder;
		}
		else if(!bCommon && this.oMappingFolder!=null)
		{
			jFolder = this.oMappingFolder.jFolder;
		}
		this.Warning();
		for(sKey in this.oFlds)
		{
			if((bCommon && this.oFlds[sKey].bCommonMappingFld==true) || (!bCommon && this.oFlds[sKey].bMappingFld==true))
			{
				aMappingFlds.push(this.oFlds[sKey]);
			}
		}
		if(oArgs.oCollection!=null)
		{
			this.Warning();
			if(oArgs.oCollection.result_fields!=null && oArgs.oCollection.result_fields.constructor === Array)
			{
				if(oArgs.oCollection.result_fields.length>0)
				{
					for(j=0; j<aMappingFlds.length; j++)
					{
						this.UpdateMappingFld({ oFld: aMappingFlds[j], oCollection: oArgs.oCollection });
						if(aMappingFlds[j].bCommonMappingFld) // common collection mapping need fill after async collection request
						{
							for(k=this.oDialog.oCurrentOWT.params.length-1; k>=0; k--)
							{
								if(aMappingFlds[j].sId==this.oDialog.oCurrentOWT.params[k].name)
								{
									aMappingFlds[j].SetValue({ sValue: this.oDialog.oCurrentOWT.params[k].value, bSuppressEvent: true });
									break;
								}
							}
						}
						jBefore.removeAttr("cx-hide");
						jFolder.removeAttr("cx-hide");
					}
				}
				else
				{
					for(j=0; j<aMappingFlds.length; j++)
					{
						this.UpdateMappingFld({ oFld: aMappingFlds[j] });
					}
					jBefore.attr({ "cx-hide": "1" });
					jFolder.attr({ "cx-hide": "1" });
					this.Warning({ bDisplay: true, sType: "no-result", jBefore: jBefore });
				}
			}
			else
			{
				for(j=0; j<aMappingFlds.length; j++)
				{
					this.UpdateMappingFld({ oFld: aMappingFlds[j] });
				}
				jBefore.attr({ "cx-hide": "1" });
				jFolder.attr({ "cx-hide": "1" });
				this.Warning({ bDisplay: true, sType: "no-result", jBefore: jBefore });
			}
		}
		return this;
	};
    CXDialogPage.prototype.UpdateModified = function(oArgs)
	{
		if(!this.oDialog.oPage.oEditor.bStateLocked)
		{
			this.oDialog.oPage.EnableTemplateBtns();
		}
        return this;
    };
	CXDialogPage.prototype.Warning = function(oArgs)
	{
		if(oArgs==null)
		{
			if(this.jWarning!=null)
			{
				this.jWarning.hide();
			}
		}
		else
		{
			if(this.jWarning==null)
			{
				this.jWarning = this.oPlayer.jStorage.find("[cx-template='dialog-warning']").clone(true).removeAttr("cx-template");
			}
			this.jWarning.attr({ "cx-state": oArgs.sType }).insertBefore(oArgs.jBefore).show();
		}
		return this;
	};
}
{ // CXRule
    window.CXRule = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jContainer = oArgs.jContainer;
        this.oRule = oArgs.oRule;
        this.iIdx = oArgs.iIdx;
        this.oParent = oArgs.oParent;
        this.aConditions = [];
        this.oBtns = {};
        this.sMode = "view";
		this.sType = "hide";
        this.Constructor();
        return this;
    };
    CXRule.prototype = Object.create(WTBaseObject.prototype);
    CXRule.prototype.constructor = CXRule;
    CXRule.prototype.Apply = function(oArgs)
	{
        if(oArgs.oRule!=null)
		{
			var sKey;
			for(sKey in this.oRule)
			{
				delete this.oRule[sKey];
			}
			for(var sKey in oArgs.oRule)
			{
				if(typeof oArgs.oRule[sKey] == "object")
				{
					this.oRule[sKey] = JSON.parse(JSON.stringify(oArgs.oRule[sKey]));
				}
				else
				{
					this.oRule[sKey] = oArgs.oRule[sKey];
				}
			}
		}
		else
		{
			var i;
			this.oRule.type = this.jActionSelector.val();
			switch(this.oRule.type)
			{
				case "hide":
				{
					this.oRule.conditions = [];
					for(i=0; i<this.aConditions.length; i++)
					{
						this.oRule.conditions.push({
							top_elem: this.aConditions[i].jSelectObject.val(),
							option_type: this.aConditions[i].jSelectOp.val(),
							value: this.aConditions[i].jFldValue.val(),
							and_or: this.aConditions[i].jSelectOperator.val(),
							type: "string",
							field: this.aConditions[i]["jSelectProp_" + this.aConditions[i].jSelectObject.val()].val(),
							bracket: (this.aConditions[i].jSelectBracketLeft.val() == "(" ? "(" : (this.aConditions[i].jSelectBracketRight.val() == ")" ? ")" : ""))
						});
					}
					break;
				}
				case "link":
				{
					this.oRule.source_template_id = this.jLinkSelect.val();
					break;
				}
			}
		}
		if(this.oPlayer.oCurrentWebMode != null)
		{
            var oToSave =
			{
                action: "save_web_mode_structure",
                web_mode_id: this.oPlayer.oCurrentWebModeCopy.id,
                web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
            };
            this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this.oPlayer.oPages["desktop"]._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true, bCleanZones: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bAfterSave: true } });
        }
        return this;
    };
    CXRule.prototype.AppendCondition = function(oArgs)
	{
        var oThis = this;
        var i;
        var iIdx = oArgs.iIdx + 1;
        var oCond =
		{
            iIdx: iIdx,
            jItem: this.oPlayer.jStorage.find("[cx-template='condition-list-item']").clone(true).removeAttr("cx-template"),
            oCondition: {}
        };
        if(oArgs.iIdx == -1)
		{
            oCond.jItem.appendTo(this.jConditionList);
        }
		else
		{
            oCond.jItem.insertAfter(this.aConditions[iIdx].jItem);
        }
        oCond.jBracketLeft = oCond.jItem.find("[cx-role='bracket-left']").attr({ "cx-state": "off" });
        oCond.jBracketRight = oCond.jItem.find("[cx-role='bracket-right']").attr({ "cx-state": "off" });
        oCond.jText = oCond.jItem.find("[cx-role='condition-text']");
        oCond.jText.html("");
        oCond.jOperator = oCond.jItem.find("[cx-role='operator']").attr({ "cx-state": "and" });
        oCond.jEdit = oCond.jItem.find("[cx-role='condition-edit']").show();
        oCond.jView = oCond.jItem.find("[cx-role='condition-view']").hide();
        oCond.jSelectBracketLeft = oCond.jEdit.find("[cx-role='select-bracket-left']").attr({ "cx-idx": iIdx }).selectmenu({ change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
        oCond.jSelectBracketRight = oCond.jEdit.find("[cx-role='select-bracket-right']").attr({ "cx-idx": iIdx }).selectmenu({ change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
        oCond.jSelectObject = oCond.jEdit.find("[cx-role='select-object']").attr({ "cx-idx": iIdx }).selectmenu({ change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
        oCond.jSelectProp_curUser = oCond.jEdit.find("[cx-role='select-property-curUser']").attr({ "cx-idx": iIdx });
        for(k=0; k<this.oPlayer.oCurrentWebModeCopy.user_fields.length; k++)
		{
            oCond.jSelectProp_curUser.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].title + '</option>');
        }
        oCond.jSelectProp_curUser.selectmenu();
        oCond.jSelectProp_curObject = oCond.jEdit.find("[cx-role='select-property-curObject']").attr({ "cx-idx": iIdx });
        for(k=0; k<this.oPlayer.oCurrentWebModeCopy.object_fields.length; k++)
		{
            oCond.jSelectProp_curObject.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].title + '</option>');
        }
        oCond.jSelectProp_curObject.selectmenu();
        oCond.jSelectProp_curContext = oCond.jEdit.find("[cx-role='select-property-curContext']").attr({ "cx-idx": iIdx });
        for(k=0; k<this.oPlayer.oCurrentWebModeCopy.context.length; k++)
		{
            oCond.jSelectProp_curContext.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.context[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.context[k].title + '</option>');
        }
        oCond.jSelectProp_curContext.selectmenu();
        if(oCond.jSelectObject.val() == "curUser")
		{
            oCond.jSelectProp_curUser.selectmenu("widget").show();
            oCond.jSelectProp_curObject.selectmenu("widget").hide();
            oCond.jSelectProp_curContext.selectmenu("widget").hide();
        }
		else if(oCond.jSelectObject.val() == "curObject")
		{
            oCond.jSelectProp_curUser.selectmenu("widget").hide();
            oCond.jSelectProp_curObject.selectmenu("widget").show();
            oCond.jSelectProp_curContext.selectmenu("widget").hide();
        }
		else if(oCond.jSelectObject.val() == "curContext")
		{
            oCond.jSelectProp_curUser.selectmenu("widget").hide();
            oCond.jSelectProp_curObject.selectmenu("widget").hide();
            oCond.jSelectProp_curContext.selectmenu("widget").show();
        }
        oCond.jSelectOp = oCond.jEdit.find("[cx-role='select-op']").attr({ "cx-idx": iIdx }).selectmenu();
        oCond.jFldValue = oCond.jEdit.find("[cx-role='fld-value']").attr({ "cx-idx": iIdx });
        oCond.jSelectOperator = oCond.jEdit.find("[cx-role='select-operator']").attr({ "cx-idx": iIdx }).selectmenu();
        oCond.jEdit.find("[cx-btn]").attr({ "cx-idx": iIdx }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
        this.aConditions.splice(iIdx, 0, oCond);
        if(this.aConditions[iIdx + 1] != null)
		{
            for(i = iIdx + 1; i<this.aConditions.length; i++)
			{
                this.aConditions[i].jSelectBracketLeft.attr({ "cx-idx": i });
                this.aConditions[i].jSelectBracketRight.attr({ "cx-idx": i });
                this.aConditions[i].jSelectObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curUser.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectOp.attr({ "cx-idx": i });
                this.aConditions[i].jFldValue.attr({ "cx-idx": i });
                this.aConditions[i].jSelectOperator.attr({ "cx-idx": i });
                this.aConditions[i].jEdit.find("[cx-btn]").attr({ "cx-idx": i });
            }
        }
        return oCond;
    };
    CXRule.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.oOps =
		{
            "eq": "&equals;",
            "neq": "&ne;",
            "gt": "&gt;",
            "gte": "&ge;",
            "lt": "&lt;",
            "lte": "&le;",
            "cn": "&ni;",
            "ncn": "&notni;"
        };
        this.jItem = this.oPlayer.jStorage.find("[cx-template='rules-list-item']").clone(true).removeAttr("cx-template").appendTo(this.jContainer);
        this.jAction = this.jItem.find("[cx-role='rule-action']");
        this.jActionView = this.jAction.find("[cx-role='rule-action-view']");
        this.jActionValue = this.jActionView.find("[cx-role='rule-action-value']");
        this.jActionEdit = this.jAction.find("[cx-role='rule-action-edit']");
        this.jActionSelector = this.jActionEdit.find("[cx-role='action-selector']").selectmenu({ change: function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
        this.jActionValue.html(this.jActionSelector.find("option:selected").text());
        this.jConditionList = this.jItem.find("[cx-role='condition-list']");
		this.jLinkList = this.jItem.find("[cx-role='link-list']");
		this.jLinkEdit = this.jLinkList.find("[cx-role='rule-edit-src']");
		this.jLinkSelect = this.jLinkList.find("[cx-role='link-src']").selectmenu({ change: function (e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); } });
		this.jLinkView = this.jLinkList.find("[cx-role='rule-view-src']");
        this.jItem.find("[cx-btn]").on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
        this.Update().SwitchMode({ sMode: "view" });
        return this;
    };
    CXRule.prototype.DeleteCondition = function(oArgs)
	{
        var i;
        var iIdx = oArgs.iIdx;
        this.aConditions[iIdx].jItem.remove();
        this.aConditions.splice(iIdx, 1);
        if(this.aConditions[iIdx] != null)
		{
            for(i = iIdx; i<this.aConditions.length; i++)
			{
                this.aConditions[i].jSelectBracketLeft.attr({ "cx-idx": i });
                this.aConditions[i].jSelectBracketRight.attr({ "cx-idx": i });
                this.aConditions[i].jSelectObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curUser.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectProp_curObject.attr({ "cx-idx": i });
                this.aConditions[i].jSelectOp.attr({ "cx-idx": i });
                this.aConditions[i].jFldValue.attr({ "cx-idx": i });
                this.aConditions[i].jSelectOperator.attr({ "cx-idx": i });
                this.aConditions[i].jEdit.find("[cx-btn]").attr({ "cx-idx": i });
            }
        }
        return this;
    };
    CXRule.prototype.SwitchMode = function(oArgs)
	{
        var i;
        if(oArgs != null)
		{
            this.sView = (oArgs.sMode == "edit" ? "edit" : "view");
        }
        switch(this.sView)
		{
            case "view":
			{
				this.jActionView.show();
				this.jActionEdit.hide();
				switch(this.oRule.type)
				{
					case "hide":
					{
						for(i=0; i<this.aConditions.length; i++)
						{
							this.aConditions[i].jView.show();
							this.aConditions[i].jEdit.hide();
						}
						break;
					}
					case "link":
					{
						this.jLinkView.show();
						this.jLinkEdit.hide();
						break;
					}
				}
				break;
			}
            case "edit":
			{
				this.jActionView.hide();
				this.jActionEdit.show();
				switch(this.oRule.type)
				{
					case "hide":
					{
						this.jItem.find("[cx-role='condition-add']").show();
						for(i=0; i<this.aConditions.length; i++)
						{
							this.aConditions[i].jView.hide();
							this.aConditions[i].jEdit.show();
						}
						break;
					}
					case "link":
					{
						this.jItem.find("[cx-role='condition-add']").hide();
						this.jLinkView.hide();
						this.jLinkEdit.show();
						break;
					}
				}
				break;
			}
        }
        return this;
    };
    CXRule.prototype.Update = function(oArgs)
	{
        var oThis = this;
        var j, k, iIdx2;
		this.jActionValue.html(this.jActionSelector.find("option:selected").text());
        this.jActionSelector.val(this.oRule.type).selectmenu("refresh");
        this.jActionValue.html(this.jActionSelector.find("option:selected").text());
		if(oArgs!=null && oArgs.bAfterSave==true)
		{
			 this.SwitchMode({ sMode: "view" });
		}
        switch(this.oRule.type)
		{
			case "local_show":
			case "local_hide":
			case "hide":
			{
				this.jItem.find("[cx-role='condition-add']").show();
				this.jLinkList.hide();
				this.jConditionList.html("").show();
				this.aConditions = [];
				if(this.oRule.conditions.length != 0)
				{
					iIdx2 = 0;
					for(j=0; j<this.oRule.conditions.length; j++)
					{
						this.aConditions.push({
							iIdx: iIdx2,
							jItem: this.oPlayer.jStorage.find("[cx-template='condition-list-item']").clone(true).removeAttr("cx-template").appendTo(this.jConditionList),
							oCondition: this.oRule.conditions[j]
						});
						this.aConditions[iIdx2].jBracketLeft = this.aConditions[iIdx2].jItem.find("[cx-role='bracket-left']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.bracket == "(" ? "on" : "off") });
						this.aConditions[iIdx2].jBracketRight = this.aConditions[iIdx2].jItem.find("[cx-role='bracket-right']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.bracket == ")" ? "on" : "off") });
						this.aConditions[iIdx2].jText = this.aConditions[iIdx2].jItem.find("[cx-role='condition-text']");
						this.aConditions[iIdx2].jText.html(this.aConditions[iIdx2].oCondition.top_elem + "." + this.aConditions[iIdx2].oCondition.field + " " + this.oOps[this.aConditions[iIdx2].oCondition.option_type] + " " + this.aConditions[iIdx2].oCondition.value);
						this.aConditions[iIdx2].jOperator = this.aConditions[iIdx2].jItem.find("[cx-role='operator']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.and_or == "and" ? "and" : "or") });
						this.aConditions[iIdx2].jEdit = this.aConditions[iIdx2].jItem.find("[cx-role='condition-edit']");
						this.aConditions[iIdx2].jView = this.aConditions[iIdx2].jItem.find("[cx-role='condition-view']");
						this.aConditions[iIdx2].jSelectBracketLeft = this.aConditions[iIdx2].jEdit.find("[cx-role='select-bracket-left']").attr({ "cx-idx": iIdx2 });
						if(this.aConditions[iIdx2].oCondition.bracket == "(")
						{
							this.aConditions[iIdx2].jSelectBracketLeft.val("(");
						}
						this.aConditions[iIdx2].jSelectBracketLeft.selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectBracketRight = this.aConditions[iIdx2].jEdit.find("[cx-role='select-bracket-right']").attr({ "cx-idx": iIdx2 });
						if(this.aConditions[iIdx2].oCondition.bracket == ")")
						{
							this.aConditions[iIdx2].jSelectBracketRight.val(")");
						}
						this.aConditions[iIdx2].jSelectBracketRight.selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectObject = this.aConditions[iIdx2].jEdit.find("[cx-role='select-object']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.top_elem).selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectProp_curUser = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curUser']").attr({ "cx-idx": iIdx2 });
						if(this.oPlayer.oCurrentWebModeCopy.user_fields!=null)
						{
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.user_fields.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curUser.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].title + '</option>');
						}
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curUser")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curUser.selectmenu();
						this.aConditions[iIdx2].jSelectProp_curObject = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curObject']").attr({ "cx-idx": iIdx2 });
						if(this.oPlayer.oCurrentWebModeCopy.object_fields!=null)
						{
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.object_fields.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curObject.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].title + '</option>');
						}
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curObject")
						{
							this.aConditions[iIdx2].jSelectProp_curObject.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curObject.selectmenu();
						this.aConditions[iIdx2].jSelectProp_curContext = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curContext']").attr({ "cx-idx": iIdx2 });
						if(this.oPlayer.oCurrentWebModeCopy.context!=null)
						{
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.context.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curContext.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.context[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.context[k].title + '</option>');
						}
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curContext")
						{
							this.aConditions[iIdx2].jSelectProp_curContext.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curContext.selectmenu();
						if(this.aConditions[iIdx2].oCondition.top_elem == "curUser")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").show();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
						}
						else if(this.aConditions[iIdx2].oCondition.top_elem == "curObject")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").show();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
						}
						else if(this.aConditions[iIdx2].oCondition.top_elem == "curContext")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").show();
						}
						this.aConditions[iIdx2].jSelectOp = this.aConditions[iIdx2].jEdit.find("[cx-role='select-op']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.option_type).selectmenu();
						this.aConditions[iIdx2].jFldValue = this.aConditions[iIdx2].jEdit.find("[cx-role='fld-value']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.value);
						this.aConditions[iIdx2].jSelectOperator = this.aConditions[iIdx2].jEdit.find("[cx-role='select-operator']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.and_or).selectmenu();
						this.aConditions[iIdx2].jEdit.find("[cx-btn]").attr({ "cx-idx": iIdx2 }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
						iIdx2++;
					}
					this.jActionView.show();
					this.jActionEdit.hide();
				}
				break;
			}
			case "link":
			{
				this.jItem.find("[cx-role='condition-add']").hide();
				if(this.oRule.source_template_id=="") // by local condition
				{
				this.jLinkList.hide();
				this.jConditionList.html("").show();
				this.aConditions = [];
				if(this.oRule.conditions.length != 0)
				{
					iIdx2 = 0;
					for(j=0; j<this.oRule.conditions.length; j++)
					{
						this.aConditions.push({
							iIdx: iIdx2,
							jItem: this.oPlayer.jStorage.find("[cx-template='condition-list-item']").clone(true).removeAttr("cx-template").appendTo(this.jConditionList),
							oCondition: this.oRule.conditions[j]
						});
						this.aConditions[iIdx2].jBracketLeft = this.aConditions[iIdx2].jItem.find("[cx-role='bracket-left']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.bracket == "(" ? "on" : "off") });
						this.aConditions[iIdx2].jBracketRight = this.aConditions[iIdx2].jItem.find("[cx-role='bracket-right']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.bracket == ")" ? "on" : "off") });
						this.aConditions[iIdx2].jText = this.aConditions[iIdx2].jItem.find("[cx-role='condition-text']");
						this.aConditions[iIdx2].jText.html(this.aConditions[iIdx2].oCondition.top_elem + "." + this.aConditions[iIdx2].oCondition.field + " " + this.oOps[this.aConditions[iIdx2].oCondition.option_type] + " " + this.aConditions[iIdx2].oCondition.value);
						this.aConditions[iIdx2].jOperator = this.aConditions[iIdx2].jItem.find("[cx-role='operator']").attr({ "cx-state": (this.aConditions[iIdx2].oCondition.and_or == "and" ? "and" : "or") });
						this.aConditions[iIdx2].jEdit = this.aConditions[iIdx2].jItem.find("[cx-role='condition-edit']");
						this.aConditions[iIdx2].jView = this.aConditions[iIdx2].jItem.find("[cx-role='condition-view']");
						this.aConditions[iIdx2].jSelectBracketLeft = this.aConditions[iIdx2].jEdit.find("[cx-role='select-bracket-left']").attr({ "cx-idx": iIdx2 });
						if(this.aConditions[iIdx2].oCondition.bracket == "(")
						{
							this.aConditions[iIdx2].jSelectBracketLeft.val("(");
						}
						this.aConditions[iIdx2].jSelectBracketLeft.selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectBracketRight = this.aConditions[iIdx2].jEdit.find("[cx-role='select-bracket-right']").attr({ "cx-idx": iIdx2 });
						if(this.aConditions[iIdx2].oCondition.bracket == ")")
						{
							this.aConditions[iIdx2].jSelectBracketRight.val(")");
						}
						this.aConditions[iIdx2].jSelectBracketRight.selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectObject = this.aConditions[iIdx2].jEdit.find("[cx-role='select-object']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.top_elem).selectmenu({
							change: function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }
						});
						this.aConditions[iIdx2].jSelectProp_curUser = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curUser']").attr({ "cx-idx": iIdx2 });
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.user_fields.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curUser.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.user_fields[k].title + '</option>');
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curUser")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curUser.selectmenu();
						this.aConditions[iIdx2].jSelectProp_curObject = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curObject']").attr({ "cx-idx": iIdx2 });
						if(this.oPlayer.oCurrentWebModeCopy.object_fields!=null)
						{
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.object_fields.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curObject.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.object_fields[k].title + '</option>');
						}
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curObject")
						{
							this.aConditions[iIdx2].jSelectProp_curObject.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curObject.selectmenu();
						this.aConditions[iIdx2].jSelectProp_curContext = this.aConditions[iIdx2].jEdit.find("[cx-role='select-property-curContext']").attr({ "cx-idx": iIdx2 });
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.context.length; k++)
						{
							this.aConditions[iIdx2].jSelectProp_curContext.append('<option value="' + this.oPlayer.oCurrentWebModeCopy.context[k].name + '">' + this.oPlayer.oCurrentWebModeCopy.context[k].title + '</option>');
						}
						if(this.aConditions[iIdx2].oCondition.top_elem == "curContext")
						{
							this.aConditions[iIdx2].jSelectProp_curContext.val(this.aConditions[iIdx2].oCondition.field);
						}
						this.aConditions[iIdx2].jSelectProp_curContext.selectmenu();
						if(this.aConditions[iIdx2].oCondition.top_elem == "curUser")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").show();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
						}
						else if(this.aConditions[iIdx2].oCondition.top_elem == "curObject")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").show();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
						}
						else if(this.aConditions[iIdx2].oCondition.top_elem == "curContext")
						{
							this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
							this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").show();
						}
						this.aConditions[iIdx2].jSelectOp = this.aConditions[iIdx2].jEdit.find("[cx-role='select-op']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.option_type).selectmenu();
						this.aConditions[iIdx2].jFldValue = this.aConditions[iIdx2].jEdit.find("[cx-role='fld-value']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.value);
						this.aConditions[iIdx2].jSelectOperator = this.aConditions[iIdx2].jEdit.find("[cx-role='select-operator']").attr({ "cx-idx": iIdx2 }).val(this.aConditions[iIdx2].oCondition.and_or).selectmenu();
						this.aConditions[iIdx2].jEdit.find("[cx-btn]").attr({ "cx-idx": iIdx2 }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
						iIdx2++;
					}
					this.jActionView.show();
					this.jActionEdit.hide();
				}
				}
				else // by object id in source
				{
					this.jConditionList.hide();
					this.jLinkList.show();
	//				this.jLinkSelect.children("option[value!='']").remove();
					var aTemplates = JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy.zones[0].templates)).sort(function (oElem1, oElem2)
					{
						if(oElem1.weight>oElem2.weight)
						{
							return 1;
						}
						if(oElem1.weight<oElem2.weight)
						{
							return -1;
						}
						return 0;
					});
					_j_loop:
					for(j=0; j<aTemplates.length; j++)
					{
						if(aTemplates[j].override_template_id==this.oRule.source_template_id)
						{
							this.jLinkView.html(aTemplates[j].weight + " " + aTemplates[j].name);
							break;
						}
						if(aTemplates[j].templates!=null)
						{
							for(k=0; k<aTemplates[j].templates.length; k++)
							{
								if(aTemplates[j].templates[k].override_template_id==this.oRule.source_template_id)
								{
									this.jLinkView.html(aTemplates[j].templates[k].weight + " " + aTemplates[j].templates[k].name);
									break _j_loop;
								}
							}
						}
					}
				}
				break;
			}
		}
        return this;
    };
    CXRule.prototype.UIEvent = function(oArgs)
	{
        var sIdx = oArgs.oElem.getAttribute("cx-idx");
        var iIdx2 = (sIdx == null) ? -1 : +sIdx;
        switch(oArgs.oElem.getAttribute("cx-role"))
		{
            case "action-selector":
			{
				this.oRule.type = $(oArgs.oElem).val();
				this.Update();
				break;
			}
			case "condition-add":
			{
				this.AppendCondition({ iIdx: iIdx2 });
				break;
			}
            case "condition-delete":
			{
				this.DeleteCondition({ iIdx: iIdx2 });
				break;
			}
            case "select-bracket-left":
			{
				if(oArgs.oElem.value == "(" && this.aConditions[iIdx2].jSelectBracketRight.val() == ")")
				{
					this.aConditions[iIdx2].jSelectBracketRight.val("").selectmenu("refresh");
				}
				break;
			}
            case "select-bracket-right":
			{
				if(oArgs.oElem.value == ")" && this.aConditions[iIdx2].jSelectBracketLeft.val() == "(")
				{
					this.aConditions[iIdx2].jSelectBracketLeft.val("").selectmenu("refresh");
				}
				break;
			}
            case "select-object":
			{
				if(oArgs.oElem.value == "curUser")
				{
					this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").show();
					this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
					this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
				}
				else if(oArgs.oElem.value == "curObject")
				{
					this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
					this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").show();
					this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").hide();
				}
				else if(oArgs.oElem.value == "curContext")
				{
					this.aConditions[iIdx2].jSelectProp_curUser.selectmenu("widget").hide();
					this.aConditions[iIdx2].jSelectProp_curObject.selectmenu("widget").hide();
					this.aConditions[iIdx2].jSelectProp_curContext.selectmenu("widget").show();
				}
				break;
			}
            case "rule-edit":
			{
				this.oPlayer.oPages["desktop"].oBuilders["rule"].Update({ oRule: this.oRule, oSrc: this }).Show();
				//this.SwitchMode({ sMode: "edit" });
				break;
			}
            case "rule-delete":
			{
				this.oParent.DeleteRule({ iIdx: this.iIdx });
				break;
			}
            case "rule-apply":
			{
				this.Apply();
				break;
			}
            case "rule-cancel":
			{
				this.Update().SwitchMode({ sMode: "view" });
				break;
			}
        }
        return true;
    };
}
{ // CXSlideFrame
    window.CXSlideFrame = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jFrame = oArgs.jFrame;
        this.oViews = {};
        this.Constructor();
        return this;
    };
    CXSlideFrame.prototype.ApplySettings = function()
	{
        this.jStyle.html(this.oPlayer.oCurrentModule.sStyleString);
        this.jBody.css({ "width": this.oPlayer.oCurrentModule.oSettings.oWidth.value + "px", "height": this.oPlayer.oCurrentModule.oSettings.oHeight.value + "px", "transform-origin": "0 0", "padding": "0", "margin": "0" });
        return this;
    };
    CXSlideFrame.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jFrameContainer = this.jFrame.parent();
        this.oFrameContentWindow = this.jFrame[0].contentWindow;
        this.jFrameContents = $(this.oFrameContentWindow);
        this.jFrameContents.on("resize", function() { oThis.Resize.call(oThis); });
        this.jHTML = this.jFrame.contents().find("html");
        this.jHead = this.jHTML.children("head");
        this.jStyle = this.jHead.children("style");
        this.jBody = this.jHTML.children("body").attr({ "cl-view": "flex" });
        return this;
    };
    CXSlideFrame.prototype.CreateView = function(oArgs)
	{
        this.oViews[oArgs.sSlideId] = { jContainer: this.oPlayer.jStorage.find("[cl-template='cxo-container']").clone(true).removeAttr("cl-template").appendTo(this.jBody) };
        this.oViews[oArgs.sSlideId].oView = new CXO({ oPlayer: this.oPlayer, jContainer: this.oViews[oArgs.sSlideId].jContainer, oObject: oArgs.oObject, jxParams: oArgs.jxParams, sView: "flex", nDesktopW: this.oPlayer.oCurrentModule.oSettings.oWidth.value, nDesktopH: this.oPlayer.oCurrentModule.oSettings.oHeight.value });
        this.Show(oArgs);
        return this;
    };
    CXSlideFrame.prototype.Hide = function(oArgs)
	{
        this.oViews[oArgs.sSlideId].jContainer.hide();
        this.oViews[oArgs.sSlideId].bVisible = false;
        return this;
    };
    CXSlideFrame.prototype.Reset = function()
	{
        delete this.oViews;
        this.oViews = {};
        this.jStyle.html("");
        this.jBody.html("");
        return this;
    };
    CXSlideFrame.prototype.Resize = function()
	{
        if(this.oPlayer.oCurrentModule != null)
		{
            var oThis = this;
            var nW = this.jFrame.width();
            var nH = nW * this.oPlayer.oCurrentModule.oSettings.oHeight.value / this.oPlayer.oCurrentModule.oSettings.oWidth.value;
            oThis.jFrame.height(nH);
            var nRatioX = nW / this.oPlayer.oCurrentModule.oSettings.oWidth.value;
            var nRatioY = nH / this.oPlayer.oCurrentModule.oSettings.oHeight.value;
            var nRatio = Math.min(nRatioX, nRatioY);
            oThis.jBody.css({ "transform": "scale(" + nRatio + ")" });
        }
        return this;
    };
    CXSlideFrame.prototype.Show = function(oArgs)
	{
        for(var sKey in this.oViews)
		{
            if(this.oViews.hasOwnProperty(sKey))
			{
                if(this.oViews[sKey].bVisible)
				{
                    this.Hide({ sSlideId: sKey });
                }
                if(sKey == oArgs.sSlideId)
				{
                    this.oViews[sKey].jContainer.show();
                    this.oViews[sKey].bVisible = true;
                }
            }
        }
        return this;
    };
    CXSlideFrame.prototype.UpdateStyles = function(oArgs)
	{
        this.jStyle.html(oArgs.sStyle);
        return this;
    };
    CXSlideFrame.prototype.UpdateView = function(oArgs)
	{
        this.oViews[oArgs.sSlideId].oView.jxParams = oArgs.jxParams;
        this.oViews[oArgs.sSlideId].oView.ReadParams().Update(oArgs);
        return this;
    };
}
{ // CXDialog
    window.CXDialog = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oPage = oArgs.oPage;
        this.sType = oArgs.sType == null ? "ui" : oArgs.sType;
        this.sTargetGroupId = null;
        this.Constructor();
        return this;
    };
    CXDialog.prototype = Object.create(WTBaseObject.prototype);
    CXDialog.prototype.constructor = CXDialog;
    CXDialog.prototype._Validate = function()
	{
        var bValid = false;
        return bValid;
    };
    CXDialog.prototype.Constructor = function()
	{
        var oThis = this;
        this.jBody = this.oPlayer.jStorage.find("[cx-template='dialog-" + this.sType + "']").clone(true).removeAttr("cx-template").appendTo(this.jContainer);
        this.jForm = this.jBody.find("form");
        this.oDialog = this.jBody.dialog({
            autoOpen: false,
            width: "auto",
            modal: true,
            dialogClass: "cx-dialog cx-dialog-" + this.sType,
            title: oThis.jBody.attr("title"),
            closeText: oThis.oPlayer._GetString({ sId: "dialog-close" }),
            classes: {
                "ui-dialog-titlebar": "cx-dialog-title"
            },
            buttons: [{
                    text: oThis.oPlayer._GetString({ sId: "dialog-ok" }),
                    class: "cx-dialog-btn cx-dialog-ok",
                    click: function(e) { oThis.UIEvent({ oThis: oThis, oEvt: e, oElem: this }); }
                },
                {
                    text: oThis.oPlayer._GetString({ sId: "dialog-cancel" }),
                    class: "cx-dialog-btn cx-dialog-cancel",
                    click: function(e) { oThis.UIEvent({ oThis: oThis, oEvt: e, oElem: this }); }
                }
            ],
            create: function() {
                oThis.jDialog = oThis.jBody.dialog("widget");
                oThis.jBtnOK = oThis.jDialog.find(".cx-dialog-ok").attr({ "cx-role": "dialog-ok" });
                oThis.jBtnCancel = oThis.jDialog.find(".cx-dialog-cancel").attr({ "cx-role": "dialog-cancel" });
            }
        });
        switch(this.sType)
		{
            case "settings":
			{
				this.jList1 = this.jBody.find("[cx-role='fld-list-1']");
				this.jList2 = this.jBody.find("[cx-role='fld-list-2']");
				this.jBlockTemplate = this.oPlayer.jStorage.find("[cx-template='fld-block']");
				this.oFlds = {};
				break;
			}
			case "objects":
			{
				this.jGroupTemplate = this.oPlayer.jStorage.find("[cx-template='object-list-group-item']");
				this.jTemplate = this.oPlayer.jStorage.find("[cx-template='object']");
				this.jList = this.jBody.find("[cx-role='object-list']");
				this.oBtns = {};
				break;
			}
            case "select-file":
			{
				this.jRepoId = this.jForm.find("[cx-role='form-repo-id']");
				this.jRepoSelect = this.jForm.find("[cx-role='repo-select']").on("change", function(e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
				this.jTypeSelect = this.jForm.find("[cx-role='type-select']").on("change", function(e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
				this.jFileList = this.jForm.find("[cx-role='file-list']");
				this.jFileFld = this.jForm.find("[cx-role='add-file']").on("change", function(e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); });
				this.jFileInfo = this.jForm.find("[cx-role='file-info']");
				this.jFileName = this.jForm.find("[cx-role='file-name']");
				this.jFileType = this.jForm.find("[cx-role='file-type']");
				this.oSelectedItem = null;
				this.oFileList = null;
				break;
			}
        }
        return this;
    };
    CXDialog.prototype.Fill = function(oArgs)
	{
        var oThis = this;
        var aFilterValues = [];
        var sKey;
        var i;
        switch(oThis.sType)
		{
            case "settings":
			{
				this.jBlockTitle = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList1);
				this.jBlockSample = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList1);
				this.jBlockMetrics = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList1);
				this.jBlockClass = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList2);
				this.jBlockColorBG = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList2);
				this.jBlockImgBG = this.jBlockTemplate.clone(true).removeAttr("cx-template").appendTo(this.jList2);
				this.oFlds["title"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.title",
						parent_wvar_name: "",
						type: "string",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-title" })
					},
					jBlock: this.jBlockTitle,
					sId: "title"
				});
				this.oFlds["title"].sDefaultValue = "";
				this.oFlds["sample_object_id"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "sample_object_id",
						parent_wvar_name: "",
						type: "foreign_elem",
						catalog: "",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-sample-object" })
					},
					jBlock: this.jBlockSample,
					sId: "sample_object_id"
				});
				this.oFlds["metrics"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.metrics",
						parent_wvar_name: "",
						type: "text",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-metrics" }),
						classes: [ "wt-lp-data-code" ]
					},
					jBlock: this.jBlockMetrics,
					sId: "metrics"
				});
				this.oFlds["metrics"].sDefaultValue = "";
				this.oFlds["local_vars"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.local_vars",
						parent_wvar_name: "",
						type: "text",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-local-vars" }),
						classes: [ "wt-lp-data-code" ]
					},
					jBlock: this.jBlockMetrics,
					sId: "local_vars"
				});
				this.oFlds["local_vars"].sDefaultValue = "";
				this.oFlds["CONFIG"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.CONFIG",
						parent_wvar_name: "",
						type: "text",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-CONFIG" }),
						classes: [ "wt-lp-data-code" ]
					},
					jBlock: this.jBlockMetrics,
					sId: "CONFIG"
				});
				this.oFlds["CONFIG"].sDefaultValue = "";
				this.oFlds["css_class"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.css_class",
						parent_wvar_name: "",
						type: "string",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-css-class" })
					},
					jBlock: this.jBlockClass,
					sId: "css_class"
				});
				this.oFlds["css_class"].sDefaultValue = "";
				this.oFlds["color_bg_page"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.color_bg_page",
						parent_wvar_name: "",
						type: "string",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-color" })
					},
					jBlock: this.jBlockColorBG,
					sId: "color_bg_page"
				});
				this.oFlds["color_bg_page"].sDefaultValue = "";
				this.oFlds["img_bg_page"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.img_bg_page",
						parent_wvar_name: "",
						type: "file",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-img" })
					},
					jBlock: this.jBlockImgBG,
					sId: "img_bg_page"
				});
				this.oFlds["img_bg_page"].sDefaultValue = "";
				this.oFlds["bg_url"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.bg_url",
						parent_wvar_name: "",
						type: "string",
						value: "",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-url" })
					},
					jBlock: this.jBlockImgBG,
					sId: "bg_url"
				});
				this.oFlds["bg_url"].sDefaultValue = "";
				this.oFlds["bg_repeat"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.bg_repeat",
						parent_wvar_name: "",
						type: "string",
						value: "no-repeat",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-repeat" })
					},
					jBlock: this.jBlockImgBG,
					sId: "bg_repeat"
				});
				this.oFlds["bg_repeat"].sDefaultValue = "no-repeat";
				this.oFlds["bg_position"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.bg_position",
						parent_wvar_name: "",
						type: "string",
						value: "center center",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-position" })
					},
					jBlock: this.jBlockImgBG,
					sId: "bg_position"
				});
				this.oFlds["bg_position"].sDefaultValue = "center center";
				this.oFlds["bg_size"] = new CXFld(
				{
					oPlayer: this.oPlayer, oDialog: this, oPage: this,
					oFld:
					{
						name: "webmode.bg_size",
						parent_wvar_name: "",
						type: "string",
						value: "contain",
						description: this.oPlayer._GetString({ sId: "settings-label-bg-size" })
					},
					jBlock: this.jBlockImgBG,
					sId: "bg_size"
				});
				this.oFlds["bg_size"].sDefaultValue = "contain";
				break;
			}
			case "objects":
			{
				var jGroupLI;
				var jGroupUL;
				var oParamSets;
				var jLI;
				var jBtn;
				var jIcon;
				var sBtnId;
				for(sKey in this.oPlayer.oStore["macros"].oData)
				{
					if(this.oPlayer.oStore["macros"].oData.hasOwnProperty(sKey))
					{
						jGroupLI = oThis.jGroupTemplate.clone(true).removeAttr("cx-template").attr({ "cx-type": "macro" }).appendTo(oThis.jList);
						jGroupUL = jGroupLI.find("[cx-role='object-list-group-list']");
						jGroupLI.find("[cx-role='object-list-group-name']").html(this.oPlayer.oStore["macros"].oData[sKey].name);
						sBtnId = sKey;
						jLI = oThis.jTemplate.clone(true).removeAttr("cx-template").appendTo(jGroupUL);
						jBtn = jLI.find("[cx-role='btn-object']").attr({ "cx-id": sKey, "cx-type": "macro" }).on("dblclick", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
						jIcon = jBtn.find("[cx-role='btn-icon']");
						if(this.oPlayer.oStore["macros"].oData[sKey].icon != null)
						{
							jIcon.css({ "background-image": "url('" + this.oPlayer.oStore["macros"].oData[sKey].icon + "')" });
						}
						else
						{
							jIcon.css({ "background-image": "url('" + this.oPlayer.oConfig.sDefaultWidgetIcon + "')" });
						}
						oThis.oBtns[sBtnId] = new CXBtn({ oPlayer: oThis.oPlayer, jContainer: jLI, sId: sBtnId, jBtn: jBtn, oContext: oThis, fn: oThis.UIEvent, oArgs: {} });
						oThis.oBtns[sBtnId].bMacro = true;
						jLI.find("[cx-role='btn-text']").hide();
						jLI.attr({ "title": this.oPlayer.oStore["macros"].oData[sKey].name });
					}
				}
				for(sKey in this.oPlayer.oStore["templates"].oData)
				{
					if(this.oPlayer.oStore["templates"].oData.hasOwnProperty(sKey))
					{
						jGroupLI = oThis.jGroupTemplate.clone(true).removeAttr("cx-template").appendTo(oThis.jList);
						jGroupUL = jGroupLI.find("[cx-role='object-list-group-list']");
						jGroupLI.find("[cx-role='object-list-group-name']").html(this.oPlayer.oStore["templates"].oData[sKey].name);
						sBtnId = sKey;
						jLI = oThis.jTemplate.clone(true).removeAttr("cx-template").appendTo(jGroupUL);
						jBtn = jLI.find("[cx-role='btn-object']").attr({ "cx-id": sKey }).on("dblclick", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this }); });
						jIcon = jBtn.find("[cx-role='btn-icon']");
						if(this.oPlayer.oStore["templates"].oData[sKey].icon != null)
						{
							jIcon.css({ "background-image": "url('" + this.oPlayer.oStore["templates"].oData[sKey].icon + "')" });
						}
						else
						{
							jIcon.css({ "background-image": "url('" + this.oPlayer.oConfig.sDefaultWidgetIcon + "')" });
						}
						oThis.oBtns[sBtnId] = new CXBtn({ oPlayer: oThis.oPlayer, jContainer: jLI, sId: sBtnId, jBtn: jBtn, oContext: oThis, fn: oThis.UIEvent, oArgs: {} });
						jLI.find("[cx-role='btn-text']").hide();
						jLI.attr({ "title": this.oPlayer.oStore["templates"].oData[sKey].name });
					}
				}
				break;
			}
            case "select-file":
			{
				if(this.oFileList == null)
				{
					this.oFileList = {};
					for(sKey in oThis.oPlayer.oStore["repos"].oData)
					{
						if(sKey == "ALL")
						{
							continue;
						}
						else if(sKey == "0")
						{
							oThis.jRepoSelect.append('<option value="0">' + this.oPlayer._GetString({ sId: "option-orphaned-resources" }) + " (" + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ")" + '</option>');
							for(i=0; i<oThis.oPlayer.oStore["repos"].oData[sKey].files.length; i++)
							{
								oThis.oFileList[oThis.oPlayer.oStore["repos"].oData[sKey].files[i].id] = new CXFileItem({ oPlayer: oThis.oPlayer, oDialog: oThis, oRepo: oThis.oPlayer.oStore["repos"].oData[sKey], oFile: oThis.oPlayer.oStore["repos"].oData[sKey].files[i], jList: oThis.jFileList });
							}
						}
						else
						{
							if(oThis.oPlayer.oStore["repos"].oData[sKey].person_id == oThis.oPlayer.sCurrentUserId) {
								if(oThis.jRepoId.val() == "") {
									oThis.jRepoId.val(sKey);
								}
								aFilterValues.push({ sId: sKey, sName: oThis.oPlayer.oStore["repos"].oData[sKey].name + " (" + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ")" });
								for(i=0; i<oThis.oPlayer.oStore["repos"].oData[sKey].files.length; i++) {
									oThis.oFileList[oThis.oPlayer.oStore["repos"].oData[sKey].files[i].id] = new CXFileItem({ oPlayer: oThis.oPlayer, oDialog: oThis, oRepo: oThis.oPlayer.oStore["repos"].oData[sKey], oFile: oThis.oPlayer.oStore["repos"].oData[sKey].files[i], jList: oThis.jFileList });
								}
							}
						}
					}
					aFilterValues.sort(function(oElem1, oElem2) { if(oElem1.sName.toLowerCase() > oElem2.sName.toLowerCase()) return 1; if(oElem1.sName.toLowerCase() < oElem2.sName.toLowerCase()) return -1; return 0; });
					for(i=0; i<aFilterValues.length; i++)
					{
						oThis.jRepoSelect.append('<option value="' + aFilterValues[i].sId + '">' + "&#128194; " + aFilterValues[i].sName + '</option>');
					}
					oThis.jRepoSelect.selectmenu({ classes: { "ui-selectmenu-menu": "cx-resources-menu" }, change: function(e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); } });
					if(oThis.jTypeSelect.children("option").length <= 1)
					{
						for(sKey in oThis.oPlayer.oStore["file_types"].oData)
						{
							if(oThis.oPlayer.oStore["file_types"].oData.hasOwnProperty(sKey))
							{
								oThis.jTypeSelect.append('<option value="' + sKey + '">' + oThis.oPlayer.oStore["file_types"].oData[sKey].name + '</option>');
							}
						}
					}
					oThis.jTypeSelect.selectmenu({ classes: { "ui-selectmenu-menu": "cx-resources-menu" }, change: function(e) { oThis.UIEvent({ oEvt: e, oElem: this, oThis: oThis }); } });
				}
				break;
			}
        }
        return oThis;
    };
    CXDialog.prototype.Filter = function(oArgs)
	{
        var oThis = this;
        var sRepoId;
        var sTypeId;
        var sKey;
        switch(oThis.sType)
		{
            case "select-file":
			{
				sRepoId = this.jRepoSelect.val();
				sTypeId = this.jTypeSelect.val();
				for(sKey in this.oFileList)
				{
					if((sRepoId == "ALL" || sRepoId == this.oFileList[sKey].oRepo.id) && (sTypeId == "ALL" || sTypeId == this.oFileList[sKey].oFile.type))
					{
						this.oFileList[sKey].Show();
					}
					else
					{
						this.oFileList[sKey].Hide();
					}
				}
				break;
			}
            case "select-module":
			{
				sRepoId = this.jRepoSelect.val();
				sTypeId = this.jTypeSelect.val();
				for(sKey in this.oResourceList.oItems)
				{
					if((sRepoId == "ALL" || sRepoId == this.oResourceList.oItems[sKey].oItem.repo_id) && (sTypeId == "ALL" || sTypeId == this.oResourceList.oItems[sKey].oItem.type))
					{
						this.oResourceList.oItems[sKey].Show();
					}
					else
					{
						this.oResourceList.oItems[sKey].Hide();
					}
				}
				break;
			}
        }
        return this;
    };
    CXDialog.prototype.Hide = function(oArgs)
	{
        var oThis = this;
        oThis.oDialog.dialog("close");
        return oThis;
    };
    CXDialog.prototype.SetTarget = function(oArgs)
	{
        this.oTarget = null;
        if(oArgs.oTarget != null)
		{
            this.oTarget = oArgs.oTarget;
        }
        return this;
    };
    CXDialog.prototype.Show = function(oArgs)
	{
        var oThis = this;
        var sKey;
        switch(oThis.sType)
		{
            case "settings":
			{
				this.Update();
				this.oDialog.dialog("option", "width", Math.round(0.8 * $(window).width()));
				this.oDialog.dialog("option", "height", Math.round(0.8 * $(window).height()));
				this.oDialog.dialog("open");
				break;
			}
			case "objects":
			{
				this.oTarget = null;
				this.oDialog.dialog("option", "width", Math.round(0.8 * $(window).width()));
				this.oDialog.dialog("option", "height", Math.round(0.8 * $(window).height()));
				this.oDialog.dialog("open");
				this.jList.children("[cx-type='macro']").show();
				if(oArgs != null && oArgs.bMacro == true)
				{
					this.oTarget = oArgs.oTarget;
					this.jList.children("[cx-type='macro']").hide();
				}
				break;
			}
            case "select-file":
			{
				var nDWidth = Math.round(0.8 * $(window).width());
				var nWHeight = $(window).height();
				var nDHeight = Math.round(0.99 * nWHeight);
				if(nDWidth > 1300)
				{
					nDWidth = 1300;
				}
				oThis.oDialog.dialog("option", "width", nDWidth);
				oThis.oDialog.dialog("option", "height", nDHeight);
				oThis.oDialog.dialog("open");
				var jWidget = oThis.oDialog.dialog("widget"); //top:" + Math.round(0.5*($(window).height() - nDHeight)) + "px"
				var nEmSize = (jWidget.width()) / 60;
				jWidget.attr({ "style": jWidget.attr("style") + ";font-size:" + nEmSize + "px !important;" });
				var nWidgetH = jWidget.height();
				var nDiff = nWidgetH - nDHeight;
				if(nDiff > 0)
				{
					jWidget.find("[cx-resize]").each(function()
					{
						var nH = $(this).outerHeight(true) - nDiff;
						$(this).attr({ "style": this.getAttribute("style") + ";min-height:" + nH + "px !important", "height": nH + "px" });
					});
				}
				var nMaxH = jWidget.find("[cx-role='select-file']").height() - jWidget.find("[cx-role='file-filter-block']").outerHeight(true);
				jWidget.find("[cx-role='list-container']").css({ "height": nMaxH + "px", "min-height": nMaxH + "px" });
				jWidget.css({ "top": Math.round(0.5 * (nWHeight - jWidget.height())) + "px" });

				for(sKey in this.oPlayer.oStore["files"].oData)
				{
					if(this.oFileList[sKey] == null)
					{
						this.oFileList[sKey] = new CXFileItem({ oPlayer: oThis.oPlayer, oDialog: oThis, oRepo: oThis.oPlayer.oStore["repos"].oData[this.oPlayer.oStore["files"].oData[sKey].repo_id], oFile: this.oPlayer.oStore["files"].oData[sKey], jList: oThis.jFileList });
					}
				}

				var aFilterValues = [];
				oThis.jRepoSelect.children("option[value!='ALL']").remove();
				for(sKey in oThis.oPlayer.oStore["repos"].oData)
				{
					if(sKey == "ALL")
					{
						continue;
					}
					else if(sKey == "0")
					{
						oThis.jRepoSelect.append('<option value="0">' + this.oPlayer._GetString({ sId: "option-orphaned-resources" }) + " (" + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ")" + '</option>');
					}
					else
					{
						if(oThis.oPlayer.oStore["repos"].oData[sKey].person_id == oThis.oPlayer.sCurrentUserId)
						{
							if(oThis.jRepoId.val() == "")
							{
								oThis.jRepoId.val(sKey);
							}
							aFilterValues.push({ sId: sKey, sName: oThis.oPlayer.oStore["repos"].oData[sKey].name + " (" + oThis.oPlayer.oStore["repos"].oData[sKey].files.length + ")" });
						}
					}
				}
				aFilterValues.sort(function(oElem1, oElem2)
				{
					if(oElem1.sName.toLowerCase() > oElem2.sName.toLowerCase())
					{
						return 1;
					}
					if(oElem1.sName.toLowerCase() < oElem2.sName.toLowerCase())
					{
						return -1;
					}
					return 0;
				});
				for(var i = 0; i<aFilterValues.length; i++)
				{
					oThis.jRepoSelect.append('<option value="' + aFilterValues[i].sId + '">' + "&#128194; " + aFilterValues[i].sName + '</option>');
				}

				for(sKey in oThis.oFileList)
				{
					oThis.oFileList[sKey].Show().Unselect();
				}
				oThis.jTypeSelect.val("ALL").selectmenu("refresh");
				oThis.Filter();

				if(oArgs != null)
				{
					if(oArgs.sSelectedId != null && oArgs.sSelectedId != "")
					{
						oThis.oFileList[oArgs.sSelectedId].Select();
					}
				}
				break;
			}
        }
        return oThis;
    };
    CXDialog.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        var sKey;
        var sRole = oArgs.oElem.getAttribute("cx-role");
        var oBtn = oArgs.oEvt.target;
        if(sRole == null || sRole == this.sType)
		{
            sRole = oBtn.getAttribute("cx-role");
        }
        switch(sRole)
		{
            case "repo-select":
            case "type-select":
			{
				oThis.Filter({ oFilter: oBtn });
				if(oThis.jRepoId != null)
				{
					oThis.jRepoId.val(oThis.jRepoSelect.val());
				}
				break;
			}
            case "add-file":
			{
				if($(oArgs.oElem).val() != "")
				{
					oThis.oPlayer.oAPI.Create({ sTarget: "resource", jForm: oThis.jForm, bFromCourse: true, oCaller: oThis });
				}
				break;
			}
            case "btn-object":
			{
				if(oArgs.oEvt.type == "dblclick")
				{
					this.oPage.oEditor.AppendItem({ sId: oArgs.oElem.getAttribute("cx-id"), bMacro: (oArgs.oElem.getAttribute("cx-type") == "macro"), oTarget: this.oTarget });
					this.Hide();
				}
				else if(oArgs.oEvt.type == "click")
				{
					for(sKey in this.oBtns)
					{
						if(this.oBtns.hasOwnProperty(sKey))
						{
							if(this.oBtns[sKey].bSelected)
							{
								this.oBtns[sKey].Unselect();
							}
							else if(sKey == oArgs.oBtn.sId)
							{
								this.oBtns[sKey].Select();
							}
						}
					}
				}
				break;
			}
            case "dialog-ok":
			{
				switch(this.sType)
				{
					case "settings":
					{
						var sVarName;
						var aWVars = [];
						var sText;
						var oText;
						if(this.oFlds["local_vars"]!=null)
						{
							sText = this.oFlds["local_vars"]._GetValue();
							if(sText!=null && sText!="")
							{
								try
								{
									oText = JSON.parse(sText);
								}
								catch(e)
								{
									alert(this.oPlayer._GetString({ sId: "settings-JSON-malformed" }).split("%1").join( this.oPlayer._GetString({ sId: "settings-label-local-vars" }) ));
									return this;
								}
							}
						}
						if(this.oFlds["CONFIG"]!=null)
						{
							sText = this.oFlds["CONFIG"]._GetValue();
							if(sText!=null && sText!="")
							{
								try
								{
									oText = JSON.parse(sText);
								}
								catch(e)
								{
									alert(this.oPlayer._GetString({ sId: "settings-JSON-malformed" }).split("%1").join( this.oPlayer._GetString({ sId: "settings-label-CONFIG" }) ));
									return this;
								}
							}
						}
						for(sKey in this.oFlds)
						{
							if(sKey=="sample_object_id")
							{
								this.oPlayer.oCurrentWebModeCopy.sample_object_id = this.oFlds[sKey]._GetValue();
								this.oPlayer.oCurrentWebModeCopy.sample_object_title = (this.oPlayer.oCurrentWebModeCopy.sample_object_id!="") ? this.oFlds[sKey].jFldValue.html() : "";
							}
							else if(sKey=="metrics" || sKey=="local_vars" || sKey=="CONFIG")
							{
								sVarName = "webmode." + sKey;
								aWVars.push({ name: sVarName, value: TOOLS.Base64.Encode({ sString: this.oFlds[sKey]._GetValue() }), type: this.oFlds[sKey].oFld.type });
							}
							else
							{
								sVarName = "webmode." + sKey;
								aWVars.push({ name: sVarName, value: this.oFlds[sKey]._GetValue({ bString: true }), type: this.oFlds[sKey].oFld.type });
							}
						}
						this.oPlayer.oCurrentWebModeCopy.wvars = JSON.parse(JSON.stringify(aWVars));
						this.oPage.SaveSettings();
						break;
					}
					case "objects":
					{
						for(sKey in this.oBtns)
						{
							if(this.oBtns.hasOwnProperty(sKey))
							{
								if(this.oBtns[sKey].bSelected)
								{
									this.oPage.oEditor.AppendItem({ sId: sKey, bMacro: (this.oBtns[sKey].bMacro == true), oTarget: this.oTarget });
									break;
								}
							}
						}
						break;
					}
					case "select-file":
					{
						if(oThis.oSelectedItem != null)
						{
							if(oThis.oTarget != null)
							{
								if(oThis.oTarget instanceof CXFld)
								{
									oThis.oTarget.SetValue({ sValue: oThis.oSelectedItem.oFile.url, oFile: oThis.oSelectedItem.oFile });
								}
							}
						}
						break;
					}
				}
				oThis.Hide();
				oThis.sTargetGroupId = null;
				break;
			}
            case "dialog-cancel":
			{
				oThis.Hide();
				oThis.sTargetGroupId = null;
				break;
			}
        }
        return oThis;
    };
    CXDialog.prototype.Update = function(oArgs)
	{
        var oThis = this;
        var i, iIdx;
        switch(oThis.sType)
		{
            case "settings":
			{
				if(this.oPlayer.oCurrentWebModeCopy.wvars!=null)
				{
					var sVarName;
					for(i=0; i<this.oPlayer.oCurrentWebModeCopy.wvars.length; i++)
					{
						if(this.oPlayer.oCurrentWebModeCopy.wvars[i].name.indexOf(".")!=-1)
						{
							sVarName = this.oPlayer.oCurrentWebModeCopy.wvars[i].name.split(".")[1];
							if(this.oFlds[sVarName]!=null)
							{
								if(sVarName=="metrics" || sVarName=="local_vars" || sVarName=="CONFIG")
								{
									this.oFlds[sVarName].SetValue({ sValue: TOOLS.Base64.Decode({ sString: this.oPlayer.oCurrentWebModeCopy.wvars[i].value }) });
								}
								else
								{
									this.oFlds[sVarName].SetValue({ sValue: this.oPlayer.oCurrentWebModeCopy.wvars[i].value });
								}
							}
						}
					}
					if(this.oPlayer.oCurrentWebModeCopy.catalog_name!=null && this.oPlayer.oCurrentWebModeCopy.catalog_name!="")
					{
						this.jBlockSample.show();
						this.oFlds["sample_object_id"].oFld.catalog = this.oPlayer.oCurrentWebModeCopy.catalog_name;
						this.oFlds["sample_object_id"].SetValue({ sValue: this.oPlayer.oCurrentWebModeCopy.sample_object_id, sName: this.oPlayer.oCurrentWebModeCopy.sample_object_title });
					}
					else
					{
						this.jBlockSample.hide();
					}
				}
				else
				{
					for(var sKey in this.oFlds)
					{
						if(sKey=="sample_object_id")
						{
							if(this.oPlayer.oCurrentWebModeCopy.catalog_name!=null && this.oPlayer.oCurrentWebModeCopy.catalog_name!="")
							{
								this.jBlockSample.show();
								this.oFlds["sample_object_id"].oFld.catalog = this.oPlayer.oCurrentWebModeCopy.catalog_name;
								this.oFlds["sample_object_id"].SetValue({ sValue: this.oPlayer.oCurrentWebModeCopy.sample_object_id, sName: this.oPlayer.oCurrentWebModeCopy.sample_object_title });
							}
							else
							{
								this.jBlockSample.hide();
							}
						}
						else
						{
							this.oFlds[sKey].SetValue({ sValue: this.oFlds[sKey].sDefaultValue });
						}
					}
				}
				break;
			}
			case "select-file":
			{
				var sNewResourceId = null;
				var sUpdatedRepoId = null;
				for(i=0; i<oArgs.oData.last.update.length; i++)
				{
					if(oArgs.oData.last.update[i].target == "repo")
					{
						sUpdatedRepoId = oArgs.oData.last.update[i].ids[0];
					}
					else if(oArgs.oData.last.update[i].target == "resource")
					{
						sNewResourceId = oArgs.oData.last.update[i].ids[0];
					}
				}
				if(sNewResourceId != null && sUpdatedRepoId != null)
				{
					oThis.jRepoSelect.val(sUpdatedRepoId);
					iIdx = -1;
					for(i=0; i<oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files.length; i++)
					{
						if(oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files[i].id == sNewResourceId)
						{
							iIdx = i;
							break;
						}
					}
					if(iIdx == -1)
					{
						for(i=0; i<oArgs.oData.repositoriums[sUpdatedRepoId].files.length; i++)
						{
							if(oArgs.oData.repositoriums[sUpdatedRepoId].files[i].id == sNewResourceId)
							{
								oArgs.oData.repositoriums[sUpdatedRepoId].files[i].repo_id = sUpdatedRepoId;
								oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files.push(JSON.parse(JSON.stringify(oArgs.oData.repositoriums[sUpdatedRepoId].files[i])));
								oThis.oPlayer.oStore["files"].UpdateSingleItem({ sId: sNewResourceId, oItem: oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files[oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files.length - 1] });
								oThis.oFileList[sNewResourceId] = new CXFileItem({ oPlayer: oThis.oPlayer, oDialog: oThis, oRepo: oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId], oFile: oThis.oPlayer.oStore["files"].oData[sNewResourceId], jList: oThis.jFileList, bPrepend: true }).Select();
								break;
							}
						}
					}
					else
					{
						if(oThis.oPlayer.oStore["files"].oData[sNewResourceId] == null)
						{
							oThis.oPlayer.oStore["files"].UpdateSingleItem({ sId: sNewResourceId, oItem: oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files[iIdx] });
						}
						oThis.oFileList[sNewResourceId] = new CXFileItem({ oPlayer: oThis.oPlayer, oDialog: oThis, oRepo: oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId], oFile: oThis.oPlayer.oStore["files"].oData[sNewResourceId], jList: oThis.jFileList, bPrepend: true }).Select();
					}
					oThis.jRepoSelect.find("option[value='" + sUpdatedRepoId + "']").html(oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].name + " (" + oThis.oPlayer.oStore["repos"].oData[sUpdatedRepoId].files.length + ")");
					oThis.jRepoSelect.selectmenu("refresh");
				}
				break;
			}
        }
        return oThis;
    };
}
{ // CXEditor
    window.CXEditor = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oPage = oArgs.oPage;
        this.oBlocks = {};
        this.oXBlocks = {};
        this.aOrder = [];
        this.oOrder = {};
        this.nW = this.oPlayer.oConfig.nZoneW;
        this.nRatio = 1;
        this.nUnscale = 1;
        this.sSelectedId = null;
        this.sSelectedMacro = null;
        this.oChanged = {};
        this.bStateLocked = false;
        this.aChangedOWTs = [];
		this.oContextByOWT = {};
		this.aUsedContext = [];
		this.iContextTimeout = 0;
        this.Constructor();
        return this;
    };
    CXEditor.prototype = Object.create(WTBaseObject.prototype);
    CXEditor.prototype.constructor = CXEditor;
    CXEditor.prototype._CleanupBeforeSend = function(oArgs)
	{
        var i, j, k, l;
        var iIdx;
        var oToSave = oArgs.oToClean;

        delete oToSave.web_mode.error;
        delete oToSave.web_mode.error_text;
        delete oToSave.web_mode.name;
        delete oToSave.web_mode._sortname;
        delete oToSave.web_mode.url;
        delete oToSave.web_mode.modification_date;
        delete oToSave.web_mode.creation_date;
        if(oToSave.web_mode.collections != null)
		{
            delete oToSave.web_mode.collections;
        }
        if(oToSave.web_mode.all_collections != null)
		{
            delete oToSave.web_mode.all_collections;
        }
        if(oToSave.web_mode.remote_actions != null)
		{
            delete oToSave.web_mode.remote_actions;
        }
        if(oToSave.web_mode.all_actions != null)
		{
            delete oToSave.web_mode.all_actions;
        }
        if(oToSave.web_mode.object_fields != null)
		{
            delete oToSave.web_mode.object_fields;
        }
        if(oToSave.web_mode.user_fields != null)
		{
            delete oToSave.web_mode.user_fields;
        }
        if(oToSave.web_mode.context != null)
		{
            delete oToSave.web_mode.context;
        }
        if(oToSave.web_mode.env != null)
		{
            delete oToSave.web_mode.env;
        }
        if(oToSave.web_mode.doc_fields != null)
		{
            delete oToSave.web_mode.doc_fields;
        }

        for(i=0; i<oToSave.web_mode.zones.length; i++)
		{
            if(oToSave.web_mode.zones[i].name == "main")
			{
                for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
				{
                    if(oToSave.web_mode.zones[i].templates[j] == null)
					{
                        continue;
                    }
                    delete oToSave.web_mode.zones[i].templates[j].name;
                    delete oToSave.web_mode.zones[i].templates[j].url;
                    delete oToSave.web_mode.zones[i].templates[j].aTree;
                    delete oToSave.web_mode.zones[i].templates[j].oTree;
                    if(oToSave.web_mode.zones[i].templates[j].templates != null)
					{
                        for(k=0; k<oToSave.web_mode.zones[i].templates[j].templates.length; k++)
						{
                            delete oToSave.web_mode.zones[i].templates[j].templates[k]._sortname;
                            delete oToSave.web_mode.zones[i].templates[j].templates[k].url;
                            delete oToSave.web_mode.zones[i].templates[j].templates[k].aTree;
                            delete oToSave.web_mode.zones[i].templates[j].templates[k].oTree;
                            if(oArgs.bNoParams)
							{
                                delete oToSave.web_mode.zones[i].templates[j].templates[k].params;
                            }
							else
							{
                                if(oToSave.web_mode.zones[i].templates[j].templates[k].params != null)
								{
                                    for(l = 0; l < oToSave.web_mode.zones[i].templates[j].templates[k].params.length; l++)
									{
                                        delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].catalog;
                                        delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].entries;
                                        delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].description;
                                        delete oToSave.web_mode.zones[i].templates[j].templates[k].params[l].view;
                                    }
                                }
                            }
                        }
                    }
                    if(oArgs.bNoParams)
					{
                        delete oToSave.web_mode.zones[i].templates[j].params;
                    }
					else
					{
                        if(oToSave.web_mode.zones[i].templates[j].params != null)
						{
                            for(l = 0; l < oToSave.web_mode.zones[i].templates[j].params.length; l++)
							{
                                delete oToSave.web_mode.zones[i].templates[j].params[l].catalog;
                                delete oToSave.web_mode.zones[i].templates[j].params[l].entries;
                                delete oToSave.web_mode.zones[i].templates[j].params[l].description;
                                delete oToSave.web_mode.zones[i].templates[j].params[l].view;
                            }
                        }
                    }
                }
                var aTmp = [];
                for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
				{
                    if(oToSave.web_mode.zones[i].templates[j] != null)
					{
                        aTmp.push(oToSave.web_mode.zones[i].templates[j]);
                    }
                }
                oToSave.web_mode.zones[i].templates = JSON.parse(JSON.stringify(aTmp));
            }
        }
        return oToSave;
    };
	CXEditor.prototype._FindInMacro = function(oArgs)
	{
		var aTmp = [];
		for(var i=0; i<oArgs.aTemplates.length; i++)
		{
			if(oArgs.aTemplates[i].override_template_id==oArgs.sId)
			{
				aTmp.push({ iIdx: i, sId: oArgs.sId });
				break;
			}
			else if(this._IsMacro({ oTemplate: oArgs.aTemplates[i] }))
			{
				if(oArgs.aTemplates[i].templates!=null)
				{
					aTmp = this._FindInMacro({ aTemplates: oArgs.aTemplates[i].templates, sId: oArgs.sId });
					if(aTmp.length!=0)
					{
						aTmp.unshift({ iIdx: i, sId: oArgs.aTemplates[i].override_template_id });
						break;
					}
				}
			}
		}
		return aTmp;
	};
    CXEditor.prototype._GetChangedOWT = function(oArgs)
	{
        var i, j, k;
        var sKey, sKey2;
        var aOWTs = [];
        var oOWT_Base = {};
        var oOWT_Copy = {};
        var oOWT_Children_Copy = {};
        var oOWT_Children_Base = {};
        for(i=0; i<this.oPlayer.oCurrentWebModeCopy.zones.length; i++)
		{
            if(this.oPlayer.oCurrentWebModeCopy.zones[i].templates.length != this.oPlayer.oCurrentWebMode.zones[i].templates.length)
			{
                // level 0 is always equal?
            }
			else
			{
                // order is also the same for level 0
                for(j=0; j<this.oPlayer.oCurrentWebModeCopy.zones[i].templates.length; j++)
				{
                    oOWT_Copy[this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].override_template_id] = this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j];
                }
                for(j=0; j<this.oPlayer.oCurrentWebMode.zones[i].templates.length; j++)
				{
                    oOWT_Base[this.oPlayer.oCurrentWebMode.zones[i].templates[j].override_template_id] = this.oPlayer.oCurrentWebMode.zones[i].templates[j];
                }
                for(sKey in oOWT_Copy)
				{
                    if(this._IsChanged({ oBase: oOWT_Base[sKey], oCopy: oOWT_Copy[sKey] }))
					{
                        aOWTs.push(sKey);
                    }
                    if(oOWT_Copy[sKey].templates != null)
					{
                        oOWT_Children_Copy = {};
                        oOWT_Children_Base = {};
                        for(j=0; j<oOWT_Copy[sKey].templates.length; j++)
						{
                            oOWT_Children_Copy[oOWT_Copy[sKey].templates[j].override_template_id] = oOWT_Copy[sKey].templates[j];
                        }
                        if(oOWT_Base[sKey].templates == null)
						{
                            if($.inArray(sKey, aOWTs) == -1)
							{
                                aOWTs.push(sKey);
                            }
                        }
						else
						{
                            for(j=0; j<oOWT_Base[sKey].templates.length; j++)
							{
                                oOWT_Children_Base[oOWT_Base[sKey].templates[j].override_template_id] = oOWT_Base[sKey].templates[j];
                            }
                            for(sKey2 in oOWT_Children_Copy)
							{
                                if(oOWT_Children_Base[sKey2] == null)
								{
                                    aOWTs.push(sKey2);
                                }
								else if(this._IsChanged({ oBase: oOWT_Children_Base[sKey2], oCopy: oOWT_Children_Copy[sKey2] }))
								{
                                    aOWTs.push(sKey2);
                                }
                            }
                        }
                    }
                }
            }
        }
        return aOWTs;
    };
    CXEditor.prototype._GetOWTCopy = function(oArgs)
	{
        var i, j, k;
        var oOWT = null;
		_main_loop:
        for(i=0; i<this.oPlayer.oCurrentWebModeCopy.zones.length; i++)
		{
            if(this.oPlayer.oCurrentWebModeCopy.zones[i].templates.length != this.oPlayer.oCurrentWebMode.zones[i].templates.length)
			{
                // level 0 is always equal?
            }
			else
			{
                // order is also the same for level 0
                for(j=0; j<this.oPlayer.oCurrentWebModeCopy.zones[i].templates.length; j++)
				{
					if(this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].override_template_id==oArgs.sId)
					{
						oOWT = this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j];
						break _main_loop;
					}
					if(this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].templates!=null)
					{
						for(k=0; k<this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].templates.length; k++)
						{
							if(this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].templates[k].override_template_id==oArgs.sId)
							{
								oOWT = this.oPlayer.oCurrentWebModeCopy.zones[i].templates[j].templates[k];
								break _main_loop;
							}
						}
					}
               }
			}
		}
        return oOWT;
    };
    CXEditor.prototype._GetMacroZonesFldName = function(oArgs)
	{
        var sName = false;
        if(oArgs.oTemplate.params != null)
		{
            for(var i = 0; i<oArgs.oTemplate.params.length; i++)
			{
                if(oArgs.oTemplate.params[i].name.indexOf("__service__zones") != -1)
				{
                    sName = oArgs.oTemplate.params[i].name;
                    break;
                }
            }
        }
        return sName;
    };
    CXEditor.prototype._GetMainZone = function(oArgs)
	{
        var oZone = null;
        if(oArgs != null)
		{
            if(oArgs.aZones != null)
			{
                if(oArgs.aZones.constructor === Array)
				{
                    for(var i = 0; i<oArgs.aZones.length; i++)
					{
                        if(oArgs.aZones[i].name == "main")
						{
                            oZone = oArgs.aZones[i];
                            break;
                        }
                    }
                }
            }
        }
        return oZone;
    };
    CXEditor.prototype._GetParam = function(oArgs)
	{
        var vParam = null;
        if(oArgs != null)
		{
            if(oArgs.aParams != null)
			{
                if(oArgs.aParams.constructor === Array && oArgs.sName != null && oArgs.sName != "")
				{
                    var bContains = (oArgs.bContains == true);
                    for(var i = 0; i<oArgs.aParams.length; i++)
					{
                        if(oArgs.sParentName!=null)
						{
							if(oArgs.aParams[i].parent_wvar_name!=oArgs.sParentName)
							{
								continue;
							}
						}
                        if(bContains)
						{
                            if(oArgs.aParams[i].name.indexOf(oArgs.sName) != -1)
							{
                                if(oArgs.bObject==true)
								{
									vParam = oArgs.aParams[i];
								}
								else
								{
									vParam = oArgs.aParams[i].value;
								}
                                break;
                            }
                        }
						else
						{
                            if(oArgs.aParams[i].name == oArgs.sName)
							{
                                if(oArgs.bObject==true)
								{
									vParam = oArgs.aParams[i];
								}
								else
								{
									vParam = oArgs.aParams[i].value;
								}
                                break;
                            }
                        }
                    }
                }
            }
        }
        return vParam;
    };
    CXEditor.prototype._GetParamName = function(oArgs)
	{
        var sParam = null;
        if(oArgs != null)
		{
            if(oArgs.aParams != null)
			{
                if(oArgs.aParams.constructor === Array && oArgs.sName != null && oArgs.sName != "")
				{
                    for(var i = 0; i<oArgs.aParams.length; i++)
					{
                        if(oArgs.aParams[i].name.indexOf(oArgs.sName) != -1)
						{
                            sParam = oArgs.aParams[i].name;
                            break;
                        }
                    }
                }
            }
        }
        return sParam;
    };
    CXEditor.prototype._GetParentMacro = function(oArgs)
	{
        var i;
        var oParent = null;
        var aZones;
        for(i=0; i<oArgs.aTemplates.length; i++)
		{
            aZones = this._MacroZones({ oTemplate: oArgs.aTemplates[i] });
            if(aZones.length != 0)
			{
                if($.inArray(oArgs.sId, aZones) != -1)
				{
                    oParent = oArgs.aTemplates[i];
                    break;
                }
            }
        }
        return oParent;
    };
    CXEditor.prototype._GetTemplateById = function(oArgs)
	{
        var oTemplate = null;
        _loop_i:
		for(var i = 0; i<oArgs.aTemplates.length; i++)
		{
			if(oArgs.aTemplates[i].override_template_id == oArgs.sId)
			{
				oTemplate = oArgs.aTemplates[i];
				break;
			}
			if(this._IsMacro({ oTemplate: oArgs.aTemplates[i] }))
			{
				if(oArgs.aTemplates[i].templates != null)
				{
					for(var j = 0; j<oArgs.aTemplates[i].templates.length; j++)
					{
						if(oArgs.aTemplates[i].templates[j].override_template_id == oArgs.sId)
						{
							oTemplate = oArgs.aTemplates[i].templates[j];
							break;
						}
					}
				}
			}
		}
        return oTemplate;
    };
    CXEditor.prototype._IsChanged = function(oArgs)
	{
        var i;
        var sKey;
        var bChanged = false;
        var oParamsBase = {};
        var oParamsCopy = {};
        for(i=0; i<oArgs.oBase.params.length; i++)
		{
            oParamsBase[TOOLS.EncodeVarName({ sText: oArgs.oBase.params[i].name })] = oArgs.oBase.params[i];
        }
        var sVarName;
        for(i=0; i<oArgs.oCopy.params.length; i++)
		{
            sVarName = TOOLS.EncodeVarName({ sText: oArgs.oCopy.params[i].name });
            if(oParamsBase[sVarName] == null)
			{
                bChanged = true;
                break;
            }
			else if(oParamsBase[sVarName].value != oArgs.oCopy.params[i].value)
			{
                bChanged = true;
                break;
            }
        }
        if(!bChanged && oArgs.oCopy.templates != null)
		{
            if(oArgs.oBase.templates == null)
			{
                bChanged = true;
            }
			else if(oArgs.oCopy.templates.length != oArgs.oBase.templates.length)
			{
                bChanged = true;
            }
			else
			{
                for(i=0; i<oArgs.oCopy.templates; i++)
				{
                    if(oArgs.oCopy.templates[i].overrode_template_id != oArgs.oBase.templates[i].overrode_template_id)
					{
                        bChanged = true;
                        break;
                    }
                }
            }
        }
        return bChanged;
    };
    CXEditor.prototype._IsChild = function(oArgs)
	{
        var bIsChild = false;
        var i;
        var aChildren = [];
        var aZones;
        for(i=0; i<oArgs.aTemplates.length; i++)
		{
            aZones = this._MacroZones({ oTemplate: oArgs.aTemplates[i] });
            if(aZones.length != 0)
			{
                aChildren = aChildren.concat(aZones);
            }
        }
        return ($.inArray(oArgs.sId, aChildren) != -1);
    };
    CXEditor.prototype._IsMacro = function(oArgs)
	{
        return this.oPlayer.oStore["macros"]._Contains({ sId: oArgs.oTemplate.id });
    };
    CXEditor.prototype._MacroZones = function(oArgs)
	{
        var aZones = [];
        if(oArgs.oTemplate.params != null)
		{
            for(var i = 0; i<oArgs.oTemplate.params.length; i++)
			{
                if(oArgs.oTemplate.params[i].name.indexOf("__service__zones") != -1)
				{
                    if(oArgs.oTemplate.params[i].value != "")
					{
                        aZones = JSON.parse(oArgs.oTemplate.params[i].value);
                        break;
                    }
                }
            }
        }
        return (typeof aZones == "object") ? (aZones.constructor === Array ? aZones : []) : [];
    };
    CXEditor.prototype._SortByWeightAscending = function(oElem1, oElem2)
	{
        return ((oElem1.iWeight > oElem2.iWeight) ? 1 : ((oElem1.iWeight < oElem2.iWeight) ? -1 : 0));
    };
    CXEditor.prototype.Adjust = function(oArgs)
	{
        if(this.jViewContainer.is(":visible"))
		{
            var nW = this.jViewWrapper.width() - 24; // some space for optional scrollbar
            var nMinW = 1.2 * this.oPlayer.oConfig.nZoneW;
            var nRatio = nW / nMinW;
            if(nRatio < 1)
			{
                this.nRatio = nRatio;
                this.nUnscale = 1 / nRatio;
                this.nW = nMinW;
                this.jViewWrapper.css({ "width": nW + "px", "min-width": nW + "px", "max-width": nW + "px" });
                this.jViewContainer.css({ "width": nMinW + "px", "min-width": nMinW + "px", "max-width": nMinW + "px", "transform": "scale(" + nRatio + "," + nRatio + ")" });
            }
        }
        return this;
    };
    CXEditor.prototype.AppendItem = function(oArgs)
	{
        var oThis = this;
        var i, j, k;
        var sId = TOOLS.ShortID();
        var sTemplateId = oArgs.sId;
        var sStoreId = ((oArgs.bMacro == true) ? "macros" : "templates");
        var oToSave =
		{
            action: "save_web_mode_structure",
            web_mode_id: this.oPlayer.sCurrentPageId,
            web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
        };

        var oTargetZone = this._GetMainZone({ aZones: oToSave.web_mode.zones });
        var oSourceZone = this._GetMainZone({ aZones: this.oPlayer.oCurrentWebModeCopy.zones });

        if(oTargetZone != null && oSourceZone != null)
		{
            delete oTargetZone.templates; // cleanup before appending one by one - to keep it simple
            oTargetZone.templates = [];
            // sort templates by weight excluding children
            var aIdxs = [];
            for(i=0; i<oSourceZone.templates.length; i++)
			{
                if(!this._IsChild({ sId: oSourceZone.templates[i].id, aTemplates: oSourceZone.templates }))
				{
                    aIdxs.push({ iIdx: i, iWeight: oSourceZone.templates[i].weight });
                }
            }
            aIdxs.sort(this._SortByWeightAscending);
            var iSelectedIdx = -1;
            for(i=0; i<aIdxs.length; i++) // append in weight order
            {
                oTargetZone.templates.push(JSON.parse(JSON.stringify(oSourceZone.templates[aIdxs[i].iIdx])));
                /*if(oTargetZone.templates[i].templates!=null)
                {
                	delete oTargetZone.templates[i].templates;
                	oTargetZone.templates[i].templates = [];  // children to be rearranged later
                }*/
                if(oTargetZone.templates[i].params != null)
				{
                    delete oTargetZone.templates[i].params; // save structure only
                }
                if(this.sSelectedId != null && this.sSelectedId != "")
				{
                    if(oTargetZone.templates[i].override_template_id == this.sSelectedId)
					{
                        iSelectedIdx = i;
                    }
                }
            }
            if(oArgs.oTarget == null) // insert new one if level 0
            {
                var oNewTemplate;
                if(iSelectedIdx != -1 && iSelectedIdx != aIdxs.length - 1) // insert after selected one
                {
                    oTargetZone.templates.splice((iSelectedIdx + 1), 0, JSON.parse(JSON.stringify(this.oPlayer.oStore[sStoreId].oData[sTemplateId])));
                    oNewTemplate = oTargetZone.templates[iSelectedIdx + 1];
                }
				else // append to end
                {
                    oTargetZone.templates.push(JSON.parse(JSON.stringify(this.oPlayer.oStore[sStoreId].oData[sTemplateId])));
                    oNewTemplate = oTargetZone.templates[oTargetZone.templates.length - 1];
                }
                oNewTemplate.override_template_id = "";
                if(oArgs.bMacro)
				{
                    oNewTemplate.templates = [];
                }
                if(oNewTemplate.params != null)
				{
                    delete oNewTemplate.params;
                }
            }
			else
			{
                var oMacro = this._GetTemplateById({ aTemplates: oTargetZone.templates, sId: oArgs.oTarget.sId });
                var aOldChildren = [];
                if(oMacro.templates != null)
				{
                    aOldChildren = JSON.parse(JSON.stringify(oMacro.templates));
                    delete oMacro.templates;
                }
                oMacro.templates = [];
				var sSelectedBlockId = null;
				var oChildren = {};
				var iLastIdx;
				switch(oArgs.oTarget.sStackType)
				{
					case "tabs":
					{
						this.aServiceZones = JSON.parse(this._GetParam({ aParams: oArgs.oTarget.oParent.oOWT.params, sName: ".__service__zones", bContains: true }));
						var aTabs = JSON.parse(this._GetParam({ aParams: oArgs.oTarget.oParent.oOWT.params, sName: ".items", bContains: true })); // oArgs.oTarget.aStacks ?
						var iTabSelected = oArgs.oTarget.iTabSelected;
						sSelectedBlockId = oArgs.oTarget.sSelectedBlockId;
						if(typeof this.aServiceZones != "object")
						{
							this.aServiceZones = [];
						}
						if(this.aServiceZones.constructor !== Array)
						{
							this.aServiceZones = [];
						}
						for(i=0; i<aTabs.length; i++)
						{
							if(this.aServiceZones[i] == null)
							{
								this.aServiceZones[i] = [];
							}
						}
						// append new
						_loop_i:
						for(i=0; i<aTabs.length; i++)
						{
							if(i == iTabSelected)
							{
								if(this.aServiceZones[i].length == 0 || sSelectedBlockId == null)
								{
									this.aServiceZones[i].push("NEW_" + sTemplateId);
									break;
								}
								else
								{
									for(j=0; j<this.aServiceZones[i].length; j++)
									{
										if(this.aServiceZones[i][j] == sSelectedBlockId)
										{
											this.aServiceZones[i].splice(j + 1, 0, "NEW_" + sTemplateId);
											break _loop_i;
										}
									}
								}
							}
						}
						for(i=0; i<aOldChildren.length; i++)
						{
							oChildren[aOldChildren[i].override_template_id] = aOldChildren[i];
						}
						// new service zones created, now fill macro.templates
						for(i=0; i<this.aServiceZones.length; i++)
						{
							for(j=0; j<this.aServiceZones[i].length; j++)
							{
								sOWTId = this.aServiceZones[i][j];
								if(sOWTId.indexOf("NEW_") != -1)
								{
									oMacro.templates.push(JSON.parse(JSON.stringify(this.oPlayer.oStore[sStoreId].oData[sTemplateId])));
									iLastIdx = oMacro.templates.length - 1;
									oMacro.templates[iLastIdx].override_template_id = "";
								}
								else
								{
									oMacro.templates.push(oChildren[JSON.parse(JSON.stringify(sOWTId))]);
									iLastIdx = oMacro.templates.length - 1;
								}
								oMacro.templates[iLastIdx].weight = 1000 * (i + 1) + 10 * (j + 1);
								delete oMacro.templates[iLastIdx].params;
							}
						}
						break;
					}
					case "horizontal":
					{
						this.aServiceZones = JSON.parse(this._GetParam({ aParams: oArgs.oTarget.oParent.oOWT.params, sName: ".__service__zones", bContains: true }));
						var aColumns = JSON.parse(this._GetParam({ aParams: oArgs.oTarget.oParent.oOWT.params, sName: ".columns", bContains: true })); // oArgs.oTarget.aStacks ?
						var iColumnSelected = oArgs.oTarget.iColumnSelected;
						sSelectedBlockId = oArgs.oTarget.sSelectedBlockId;
						if(typeof this.aServiceZones != "object")
						{
							this.aServiceZones = [];
						}
						if(this.aServiceZones.constructor !== Array)
						{
							this.aServiceZones = [];
						}
						// append new
						for(i=0; i<aColumns.length; i++)
						{
							if(this.aServiceZones[i] == null)
							{
								this.aServiceZones[i] = [];
							}
						}
						_loop_i:
						for(i=0; i<aColumns.length; i++)
						{
							if(i == iColumnSelected)
							{
								if(this.aServiceZones[i].length == 0 || sSelectedBlockId == null)
								{
									this.aServiceZones[i].push("NEW_" + sTemplateId);
									break;
								}
								else
								{
									for(j=0; j<this.aServiceZones[i].length; j++)
									{
										if(this.aServiceZones[i][j] == sSelectedBlockId)
										{
											this.aServiceZones[i].splice(j + 1, 0, "NEW_" + sTemplateId);
											break _loop_i;
										}
									}
								}
							}
						}
						for(i=0; i<aOldChildren.length; i++)
						{
							oChildren[aOldChildren[i].override_template_id] = aOldChildren[i];
						}
						// new service zones created, now fill macro.templates
						for(i=0; i<this.aServiceZones.length; i++)
						{
							for(j=0; j<this.aServiceZones[i].length; j++)
							{
								sOWTId = this.aServiceZones[i][j];
								if(sOWTId.indexOf("NEW_") != -1)
								{
									oMacro.templates.push(JSON.parse(JSON.stringify(this.oPlayer.oStore[sStoreId].oData[sTemplateId])));
									iLastIdx = oMacro.templates.length - 1;
									oMacro.templates[iLastIdx].override_template_id = "";
								}
								else
								{
									oMacro.templates.push(oChildren[JSON.parse(JSON.stringify(sOWTId))]);
									iLastIdx = oMacro.templates.length - 1;
								}
								oMacro.templates[iLastIdx].weight = 1000 * (i + 1) + 10 * (j + 1);
								delete oMacro.templates[iLastIdx].params;
							}
						}
						break;
					}
					case "vertical":
					{
						aIdxs = [];
						for(i=0; i<aOldChildren.length; i++)
						{
							aIdxs.push({ iIdx: i, iWeight: aOldChildren[i].weight, sOWTId: aOldChildren[i].override_template_id });
						}
						aIdxs.sort(this._SortByWeightAscending);
						iSelectedIdx = -1;
						if(this.sSelectedId != oArgs.oTarget.sId)
						{
							for(i=0; i<aIdxs.length; i++)
							{
								if(aIdxs[i].sOWTId == this.sSelectedId)
								{
									iSelectedIdx = i;
									break;
								}
							}
						}
						if(iSelectedIdx == -1) // append to end
						{
							aIdxs.push({ sOWTId: "" });
						}
						else
						{
							aIdxs.splice(iSelectedIdx + 1, 0, { sOWTId: "" });
						}
						for(i=0; i<aIdxs.length; i++)
						{
							if(aIdxs[i].sOWTId == "") // insert new
							{
								oMacro.templates.push(JSON.parse(JSON.stringify(this.oPlayer.oStore[sStoreId].oData[sTemplateId])));
								oMacro.templates[i].override_template_id = "";
							}
							else
							{
								oMacro.templates.push(aOldChildren[aIdxs[i].iIdx]);
							}
							delete oMacro.templates[i].params;
							oMacro.templates[i].weight = 10 * (i + 1);
						}
						break;
					}
				}
            }
            this.oPlayer.aLoading.push("_NEW");
            for(i=0; i<oTargetZone.templates.length; i++) // finally, recalc weights for level 0
            {
                oTargetZone.templates[i].weight = 10 * (i + 1);
            }
            /* level 0 completed, let's make children */
        }

        if(oArgs.oTarget != null) // append to macro
        {
            this.Load(
			{
                sURL: this.oPlayer.oConfig.sRootAPIURL,
                sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: false })))),
                oContext: this,
                fnSuccess: this.Update,
                oSuccessArgs: { sItemId: sId, sTemplateId: sTemplateId, bAfterAppend: true, oTarget: oArgs.oTarget }
            });
        }
		else // append to root
        {
            this.Load(
			{
                sURL: this.oPlayer.oConfig.sRootAPIURL,
                sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: false })))),
                oContext: this,
                fnSuccess: this.Update,
                oSuccessArgs: { sItemId: sId, sTemplateId: sTemplateId, bAfterAppend: true }
            });
        }
        return this;
    };
    CXEditor.prototype.ApplyUpdatedParams = function (oArgs)
	{ // create new params if params were changed
		var i;
		var oParams = {};
		switch(oArgs.oTemplate.id)
		{
			case "0x5B72A93333B55E41":
			{
				for(i=0; i<oArgs.oTemplate.params.length; i++)
				{
					oParams[oArgs.oTemplate.params[i].name] = oArgs.oTemplate.params[i];
				}
				if(oParams["block_list.font_family_text"]==null && oParams["block_list.font_family"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_list.font_family"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_list.font_family_text";
					oParams["block_list.font_family_text"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_list.font_family_custom_text"]==null && oParams["block_list.font_family_custom"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_list.font_family_custom"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_list.font_family_custom_text";
					oParams["block_list.font_family_custom_text"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_list.font_weight_text"]==null && oParams["block_list.font_weight"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_list.font_weight"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_list.font_weight_text";
					oParams["block_list.font_weight_text"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_list.font_style_text"]==null && oParams["block_list.font_style"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_list.font_style"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_list.font_style_text";
					oParams["block_list.font_style_text"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				break;
			}
			case "0x5B72A93333B55E29":
			{
				for(i=0; i<oArgs.oTemplate.params.length; i++)
				{
					oParams[oArgs.oTemplate.params[i].name] = oArgs.oTemplate.params[i];
				}
				if(oParams["block_quote.font_size_author"]==null && oParams["block_quote.font_size"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_quote.font_size"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_quote.font_size_author";
					oParams["block_quote.font_size_author"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				break;
			}
			case "0x5B0FF12E1F900D5F":
			{
				for(i=0; i<oArgs.oTemplate.params.length; i++)
				{
					oParams[oArgs.oTemplate.params[i].name] = oArgs.oTemplate.params[i];
				}
				if(oParams["block_picture.font_size"]==null && oParams["block_picture.text_size"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_picture.text_size"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_picture.font_size";
					oParams["block_picture.font_size"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				break;
			}
			case "0x5D15DF7C7BA01AF3":
			{
				for(i=0; i<oArgs.oTemplate.params.length; i++)
				{
					oParams[oArgs.oTemplate.params[i].name] = oArgs.oTemplate.params[i];
				}
				if(oParams["block_cards.font_size_header"]==null && oParams["block_cards.font_size"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_cards.font_size"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_cards.font_size_header";
					oParams["block_cards.font_size_header"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				break;
			}
			case "0x5B0FF12E1F900D5B":
			{
				for(i=0; i<oArgs.oTemplate.params.length; i++)
				{
					oParams[oArgs.oTemplate.params[i].name] = oArgs.oTemplate.params[i];
				}
				if(oParams["block_header.font_size_header"]==null && oParams["block_header.font_size"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_header.font_size"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_header.font_size_header";
					oParams["block_header.font_size_header"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_header.font_family_subheader"]==null && oParams["block_header.font_family"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_header.font_family"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_header.font_family_subheader";
					oParams["block_header.font_family_subheader"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_header.font_family_custom_subheader"]==null && oParams["block_header.font_family_custom"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_header.font_family_custom"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_header.font_family_custom_subheader";
					oParams["block_header.font_family_custom_subheader"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_header.font_weight_subheader"]==null && oParams["block_header.font_weight"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_header.font_weight"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_header.font_weight_subheader";
					oParams["block_header.font_weight_subheader"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				if(oParams["block_header.font_style_subheader"]==null && oParams["block_header.font_style"]!=null)
				{
					oArgs.oTemplate.params.push(JSON.parse(JSON.stringify(oParams["block_header.font_style"])));
					oArgs.oTemplate.params[oArgs.oTemplate.params.length-1].name = "block_header.font_style_subheader";
					oParams["block_header.font_style_subheader"] = oArgs.oTemplate.params[oArgs.oTemplate.params.length-1];
				}
				break;
			}
		}
		return this;
	};
	CXEditor.prototype.ApplyWVars = function(oArgs)
	{
        var i;
		if(this.oPlayer.oCurrentWebModeCopy.wvars!=null)
		{
			if(Array.isArray(this.oPlayer.oCurrentWebModeCopy.wvars))
			{
				if(this.oPlayer.oCurrentWebModeCopy.wvars.length>0)
				{
					var oCSS = {};
					var sVarName;
					for(i=0; i<this.oPlayer.oCurrentWebModeCopy.wvars.length; i++)
					{
						sVarName = (this.oPlayer.oCurrentWebModeCopy.wvars[i].name.indexOf(".")!=-1) ? this.oPlayer.oCurrentWebModeCopy.wvars[i].name.split(".")[1] : this.oPlayer.oCurrentWebModeCopy.wvars[i].name;
						oCSS[sVarName] = (this.oPlayer.oCurrentWebModeCopy.wvars[i].value==null || this.oPlayer.oCurrentWebModeCopy.wvars[i].value=="") ? "" : this.oPlayer.oCurrentWebModeCopy.wvars[i].value;
					}
					if(oCSS["bg_url"]=="" && oCSS["img_bg_page"]!="")
					{
						oCSS["bg_url"] = "download_file.html?file_id=" + oCSS["img_bg_page"];
					}
					this.jViewContainer.css({ "background-color": oCSS["color_bg_page"] });
					if(oCSS["bg_url"]!="")
					{
						this.jViewContainer.css({ "background-image": "url('" + oCSS["bg_url"] + "')", "background-repeat": oCSS["bg_repeat"], "background-position": oCSS["bg_position"], "background-size": oCSS["bg_size"] });
					}
					else
					{
						this.jViewContainer.css({ "background-image": "none" });
					}
				}
				else
				{
					this.jViewContainer.css({ "background-color": "", "background-image": "none" });
				}
			}
			else
			{
				this.jViewContainer.css({ "background-color": "", "background-image": "none" });
			}
		}
		else
		{
			this.jViewContainer.css({ "background-color": "", "background-image": "none" });
		}
        return this;
    };
    CXEditor.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jViewContainer = this.jContainer.find("[cx-role='view-container']");
        this.jViewWrapper = this.jContainer.find("[cx-role='view-wrapper']");
        this.jFakeContainer = this.jContainer.find("[cx-role='fake-container']"); // invisible to place children of macro
        this.oPage.Subscribe({ sId: this.sId, sEvent: "shown", fn: oThis.Adjust, oContext: oThis, oArgs: { oElem: oThis } });
        return this;
    };
    CXEditor.prototype.Delete = function(oArgs)
	{
        var i, j, k;
        if(oArgs != null)
		{
            if(oArgs.oItem != null)
			{
                var oToSave =
				{
                    action: "save_web_mode_structure",
                    web_mode_id: this.oPlayer.sCurrentPageId,
                    web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
                };
                for(i=0; i<oToSave.web_mode.zones.length; i++)
				{
                    if(oToSave.web_mode.zones[i].name == "main")
					{
                        var iIdx = -1;
                        var oMacro = null;
                        _loop_j:
						for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
						{
							if(oToSave.web_mode.zones[i].templates[j].override_template_id == oArgs.oItem.sId)
							{
								iIdx = j;
								break;
							}
							else if(this._IsMacro({ oTemplate: oToSave.web_mode.zones[i].templates[j] }))
							{
								if(oToSave.web_mode.zones[i].templates[j].templates != null)
								{
									for(k=0; k<oToSave.web_mode.zones[i].templates[j].templates.length; k++)
									{
										if(oToSave.web_mode.zones[i].templates[j].templates[k].override_template_id == oArgs.oItem.sId)
										{
											iIdx = k;
											oMacro = oToSave.web_mode.zones[i].templates[j];
											break _loop_j;
										}
									}
								}
							}
						}
                        if(iIdx != -1)
						{
                            if(oMacro != null)
							{
                                /*var iServiceIdx = oMacro.params.findIndex(function (item) { return (item.name.indexOf(".__service__zones")!=-1); });
								if(iServiceIdx!=-1)
								{
									var aServiceArray = JSON.parse(oMacro.params[iServiceIdx].value);
									if(aServiceArray.length!=0)
									{
										var iIdxToRemove = -1;
										if(typeof aServiceArray[0] == "string") // plain vertical stack
										{
											iIdxToRemove = aServiceArray.findIndex(function (item) { return (item==oArgs.oItem.sId); });
											if(iIdxToRemove!=-1)
											{
												aServiceArray.splice(iIdxToRemove, 1);
											}
										}
										else if(typeof aServiceArray[0] == "object") // horiz. stack ot tabs
										{
											for(j=0; j<aServiceArray.length; j++)
											{
												iIdxToRemove = aServiceArray[j].findIndex(function (item) { return (item==oArgs.oItem.sId); });
												if(iIdxToRemove!=-1)
												{
													aServiceArray[j].splice(iIdxToRemove, 1);
													break;
												}
											}
										}
										oMacro.params[iServiceIdx].value = JSON.stringify(aServiceArray);
									}
								}*/
								oMacro.templates.splice(iIdx, 1);
                            }
							else
							{
                                oToSave.web_mode.zones[i].templates.splice(iIdx, 1);
                            }
                        }
                    }
                }
                this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { oItem: oArgs.oItem, bAfterDelete: true } });
            }
        }
        return this;
    };
	CXEditor.prototype.DeleteMacroChildren = function(oArgs)
	{
		var j;
		var oTemplate;
		var aToDelete = [];
		var iServiceIdx = oArgs.oMacro.params.findIndex(function (item) { return (item.name.indexOf(".__service__zones")!=-1); });
		if(iServiceIdx!=-1)
		{
			var aServiceArray = JSON.parse(oArgs.oMacro.params[iServiceIdx].value);
			if(aServiceArray.length!=0)
			{
				if(typeof aServiceArray[0] == "string") // plain vertical stack
				{
					aToDelete = JSON.parse(JSON.stringify(aServiceArray));
				}
				else if(typeof aServiceArray[0] == "object") // horiz. stack ot tabs
				{
					for(j=0; j<aServiceArray.length; j++)
					{
						aToDelete = aToDelete.concat(aServiceArray[j]);
					}
				}
				for(j=0; j<aToDelete.length; j++)
				{
					oTemplate = this._GetTemplateById({ aTemplates: oArgs.oMacro.templates, sId: aToDelete[j] });
					if(this._IsMacro({ oTemplate: oTemplate }))
					{
						this.DeleteMacroChildren({ oMacro: oTemplate });
					}
					if(this.oXBlocks[aToDelete[j]]!=null)
					{
						this.oXBlocks[aToDelete[j]].Delete();
						delete this.oXBlocks[aToDelete[j]];
					}
				}
			}
		}
		return this;
	};
    CXEditor.prototype.Fill = function(oArgs)
	{
        var i, j, k;
        var sKey;
        /* reset workarea and blocks */
        this.oPage.ModifyView({ sTarget: "btn-add-item", sAction: "reset" });
        this.jViewContainer.html("");
		this.ApplyWVars();
        this.aOrder = [];
        this.oXBlocks = {};
        this.oBlocksLoaded = {};
        if(Object.keys(this.oBlocks).length != 0)
		{
            for(sKey in this.oBlocks)
			{
                if(this.oBlocks.hasOwnProperty(sKey))
				{
                    this.oBlocks[sKey].Delete();
                    delete this.oBlocks[sKey];
                }
            }
        }
        this.oBlocks = {};

        var sOWTId, sParentId;
        var bIsMacro, bIsChild;
        var aChildren = [];
        var oTemplate = null;
        var oCurTemplate = null;
        var oParentOWT = null;
        var aLocalOrder = [];
        var oCurrentZone = this._GetMainZone({ aZones: this.oPlayer.oCurrentWebModeCopy.zones });

        if(oCurrentZone != null)
		{
            for(i=0; i<oCurrentZone.templates.length; i++)
			{
                aLocalOrder.push({ iWeight: oCurrentZone.templates[i].weight, iIdx: i });
            }
            aLocalOrder.sort(this._SortByWeightAscending);

            for(i=0; i<aLocalOrder.length; i++)
			{
                oCurTemplate = oCurrentZone.templates[aLocalOrder[i].iIdx];
				this.ApplyUpdatedParams({ oTemplate: oCurTemplate });
                sOWTId = oCurTemplate.override_template_id;
                this.aOrder.push(sOWTId);
                bIsMacro = this._IsMacro({ oTemplate: oCurTemplate });

                this.oXBlocks[sOWTId] = (new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jViewContainer, sId: sOWTId, oEditor: this, oOWT: oCurTemplate, sTemplateId: oCurTemplate.id, bIsMacro: bIsMacro, bIsChild: false, oParentOWT: null })).Update({ oTemplate: oCurTemplate });
                this.oXBlocks[sOWTId].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oCurTemplate } });

                if(bIsMacro) // create child blocks in fake container
                {
                    oParentOWT = oCurTemplate;
                    aChildren = this._MacroZones({ oTemplate: oCurTemplate }); // always returns array
                    for(j=0; j<aChildren.length; j++)
					{
                        if(typeof aChildren[j] == "object")
						{
                            if(aChildren[j].constructor === Array)
							{
                                for(k=0; k<aChildren[j].length; k++)
								{
                                    oTemplate = this._GetTemplateById({ aTemplates: oCurrentZone.templates, sId: aChildren[j][k] });
                                    if(oTemplate != null)
									{
                                        this.oXBlocks[aChildren[j][k]] = (new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jFakeContainer, sId: aChildren[j][k], oEditor: this, oOWT: oTemplate, sTemplateId: oTemplate.id, bIsMacro: false, bIsChild: true, oParentOWT: oCurTemplate })).Update({ oTemplate: oTemplate });
                                        this.oXBlocks[aChildren[j][k]].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oTemplate } });
                                    }
                                }
                            }
                        }
						else
						{
                            oTemplate = this._GetTemplateById({ aTemplates: oCurrentZone.templates, sId: aChildren[j] });
                            if(oTemplate != null)
							{
                                this.oXBlocks[aChildren[j]] = (new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jFakeContainer, sId: aChildren[j], oEditor: this, oOWT: oTemplate, sTemplateId: oTemplate.id, bIsMacro: false, bIsChild: true, oParentOWT: oCurTemplate })).Update({ oTemplate: oTemplate });
                                this.oXBlocks[aChildren[j]].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oTemplate } });
                            }
                        }
                    }
                }
            }
        }
        if(this.aOrder.length != 0)
		{
            this.oXBlocks[this.aOrder[0]].Select();
            this.oPage.ModifyView({ sTarget: "context", sAction: "enable" });
        }
		else
		{
            for(sKey in this.oPage.oTemplateDialogs)
			{
                if(this.oPage.oTemplateDialogs.hasOwnProperty(sKey))
				{
                    this.oPage.oTemplateDialogs[sKey].Hide();
                }
            }
            this.oPage.ModifyView({ sTarget: "context", sAction: "disable" });
        }
        return this;
    };
    CXEditor.prototype.Reorder = function(oArgs)
	{
        if(oArgs != null)
		{
            if(oArgs.oItem != null)
			{
                var aReordered, aNewOrder;
                var oToSave;
                var bReordered = false;
                var i, j, iIdx;
                var oTmp;
                if(oArgs.oMacro != null)
				{
                    bReordered = false;
					switch(oArgs.oMacro.oBlock.sStackType)
					{
						case "tabs":
						{
							var iTab = oArgs.oMacro.oBlock.oZones[oArgs.oItem.sId].iTab;
							aNewOrder = oArgs.oMacro.oBlock.aServiceZones[iTab].slice();
							iIdx = $.inArray(oArgs.oItem.sId, oArgs.oMacro.oBlock.aServiceZones[iTab]);
							if(oArgs.sDir == "up" && iIdx > 0)
							{
								aNewOrder.splice(iIdx - 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							else if(oArgs.sDir == "down" && iIdx < aNewOrder.length - 1)
							{
								aNewOrder.splice(iIdx + 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							if(bReordered)
							{
								oArgs.oMacro.oBlock.aServiceZones[iTab] = aNewOrder.slice();
								oToSave =
								{
									action: "save_web_mode_structure",
									web_mode_id: this.oPlayer.sCurrentPageId,
									web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
								};
								for(i=0; i<oToSave.web_mode.zones.length; i++)
								{
									if(oToSave.web_mode.zones[i].name == "main")
									{
										iIdx = -1;
										aReordered = [];
										for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
										{
											if(oArgs.oMacro.sId == oToSave.web_mode.zones[i].templates[j].override_template_id)
											{
												this.aServiceZones = JSON.parse(this._GetParam({ aParams: oToSave.web_mode.zones[i].templates[j].params, sName: ".__service__zones", bContains: true }));
												this.aServiceZones[iTab] = aNewOrder.slice();
												aReordered = [];
												for(k=0; k<this.aServiceZones.length; k++)
												{
													for(l = 0; l < this.aServiceZones[k].length; l++)
													{
														oTmp = this._GetTemplateById({ sId: this.aServiceZones[k][l], aTemplates: oToSave.web_mode.zones[i].templates[j].templates });
														oTmp.weight = (k + 1) * 1000 + l * 10;
														aReordered.push(JSON.parse(JSON.stringify(oTmp)));
													}
												}
												oToSave.web_mode.zones[i].templates[j].templates = aReordered.slice();
												break;
											}
										}
									}
								}
								this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { oItem: oArgs.oItem, oMacro: oArgs.oMacro, bAfterReorder: true } });
							}
							break;
						}
						case "horizontal":
						{
							var iColumn = oArgs.oMacro.oBlock.oZones[oArgs.oItem.sId].iColumn;
							aNewOrder = oArgs.oMacro.oBlock.aServiceZones[iColumn].slice();
							iIdx = $.inArray(oArgs.oItem.sId, oArgs.oMacro.oBlock.aServiceZones[iColumn]);
							if(oArgs.sDir == "up" && iIdx > 0)
							{
								aNewOrder.splice(iIdx - 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							else if(oArgs.sDir == "down" && iIdx < aNewOrder.length - 1)
							{
								aNewOrder.splice(iIdx + 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							if(bReordered)
							{
								oArgs.oMacro.oBlock.aServiceZones[iColumn] = aNewOrder.slice();
								oToSave = {
									action: "save_web_mode_structure",
									web_mode_id: this.oPlayer.sCurrentPageId,
									web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
								};
								for(i=0; i<oToSave.web_mode.zones.length; i++)
								{
									if(oToSave.web_mode.zones[i].name == "main")
									{
										iIdx = -1;
										aReordered = [];
										for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
										{
											if(oArgs.oMacro.sId == oToSave.web_mode.zones[i].templates[j].override_template_id)
											{
												this.aServiceZones = JSON.parse(this._GetParam({ aParams: oToSave.web_mode.zones[i].templates[j].params, sName: ".__service__zones", bContains: true }));
												this.aServiceZones[iColumn] = aNewOrder.slice();
												aReordered = [];
												for(k=0; k<this.aServiceZones.length; k++)
												{
													for(l = 0; l < this.aServiceZones[k].length; l++)
													{
														oTmp = this._GetTemplateById({ sId: this.aServiceZones[k][l], aTemplates: oToSave.web_mode.zones[i].templates[j].templates });
														oTmp.weight = (k + 1) * 1000 + l * 10;
														aReordered.push(JSON.parse(JSON.stringify(oTmp)));
													}
												}
												oToSave.web_mode.zones[i].templates[j].templates = aReordered.slice();
												break;
											}
										}
									}
								}
								this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { oItem: oArgs.oItem, oMacro: oArgs.oMacro, bAfterReorder: true } });
							}
							break;
						}
						case "vertical":
						{
							aNewOrder = oArgs.oMacro.oBlock.aServiceZones.slice();
							iIdx = $.inArray(oArgs.oItem.sId, oArgs.oMacro.oBlock.aServiceZones);
							if(oArgs.sDir == "up" && iIdx > 0)
							{
								aNewOrder.splice(iIdx - 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							else if(oArgs.sDir == "down" && iIdx < aNewOrder.length - 1)
							{
								aNewOrder.splice(iIdx + 1, 0, aNewOrder.splice(iIdx, 1)[0]);
								bReordered = true;
							}
							if(bReordered)
							{
								oArgs.oMacro.oBlock.aServiceZones = aNewOrder.slice();
								oToSave =
								{
									action: "save_web_mode_structure",
									web_mode_id: this.oPlayer.sCurrentPageId,
									web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
								};
								for(i=0; i<oToSave.web_mode.zones.length; i++)
								{
									if(oToSave.web_mode.zones[i].name == "main")
									{
										iIdx = -1;
										aReordered = [];
										for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
										{
											if(oArgs.oMacro.sId == oToSave.web_mode.zones[i].templates[j].override_template_id)
											{
												this.aServiceZones = aNewOrder.slice();
												aReordered = [];
												for(k=0; k<this.aServiceZones.length; k++)
												{
													oTmp = this._GetTemplateById({ sId: this.aServiceZones[k], aTemplates: oToSave.web_mode.zones[i].templates[j].templates });
													oTmp.weight = k * 10;
													aReordered.push(JSON.parse(JSON.stringify(oTmp)));
												}
												oToSave.web_mode.zones[i].templates[j].templates = aReordered.slice();
												break;
											}
											/*else
											{
												delete oToSave.web_mode.zones[i].templates[j];
											}*/
										}
										oToSave.web_mode.zones[i].templates = oToSave.web_mode.zones[i].templates.filter(function(elem) { return (elem != undefined); });
									}
								}
								this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { oItem: oArgs.oItem, oMacro: oArgs.oMacro, bAfterReorder: true } });
							}
							break;
						}
					}
                }
				else
				{
                    aNewOrder = this.aOrder.slice();
                    iIdx = $.inArray(oArgs.oItem.sId, aNewOrder);
                    bReordered = false;

                    if(oArgs.sDir == "up" && iIdx > 0)
					{
                        aNewOrder.splice(iIdx - 1, 0, aNewOrder.splice(iIdx, 1)[0]);
                        bReordered = true;
                    }
					else if(oArgs.sDir == "down" && iIdx < aNewOrder.length - 1)
					{
                        aNewOrder.splice(iIdx + 1, 0, aNewOrder.splice(iIdx, 1)[0]);
                        bReordered = true;
                    }
                    if(bReordered)
					{
                        oToSave =
						{
                            action: "save_web_mode_structure",
                            web_mode_id: this.oPlayer.sCurrentPageId,
                            web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
                        };
                        for(i=0; i<oToSave.web_mode.zones.length; i++)
						{
                            if(oToSave.web_mode.zones[i].name == "main")
							{
                                iIdx = -1;
                                aReordered = [];
                                for(j=0; j<oToSave.web_mode.zones[i].templates.length; j++)
								{
                                    iIdx = $.inArray(oToSave.web_mode.zones[i].templates[j].override_template_id, aNewOrder);
                                    aReordered[iIdx] = JSON.parse(JSON.stringify(oToSave.web_mode.zones[i].templates[j]));
                                    aReordered[iIdx].weight = 10 * (iIdx + 1);
                                }
                                oToSave.web_mode.zones[i].templates = aReordered;
                            }
                        }
                        this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { oItem: oArgs.oItem, bAfterReorder: true } });
                    }
                }
            }
        }
        return this;
    };
    CXEditor.prototype.ResetChanged = function(oArgs)
	{
		this.oChanged[this.oPlayer.oCurrentWebModeCopy.id] = [];
		this.oPage.DisableTemplateBtns();
        return this;
    };
    CXEditor.prototype.Save = function(oArgs)
	{
        this.aChangedOWTs = this._GetChangedOWT();
        if(this.aChangedOWTs.length == 0)
		{
			if(this.oPage.oCurrentObjectDialog.sCurrentOWTId!=null && this.oPage.oCurrentObjectDialog.sCurrentOWTId!="")
			{
				this.aChangedOWTs.push(this.oPage.oCurrentObjectDialog.sCurrentOWTId);
			}
			else
			{
				return this;
			}
        }
        var i, j, k;
        var sKey;
        var aFiltered;
        var bHasChanged;
        var oToSave =
		{
            action: "save_web_mode_templates",
            web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
        };
        /* filter unchanged owts */
		var oMainZone = this._GetMainZone({ aZones: oToSave.web_mode.zones });
		if(oMainZone!=null)
		{
			for(j=0; j<oMainZone.templates.length; j++)
			{
				if(this._IsMacro({ oTemplate: oMainZone.templates[j] }))
				{
					bHasChanged = false;
					if(oMainZone.templates[j].templates != null)
					{
						for(k=0; k<oMainZone.templates[j].templates.length; k++)
						{
							if($.inArray(oMainZone.templates[j].templates[k].override_template_id, this.aChangedOWTs) == -1)
							{
								delete oMainZone.templates[j].templates[k]; // deleted elem becomes undefined, to be filtered
							}
							else
							{
								bHasChanged = true;
							}
						}
						oMainZone.templates[j].templates = oMainZone.templates[j].templates.filter(function(elem) { return (elem != undefined); }); // filter undefined items
					}
					if(bHasChanged && ($.inArray(oMainZone.templates[j].override_template_id, this.aChangedOWTs) == -1)) // child changed, macro must be saved too
					{
						this.aChangedOWTs.push(oMainZone.templates[j].override_template_id);
					}
				}

				if($.inArray(oMainZone.templates[j].override_template_id, this.aChangedOWTs) == -1)
				{
					delete oMainZone.templates[j];  // deleted elem becomes undefined, to be filtered
				}
			}

			oMainZone.templates = oMainZone.templates.filter(function(elem) { return (elem != undefined); }); // filter undefined items

			for(j=0; j<oMainZone.templates.length; j++)
			{
				this.UpdateOWTValuesFromFlds({ oOWT: oMainZone.templates[j] });
/*				if(oMainZone.templates[j].templates!=null)
				{
					if(Array.isArray(oMainZone.templates[j].templates))
					{
						for(k=0; k<oMainZone.templates[j].templates.length; k++)
						{
							this.UpdateOWTValuesFromFlds({ oOWT: oMainZone.templates[j].templates[k] });
						}
					}
				}*/
            }
        }

        this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: false })))), oContext: this, fnSuccess: this.Update, oSuccessArgs: { bAfterSave: true, oEditedOWT: null } });
        return this;
    };
    CXEditor.prototype.SaveContext = function(oArgs)
	{
		if(this.oPlayer.oCurrentWebMode != null)
		{
			var i, j;
			var aUsed = [];
			var bExist = false;
			for(i=0; i<this.aUsedContext.length; i++)
			{
				if(this.aUsedContext[i]!="")
				{
					bExist = false;
					for(j=0; j<this.oPlayer.oCurrentWebModeCopy.context.length; j++)
					{
						if(this.oPlayer.oCurrentWebModeCopy.context[j].name==this.aUsedContext[i])
						{
							aUsed.push({ id: this.oPlayer.oCurrentWebModeCopy.context[j].id, code: this.aUsedContext[i] });
							bExist = true;
							break;
						}
					}
					if(!bExist )
					{
						aUsed.push({ id: this.aUsedContext[i] });
					}
				}
			}
			this.oPlayer.oCurrentWebModeCopy.used_context = aUsed;
			var oToSave =
			{
				action: "save_web_mode_structure",
				web_mode_id: this.oPlayer.oCurrentWebModeCopy.id,
				web_mode: JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy))
			};
			this.Load({ sURL: this.oPlayer.oConfig.sRootAPIURL, sData: ("action=" + encodeURIComponent(JSON.stringify(this._CleanupBeforeSend({ oToClean: oToSave, bNoParams: true, bCleanZones: true })))), oContext: this });
		}
        return this;
    };
    CXEditor.prototype.SetChanged = function(oArgs)
	{
        if(this.oChanged[this.oPlayer.oCurrentWebModeCopy.id] == null)
		{
            this.oChanged[this.oPlayer.oCurrentWebModeCopy.id] = [];
        }
        if($.inArray(oArgs.oOWT.override_template_id, this.oChanged[this.oPlayer.oCurrentWebModeCopy.id]) == -1)
		{
            this.oChanged[this.oPlayer.oCurrentWebModeCopy.id].push(oArgs.oOWT.override_template_id);
        }
        return this;
    };
    CXEditor.prototype.UIEvent = function(oArgs)
	{
        return this;
    };
    CXEditor.prototype.Unselect = function(oArgs)
	{
        for(var sKey in this.oXBlocks)
		{
            if(this.oXBlocks.hasOwnProperty(sKey))
			{
                if(this.oXBlocks[sKey].bIsChild == true)
				{
                    continue;
                }
                this.oXBlocks[sKey].Unselect();
            }
        }
        return this;
    };
	CXEditor.prototype.Update = function(oArgs)
	{
        if(oArgs != null)
		{
            if(oArgs.oThis != null)
			{
                if(this.sSelectedId != null)
				{
                    this.oPage.Update({ sType: "template_params", sTemplateId: this.oXBlocks[this.sSelectedId].sTemplateId, oOWT: this.oXBlocks[this.sSelectedId].oOWT });
                }
				else
				{
                    this.oPage.Update({ sType: "template_params", sTemplateId: oArgs.oThis.sTemplateId, oOWT: oArgs.oOWT });
                }
            }
			else if(oArgs.oData != null)
			{
                var oCurrentZone = null;
                var oDataMainZone = null;
                var i, j, k, l, m;
                var iIdx = -1;
                var aOldLevel0 = [];
                var aNewLevel0 = [];
                var sNewOWTId = null;
                var sNewTemplateId = null;
                var sNewURL = null;
                var iNewIdx = -1;
                var aIdxs = [];
				var oMacro;
                var oMacroOld;
                var oMacroNew;
                var oMacroBefore;
                var oMacroAfter;
                var aOldIds;
                var aNewIds;
                var aNewOrder;
                var aOldOrder;
                var aOldTemplates;
                var sOWTId;
                var sFldName;
                var sToDeleteId;
                var sSiblingId;
                var iColumnId = -1;
                if(oArgs.oData.action_completed == "save_web_mode_structure")
				{
                    oCurrentZone = this._GetMainZone({ aZones: this.oPlayer.oCurrentWebModeCopy.zones });
                    if(oArgs.oData.web_mode != null)
					{
                        if(oArgs.oData.web_mode.zones != null)
						{
                            oDataMainZone = this._GetMainZone({ aZones: oArgs.oData.web_mode.zones });
                        }
                    }
                    if(oCurrentZone != null && oDataMainZone != null)
					{
                        if(oArgs.bAfterAppend == true)
						{
                            for(i=0; i<oCurrentZone.templates.length; i++) // current template ids
                            {
                                aOldLevel0.push(oCurrentZone.templates[i].override_template_id); // level 0
                            }
                            for(i=0; i<oDataMainZone.templates.length; i++) // new template ids
                            {
                                aNewLevel0.push(oDataMainZone.templates[i].override_template_id); // level 0
                                if($.inArray(oDataMainZone.templates[i].override_template_id, aOldLevel0) == -1)
								{
                                    sNewOWTId = oDataMainZone.templates[i].override_template_id;
                                    sNewTemplateId = oDataMainZone.templates[i].id;
                                    if(oDataMainZone.templates[i].url != null)
									{
                                        sNewURL = oDataMainZone.templates[i].url;
                                    }
									else
									{
                                        sNewURL = "custom_web_template.html?custom_web_template_id=" + sNewTemplateId + "&override_web_template=" + sNewOWTId;
                                        oDataMainZone.templates[i].url = sNewURL;
                                    }
                                    if(sNewURL.indexOf("lpe=1") == -1)
									{
                                        oDataMainZone.templates[i].url += "&lpe=1";
                                        sNewURL += "&lpe=1";
                                    }
                                    iNewIdx = i;
                                }
                                aIdxs.push({ iIdx: i, sOWTId: oDataMainZone.templates[i].override_template_id, iWeight: oDataMainZone.templates[i].weight });
                            }
                            if(sNewOWTId != null) // got new on level 0
                            {
                                aOldOrder = this.aOrder.slice();
                                this.aOrder = [];
                                aIdxs.sort(function(oElem1, oElem2) { return ((oElem1.iWeight > oElem2.iWeight) ? 1 : ((oElem1.iWeight < oElem2.iWeight) ? -1 : 0)); });
                                aOldTemplates = JSON.parse(JSON.stringify(oCurrentZone.templates));
                                delete oCurrentZone.templates;
                                oCurrentZone.templates = [];
                                for(i=0; i<aIdxs.length; i++)
								{
                                    this.aOrder.push(aIdxs[i].sOWTId);
                                    if(aIdxs[i].sOWTId != sNewOWTId) // copy old unchanged
                                    {
                                        for(j=0; j<aOldTemplates.length; j++)
										{
                                            if(aOldTemplates[j].override_template_id == aIdxs[i].sOWTId)
											{
                                                oCurrentZone.templates.push(JSON.parse(JSON.stringify(aOldTemplates[j])));
                                                break;
                                            }
                                        }
                                    }
									else // copy new
                                    {
                                        oCurrentZone.templates.push(JSON.parse(JSON.stringify(oDataMainZone.templates[aIdxs[i].iIdx])));
                                        iNewIdx = oCurrentZone.templates.length - 1;
                                        if(oCurrentZone.templates[iNewIdx].params == null) // append default params
                                        {
                                            if(this.oPlayer.oStore["templates"].oData[oCurrentZone.templates[iNewIdx].id] != null)
											{
                                                oCurrentZone.templates[iNewIdx].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["templates"].oData[oCurrentZone.templates[iNewIdx].id].params));
                                            }
											else
											{
                                                oCurrentZone.templates[iNewIdx].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["macros"].oData[oCurrentZone.templates[iNewIdx].id].params));
                                            }
                                        }
                                    }
                                }
                                // now we have current page updated, but store, blocks and view are still untouched
                                this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: this.oPlayer.oCurrentWebModeCopy.id, oItem: this.oPlayer.oCurrentWebModeCopy, bSuppressEvent: true }); // update store
                                // create new block
                                this.oXBlocks[sNewOWTId] = new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jViewContainer, sId: sNewOWTId, oEditor: this, oOWT: oCurrentZone.templates[iNewIdx], sTemplateId: oCurrentZone.templates[iNewIdx].id, bIsMacro: this._IsMacro({ oTemplate: oCurrentZone.templates[iNewIdx] }), bIsChild: false, oParentOWT: null });
                                this.oXBlocks[sNewOWTId].Load({ sURL: sNewURL, sDataType: "html", oContext: this.oXBlocks[sNewOWTId], fnSuccess: this.oXBlocks[sNewOWTId].Update, oSuccessArgs: {} });
                                this.oXBlocks[sNewOWTId].Subscribe({ sEvent: "loaded", bOnce: true, sSubscriberId: this.sId, oContext: this.oXBlocks[sNewOWTId], fn: this.oXBlocks[sNewOWTId].Select, oArgs: {} });
                                this.oXBlocks[sNewOWTId].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oCurrentZone.templates[iNewIdx] } });
                                // after block created and load started we can reaarange view items
                                if(aOldOrder.length != 0) // exclude single block case
                                {
                                    for(i=0; i<this.aOrder.length; i++)
									{
                                        if(this.aOrder[i] == sNewOWTId)
										{
                                            this.oXBlocks[this.aOrder[i]].oBlock.jBlock.insertAfter(this.oXBlocks[this.aOrder[i - 1]].oBlock.jBlock);
                                        }
                                    }
                                }
                                this.SetChanged({ oOWT: oCurrentZone.templates[iNewIdx] });
                            }
							else // search children
                            {
                                _loop_i:
								for(i=0; i<oCurrentZone.templates.length; i++)
								{
                                    if(this._IsMacro({ oTemplate: oCurrentZone.templates[i] }))
									{
                                        oMacroOld = oCurrentZone.templates[i];
                                        oMacroNew = this._GetTemplateById({ aTemplates: oDataMainZone.templates, sId: oCurrentZone.templates[i].override_template_id });
                                        if(oMacroNew.templates == null)
										{
                                            continue;
                                        }
                                        aIdxs = [];
                                        aOldIds = [];
                                        aOldTemplates = [];
                                        if(oMacroOld.templates != null)
										{
                                            aOldTemplates = JSON.parse(JSON.stringify(oMacroOld.templates));
                                            for(j=0; j<aOldTemplates.length; j++)
											{
                                                aOldIds.push(aOldTemplates[j].override_template_id);
                                            }
                                        }
                                        for(j=0; j<oMacroNew.templates.length; j++)
										{
                                            aIdxs.push({ iIdx: j, iWeight: oMacroNew.templates[j].weight, sOWTId: oMacroNew.templates[j].override_template_id });
                                        }
                                        aIdxs.sort(this._SortByWeightAscending);

                                        for(j=0; j<oMacroNew.templates.length; j++)
										{
                                            if($.inArray(oMacroNew.templates[j].override_template_id, aOldIds) == -1)
											{
                                                this.sNewOWTId = oMacroNew.templates[j].override_template_id;
                                                iNewIdx = j;
                                                sNewTemplateId = oMacroNew.templates[j].id;
                                                if(oMacroNew.templates[j].url != null)
												{
                                                    sNewURL = oMacroNew.templates[j].url;
                                                }
												else
												{
                                                    sNewURL = "custom_web_template.html?custom_web_template_id=" + sNewTemplateId + "&override_web_template=" + sNewOWTId;
                                                    oMacroNew.templates[j].url = sNewURL;
                                                }

                                                delete oMacroOld.templates;
                                                oMacroOld.templates = [];
                                                sFldName = this._GetMacroZonesFldName({ oTemplate: oArgs.oTarget.oParent.oOWT });
                                                aNewOrder = [];
                                                if(oArgs.oTarget.bMultiple)
												{
                                                    for(k=0; k<this.aServiceZones.length; k++)
													{
                                                        aNewOrder[k] = [];
                                                        for(l = 0; l < this.aServiceZones[k].length; l++)
														{
                                                            sOWTId = this.aServiceZones[k][l];
                                                            if(sOWTId.indexOf("NEW_") != -1)
															{
                                                                aNewOrder[k][l] = this.aServiceZones[k][l] = this.sNewOWTId;
                                                                iLastIdx = oMacroOld.templates.length;
                                                                oMacroOld.templates.push(JSON.parse(JSON.stringify(oMacroNew.templates[j])));
                                                                if(oMacroOld.templates[iLastIdx].params == null)
																{
                                                                    if(this.oPlayer.oStore["templates"].oData[sNewTemplateId] != null)
																	{
                                                                        oMacroOld.templates[iLastIdx].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["templates"].oData[sNewTemplateId].params));
                                                                    }
																	else
																	{
                                                                        oMacroOld.templates[iLastIdx].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["macros"].oData[sNewTemplateId].params));
                                                                    }
                                                                }
                                                                this.oXBlocks[this.sNewOWTId] = new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jFakeContainer, sId: this.sNewOWTId, oEditor: this, oOWT: oMacroOld.templates[iLastIdx], sTemplateId: sNewTemplateId, bIsMacro: false, bIsChild: true, oParentOWT: oCurrentZone.templates[i] });
                                                                this.oXBlocks[this.sNewOWTId].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oCurrentZone.templates[i] } }); // subscribe update parent on selection
                                                            }
															else
															{
                                                                aNewOrder[k][l] = this.aServiceZones[k][l];
                                                                for(m = 0; m < aOldTemplates.length; m++)
																{
                                                                    if(aOldTemplates[m].override_template_id == aNewOrder[k][l])
																	{
                                                                        oMacroOld.templates.push(JSON.parse(JSON.stringify(aOldTemplates[m])));
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                    for(l = 0; l < oMacroOld.params.length; l++)
													{
                                                        if(oMacroOld.params[l].name == sFldName)
														{
                                                            oMacroOld.params[l].value = JSON.stringify(aNewOrder);
                                                            break;
                                                        }
                                                    }
                                                }
												else
												{
                                                    for(k=0; k<aIdxs.length; k++) // rewrite templates
                                                    {
                                                        iIdx = $.inArray(aIdxs[k].sOWTId, aOldIds);
                                                        if(iIdx == -1) // new one + params
                                                        {
                                                            oMacroOld.templates.push(JSON.parse(JSON.stringify(oMacroNew.templates[j])));
                                                            if(oMacroOld.templates[k].params == null)
															{
                                                                if(this.oPlayer.oStore["templates"].oData[sNewTemplateId] != null)
																{
                                                                    oMacroOld.templates[k].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["templates"].oData[sNewTemplateId].params));
                                                                }
																else
																{
                                                                    oMacroOld.templates[k].params = JSON.parse(JSON.stringify(this.oPlayer.oStore["macros"].oData[sNewTemplateId].params));
                                                                }
                                                            }
                                                            this.oXBlocks[this.sNewOWTId] = new CXBlock({ oPlayer: this.oPlayer, jContainer: this.jFakeContainer, sId: this.sNewOWTId, oEditor: this, oOWT: oMacroOld.templates[k], sTemplateId: sNewTemplateId, bIsMacro: false, bIsChild: true, oParentOWT: oCurrentZone.templates[i] });
                                                            this.oXBlocks[this.sNewOWTId].Subscribe({ sEvent: "select", bOnce: false, sSubscriberId: this.sId, oContext: this, fn: this.Update, oArgs: { oOWT: oCurrentZone.templates[i] } }); // subscribe update parent on selection
                                                        }
														else // append old and update weight
                                                        {
                                                            oMacroOld.templates.push(JSON.parse(JSON.stringify(aOldTemplates[iIdx])));
                                                            oMacroOld.templates[k].weight = aIdxs[k].iWeight;
                                                        }
                                                        aNewOrder.push(aIdxs[k].sOWTId);
                                                    }
                                                    this.oXBlocks[oArgs.oTarget.sId].Select();
                                                }
                                                for(k=0; k<oMacroOld.params.length; k++)
												{
                                                    if(oMacroOld.params[k].name == sFldName)
													{
                                                        oMacroOld.params[k].value = JSON.stringify(aNewOrder);
                                                        break;
                                                    }
                                                }
                                                if(this.oPage.oCurrentObjectDialog.aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })] == null)
												{
                                                    this.oPage.oTemplateDialogs[oArgs.oTarget.oParent.oOWT.id].aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })].SetValue({ sValue: JSON.stringify(aNewOrder) });
                                                }
												else
												{
                                                    this.oPage.oCurrentObjectDialog.aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })].SetValue({ sValue: JSON.stringify(aNewOrder) });
                                                }
                                                this.Subscribe({ sEvent: "loaded", bOnce: true, sSubscriberId: oArgs.oTarget.sId, oContext: this.oXBlocks[oArgs.oTarget.sId], fn: this.oXBlocks[oArgs.oTarget.sId].Update, oArgs: { oTemplate: oArgs.oTarget.oOWT } });
                                                this.oXBlocks[oArgs.oTarget.sId].Subscribe({ sEvent: "stack_updated", bOnce: true, sSubscriberId: oArgs.oTarget.sId, oContext: this.oXBlocks[oArgs.oTarget.sId], fn: this.oXBlocks[oArgs.oTarget.sId].Select, oArgs: {} });
                                                this.oXBlocks[oArgs.oTarget.sId].Subscribe({ sEvent: "stack_updated", bOnce: true, sSubscriberId: oArgs.oTarget.sId, oContext: this.oXBlocks[oArgs.oTarget.sId], fn: this.oXBlocks[oArgs.oTarget.sId].SelectZone, oArgs: { sId: this.sNewOWTId } });
                                                this.Save();

                                                break _loop_i; // new item is always single
                                            }
                                        }
                                    }
                                }
                            }
                        }
						else if(oArgs.bAfterDelete == true)
						{
							var sItemToDelete = oArgs.oItem.sId;
							var bTargetIsMacro = this._IsMacro({ oTemplate: this._GetTemplateById({ aTemplates: oCurrentZone.templates, sId: sItemToDelete }) });
							// 1.locate target OWT, get target path
							var aPath = [];
							for(i=0; i<oCurrentZone.templates.length; i++)
							{
								if(oCurrentZone.templates[i].override_template_id==sItemToDelete)
								{
									aPath.push({ iIdx: i, sId: sItemToDelete });
									break;
								}
								else if(this._IsMacro({ oTemplate: oCurrentZone.templates[i] }))
								{
									if(oCurrentZone.templates[i].templates!=null)
									{
										aPath = this._FindInMacro({ aTemplates: oCurrentZone.templates[i].templates, sId: sItemToDelete });
										if(aPath.length!=0)
										{
											aPath.unshift({ iIdx: i, sId: oCurrentZone.templates[i].override_template_id });
											break;
										}
									}
								}
							}
							// 2. IF path length==1 && !Macro - delete target, update level order, no ui update
							// 3. IF path length==1 && Macro - delete all descendants first, then delete target, update level order, no ui update
							if(aPath.length==1)
							{
								if(bTargetIsMacro)
								{
									this.DeleteMacroChildren({ oMacro: oCurrentZone.templates[aPath[0].iIdx] });
								}
								oCurrentZone.templates.splice(aPath[0].iIdx, 1); // remove from zone
								this.oXBlocks[aPath[0].sId].Delete();
								delete this.oXBlocks[aPath[0].sId]; // remove block from editor
								this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: this.oPlayer.oCurrentWebModeCopy.id, oItem: this.oPlayer.oCurrentWebModeCopy, bSuppressEvent: true }); // update store
								iIdx = this.aOrder.findIndex(function (item) { return (item==sItemToDelete); });
								if(iIdx!=-1) // reorder and set selection
								{
									this.aOrder.splice(iIdx, 1);
									if(this.aOrder.length == 0)
									{
										this.Fill(); // cleanup right panel
									}
									else
									{
										if(iIdx==0)
										{
											if(this.aOrder[iIdx]!=null)
											{
												this.oXBlocks[this.aOrder[iIdx]].Select();
											}
										}
										else if(this.aOrder[iIdx-1] != null)
										{
											this.oXBlocks[this.aOrder[iIdx-1]].Select();
										}
									}
								}
							}
							// 4. IF path length>1 && !Macro - delete target, update parent service fld, update parent column order, update level 0 ancestors ui
							// 5. IF path length>1 && Macro - delete all descendants first, then delete target, update parent service fld, update parent column order, update level 0ancestors ui
							else if(aPath.length>1)
							{
								if(bTargetIsMacro)
								{
									this.DeleteMacroChildren({ oMacro: oCurrentZone.templates[aPath[aPath.length-1].iIdx] });
								}
								var oParent;
								var oRoot;
								var aCurTemplates = oCurrentZone.templates;
								for(i=0; i<aPath.length; i++)
								{
									if(i==0)
									{
										oRoot = aCurTemplates[aPath[i].iIdx];
									}
									if(i==(aPath.length-2))
									{
										oParent = aCurTemplates[aPath[i].iIdx];
									}
									if(i==(aPath.length-1))
									{
										aCurTemplates.splice(aPath[aPath.length-1].iIdx, 1); // remove from zone
										this.oXBlocks[aPath[aPath.length-1].sId].Delete();
										delete this.oXBlocks[aPath[aPath.length-1].sId]; // remove block from editor
									}
									else
									{
										aCurTemplates = aCurTemplates[aPath[i].iIdx].templates;
									}
								}

								var iServiceIdx = oParent.params.findIndex(function (item) { return (item.name.indexOf(".__service__zones")!=-1); });
								var iIdxToRemove = -1;
								if(iServiceIdx!=-1)
								{
									var aServiceArray = JSON.parse(oParent.params[iServiceIdx].value);
									if(aServiceArray.length!=0)
									{
										if(typeof aServiceArray[0] == "string") // plain vertical stack
										{
											iIdxToRemove = aServiceArray.findIndex(function (item) { return (item==sItemToDelete); });
											if(iIdxToRemove!=-1)
											{
												aServiceArray.splice(iIdxToRemove, 1);
											}
										}
										else if(typeof aServiceArray[0] == "object") // horiz. stack ot tabs
										{
											for(j=0; j<aServiceArray.length; j++)
											{
												iIdxToRemove = aServiceArray[j].findIndex(function (item) { return (item==sItemToDelete); });
												if(iIdxToRemove!=-1)
												{
													aServiceArray[j].splice(iIdxToRemove, 1);
													break;
												}
											}
										}
										if(iIdxToRemove!=-1)
										{
											oParent.params[iServiceIdx].value = JSON.stringify(aServiceArray);
										}
									}
								}

								this.oXBlocks[oParent.override_template_id].Select(); // select macro temporarily
								this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: this.oPlayer.oCurrentWebModeCopy.id, oItem: this.oPlayer.oCurrentWebModeCopy, bSuppressEvent: true }); // update store

							}
							this.Save();
							// 6. Save updated WM templates
	                    }
						else if(oArgs.bAfterReorder)
						{
                            if(oArgs.oItem.bIsChild)
							{
                                sFldName = this._GetMacroZonesFldName({ oTemplate: oArgs.oMacro.oOWT });
                                oMacroBefore = this._GetTemplateById({ aTemplates: oCurrentZone.templates, sId: oArgs.oMacro.sId });
                                for(l = 0; l < oMacroBefore.params.length; l++)
								{
                                    if(oMacroBefore.params[l].name == sFldName)
									{
                                        oMacroBefore.params[l].value = JSON.stringify(this.aServiceZones);
                                        break;
                                    }
                                }
                                if(this.oPage.oCurrentObjectDialog.aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })] == null)
								{
                                    this.oPage.oTemplateDialogs[oArgs.oMacro.sTemplateId].aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })].SetValue({ sValue: JSON.stringify(this.aServiceZones) });
                                }
								else
								{
                                    this.oPage.oCurrentObjectDialog.aDialogPages[0].oFlds[TOOLS.EncodeVarName({ sText: sFldName })].SetValue({ sValue: JSON.stringify(this.aServiceZones) });
                                }
                                this.Subscribe({ sEvent: "loaded", bOnce: true, sSubscriberId: oArgs.oMacro.sId, oContext: this.oXBlocks[oArgs.oMacro.sId], fn: this.oXBlocks[oArgs.oMacro.sId].Update, oArgs: { oTemplate: oArgs.oMacro.oOWT } });
                                this.oXBlocks[oArgs.oMacro.sId].Subscribe({ sEvent: "stack_updated", bOnce: true, sSubscriberId: oArgs.oMacro.sId, oContext: this.oXBlocks[oArgs.oMacro.sId], fn: this.oXBlocks[oArgs.oMacro.sId].Select, oArgs: {} });
                                this.oXBlocks[oArgs.oMacro.sId].Subscribe({ sEvent: "stack_updated", bOnce: true, sSubscriberId: oArgs.oMacro.sId, oContext: this.oXBlocks[oArgs.oMacro.sId], fn: this.oXBlocks[oArgs.oMacro.sId].SelectZone, oArgs: { sId: oArgs.oItem.sId } });
                                this.Save();
                            }
							else
							{
                                aNewOrder = [];
                                aOldOrder = this.aOrder.slice();
                                var bNeedUpdate = false;
                                for(i=0; i<oDataMainZone.templates.length; i++) // level 0 first
                                {
                                    aNewOrder.push({ iWeight: oDataMainZone.templates[i].weight, iIdx: i, sOWTId: oDataMainZone.templates[i].override_template_id });
                                    for(j=0; j<oCurrentZone.templates.length; j++) // copy new weight, dumb but safe
                                    {
                                        if(oCurrentZone.templates[j].override_templates_id == oDataMainZone.templates[i].override_templates_id)
										{
                                            oCurrentZone.templates[j].weight = oDataMainZone.templates[i].weight;
                                            break;
                                        }
                                    }
                                }
                                aNewOrder.sort(function(oElem1, oElem2) { return ((oElem1.iWeight > oElem2.iWeight) ? 1 : ((oElem1.iWeight < oElem2.iWeight) ? -1 : 0)); });

                                this.aOrder = [];
                                for(i=0; i<aNewOrder.length; i++)
								{
                                    if(aOldOrder[i] != aNewOrder[i].sOWTId)
									{
                                        if(i == 0)
										{
                                            this.oXBlocks[aNewOrder[i].sOWTId].oBlock.jBlock.prependTo(this.jViewContainer);
                                        }
										else
										{
                                            this.oXBlocks[aNewOrder[i].sOWTId].oBlock.jBlock.insertAfter(this.oXBlocks[aOldOrder[i - 1]].oBlock.jBlock);
                                        }
                                    }
                                    this.aOrder.push(aNewOrder[i].sOWTId);
                                }
                            }
                            // children do not need reordering since actual order is stored in parent macro
                            this.oPlayer.oStore["webmodes"].UpdateSingleItem({ sId: this.oPlayer.oCurrentWebModeCopy.id, oItem: this.oPlayer.oCurrentWebModeCopy, bSuppressEvent: true }); // update store
                        }
                        this.oPlayer.oCurrentWebMode = JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy));
                    }
                }
				else if(oArgs.oData.action_completed == "save_web_mode_templates")
				{
                    var sName;
                    if(this.aChangedOWTs.length != 0)
					{
                        for(i=0; i<this.aChangedOWTs.length; i++)
						{
                            if(this.oXBlocks[this.aChangedOWTs[i]] != null)
							{
                                if(!this.oXBlocks[this.aChangedOWTs[i]].bIsChild)
								{
                                    this.oXBlocks[this.aChangedOWTs[i]].Update({ oTemplate: this._GetTemplateById({ sId: this.aChangedOWTs[i], aTemplates: this.oPlayer.oCurrentWebModeCopy.zones[0].templates }) });
                                }
                            }
                        }
                        this.oPlayer.oCurrentWebMode = JSON.parse(JSON.stringify(this.oPlayer.oCurrentWebModeCopy));
                        this.aChangedOWTs = [];
                    }
                }
            }
        }
        return this;
    };
	CXEditor.prototype.UpdateAll = function(oArgs)
	{
        this.oPlayer.oCurrentWebMode.sample_object_id = this.oPlayer.oCurrentWebModeCopy.sample_object_id;
		this.oPlayer.oCurrentWebMode.sample_object_title = this.oPlayer.oCurrentWebModeCopy.sample_object_title;
        if(this.oPlayer.oCurrentWebMode.catalog_name != null && this.oPlayer.oCurrentWebMode.catalog_name != "")
		{
            this.oPage.jTestObjectContainer.show();
			this.oPage.jBtnHintObject.removeAttr("cx-no-data").show();
			this.oPage.jBtnHintContext.removeAttr("cx-no-data").show();
            if(this.oPlayer.oCurrentWebMode.sample_object_id != null && this.oPlayer.oCurrentWebMode.sample_object_id != "")
			{
                if(this.oPlayer.oCurrentWebMode.sample_object_title != null && this.oPlayer.oCurrentWebMode.sample_object_title != "")
				{
					this.oPage.jTestObjectValue.html(this.oPlayer.oCurrentWebMode.sample_object_title);
                }
				else
				{
                    this.oPage.jTestObjectValue.html(this.oPlayer.oCurrentWebMode.sample_object_id);
                }
            }
			else
			{
                this.oPage.jTestObjectValue.html(this.oPlayer._GetString({ sId: "test-object-not-selected" }));
            }
        }
		else
		{
            this.oPage.jTestObjectContainer.hide();
			this.oPage.jBtnHintObject.attr({ "cx-no-data": "1" }).hide();
			this.oPage.jBtnHintContext.attr({ "cx-no-data": "1" }).hide();
        }
		this.ApplyWVars();
        for(var sKey in this.oXBlocks)
		{
            this.oXBlocks[sKey].Update({ oTemplate: this.oXBlocks[sKey].oOWT });
        }
        return this;
    };
    CXEditor.prototype.UpdateColumns = function(oArgs)
	{
        for(var i = 0; i<oArgs.oContext.oDialog.oCurrentOWT.params.length; i++)
		{
            if(oArgs.oContext.oDialog.oCurrentOWT.params[i].name == "macro_stack_horizontal.__service__zones")
			{
                var aCopy = JSON.parse(oArgs.oContext.oDialog.oCurrentOWT.params[i].value).slice();
                if(oArgs.oPassedArgs.iDeletedItem != null)
				{
                    if(aCopy[oArgs.oPassedArgs.iDeletedItem] != null)
					{
                        aCopy.splice(oArgs.oPassedArgs.iDeletedItem, 1);
                    }
                }
				else if(oArgs.oPassedArgs.iNewItem != null)
				{
                    aCopy.splice(oArgs.oPassedArgs.iNewItem, 0, []);
                }
                oArgs.oContext.oDialog.oCurrentOWT.params[i].value = JSON.stringify(aCopy);
                break;
            }
        }
        return this;
    };
    CXEditor.prototype.UpdateContext = function(oArgs)
	{
		var oThis = this;
		var bChanged = false;
		var i, j;
		var sKey;
		this.oContextByOWT[oArgs.sOWTId] = JSON.parse(JSON.stringify(oArgs.aUsed));
		if(oArgs.aAdded.length>0)
		{
			for(i=0; i<oArgs.aAdded.length; i++)
			{
				if($.inArray(oArgs.aAdded[i], this.aUsedContext)==-1)
				{
					this.aUsedContext.push(oArgs.aAdded[i]);
					bChanged = true;
				}
			}
		}
		var aToExclude = [];
		if(oArgs.aDeleted.length>0)
		{
			var iIdx;
			var bUsed = false;
			for(i=0; i<oArgs.aDeleted.length; i++)
			{
				bUsed = false;
				for(sKey in this.oContextByOWT) // delete
				{
					if(sKey!=oArgs.sOWTId)
					{
						if($.inArray(oArgs.aDeleted[i], this.oContextByOWT[sKey])!=-1)
						{
							bUsed = true;
							break;
						}
					}
				}
				if(!bUsed)
				{
					iIdx = $.inArray(oArgs.aDeleted[i], this.aUsedContext);
					if(iIdx!=-1)
					{
						this.aUsedContext.splice(iIdx, 1);
						bChanged = true;
					}
				}
			}
		}
		if(this.oPlayer.oCurrentWebMode != null)
		{
			var aUsed = [];
			for(i=0; i<this.aUsedContext.length; i++)
			{
				if(this.aUsedContext[i]!="")
				{
					aUsed.push({ id: this.aUsedContext[i] });
				}
			}
			this.oPlayer.oCurrentWebModeCopy.used_context = aUsed;
		}
		if(bChanged)
		{
			clearTimeout(this.iContextTimeout);
			this.iContextTimeout = setTimeout(function () { oThis.SaveContext.call(oThis, {}); }, 3000);
		}
		return this;
	};
    CXEditor.prototype.UpdateOWTValuesFromFlds = function(oArgs)
	{
        var oThis = this;
		function CollectChildParams(oA)
		{
			var sChildParamFldName = oFld.sId + "__params__";
			var sParentValue = oFld._GetValue();
			var oChildParam = oThis._GetParam({ aParams: oA.aParams, sName: sChildParamFldName, sParentName: oFld.sId, bObject: true });
			if(oChildParam==null)
			{
				oChildParam =
				{
					name: sChildParamFldName,
					parent_wvar_name: oFld.sId,
					position: 1,
					type: "string",
					value: ""
				};
				oA.aParams.push(oChildParam);
			}
			if(oA.oParentFld.bActionFld==true)
			{
				if(sParentValue=="")
				{
					oChildParam.value = {};
				}
				else
				{
					if(oFld.aDynamicOptions!=null)
					{
						for(var m=0; m<oFld.aDynamicOptions.length; m++)
						{
							if(oFld.aDynamicOptions[m].id==sParentValue)
							{
								oChildParam.value = { id: sParentValue, wvars: [] };
								if(oFld.aDynamicOptions[m].wvars!=null)
								{
									for(var n=0; n<oFld.aDynamicOptions[m].wvars.length; n++)
									{
										if(oFld.aDynamicOptions[m].wvars[n].silent==true)
										{
											continue;
										}
										oChildParam.value.wvars.push({ name: oFld.aDynamicOptions[m].wvars[n].name, type: oFld.aDynamicOptions[m].wvars[n].type, value: oFld.oChildParamFlds[oFld.aDynamicOptions[m].wvars[n].name]._GetValue() });
									}
								}
								break;
							}
						}
					}
				}
			}
			else if(oA.oParentFld.bCommonActionFld==true)
			{

			}
			else if(oA.oParentFld.bCollectionFld==true)
			{

			}
			else if(oA.oParentFld.bCommonCollectionFld==true)
			{

			}
			oChildParam.value = (oChildParam.value!="") ? JSON.stringify(oChildParam.value) : "";
			return true;
		}
        var i, j, k, iIdx;
        var sKey;
        var oFld;
        var aObjItems;
        var oObj;
        var oChildParams;
        var aUsedParamNames = [];
        var aNewParams = [];
		var oChildParamFld;
        var oFlds = this.oPage.oTemplateDialogs[oArgs.oOWT.id].aDialogPages[0].oFlds;
        if(oArgs != null)
		{
            for(i=0; i<oArgs.oOWT.params.length; i++)
			{
                aUsedParamNames.push(oArgs.oOWT.params[i].name);
            }
            for(i=0; i<oArgs.oOWT.params.length; i++)
			{
                if(oArgs.oOWT.params[i].name.indexOf("__remote_action____params__")!=-1 || oArgs.oOWT.params[i].name.indexOf("remote_action_common__params__")!=-1 || oArgs.oOWT.params[i].name.indexOf("__collection____params__")!=-1 || oArgs.oOWT.params[i].name.indexOf("collection_common__params__")!=-1)
				{
					continue; // this field goes to CollectChildParams from parent
				}
                oFld = oFlds[TOOLS.EncodeVarName({ sText: oArgs.oOWT.params[i].name })];
                oChildParams = null;
                if(oFld != null)
				{
                    switch(oFld.sType)
					{
                        case "foreign_elem":
						{
							oArgs.oOWT.params[i].value = oFld._GetValue({ bString: true });
							if(oFld.oChildParamFlds != null) // action or collection
							{
								CollectChildParams({ aParams: oArgs.oOWT.params, oParentFld: oFld });
							}
							break;
						}
                        case "select_to_foreign_elem":
						{
							oArgs.oOWT.params[i].value = oFld._GetValue();
							if(oFld.oChildParamFlds != null)
							{
								sParentWVarName = oArgs.oOWT.params[i].name;
								oChildParams = oFld.oChildParamFlds;
								if(oChildParams != null)
								{
									j = 0;
									for(sKey in oChildParams)
									{
										if(oChildParams.hasOwnProperty(sKey))
										{
											iIdx = $.inArray(TOOLS.DecodeVarName({ sText: sKey }), aUsedParamNames);
											if(iIdx == -1)
											{
												j++;
												aNewParams.push({
													name: oChildParams[sKey].oFld.name,
													value: oChildParams[sKey]._GetValue({ bString: true }),
													type: oChildParams[sKey].oFld.type,
													parent_wvar_name: sParentWVarName,
													position: j
												});
											}
											else
											{
												oArgs.oOWT.params[iIdx].value = oChildParams[sKey]._GetValue({ bString: true });
											}
										}
									}
								}
							}
							break;
						}
                        case "folder":
						{
							break;
						}
                        case "object":
						{
							aObjItems = [];
							for(j=0; j<oFld.oControl.aPages.length; j++)
							{
								sKey = oFld.oControl.aPages[j].sId;
								if(oFld.oListItems.hasOwnProperty(sKey))
								{
									oObj = {};
									for(k=0; k<oFld.oFld.entries.length; k++)
									{
										oObj[oFld.oFld.entries[k].id] = oFld.oListItems[sKey].oFlds[TOOLS.EncodeVarName({ sText: oFld.oFld.entries[k].id })]._GetValue({ bString: true });
									}
									aObjItems.push(JSON.parse(JSON.stringify(oObj)));
								}
							}
							oArgs.oOWT.params[i].value = JSON.stringify(aObjItems);
							break;
						}
                        default:
						{
							oArgs.oOWT.params[i].value = oFld._GetValue({ bString: true });
							break;
						}
                    }
                }
            }
            for(i=0; i<aNewParams.length; i++)
			{
                oArgs.oOWT.params.push(JSON.parse(JSON.stringify(aNewParams[i])));
            }
        }
        return this;
    };
}
{ // CXViewBlock - single object shadow
    window.CXViewBlock = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oParent = oArgs.oParent;
        this.oEditor = this.oParent.oEditor;
        this.oSrc = oArgs.oSrc;
        this.oBtns = {};
		this.aUsedContext = [];
        this.Constructor();
        return this;
    };
    CXViewBlock.prototype = Object.create(WTBaseObject.prototype);
    CXViewBlock.prototype.constructor = CXViewBlock;
    CXViewBlock.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jBlock = this.oPlayer.jStorage.find("[cx-template='view-block-template']").clone(true).removeAttr("cx-template").attr({ "cx-id": this.sId, "cx-template-id": this.oParent.sTemplateId }).appendTo(this.jContainer).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }).hide();
        this.jBlockBtns = this.jBlock.find("[cx-role='block-btns']");
        this.jName = this.jBlock.find("[cx-role='template-name']");
        if(this.oParent.oEditor.nUnscale != 1)
		{
            this.jName.css({ "transform": "scale(" + this.oParent.oEditor.nUnscale + "," + this.oParent.oEditor.nUnscale + ")" });
            this.jBlockBtns.css({ "transform": "scale(" + this.oParent.oEditor.nUnscale + "," + this.oParent.oEditor.nUnscale + ")" });
        }
        this.jBlockFrame = this.jBlock.find("[cx-role='view-frame']");
        this.jThrobber = this.jBlock.find("[cx-role='view-block-wait']");
        this.jName.html(this.oPlayer.oStore[this.oParent.sStoreId].oData[this.oParent.sTemplateId].name);
        this.jBlock.find("[cx-btn]").each(function() {
            oThis.oBtns[this.getAttribute("cx-btn")] = { jBtn: $(this).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
        });
        this.bVisible = false;
        return this;
    };
    CXViewBlock.prototype.Select = function(oArgs)
	{
        var oThis = this;
        this.oEditor.Unselect();
        this.jBlock.attr({ "cx-state": "selected" });
        this.bSelected = true;
        this.oEditor.sSelectedId = this.sId;
        this.oEditor.sSelectedMacro = (this.oParent.bIsChild) ? this.oParent.oParentOWT.override_template_id : null;
        this.FireEvent({ sEvent: "select" });
        this.oParent.FireEvent({ sEvent: "select" });
        this.oEditor.FireEvent({ sEvent: "select" });
        return this;
    };
    CXViewBlock.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        var sRole = oArgs.oElem.getAttribute("cx-role");
        switch(sRole)
		{
            case "view-block":
			{
				this.Select();
				this.oPlayer.oPages.desktop.oBtns["add-slide"].jBtn.css({ "margin-top": (this.jBlock.position().top) + "px" });
				if(typeof this.jBlock[0].scrollIntoViewIfNeeded == "function")
				{
					this.jBlock[0].scrollIntoViewIfNeeded();
				}
				else
				{
					this.jBlock[0].scrollIntoView(true);
				}
				break;
			}
            case "btn-block-delete":
			{
				var sTemplateName = this.oParent.oOWT.name;
				if(sTemplateName==null)
				{
					if(this.oParent.oOWT._sortname!=null)
					{
						sTemplateName = this.oParent.oOWT._sortname.charAt(0).toUpperCase() + this.oParent.oOWT._sortname.substr(1);
					}
					else
					{
						sTemplateName = this.oParent.oOWT.id;
					}
				}
				this.oPlayer.oAlert.Show({
					sTitle: oThis.oPlayer._GetString({ sId: "cx-confirm-title-delete-item" }),
					sText: this.oPlayer._GetString({ sId: "cx-confirm-text-delete-item" }).split("%1").join(sTemplateName),
					bDisplayCancel: true,
					oOKContext: oThis,
					fnOK: function() {
						oThis.oEditor.Delete({ oItem: oThis });
					},
					oArgsOK: {}
				});
				break;
			}
            case "btn-block-up":
			{
				//if(noparent)
				this.oEditor.Reorder({ oItem: this.oParent, sDir: "up" });
				break;
			}
            case "btn-block-down":
			{
				//if(noparent)
				this.oEditor.Reorder({ oItem: this.oParent, sDir: "down" });
				break;
			}
        }
        oArgs.oEvt.preventDefault();
        oArgs.oEvt.stopPropagation();
        oArgs.oEvt.stopImmediatePropagation();
        return this;
    };
    CXViewBlock.prototype.Unselect = function(oArgs)
	{
        var oThis = this;
        this.jBlock.removeAttr("cx-state");
        this.bSelected = false;
        if(this.oEditor.sSelectedId == this.sId)
		{
            this.oEditor.sSelectedId = "";
        }
        this.FireEvent({ sEvent: "unselect" });
        return this;
    };
    CXViewBlock.prototype.Update = function(oArgs)
	{
        var oThis = this;
        if(oArgs.oData != null)
		{
            this.jBlockFrame.html(oArgs.oData);
			this.UpdateContext();
            if(!this.bVisible)
			{
                this.jBlock.slideDown(250);
                this.bVisible = true;
            }
            this.jThrobber.fadeOut(250);
            this.FireEvent({ sEvent: "loaded" });
            var iIdx = $.inArray(this.sId, this.oPlayer.aLoading);
            if(iIdx == -1)
			{
                iIdx = $.inArray("_NEW", this.oPlayer.aLoading);
            }
            if(iIdx != -1)
			{
                this.oPlayer.aLoading.splice(iIdx, 1);
                this.oPlayer.bLockParamUpdate = (this.oPlayer.aLoading.length != 0);
            }
        }
		else if(oArgs.oTemplate != null)
		{
            this.oParent.oTemplate = oArgs.oTemplate;
            this.oParent.sTemplateId = this.oParent.oTemplate.id;
			this.jName.html(this.oParent.oTemplate.name);
			this.jThrobber.show();
			if(this.oParent.oTemplate.url.indexOf("lpe=1") == -1)
			{
				this.oParent.oTemplate.url += "&lpe=1";
			}
			var sObjectIdPart = "&object_id="; // object_id points to owt and is already in url
			var sObjectId = (this.oPlayer.oCurrentWebModeCopy.sample_object_id != null && this.oPlayer.oCurrentWebModeCopy.sample_object_id != "") ? this.oPlayer.oCurrentWebModeCopy.sample_object_id : "";
			if(sObjectId != "")
			{
				sObjectIdPart += sObjectId;
			}
			if(this.oParent.oTemplate.url.indexOf("object_id=") == -1)
			{
				this.oParent.oTemplate.url += sObjectIdPart;
			}
			else
			{
				if(this.oParent.oTemplate.url.indexOf(sObjectIdPart) == -1) {
					var aParts = this.oParent.oTemplate.url.split("&object_id=");
					var aChunks = aParts[1].split("&");
					aChunks[0] = sObjectId;
					aParts[1] = aChunks.join("&");
					this.oParent.oTemplate.url = aParts.join("&object_id=");
				}
			}
			if(this.oParent.oTemplate.url.indexOf("curcatalog=") == -1)
			{
				this.oParent.oTemplate.url += "&curcatalog=" + this.oPlayer.oCurrentWebModeCopy.catalog_name;
			}
			if(this.oParent.oTemplate.url.indexOf("web_mode_id=") == -1)
			{
				this.oParent.oTemplate.url += "&web_mode_id=" + this.oPlayer.oCurrentWebModeCopy.id;
			}
			if(this.oParent.oTemplate.url.indexOf("web_design_id=") == -1)
			{
				this.oParent.oTemplate.url += "&web_design_id=" + this.oPlayer.oCurrentWebModeCopy.web_design_id;
			}
			this.Load({ sURL: this.oParent.oTemplate.url, sDataType: "html", oContext: this, fnSuccess: this.Update, oSuccessArgs: {} });
        }
        return this;
    };
    CXViewBlock.prototype.UpdateContext = function(oArgs)
	{
		var i;
		var aBefore = JSON.parse(JSON.stringify(this.aUsedContext));
		this.aUsedContext = [];
		var jFirstChild = this.jBlockFrame.children("div:first");
		if(jFirstChild.length>0)
		{
			var sUC = jFirstChild.attr("wt-used-context");
			if(sUC!=null)
			{
				if(sUC!="")
				{
					this.aUsedContext = sUC.split(";");
				}
			}
		}
		if(this.aUsedContext.length!=0 || aBefore.length!=0)
		{
			var aAdded = [];
			var aDeleted = [];
			for(i=0; i<this.aUsedContext.length; i++)
			{
				if($.inArray(this.aUsedContext[i], aBefore)==-1)
				{
					aAdded.push(this.aUsedContext[i]);
				}
			}
			for(i=0; i<aBefore.length; i++)
			{
				if($.inArray(aBefore[i], this.aUsedContext)==-1)
				{
					aDeleted.push(aBefore[i]);
				}
			}
			 this.oEditor.UpdateContext({ sOWTId: jFirstChild.attr("wt-owt-id"), aUsed: this.aUsedContext, aAdded: aAdded, aDeleted: aDeleted });
		}
		return this;
	};
}
{ // CXViewMacro - macro zone shadow, single stack for vertical, multiple stacks for horizontal
    window.CXViewMacro = function(oArgs)
	{
        WTBaseObject.call(this, oArgs);
        this.oParent = oArgs.oParent;
        this.oSource = oArgs.oSource;
        this.oEditor = this.oParent.oEditor;
        this.oBtns = {};
        this.aStacks = [];
		this.aUsedContext = [];
        this.Constructor();
        return this;
    };
    CXViewMacro.prototype = Object.create(WTBaseObject.prototype);
    CXViewMacro.prototype.constructor = CXViewMacro;
    CXViewMacro.prototype.AdjustBtn = function(oArgs)
	{
        var sBlockId = null;
		var nTop, nLeft;
		if(this.sSelectedBlockId!=null && this.oZones[this.sSelectedBlockId]==null)
		{
			this.sSelectedBlockId = null;
		}
		switch(this.sStackType)
		{
			case "tabs":
			{
				var iTab = null;
				if(this.sSelectedBlockId!=null)
				{
					sBlockId = this.sSelectedBlockId;
					iTab = this.oZones[sBlockId].iTab;
				}
				else if(this.iTabSelected!=null)
				{
					iTab = this.iTabSelected;
					if(this.aServiceZones != null)
					{
						if(this.aServiceZones.constructor === Array)
						{
							if(this.aServiceZones[iTab] != null)
							{
								if(this.aServiceZones[iTab].constructor === Array)
								{
									if(this.aServiceZones[iTab].length != 0)
									{
										sBlockId = this.aServiceZones[iTab][this.aServiceZones[iTab].length - 1];
									}
									else
									{
										sBlockId = "empty";
									}
								}
							}
							else
							{
								sBlockId = "empty";
							}
						}
					}
				}
				nTop = 0;
				nLeft = 0;
				if(iTab!=null && sBlockId!=null)
				{
					if(this.aStacks[iTab]!=null)
					{
						if(sBlockId=="empty")
						{
							nTop = parseFloat(this.aStacks[iTab].jControl.css("top")) + 0.5 * parseFloat(this.aStacks[iTab].jControl.css("height"));
							nLeft = parseFloat(this.aStacks[iTab].jControl.css("left")) + parseFloat(this.aStacks[iTab].jControl.css("width"));
							this.aStacks[iTab].jBtnContainer.css({ "left": nLeft + "px", "top": nTop + "px" });
						}
						else
						{
							nTop = parseFloat(this.oZones[sBlockId].jControl.css("top")) + parseFloat(this.oZones[sBlockId].jControl.css("height"));
							nLeft = parseFloat(this.oZones[sBlockId].jControl.css("left")) + parseFloat(this.oZones[sBlockId].jControl.css("width"));
							this.aStacks[iTab].jBtnContainer.css({ "left": nLeft + "px", "top": nTop + "px" });
						}
					}
				}
				break;
			}
			case "horizontal":
			{
				var iColumn = null;
				if(this.sSelectedBlockId!=null)
				{
					sBlockId = this.sSelectedBlockId;
					iColumn = this.oZones[sBlockId].iColumn;
				}
				else if(this.iColumnSelected!=null)
				{
					iColumn = this.iColumnSelected;
					if(this.aServiceZones != null)
					{
						if(this.aServiceZones.constructor === Array)
						{
							if(this.aServiceZones[iColumn] != null)
							{
								if(this.aServiceZones[iColumn].constructor === Array)
								{
									if(this.aServiceZones[iColumn].length != 0)
									{
										sBlockId = this.aServiceZones[iColumn][this.aServiceZones[iColumn].length - 1];
									}
									else
									{
										sBlockId = "empty";
									}
								}
							}
						}
					}
				}
				if(iColumn!=null && sBlockId!=null)
				{
					if(this.aStacks[iColumn]!=null)
					{
						nTop = 0;
						if(sBlockId=="empty")
						{
							nTop = parseFloat(this.aStacks[iColumn].jControl.css("top")) + 0.5 * parseFloat(this.aStacks[iColumn].jControl.css("height"));
							nLeft = parseFloat(this.aStacks[iColumn].jControl.css("left")) + parseFloat(this.aStacks[iColumn].jControl.css("width"));
							this.aStacks[iColumn].jBtnContainer.css({ "left": nLeft + "px", "top": nTop + "px" });
						}
						else
						{
							nTop = parseFloat(this.oZones[sBlockId].jControl.css("top")) + parseFloat(this.oZones[sBlockId].jControl.css("height"));
							nLeft = parseFloat(this.oZones[sBlockId].jControl.css("left")) + parseFloat(this.oZones[sBlockId].jControl.css("width"));
							this.aStacks[iColumn].jBtnContainer.css({ "left": nLeft + "px", "top": nTop + "px" });
						}
					}
				}
				break;
			}
			case "vertical":
			{
				break;
			}
		}
        return this;
    };
    CXViewMacro.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.sStoreId = "macros";
		this.sStackType = this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: ".__service__stack_type", bContains: true });
		if(this.sStackType=="tabs")
		{
			this.sTabType = this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: ".tab_type", bContains: true });
		}
        this.bMultiple = (this.sStackType=="horizontal" || this.sStackType=="tabs");
        this.jBlock = this.oPlayer.jStorage.find("[cx-template='view-block']").clone(true).removeAttr("cx-template").attr({ "cx-macro-type": this.sStackType, "cx-id": this.sId, "cx-template-id": this.oParent.sTemplateId }).appendTo(this.jContainer).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }).hide();
        this.jBlock.find("[cx-mask='block']").remove();
        this.jMacroControls = this.jBlock.find("[cx-role='macro-controls']");
        this.jBlockBtns = this.jBlock.find("[cx-role='block-btns']");
        this.jMacroBtns = this.jBlock.find("[cx-role='macro-btns']");
        this.jName = this.jBlock.find("[cx-role='template-name']");
        this.jBlock.attr({ "cx-macro": "1" });
        this.jBlockBtns.remove();
        this.jMacroControls.show();
        this.jMacroControlTemplate = this.oPlayer.jStorage.find("[cx-template='macro-control-template']");
 //       this.jMacroBtnTemplate = this.oPlayer.jStorage.find("[cx-template='macro-btn-template']");
        this.oZones = {};
        if(this.oEditor.nUnscale != 1)
		{
            this.jName.css({ "transform": "scale(" + oThis.oEditor.nUnscale + "," + oThis.oEditor.nUnscale + ")" });
            this.jMacroBtns.find("[cx-role='macro-btns-container']").css({ "transform": "scale(" + oThis.oEditor.nUnscale + "," + oThis.oEditor.nUnscale + ")" });
        }
		switch(this.sStackType)
		{
			case "horizontal":
			{
				this.sColumnsFldName = this.oEditor._GetParamName({ aParams: this.oParent.oOWT.params, sName: ".columns" });
				this.sColumnsFldNameEncoded = TOOLS.EncodeVarName({ sText: this.sColumnsFldName });
				this.jBlock.attr({ "cx-macro-horizontal": "1" });
				// sync link with dialog fld
				this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sColumnsFldNameEncoded].oControl.Subscribe({ sId: this.oParent.sTemplateId, sEvent: "select", fn: oThis.UIEvent, oContext: oThis, oArgs: { oElem: this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sColumnsFldNameEncoded], oThis: oThis, oEvt: { type: "select" } } });
				break;
			}
			case "tabs":
			{
				this.sTabsFldName = this.oEditor._GetParamName({ aParams: this.oParent.oOWT.params, sName: ".items" });
				this.sTabsFldNameEncoded = TOOLS.EncodeVarName({ sText: this.sTabsFldName });
				this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sTabsFldNameEncoded].oControl.Subscribe({ sId: this.oParent.sTemplateId, sEvent: "select", fn: oThis.UIEvent, oContext: oThis, oArgs: { oElem: this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sTabsFldNameEncoded], oThis: oThis, oEvt: { type: "select" } } });
				break;
			}
			case "vertical":
			default:
			{
				// vertical = default, no actions here
				break;
			}
		}
        this.jBlockFrame = this.jBlock.find("[cx-role='view-frame']");
        this.jThrobber = this.jBlock.find("[cx-role='view-block-wait']");
        this.jName.html(this.oPlayer.oStore[this.sStoreId].oData[this.oParent.sTemplateId].name);
        this.jBlock.find("[cx-btn]").each(function()
		{
            oThis.oBtns[this.getAttribute("cx-btn")] = { jBtn: $(this).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); }) };
        });
        this.bVisible = false;
        return this;
    };
    CXViewMacro.prototype.FldSync = function(oArgs)
	{
        var sFldName, sFldNameEncoded;
		switch(this.sStackType)
		{
			case "horizontal":
			{
				sFldName = this.sColumnsFldName;
				sFldNameEncoded = this.sColumnsFldNameEncoded;
				break;
			}
			case "tabs":
			{
				sFldName = this.sTabsFldName;
				sFldNameEncoded = this.sTabsFldNameEncoded;
				break;
			}
		}
		var oFld = this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[sFldNameEncoded];
        var iCnt = -1;
        if(oFld.oCurrentListItem != null)
		{
            for(var sKey in oFld.oListItems)
			{
                if(oFld.oListItems.hasOwnProperty(sKey))
				{
                    iCnt++;
                    if(oFld.oCurrentListItem.sId==sKey)
					{
                        break;
                    }
                }
            }
        }
		else if(oFld.oListItems!=null)
		{
            iCnt = Object.keys(oFld.oListItems).length - 1;
        }
		else
		{
			var sData = this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: sFldName, bContains: false });
			if(sData!="")
			{
				iCnt = JSON.parse(this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: sFldName, bContains: false })).length - 1;
			}
        }
        if(iCnt != -1)
		{
			switch(this.sStackType)
			{
				case "tabs":
				{
					this.SelectTab({ iTab: iCnt, bSuppressEvent: true });
					break;
				}
				case "horizontal":
				{
					this.SelectColumn({ iColumn: iCnt, bSuppressEvent: true });
					break;
				}
				case "tabs":
				{
					if(this.iTabSelected!=null)
					{
						this.SelectTab({ iTab: this.iTabSelected, bSuppressEvent: true });
					}
					else
					{
						this.SelectTab({ iTab: iCnt, bSuppressEvent: true });
					}
					break;
				}
			}
        }
        return this;
    };
	CXViewMacro.prototype.PlaceStack = function (oArgs)
	{
		var iCnt = 0;
		var jParent;
		switch(this.sStackType)
		{
			case "tabs":
			{
				oArgs.oStack.nW = oArgs.oStack.jSrcPage[0].offsetWidth;
				oArgs.oStack.nH = oArgs.oStack.jSrcPage[0].offsetHeight;
				oArgs.oStack.nTabW = oArgs.oStack.jSrcTab[0].offsetWidth;
				oArgs.oStack.nTabH = oArgs.oStack.jSrcTab[0].offsetHeight;
				oArgs.oStack.nX = 0;
				oArgs.oStack.nY = 0;
				oArgs.oStack.nTabX = 0;
				oArgs.oStack.nTabY = 0;
				jParent = oArgs.oStack.jSrcPage;
				while(jParent[0]!=this.jBlockFrame[0])
				{
					oArgs.oStack.nX += jParent[0].offsetLeft;
					oArgs.oStack.nY += jParent[0].offsetTop;
					jParent = jParent.parent();
					if(++iCnt > 10)
					{
						break;
					}
				}
				jParent = oArgs.oStack.jSrcTab;
				iCnt = 0;
				while(jParent[0]!=this.jBlockFrame[0])
				{
					oArgs.oStack.nTabX += jParent[0].offsetLeft;
					oArgs.oStack.nTabY += jParent[0].offsetTop;
					jParent = jParent.parent();
					if(++iCnt > 10)
					{
						break;
					}
				}
				oArgs.oStack.jControl.css({ "left": oArgs.oStack.nX + "px", "top": oArgs.oStack.nY + "px", "width": oArgs.oStack.nW + "px", "height": oArgs.oStack.nH + "px" });
				oArgs.oStack.jControlBtn.css({ "left": oArgs.oStack.nTabX + "px", "top": oArgs.oStack.nTabY + "px", "width": oArgs.oStack.nTabW + "px", "height": oArgs.oStack.nTabH + "px" });
				break;
			}
			case "horizontal":
			{
				oArgs.oStack.nW = oArgs.oStack.jSrcColumn[0].offsetWidth;
				oArgs.oStack.nH = oArgs.oStack.jSrcColumn[0].offsetHeight;
				oArgs.oStack.nX = 0;
				oArgs.oStack.nY = 0;
				jParent = oArgs.oStack.jSrcColumn;
				while(jParent[0]!=this.jBlockFrame[0])
				{
					oArgs.oStack.nX += jParent[0].offsetLeft;
					oArgs.oStack.nY += jParent[0].offsetTop;
					jParent = jParent.parent();
					if(++iCnt > 10)
					{
						break;
					}
				}
				oArgs.oStack.jControl.css({ "left": oArgs.oStack.nX + "px", "top": oArgs.oStack.nY + "px", "width": oArgs.oStack.nW + "px", "height": oArgs.oStack.nH + "px" });
				break;
			}
			case "vertical":
			{
				break;
			}
		}
		return this;
	};
	CXViewMacro.prototype.PlaceZone = function (oArgs)
	{
		var iCnt = 0;
		var sId = oArgs.sId;
		var jCurZone = this.jBlockFrame.find("[wt-role='macro-zone'][wt-owt-id='" + sId + "']"); //if(jCurZone.length==0) return this;
		var jParent;
		this.oZones[sId].nW = jCurZone[0].offsetWidth;
		this.oZones[sId].nH = jCurZone[0].offsetHeight;
		this.oZones[sId].nX = 0;
		this.oZones[sId].nY = 0;
		jParent = $(jCurZone);
		while(jParent[0] != this.jBlockFrame[0])
		{
			this.oZones[sId].nX += jParent[0].offsetLeft;
			this.oZones[sId].nY += jParent[0].offsetTop;
			jParent = jParent.parent();
			if(++iCnt > 20)
			{
				break;
			}
		}
		this.oZones[sId].jControl.css({ "left": this.oZones[sId].nX + "px", "top": this.oZones[sId].nY + "px", "width": this.oZones[sId].nW + "px", "height": this.oZones[sId].nH + "px" });
		return this;
	};
    CXViewMacro.prototype.Select = function(oArgs)
	{
        var oThis = this;
        this.oEditor.Unselect();
        this.jBlock.attr({ "cx-state": "selected" });
        this.bSelected = true;
        this.oEditor.sSelectedId = this.sId;
        this.oEditor.sSelectedMacro = this.sId;
        if(this.bMultiple)
		{
            this.FldSync();
        }
        if(oArgs != null)
		{
            if(oArgs.bSuppressEvent == true)
			{
                return this;
            }
        }
        this.FireEvent({ sEvent: "select" });
        this.oParent.FireEvent({ sEvent: "select" });
        this.oEditor.FireEvent({ sEvent: "select" });
        return this;
    };
    CXViewMacro.prototype.SelectBlock = function(oArgs)
	{
        var oThis = this;
        if(oArgs == null)
		{
            return this;
        }
        if(this.oZones[oArgs.sBlockId] != null)
		{
            this.oZones[oArgs.sBlockId].bSelected = true;
            this.oZones[oArgs.sBlockId].jControl.attr({ "cx-state": "selected" });
            if(this.oEditor.oXBlocks[oArgs.sBlockId] != null)
			{
                this.oEditor.oXBlocks[oArgs.sBlockId].Select();
                this.jBlock.attr({ "cx-state": "selected" });
            }
            this.sSelectedBlockId = oArgs.sBlockId;
            setTimeout(function() { oThis.AdjustBtn(); }, 50);
        }
        return this;
    };
    CXViewMacro.prototype.SelectColumn = function(oArgs)
	{
        if(oArgs == null || this.aStacks == null)
		{
            return this;
        }
        var oThis = this;
        var iColumn = oArgs.iColumn;
        if(!isNaN(iColumn))
		{
            for(var i = 0; i<this.aStacks.length; i++)
			{
                if(i == iColumn)
				{
                    this.aStacks[i].jControl.attr({ "cx-state": "selected" });
                    this.aStacks[i].jBtnContainer.show();
                    this.aStacks[i].bSelected = true;
                    this.iColumnSelected = i;
                    if(oArgs.bSuppressEvent != true)
					{
                        this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sColumnsFldNameEncoded].oControl.aPages[i].jBtn.click();
                    }
                }
				else
				{
                    this.UnselectColumn({ iColumn: i });
                }
            }
            setTimeout(function() { oThis.AdjustBtn(); }, 50);
        }
        if(oArgs.bSuppressEvent != true)
		{
            this.FireEvent({ sEvent: "selectcolumn" });
            this.oParent.FireEvent({ sEvent: "selectcolumn" });
            this.oEditor.FireEvent({ sEvent: "selectcolumn" });
        }
        return this;
    };
    CXViewMacro.prototype.SelectTab = function(oArgs)
	{
        if(oArgs==null || this.aStacks==null)
		{
            return this;
        }
        var oThis = this;
		var i;
        var iTab = oArgs.iTab;
        if(!isNaN(iTab))
		{
            for(i=0; i<this.aStacks.length; i++)
			{
                if(i==iTab)
				{
                    this.aStacks[i].jControl.show().attr({ "cx-state": "selected" });
					this.aStacks[i].jControlBtn.attr({ "cx-state": "selected" });
					this.aStacks[i].jSrcTab.attr({ "wt-state": "selected" });
					this.aStacks[i].jSrcPage.show();
                    this.aStacks[i].jBtnContainer.show();
                    this.aStacks[i].bSelected = true;
                    this.iTabSelected = i;
                    if(oArgs.bSuppressEvent != true)
					{
                        this.oEditor.oPage.oTemplateDialogs[this.oParent.sTemplateId].aDialogPages[0].oFlds[this.sTabsFldNameEncoded].oControl.aPages[i].jBtn.click();
                    }
                }
				else
				{
					this.aStacks[i].jSrcPage.hide();
					this.aStacks[i].jControl.hide();
					this.aStacks[i].jSrcPage.hide();
					this.aStacks[i].jBtnContainer.hide();
					this.aStacks[i].jControl.removeAttr("cx-state");
					this.aStacks[i].jControlBtn.removeAttr("cx-state");
					this.aStacks[i].jSrcTab.removeAttr("wt-state");
                }
            }
			if(this.iTabSelected>=0 && this.iTabSelected<this.aStacks.length)
			{
				if(this.sTabType=="accordeon")
				{
					for(i=0; i<this.aStacks.length; i++)
					{
						this.PlaceStack({ oStack: this.aStacks[i] });
					}
				}
				else
				{
					this.PlaceStack({ oStack: this.aStacks[this.iTabSelected] });
				}
				this.SelectTabZones({ iTab: i });
			}
            setTimeout(function() { oThis.AdjustBtn(); }, 50);
        }
        if(oArgs.bSuppressEvent != true)
		{
            this.FireEvent({ sEvent: "selectcolumn" });
            this.oParent.FireEvent({ sEvent: "selectcolumn" });
            this.oEditor.FireEvent({ sEvent: "selectcolumn" });
        }
        return this;
    };
	CXViewMacro.prototype.SelectTabZones = function (oArgs)
	{
		var oThis = this;
		var sId;
		var jCurZone;
		var jParent;
		var i, j, iCnt;
		if(this.aServiceZones!=null)
		{
			if(this.aServiceZones.constructor === Array)
			{
				for(i=0; i<this.aServiceZones.length; i++)
				{
					if(typeof this.aServiceZones[i] == "object")
					{
						if(this.aServiceZones[i].constructor === Array)
						{
							if(i==this.iTabSelected)
							{
								for(j=0; j<this.aServiceZones[i].length; j++)
								{
									sId = this.aServiceZones[i][j];
									if(this.oZones[sId]==null)
									{
										continue;
									}
									jCurZone = this.jBlockFrame.find("[wt-role='macro-zone'][wt-owt-id='" + sId + "']");
									if(this.oEditor.nUnscale != 1)
									{
										this.oZones[sId].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
										this.oZones[sId].jBlockBtns.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
									}
									this.oZones[sId].jControl.show();
									this.PlaceZone({ sId: sId });
									if(sId == this.sSelectedChildId)
									{
										oThis.oZones[sId].jControl.attr({ "cx-state": "selected" });
									}
								}
							}
							else
							{
								for(j=0; j<this.aServiceZones[i].length; j++)
								{
									if(this.oZones[this.aServiceZones[i][j]]==null)
									{
										continue;
									}
									this.oZones[this.aServiceZones[i][j]].jControl.hide();
								}
							}
						}
					}
				}
			}
		}
		return this;
	};
    CXViewMacro.prototype.SelectZone = function(oArgs)
	{
        for(var sKey in this.oZones)
		{
            if(sKey != oArgs.sId)
			{
                this.oZones[sKey].bSelected = false;
                this.oZones[sKey].jControl.removeAttr("cx-state");
            }
			else
			{
                this.oZones[sKey].bSelected = true;
                this.oZones[sKey].jControl.attr({ "cx-state": "selected" });
                if(this.oEditor.oBlocks[sKey] != null)
				{
                    this.oEditor.oBlocks[sKey].Select();
                }
            }
        }
        return this;
    };
    CXViewMacro.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        if(oArgs.oEvt!=null)
		{
            if(oArgs.oEvt.type=="select")
			{
                this.FldSync();
                return this;
            }
        }
        var sId, sTemplateName;
        var sRole = oArgs.oElem.getAttribute("cx-role");
        switch(sRole)
		{
            case "add-template":
			{
				var iColumn = this.iColumnSelected;
				this.oEditor.oPage.oDialogs["objects"].Show({ bMacro: true, bColumn: true, oTarget: this });
				break;
			}
            case "view-block": // select whole macro
			{
				this.UnselectColumn().UnselectBlock().Select(); // unselect any column if selected,
				this.oPlayer.oPages.desktop.oBtns["add-slide"].jBtn.css({ "margin-top": (this.jBlock.position().top) + "px" });
				if(typeof this.jBlock[0].scrollIntoViewIfNeeded == "function")
				{
					this.jBlock[0].scrollIntoViewIfNeeded();
				}
				else
				{
					this.jBlock[0].scrollIntoView(true);
				}
				break;
			}
            case "macro-control":
			{
				this.Select(); // select macro anyway
				if(oArgs.oElem.getAttribute("cx-owt-id") != null) // click on block
				{
					sId = oArgs.oElem.getAttribute("cx-owt-id");
					if(this.oZones[sId] != null)
					{
						if(this.oZones[sId].iColumn != null)
						{
							if(this.iColumnSelected != this.oZones[sId].iColumn)
							{
								this.UnselectColumn().SelectColumn({ iColumn: this.oZones[sId].iColumn, bSuppressEvent: true });
							}
						}
						this.UnselectBlock().SelectBlock({ sBlockId: sId });
					}
				}
				else if(oArgs.oElem.getAttribute("cx-column") != null) // click on column
				{
					this.UnselectBlock().UnselectColumn().SelectColumn({ iColumn: +oArgs.oElem.getAttribute("cx-column") });
				}
				else if(oArgs.oElem.getAttribute("cx-tab") != null) // click on tab
				{
					this.UnselectBlock().SelectTab({ iTab: +oArgs.oElem.getAttribute("cx-tab") });
				}
				break;
			}
            case "btn-block-delete":
			{
				sTemplateName = this.oParent.oOWT.name;
				if(sTemplateName==null)
				{
					if(this.oParent.oOWT._sortname!=null)
					{
						sTemplateName = this.oParent.oOWT._sortname.charAt(0).toUpperCase() + this.oParent.oOWT._sortname.substr(1);
					}
					else
					{
						sTemplateName = this.oParent.oOWT.id;
					}
				}
				this.oPlayer.oAlert.Show(
				{
					sTitle: oThis.oPlayer._GetString({ sId: "cx-confirm-title-delete-item" }),
					sText: this.oPlayer._GetString({ sId: "cx-confirm-text-delete-item" }).split("%1").join(sTemplateName),
					bDisplayCancel: true,
					oOKContext: oThis,
					fnOK: function() { oThis.oEditor.Delete({ oItem: oThis }); },
					oArgsOK: {}
				});
				break;
			}
            case "btn-child-delete":
			{
				sId = oArgs.oElem.getAttribute("cx-owt-id");
				sTemplateName = this.oZones[sId].oOWT.name;
				if(sTemplateName==null)
				{
					if(this.oParent.oOWT._sortname!=null)
					{
						sTemplateName = this.oZones[sId].oOWT._sortname.charAt(0).toUpperCase() + this.oZones[sId].oOWT._sortname.substr(1);
					}
					else
					{
						sTemplateName = this.oZones[sId].oOWT.id;
					}
				}
				this.oPlayer.oAlert.Show(
				{
					sTitle: oThis.oPlayer._GetString({ sId: "cx-confirm-title-delete-item" }),
					sText: this.oPlayer._GetString({ sId: "cx-confirm-text-delete-item" }).split("%1").join(sTemplateName),
					bDisplayCancel: true,
					oOKContext: oThis,
					fnOK: function() { oThis.oEditor.Delete({ oItem: oThis.oEditor.oXBlocks[sId] }); },
					oArgsOK: {}
				});
				break;
			}
            case "btn-child-up":
			{
				sId = oArgs.oElem.getAttribute("cx-owt-id");
				this.oEditor.Reorder({ oItem: this.oEditor.oXBlocks[sId], oMacro: this.oParent, sDir: "up" });
				break;
			}
            case "btn-child-down":
			{
				sId = oArgs.oElem.getAttribute("cx-owt-id");
				this.oEditor.Reorder({ oItem: this.oEditor.oXBlocks[sId], oMacro: this.oParent, sDir: "down" });
				break;
			}
            case "btn-block-up":
			{
				//if(noparent)
				this.oEditor.Reorder({ oItem: this.oParent, sDir: "up" });
				break;
			}
            case "btn-block-down":
			{
				//if(noparent)
				this.oEditor.Reorder({ oItem: this.oParent, sDir: "down" });
				break;
			}
        }
        oArgs.oEvt.preventDefault();
        oArgs.oEvt.stopPropagation();
        oArgs.oEvt.stopImmediatePropagation();
        return this;
    };
    CXViewMacro.prototype.Unselect = function(oArgs)
	{
        var oThis = this;
        this.jBlock.removeAttr("cx-state");
        this.bSelected = false;
        if(this.oEditor.sSelectedId == this.sId)
		{
            this.oEditor.sSelectedId = "";
        }
        this.FireEvent({ sEvent: "unselect" });
        return this;
    };
    CXViewMacro.prototype.UnselectBlock = function(oArgs)
	{
        if(oArgs == null)
		{
            for(var sKey in this.oZones)
			{
                if(this.oZones[sKey].bSelected)
				{
                    this.oEditor.oXBlocks[sKey].Unselect();
                    this.oZones[sKey].jControl.removeAttr("cx-state");
                }
            }
            this.sSelectedBlockId = null;
        }
		else if(oArgs.sBlockId != null)
		{
            if(this.oZones[oArgs.sBlockId] != null)
			{
                if(this.oZones[oArgs.sBlockId].bSelected)
				{
                    this.oEditor.oXBlocks[oArgs.sBlockId].Unselect();
                    this.oZones[oArgs.sBlockId].jControl.removeAttr("cx-state");
                    this.sSelectedBlockId = null;
                }
            }
        }
        return this;
    };
    CXViewMacro.prototype.UnselectColumn = function(oArgs)
	{
        if(oArgs == null)
		{
            for(var i = 0; i<this.aStacks.length; i++)
			{
                if(this.aStacks[i].bSelected)
				{
                    this.aStacks[i].jControl.removeAttr("cx-state");
                    this.aStacks[i].bSelected = false;
                    this.aStacks[i].jBtnContainer.hide();
                }
            }
            this.iColumnSelected = null;
        }
		else if(oArgs.iColumn != null)
		{
            if(this.aStacks[oArgs.iColumn].bSelected)
			{
                this.aStacks[oArgs.iColumn].jControl.removeAttr("cx-state");
                this.aStacks[oArgs.iColumn].bSelected = false;
                this.aStacks[oArgs.iColumn].jBtnContainer.hide();
                this.iColumnSelected = null;
            }
        }
        return this;
    };
    CXViewMacro.prototype.Update = function(oArgs)
	{
        var oThis = this;
        if(oArgs.oData != null)
		{
            this.jBlockFrame.html(oArgs.oData);
			this.UpdateContext();
            if(!this.bVisible)
			{
                this.jBlock.slideDown(250);
                this.bVisible = true;
            }
            this.UpdateStack();
            if(this.oEditor.sCurrentMovedId != null)
			{
                this.oEditor.oXBlocks[this.oEditor.sCurrentMovedId].Select();
                this.oEditor.sCurrentMovedId = null;
            }
            this.jThrobber.fadeOut(250);
            if(this.oEditor.oPage.oCurrentObjectDialog != null)
			{
                if(this.oEditor.oPage.oCurrentObjectDialog.oCurrentOWT != null)
				{
                    var sId = this.oEditor.oPage.oCurrentObjectDialog.oCurrentOWT.override_template_id;
                    this.Select();
                    if(this.oZones[sId] != null)
					{
                        if(this.oZones[sId] != null)
						{
                            if(this.oZones[sId].iColumn != null)
							{
                                if(this.iColumnSelected != this.oZones[sId].iColumn)
								{
                                    this.UnselectColumn().SelectColumn({ iColumn: this.oZones[sId].iColumn, bSuppressEvent: true });
                                }
                            }
                            this.UnselectBlock().SelectBlock({ sBlockId: sId });
                        }
                    }
                }
            }
            this.oParent.FireEvent({ sEvent: "loaded" });
            var iIdx = $.inArray(this.sId, this.oPlayer.aLoading);
            if(iIdx == -1)
			{
                iIdx = $.inArray("_NEW", this.oPlayer.aLoading);
            }
            if(iIdx != -1)
			{
                this.oPlayer.aLoading.splice(iIdx, 1);
                this.oPlayer.bLockParamUpdate = (this.oPlayer.aLoading.length != 0);
            }
        }
		else if(oArgs.oTemplate != null)
		{
            this.oTemplate = oArgs.oTemplate;
            this.sTemplateId = this.oTemplate.id;
            this.jName.html(this.oTemplate.name);
            this.jThrobber.show();
            if(this.oTemplate.url.indexOf("lpe=1") == -1)
			{
                this.oTemplate.url += "&lpe=1";
            }
            var sObjectIdPart = "&object_id="; // object_id points to owt and is already in url
            var sObjectId = (this.oPlayer.oCurrentWebModeCopy.sample_object_id != null && this.oPlayer.oCurrentWebModeCopy.sample_object_id != "") ? this.oPlayer.oCurrentWebModeCopy.sample_object_id : "";
            if(sObjectId != "")
			{
                sObjectIdPart += sObjectId;
            }
            if(this.oTemplate.url.indexOf("object_id=") == -1)
			{
                this.oTemplate.url += sObjectIdPart;
            }
			else
			{
                if(this.oTemplate.url.indexOf(sObjectIdPart) == -1)
				{
                    var aParts = this.oTemplate.url.split("&object_id=");
                    var aChunks = aParts[1].split("&");
                    aChunks[0] = sObjectId;
                    aParts[1] = aChunks.join("&");
                    this.oTemplate.url = aParts.join("&object_id=");
                }
            }
            if(this.oTemplate.url.indexOf("curcatalog=") == -1)
			{
                this.oTemplate.url += "&curcatalog=" + this.oPlayer.oCurrentWebModeCopy.catalog_name;
            }
			if(this.oTemplate.url.indexOf("web_mode_id=") == -1)
			{
				this.oTemplate.url += "&web_mode_id=" + this.oPlayer.oCurrentWebModeCopy.id;
			}
			if(this.oTemplate.url.indexOf("web_design_id=") == -1)
			{
				this.oTemplate.url += "&web_design_id=" + this.oPlayer.oCurrentWebModeCopy.web_design_id;
			}
            this.Load({ sURL: this.oTemplate.url, sDataType: "html", oContext: this, fnSuccess: this.Update, oSuccessArgs: {} });
        }
        this.bViewInitialized = true;
        return this;
    };
    CXViewMacro.prototype.UpdateContext = function(oArgs)
	{
		var i;
		var aBefore = JSON.parse(JSON.stringify(this.aUsedContext));
		this.aUsedContext = [];
		var jFirstChild = this.jBlockFrame.children(":first");
		var jUC = this.jBlockFrame.find("[wt-used-context]");
		if(jUC.length>0)
		{
			var aUC = [];
			jUC.each(function () { aUC.push(this.getAttribute("wt-used-context")); });
			var sUC = aUC.join(";");
			if(sUC!="")
			{
				aUC = sUC.split(";");
				this.aUsedContext = aUC.filter(function (value, index, self) { return self.indexOf(value) === index; });
			}
		}
		if(this.aUsedContext.length!=0 || aBefore.length!=0)
		{
			var aAdded = [];
			var aDeleted = [];
			for(i=0; i<this.aUsedContext.length; i++)
			{
				if($.inArray(this.aUsedContext[i], aBefore)==-1)
				{
					aAdded.push(this.aUsedContext[i]);
				}
			}
			for(i=0; i<aBefore.length; i++)
			{
				if($.inArray(aBefore[i], this.aUsedContext)==-1)
				{
					aDeleted.push(aBefore[i]);
				}
			}
			 this.oEditor.UpdateContext({ sOWTId: jFirstChild.attr("wt-owt-id"), aUsed: this.aUsedContext, aAdded: aAdded, aDeleted: aDeleted });
		}
		return this;
	};
	CXViewMacro.prototype.UpdateStack = function(oArgs)
	{
        var oThis = this;
        var i, j, iCnt;
        var sKey;
        var aChildOWT, aServiceZones;
        for(i=0; i<this.aStacks.length; i++) // cleanup
        {
            this.aStacks[i].jControl.remove();
			if(this.aStacks[i].jControlBtn!=null)
			{
				this.aStacks[i].jControlBtn.remove();
			}
            this.aStacks[i].jBtnContainer.remove();
        }
        for(sKey in this.oZones) // cleanup
        {
            if(this.oZones.hasOwnProperty(sKey))
			{
                this.oZones[sKey].jControl.remove();
                delete this.oZones[sKey];
            }
        }
        this.aStacks = [];
        this.aZones = [];
        this.oZones = {};
        var sServiceZones = this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: ".__service__zones", bContains: true });
        var jParent;
        var jCurZone;
        var sCurOWTId;
		switch(this.sStackType)
		{
			case "tabs":
			{
				var sTabs = this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: this.sTabsFldName, bContains: false });
				var aTabs = sTabs=="" ? [] : JSON.parse(sTabs);
				if(typeof aTabs == "object")
				{
					if(aTabs.constructor === Array)
					{
						var jSrcTabs = this.jBlockFrame.find("[wt-role='tab-btn']");
						if(jSrcTabs.length!=0)
						{
							if(jSrcTabs[0].getAttribute("wt-unify")=="1")
							{
								var nMaxW = 0;
								jSrcTabs.each(function ()
								{
									var nW = $(this).width();
									if(nW>nMaxW)
									{
										nMaxW = nW;
									}
								});
								if(nMaxW>0)
								{
									jSrcTabs.width(nMaxW);
								}
							}
						}
						var jSrcPages = this.jBlockFrame.find("[wt-role='tab-page']");
						var iIdx;
						for(i=0; i<aTabs.length; i++)
						{
							iIdx = i + 1;
							this.aStacks[i] =
							{
								iIdx: iIdx,
								jSrcTab: jSrcTabs.filter("[wt-idx='" + i + "']"),
								jSrcPage: jSrcPages.filter("[wt-idx='" + i + "']"),
								nX: 0,
								nY: 0,
								nTabX: 0,
								nTabY: 0
							};
							this.aStacks[i].jContainer = this.aStacks[i].jSrcPage.find("[wt-role='page-list']");
							this.aStacks[i].jControl = oThis.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-macro-id": this.sId, "cx-tab": i }).appendTo(this.jMacroControls);
							this.aStacks[i].jControlBtn = oThis.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-macro-id": this.sId, "cx-tab": i }).appendTo(this.jMacroControls).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
							this.aStacks[i].jControlBtn.find("[cx-role='btn-container']").remove();

							this.aStacks[i].jName = this.aStacks[i].jControl.find("[cx-role='template-name']").attr({ "cx-tab-name": this.aStacks[i].iIdx }).html(this.aStacks[i].iIdx).hide();
							this.aStacks[i].jNameBtn = this.aStacks[i].jControlBtn.find("[cx-role='template-name']").attr({ "cx-tab-name": this.aStacks[i].iIdx }).html(this.aStacks[i].iIdx);
							this.aStacks[i].jControl.find("[cx-role='block-btns']").remove();
							this.aStacks[i].jControlBtn.find("[cx-role='block-btns']").remove();
							this.aStacks[i].jContent = this.aStacks[i].jControl.find("[cx-role='block-btns']");
							if(this.oEditor.nUnscale!=1)
							{
								this.aStacks[i].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
								this.aStacks[i].jNameBtn.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
							}
							this.PlaceStack({ oStack: this.aStacks[i] });
							this.aStacks[i].jBtnContainer = this.aStacks[i].jControl.find("[cx-role='btn-container']").attr({ "cx-tab": i }).appendTo(this.jBlock).hide();
							this.aStacks[i].jBtn = this.aStacks[i].jBtnContainer.find("[cx-role='add-template']").attr({ "cx-tab": i }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
						}
						if(this.bSelected)
						{
							this.FldSync();
						}
					}
				}
				// tabs built. now create inner items, if any
				this.aServiceZones = JSON.parse(sServiceZones);
				if(this.aServiceZones.constructor === Array)
				{
					for(i=0; i<this.aServiceZones.length; i++)
					{
						if(typeof this.aServiceZones[i] == "object")
						{
							if(this.aServiceZones[i].constructor === Array)
							{
								for(j=0; j<this.aServiceZones[i].length; j++)
								{
									sId = this.aServiceZones[i][j];
									jCurZone = this.jBlockFrame.find("[wt-role='macro-zone'][wt-owt-id='" + sId + "']");
									this.oZones[sId] =
									{
										iTab: i,
										sOWTId: sId,
										oBtns: {},
										jContainer: jCurZone,
										nX: 0,
										nY: 0,
										nW: 0,
										nH: 0,
										jControl: this.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-owt-id": sId }).appendTo(this.jMacroControls).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }),
										oOWT: oThis.oEditor._GetTemplateById({ aTemplates: this.oPlayer.oCurrentWebModeCopy.zones[0].templates, sId: sId })
									};
									this.oZones[sId].jControl.find("[cx-role='btn-container']").remove();
									this.oZones[sId].jName = this.oZones[sId].jControl.find("[cx-role='template-name']").html(this.oZones[sId].oOWT.name);
									this.oZones[sId].jBlockBtns = this.oZones[sId].jControl.find("[cx-role='block-btns']");
									if(this.oEditor.nUnscale != 1)
									{
										this.oZones[sId].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
										this.oZones[sId].jBlockBtns.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
									}
									this.PlaceZone({ sId: sId });
									if(sId == oThis.sSelectedChildId)
									{
										oThis.oZones[sId].jControl.attr({ "cx-state": "selected" });
									}
									oThis.oZones[sId].jContainer.find("img").each(function() { $(this).on("load", function() { oThis.UpdateStack(); }); });
									oThis.oZones[sId].jBlockBtns.find("[cx-btn]").each(function()
									{
										$(this).show();
										oThis.oZones[sId].oBtns[this.getAttribute("cx-btn")] = { jBtn: $(this).attr({ "cx-owt-id": sId }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }) };
									});
									if(j==0)
									{
										this.oZones[sId].oBtns["up"].jBtn.hide();
									}
									if(j==this.aServiceZones[i].length - 1)
									{
										this.oZones[sId].oBtns["down"].jBtn.hide();
									}
									oThis.aZones.push(oThis.oZones[sId]);
								}
							}
						}
					}
				}
				break;
			}
			case "horizontal":
			{
				var aColumns = JSON.parse(this.oEditor._GetParam({ aParams: this.oParent.oOWT.params, sName: this.sColumnsFldName, bContains: false }));
				if(typeof aColumns == "object")
				{
					if(aColumns.constructor === Array)
					{
						var jSrcColumns = this.jBlockFrame.find("[wt-role='macro-column']");
						for(i=0; i<aColumns.length; i++)
						{
							this.aStacks[i] =
							{
								iIdx: i + 1,
								jSrcColumn: $(jSrcColumns[i]),
								nX: 0,
								nY: 0
							};
							this.aStacks[i].jContainer = this.aStacks[i].jSrcColumn.find("[wt-role='macro-column-content']");
							this.aStacks[i].jControl = oThis.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-macro-id": this.sId, "cx-column": i }).appendTo(this.jMacroControls).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
							this.aStacks[i].jName = this.aStacks[i].jControl.find("[cx-role='template-name']").attr({ "cx-column-name": this.aStacks[i].iIdx }).html(this.aStacks[i].iIdx);
							this.aStacks[i].jControl.find("[cx-role='block-btns']").remove();
							this.aStacks[i].jContent = this.aStacks[i].jControl.find("[cx-role='block-btns']");
							if(this.oEditor.nUnscale != 1) {
								this.aStacks[i].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
							}
							if(this.aStacks[i].jSrcColumn.length>0)
							{
								this.PlaceStack({ oStack: this.aStacks[i] });
							}
							this.aStacks[i].jBtnContainer = this.aStacks[i].jControl.find("[cx-role='btn-container']").attr({ "cx-column": i }).appendTo(this.jBlock).hide();
							this.aStacks[i].jBtn = this.aStacks[i].jBtnContainer.find("[cx-role='add-template']").attr({ "cx-column": i }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e }); });
						}
						if(this.bSelected)
						{
							this.FldSync();
						}
					}
				}
				// columns built. now create inner items, if any
				this.aServiceZones = JSON.parse(sServiceZones);
				if(this.aServiceZones.constructor === Array)
				{
					for(i=0; i<this.aServiceZones.length; i++)
					{
						if(typeof this.aServiceZones[i] == "object")
						{
							if(this.aServiceZones[i].constructor === Array)
							{
								for(j=0; j<this.aServiceZones[i].length; j++)
								{
									sId = this.aServiceZones[i][j];
									jCurZone = this.jBlockFrame.find("[wt-role='macro-zone'][wt-owt-id='" + sId + "']");
									this.oZones[sId] =
									{
										iColumn: i,
										sOWTId: sId,
										oBtns: {},
										jContainer: jCurZone,
										nX: 0,
										nY: 0,
										nW: 0,
										nH: 0,
										jControl: this.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-owt-id": sId }).appendTo(this.jMacroControls).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }),
										oOWT: oThis.oEditor._GetTemplateById({ aTemplates: this.oPlayer.oCurrentWebModeCopy.zones[0].templates, sId: sId })
									};
									this.oZones[sId].jControl.find("[cx-role='btn-container']").remove();
									this.oZones[sId].jName = this.oZones[sId].jControl.find("[cx-role='template-name']").html(this.oZones[sId].oOWT.name);
									this.oZones[sId].jBlockBtns = this.oZones[sId].jControl.find("[cx-role='block-btns']");
									if(this.oEditor.nUnscale != 1)
									{
										this.oZones[sId].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
										this.oZones[sId].jBlockBtns.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
									}
									this.PlaceZone({ sId: sId });
									if(sId == oThis.sSelectedChildId)
									{
										oThis.oZones[sId].jControl.attr({ "cx-state": "selected" });
									}
									oThis.oZones[sId].jContainer.find("img").each(function() { $(this).on("load", function() { oThis.UpdateStack(); }); });

									oThis.oZones[sId].jBlockBtns.find("[cx-btn]").each(function() {
										$(this).show();
										oThis.oZones[sId].oBtns[this.getAttribute("cx-btn")] = { jBtn: $(this).attr({ "cx-owt-id": sId }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }) };
									});
									if(j == 0)
									{
										this.oZones[sId].oBtns["up"].jBtn.hide();
									}
									if(j == this.aServiceZones[i].length - 1)
									{
										this.oZones[sId].oBtns["down"].jBtn.hide();
									}
									oThis.aZones.push(oThis.oZones[sId]);
								}
							}
						}
					}
				}
				break;
			}
			case "vertical":
			{
				this.aServiceZones = JSON.parse(sServiceZones);
				if(this.aServiceZones.constructor === Array)
				{
					for(i=0; i<this.aServiceZones.length; i++)
					{
						sId = this.aServiceZones[i];
						jCurZone = this.jBlockFrame.find("[wt-role='macro-zone'][wt-owt-id='" + sId + "']");
						this.oZones[sId] =
						{
							iColumn: 0,
							sOWTId: sId,
							oBtns: {},
							jContainer: jCurZone,
							nX: 0,
							nY: 0,
							nW: 0,
							nH: 0,
							jControl: this.jMacroControlTemplate.clone(true).removeAttr("cx-template").attr({ "cx-owt-id": sId }).appendTo(this.jMacroControls).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }),
							oOWT: oThis.oEditor._GetTemplateById({ aTemplates: this.oPlayer.oCurrentWebModeCopy.zones[0].templates, sId: sId })
						};
						this.oZones[sId].jControl.find("[cx-role='btn-container']").remove();
						this.oZones[sId].jName = this.oZones[sId].jControl.find("[cx-role='template-name']").html(this.oZones[sId].oOWT.name);
						this.oZones[sId].jBlockBtns = this.oZones[sId].jControl.find("[cx-role='block-btns']");
						if(this.oEditor.nUnscale != 1)
						{
							this.oZones[sId].jName.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
							this.oZones[sId].jBlockBtns.css({ "transform": "scale(" + this.oEditor.nUnscale + "," + this.oEditor.nUnscale + ")" });
						}
						this.PlaceZone({ sId: sId });
						if(sId == oThis.sSelectedChildId)
						{
							oThis.oZones[sId].jControl.attr({ "cx-state": "selected" });
						}
						oThis.oZones[sId].jContainer.find("img").each(function() { $(this).on("load", function() { oThis.UpdateStack.call(oThis); }); });
						oThis.oZones[sId].jBlockBtns.find("[cx-btn]").each(function()
						{
							$(this).show();
							oThis.oZones[sId].oBtns[this.getAttribute("cx-btn")] = { jBtn: $(this).attr({ "cx-owt-id": sId }).on("click", function(e) { oThis.UIEvent.call(oThis, { oElem: this, oEvt: e, bMacro: true, sZoneId: sId }); }) };
						});
						if(i == 0)
						{
							this.oZones[sId].oBtns["up"].jBtn.hide();
						}
						if(i == this.aServiceZones.length - 1)
						{
							this.oZones[sId].oBtns["down"].jBtn.hide();
						}
						oThis.aZones.push(oThis.oZones[sId]);
					}
				}
				break;
			}
		}
        this.oParent.FireEvent({ sEvent: "stack_updated" });
        return this;
    };
}
{ // CXFileItem
    window.CXFileItem = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.oDialog = oArgs.oDialog;
        this.oRepo = oArgs.oRepo; // repo item from oStore
        this.oFile = oArgs.oFile; // file item from oStore
        this.jList = oArgs.jList;
        this.jScrollContainer = this.jList.parents("[cx-role='list-container']:first");
        this.bSelected = false;
        this.bVisible = true;
        this.bPrepend = oArgs.bPrepend == true;
        this.Constructor().Update();
        return this;
    };
    CXFileItem.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jItem = this.oPlayer.jStorage.find("[cx-template='file-tile']").clone(true).removeAttr("cx-template").attr({ "cx-repo": this.oRepo.id, "cx-file": this.oFile.id }).on("click", function(e) { oThis.UIEvent.call(oThis, { oEvt: e, oElem: this, oThis: oThis }); });
        if(this.bPrepend)
		{
            this.jItem.prependTo(this.jList);
        }
		else
		{
            this.jItem.appendTo(this.jList);
        }
        this.jName = this.jItem.find("[cx-role='file-title']");
        this.jIcon = this.jItem.find("[cx-role='file-splash']");
        this.jSize = this.jItem.find("[cx-role='file-size']");
        this.jModified = this.jItem.find("[cx-role='date-updated']");

        this.jName.html(this.oFile.name);
        if(this.oFile.type == "img" && this.oFile.url != "") {
            if(this.oFile.url.charAt(0) != "/") {
                this.oFile.url = "/" + this.oFile.url;
            }
            this.jItem.find("[cx-role='file-splash']").css({ "background-image": "url('" + this.oFile.url + "')" });
        } else {
            this.jItem.find("[cx-role='resource-splash']").css({ "background-image": "url('" + this.oPlayer.oConfig.sImgURL + "/ico-file-" + this.oFile.type + ".svg')" });
        }
        this.jSize = this.jItem.find("[cx-role='file-size']").html(TOOLS.FileSizeString({ nBytes: this.oFile.size }));
        this.jModified = this.jItem.find("[cx-role='date-updated']").html(TOOLS.DateStringFromISO8601({ sISODate: this.oFile.modified, sFormat: "dd.mm.yy" }));
        return this;
    };
    CXFileItem.prototype.Hide = function(oArgs)
	{
        this.jItem.hide();
        this.bVisible = false;
        return this;
    };
    CXFileItem.prototype.Select = function(oArgs)
	{
        var oThis = this;
        for(var sKey in this.oDialog.oFileList)
		{
            if(this.oDialog.oFileList[sKey].bSelected)
			{
                this.oDialog.oFileList[sKey].Unselect();
            }
        }
        this.jItem.attr({ "cx-state": "selected" });
        this.jScrollContainer.scrollTop(this.jScrollContainer.scrollTop() + this.jItem.position().top);
        this.bSelected = true;
        this.oDialog.oSelectedItem = this;
        return oThis;
    };
    CXFileItem.prototype.Show = function(oArgs)
	{
        this.jItem.show();
        this.bVisible = true;
        return this;
    };
    CXFileItem.prototype.UIEvent = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXFileItem))
		{
            oThis = oArgs.oThis;
            if(!(oThis instanceof CXFileItem))
			{
                return this;
            }
        }
        oThis.Select();
        return oThis;
    };
    CXFileItem.prototype.Unselect = function(oArgs)
	{
        var oThis = this;
        this.jItem.attr({ "cx-state": "idle" });
        this.bSelected = false;
        return oThis;
    };
    CXFileItem.prototype.Update = function(oArgs)
	{
        var oThis = this;
        this.jName.html(this.oFile.name);
        if(this.oFile.type == "img" && this.oFile.url != "")
		{
            if(this.oFile.url.charAt(0) != "/")
			{
                this.oFile.url = "/" + this.oFile.url;
            }
            this.jIcon.css({ "background-image": "url('" + this.oFile.url + "')" });
        }
		else
		{
            this.jIcon.css({ "background-image": "url('" + this.oPlayer.oConfig.sImgURL + "ico-file-" + this.oFile.type + ".svg')" });
        }
        this.jSize.html(TOOLS.FileSizeString({ nBytes: this.oFile.size }));
        this.jModified.html(TOOLS.DateStringFromISO8601({ sISODate: this.oFile.modified, sFormat: "dd.mm.yy" }));
        return this;
    };
}
{ // CXAPI
    window.CXAPI = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        return this;
    };
    CXAPI.prototype.Create = function(oArgs)
	{
        var oThis = this;
        var bAutoOpen = false;
        if(oArgs != null)
		{
            oThis.oPlayer.oMask.Show({ bCurtain: true });
            oArgs.jForm.find("[cx-role='form-code']").val(TOOLS.ShortID());
            switch(oArgs.sTarget)
			{
                case "repo":
				{
					oArgs.jForm.find("[cx-role='form-action']").val("create_repo");
					break;
				}
                case "resource":
				{
					oArgs.jForm.find("[cx-role='form-action']").val("create_resource");
					break;
				}
            }
            var oFormData = new FormData();
            var aParams = oArgs.jForm.serializeArray();
            var aFileFld = oArgs.jForm.find("[type='file']");
            if(aFileFld.length != 0)
			{
                var aFiles = aFileFld[0].files;
                if(aFiles.length > 1)
				{
                    $.each(aFiles, function(i, oFile)
					{
                        oFormData.append("file-" + i, oFile);
                    });
                }
				else if(aFiles.length == 1)
				{
                    oFormData.append("file_data", aFiles[0]);
                }
            }
            $.each(aParams, function(i, oVal)
			{
                oFormData.append(oVal.name, oVal.value);
            });
            $.ajax(
			{
                url: TOOLS.AppendURLParams({ sURL: oThis.oPlayer.oConfig.sFileAPIURL, sParams: ("secid=" + oThis.oPlayer.sSecId) }),
                data: oFormData,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                type: "POST",
                complete: function(oData)
				{
                    return true;
                },
                failure: function(oData)
				{
                    oThis.oPlayer.oMask.Hide();
                    window.console.log("Create - failure");
                    return false;
                },
                success: function(oData)
				{
                    window.console.log("Create " + oArgs.sTarget + " - success");
                    if(typeof oData == "object")
					{
                        oThis.oData = oData;
                        switch(oArgs.sTarget)
						{
                            case "resource":
							{
								oThis.oPlayer.oPages["resources"].Update({ oData: oData, bFromCourse: (oArgs.bFromCourse == true) });
								if(oArgs.bFromCourse)
								{
									if(oArgs.oCaller != null)
									{
										oArgs.oCaller.Update({ oData: oData });
									}
									else
									{
										oThis.oPlayer.oPages["desktop"].oDialogs["selectfile"].Update({ oData: oData });
									}
								}
								break;
							}
                            case "repo":
							{
								oThis.oPlayer.oPages["resources"].Update({ oData: oData });
								break;
							}
                        }
                    }
					else
					{
                        window.console.log("Create - success - malformed");
                    }
                    oThis.oPlayer.oMask.Hide();
                    return true;
                }
            });
        }
        return this;
    };
    CXAPI.prototype.Delete = function(oArgs)
	{
        var oThis = this;
        if(!(oThis instanceof CXAPI)) {
            if(oThis instanceof CX) {
                oThis = oThis.oAPI;
            } else if(oThis.oPlayer != null) {
                oThis = oThis.oPlayer.oAPI;
            } else {
                oThis = oArgs.oThis;
                if(!(oThis instanceof CXAPI)) {
                    oThis = oArgs.oArgs.oThis;
                    if(!(oThis instanceof CXAPI)) {
                        if(oThis.oPlayer != null) {
                            oThis = oThis.oPlayer.oAPI;
                        }
                    }
                }
            }
            if(!(oThis instanceof CXAPI)) {
                return this;
            }
        }
        if(oArgs != null)
		{
            if(oArgs.oFormData != null)
			{
                oThis.oPlayer.oMask.Show({ bCurtain: true });
                $.ajax(
				{
                    url: TOOLS.AppendURLParams({ sURL: oThis.oPlayer.oConfig.sFileAPIURL, sParams: ("secid=" + oThis.oPlayer.sSecId) }),
                    data: oArgs.oFormData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    dataType: "json",
                    type: "POST",
                    complete: function(oData)
					{
                        return true;
                    },
                    failure: function(oData)
					{
                        oThis.oPlayer.oMask.Hide();
                        window.console.log("Delete - failure");
                        return false;
                    },
                    success: function(oData)
					{
                        window.console.log("Delete " + oArgs.sTarget + " - success");
                        if(typeof oData == "object")
						{
                            oThis.oData = oData;
                            switch(oArgs.sTarget)
							{
                                case "clcourse":
								{
									oThis.oPlayer.oPages["clcourses"].Update({ oData: oData });
									break;
								}
                                case "resource":
								{
									oThis.oPlayer.oPages["resources"].Update({ oData: oData, bFromCourse: (oArgs.bFromCourse == true) });
									break;
								}
                                case "repo":
								{
									//oThis.oPlayer.oPages["resources"].Update({ oData: oData });
									break;
								}
                            }
                        }
						else
						{
                            window.console.log("delete - success - malformed");
                        }
                        oThis.oPlayer.oMask.Hide();
                        return true;
                    }
                });
            }
        }
        return this;
    };
    CXAPI.prototype.Update = function(oArgs)
	{
        var oThis = this;
        if(oArgs != null)
		{
            var oFormData = new FormData();
            switch(oArgs.sTarget) {
                case "repo":
                    {
                        oArgs.jForm.find("[cx-role='form-action']").val("create_repo");
                        break;
                    }
                case "resource":
                    {
                        oArgs.jForm.find("[cx-role='form-action']").val("update_resource");
                        break;
                    }
            }
            var aParams = oArgs.jForm.serializeArray();
            var aFileFld = oArgs.jForm.find("[type='file']");
            if(aFileFld.length != 0)
			{
                var aFiles = aFileFld[0].files;
                if(aFiles.length > 1)
				{
                    $.each(aFiles, function(i, oFile)
					{
                        oFormData.append("file-" + i, oFile);
                    });
                }
				else if(aFiles.length == 1)
				{
                    oFormData.append("file_data", aFiles[0]);
                }
            }
            $.each(aParams, function(i, oVal)
			{
                oFormData.append(oVal.name, oVal.value);
            });
            $.ajax(
			{
                url: TOOLS.AppendURLParams({ sURL: oThis.oPlayer.oConfig.sFileAPIURL, sParams: ("secid=" + oThis.oPlayer.sSecId) }),
                data: oFormData,
                cache: false,
                contentType: false,
                processData: false,
                dataType: "json",
                type: "POST",
                complete: function(oData)
				{
                    return true;
                },
                failure: function(oData)
				{
                    oThis.oPlayer.oMask.Hide();
                    window.console.log("Update - failure");
                    return false;
                },
                success: function(oData)
				{
                    window.console.log("Update " + oArgs.sTarget + " - success");
                    if(typeof oData == "object")
					{
                        oThis.oData = oData;
                        switch(oArgs.sTarget)
						{
                            case "clcourse":
							{
								oThis.oPlayer.oPages["clcourses"].Update({ oData: oData });
								break;
							}
                            case "resource":
							{
								oThis.oPlayer.oPages["resources"].Update({ oData: oData });
								if(oArgs.bFromCourse) {
									if(oArgs.oCaller != null) {
										oArgs.oCaller.Update({ oData: oData });
									} else {
										oThis.oPlayer.oPages["desktop"].oDialogs["selectfile"].Update({ oData: oData });
									}
								}
								break;
							}
                            case "repo":
							{
								oThis.oPlayer.oPages["resources"].Update({ oData: oData });
								break;
							}
                        }
                    }
					else
					{
                        window.console.log("Create - success - malformed");
                    }
                    oThis.oPlayer.oMask.Hide();
                    return true;
                }
            });
        }
        return this;
    };
}
{ // CXAlert
    window.CXAlert = function(oArgs)
	{
        this.oPlayer = oArgs.oPlayer;
        this.jContainer = oArgs.jContainer;
        this.oBtns = {};
        this.oParent = null;
        this.Constructor();
        return this;
    };
    CXAlert.prototype.Constructor = function(oArgs)
	{
        var oThis = this;
        this.jAlert = this.oPlayer.jStorage.find("[cx-template='alert']").clone(true).appendTo(this.jContainer);
        this.sBasicClass = this.jAlert[0].className;
        this.jTitle = this.jAlert.find("[cx-role='alert-title']");
        this.jText = this.jAlert.find("[cx-role='alert-text']");
        this.oBtns.ok = new CXBtn(
		{
            oPlayer: this.oPlayer,
            oContainer: this.jAlert[0],
            jBtn: this.jAlert.find("[cx-role='alert-btn-ok']"),
            fn: function() { oThis.UIEvent.call(oThis, { oElem: this, sAction: "ok" }); }
        });
        this.oBtns.cancel = new CXBtn(
		{
            oPlayer: this.oPlayer,
            oContainer: this.jAlert[0],
            jBtn: this.jAlert.find("[cx-role='alert-btn-cancel']"),
            fn: function() { oThis.UIEvent.call(oThis, { oElem: this, sAction: "cancel" }); }
        });
        return this;
    };
    CXAlert.prototype.Hide = function(oArgs)
	{
        this.oPlayer.oMask.Hide();
        this.jAlert.hide();
        return this;
    };
    CXAlert.prototype.SetParent = function(oArgs)
	{
        this.oParent = oArgs.oParent;
        if(oArgs.sAction != null)
		{
            this.sAction = oArgs.sAction;
        }
        return this;
    };
    CXAlert.prototype.Show = function(oArgs)
	{
        this.oPlayer.oMask.Show({ bOn: true, bPlain: true });
        this.jAlert[0].className = this.sBasicClass;
        if(oArgs.sClass != null)
		{
            this.jAlert.addClass(oArgs.sClass);
        }
        this.jAlert.show();
        this.jTitle.html(oArgs.sTitle);
        this.jText.html(oArgs.sText);
        if(oArgs.bDisplayCancel)
		{
            this.oBtns.cancel.Show();
            if(oArgs.fnCancel != null)
			{
                this.fnCancel = oArgs.fnCancel;
            }
			else
			{
                this.fnCancel = null;
            }
        }
		else
		{
            this.oBtns.cancel.Hide();
        }
        this.oOKContext = (oArgs.oOKContext != null) ? oArgs.oOKContext : this.oPlayer;
        if(oArgs.fnOK != null && typeof oArgs.fnOK == "function")
		{
            this.fnOK = oArgs.fnOK;
            this.oArgsOK = oArgs.oArgsOK;
        }
		else
		{
            this.fnOK = null;
        }
        var iH = this.jAlert.height();
        var iWH = $(window).height();
        if(iH >= iWH)
		{
            iWH = 0;
        }
		else
		{
            iWH = 0.5 * (iWH - iH);
        }
        var iScrollT = $("body")[0].scrollTop;
        if(iScrollT == 0)
		{
            iScrollT = $("html")[0].scrollTop;
        }
        this.jAlert.css({ "top": (iScrollT + iWH) + "px" });
        return this;
    };
    CXAlert.prototype.UIEvent = function(oArgs)
	{
        switch(oArgs.sAction)
		{
            case "ok":
			{
				if(this.fnOK != null)
				{
					if(typeof this.fnOK == "function")
					{
						this.fnOK.call(this.oOKContext, this.oArgsOK);
					}
				}
				this.Hide();
				break;
			}
            case "cancel":
			{
				if(this.fnCancel != null)
				{
					this.fnCancel();
				}
				this.Hide();
				break;
			}
		}
        return this;
    };
}
{ // CXBlock - single object
    window.CXBlock = function(oArgs)
	{
        WTBaseObject.call(this, oArgs); // sId, jContainer, oPlayer
        this.oEditor = oArgs.oEditor;
        this.sTemplateId = oArgs.sTemplateId;
        this.oOWT = oArgs.oOWT;
        this.bIsMacro = (oArgs.bIsMacro == true);
        this.bIsChild = (oArgs.bIsChild == true);
        this.oParentOWT = oArgs.oParentOWT;
        this.iWeight = 0;
        this.Constructor();
        return this;
    };
    CXBlock.prototype = Object.create(WTBaseObject.prototype);
    CXBlock.prototype.constructor = CXBlock;
    CXBlock.prototype.Constructor = function(oArgs)
	{
        this.iWeight = this.oOWT.weight;
        this.sStoreId = this.bMacro ? "macros" : "templates";
        if(this.bIsMacro)
		{
            this.oBlock = new CXViewMacro({ oPlayer: this.oPlayer, jContainer: this.jContainer, sId: this.sId, oParent: this });
        }
		else
		{
            this.oBlock = new CXViewBlock({ oPlayer: this.oPlayer, jContainer: this.jContainer, sId: this.sId, oParent: this });
        }
        return this;
    };
    CXBlock.prototype.Delete = function(oArgs)
	{
        this.oBlock.jBlock.remove();
        return this;
    };
    CXBlock.prototype.Save = function(oArgs)
	{
        return this;
    };
    CXBlock.prototype.Select = function(oArgs)
	{
        this.oBlock.Select(oArgs);
        return this;
    };
    CXBlock.prototype.SelectZone = function(oArgs)
	{
        this.oBlock.SelectZone(oArgs);
        return this;
    };
    CXBlock.prototype.Unselect = function(oArgs)
	{
        this.oBlock.Unselect();
        return this;
    };
    CXBlock.prototype.Update = function(oArgs)
	{
        this.oBlock.Update(oArgs);
        return this;
    };
}

{ // TOOLS
    if(typeof TOOLS == "undefined")
	{
        var TOOLS = {};
    }
    if(TOOLS._Hyphenate == null)
	{
        TOOLS._Hyphenate = function(oArgs)
		{
            function fnHyphens(sTxt)
			{
                var sString = sTxt;
                var aVowels = ["_", "A", "a", "E", "e", "I", "i", "O", "o", "U", "u", "Y", "y", "А", "а", "Е", "е", "И", "и", "Й", "й", "О", "о", "У", "у", "Ы", "ы", "Э", "э", "Ю", "ю", "Я", "я", "Α", "α", "Ε", "ε", "Η", "η", "I", "ι", "Ο", "ο", "Υ", "υ", "Ω", "ω"];
                if(sString.length > 10)
				{
                    var aChars = sString.split("");
                    var iBlock = 0;
                    for(var k = 1; k<aChars.length - 3; k++)
					{
                        if(iBlock > 3)
						{
                            if($.inArray(aChars[k], aVowels) != -1)
							{
                                aChars[k] += "&shy;";
                                iBlock = 0;
                                continue;
                            }
                        }
                        iBlock++;
                    }
                    sString = aChars.join("");
                }
                return sString;
            }
            var sValue = oArgs.sText;
            var i, j;
            if(sValue.length > 40)
			{
                var aParts = sValue.split("<");
                var iCnt = 0;
                var aChunks;
                var aWords;
                var aChars;
                if(aParts.length > 1)
				{
                    while(aParts[iCnt] != null)
					{
                        aChunks = aParts[iCnt].split(">");
                        if(aChunks.length > 1)
						{
                            for(i = 1; i<aChunks.length; i++) // first item is tag
                            {
                                aWords = aChunks[i].split(" ");
                                for(j=0; j<aWords.length; j++)
								{
                                    if(aWords[j].length > 40 && aWords[j].indexOf("{{")==-1 && aWords[j].indexOf("}}")==-1)
									{
                                        aWords[j] = fnHyphens(aWords[j]);
                                    }
                                }
                                aChunks[i] = aWords.join(" ");
                            }
                        }
                        aParts[iCnt] = aChunks.join(">");
                        iCnt++;
                    }
                    sValue = aParts.join("<");
                }
				else
				{
                    aWords = sValue.split(" ");
                    for(j=0; j<aWords.length; j++)
					{
                        if(aWords[j].length > 30)
						{
                            aWords[j] = fnHyphens(aWords[j]);
                        }
                    }
                    sValue = aWords.join(" ");
                }
            }
            return sValue;
        };
    }
    if(TOOLS.Cookie == null)
	{
        TOOLS.Cookie =
		{
            Get: function(oArgs)
			{
                var aMatches = document.cookie.match(new RegExp("(?:^|; )" + oArgs.sName.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"));
                return aMatches ? decodeURIComponent(aMatches[1]) : undefined;
            },
            Delete: function(oArgs)
			{
                TOOLS.Cookie.Set({ sName: oArgs.sName, sValue: null, oProps: { expires: -1 } });
                return true;
            },
            Set: function(oArgs)
			{ // sName, sValue, oProps:{ expires (integer seconds or UTC string),... }
                var oProps = oArgs.oProps || {};
                var iExpires = oProps.expires;
                if(typeof iExpires == "number" && iExpires)
				{
                    var dExpires = new Date();
                    dExpires.setTime(dExpires.getTime() + iExpires * 1000);
                    oProps.expires = dExpires.toUTCString();
                }
                var sValue = encodeURIComponent(oArgs.sValue);
                var sCookieText = oArgs.sName + "=" + sValue;
                var sPropValue;
                for(var sName in oProps)
				{
                    if(oProps.hasOwnProperty(sName))
					{
                        sCookieText += "; " + sName;
                        sPropValue = oProps[sName];
                        if(sPropValue !== true)
						{
                            sCookieText += "=" + sPropValue;
                        }
                    }
                }
                document.cookie = sCookieText;
                return true;
            }
        };
    }
    if(TOOLS.DateStringFromISO8601 == null)
	{
        TOOLS.DateStringFromISO8601 = function(oArgs)
		{ // sISODate, sFormat, bTime, sTimeFormat
            var sDateString = "dd.mm.yy";
            var sISOString = (oArgs.sISODate != null ? oArgs.sISODate : (new Date()).toISOString());
            var aParts = sISOString.toUpperCase().split("T");
            if(aParts[0] != null)
			{
                var aDate = aParts[0].split("-");
                var oDS =
				{
                    "Y": aDate[0],
                    "M": aDate[1],
                    "D": aDate[2]
                };
                if(oArgs.sFormat != null)
				{
                    sDateString = oArgs.sFormat.toLowerCase();
                }
                var aTmp = sDateString.split("dd");
                sDateString = aTmp.join(oDS.D);
                aTmp = sDateString.split("mm");
                sDateString = aTmp.join(oDS.M);
                aTmp = sDateString.split("yy");
                sDateString = aTmp.join(oDS.Y);
                if(oArgs.bTime == true && aParts[1] != null)
				{
                    var aTime = aParts[1].split(":");
                    var sTimeString = "hh:mm:ss";
                    if(oArgs.sTimeFormat != null)
					{
                        sTimeString = oArgs.sTimeFormat.toLowerCase();
                    }
                    var oTS =
					{
                        "H": parseInt(aTime[0], 10),
                        "M": parseInt(aTime[1], 10),
                        "S": parseInt(aTime[2], 10)
                    };
                    aTmp = sTimeString.split("hh");
                    sTimeString = aTmp.join((String(oTS.H).length == 1) ? "0" + oTS.H : oTS.H);
                    aTmp = sTimeString.split("mm");
                    sTimeString = aTmp.join((String(oTS.M).length == 1) ? "0" + oTS.M : oTS.M);
                    aTmp = sTimeString.split("ss");
                    sTimeString = aTmp.join((String(oTS.S).length == 1) ? "0" + oTS.S : oTS.S);
                    sDateString += " " + sTimeString;
                }
                return sDateString;
            }
            return oArgs.sISODate;
        };
    }
    if(TOOLS.DateStringToISO8601 == null)
	{
        TOOLS.DateStringToISO8601 = function(oArgs)
		{ // sDateString, sFormat
            var sDivider = (oArgs.sFormat.indexOf(".") != -1) ? "." : ((oArgs.sFormat.indexOf("-") != -1) ? "-" : ((oArgs.sFormat.indexOf("/") != -1) ? "/" : " "));
            var aFormatParts = oArgs.sFormat.toLowerCase().split(sDivider);
            var aDateParts = oArgs.sDateString.split(sDivider);
            return (aDateParts[$.inArray("yy", aFormatParts)] + "-" + aDateParts[$.inArray("mm", aFormatParts)] + "-" + aDateParts[$.inArray("dd", aFormatParts)] + "T00:00:00");
        };
    }
    if(TOOLS.AppendNode == null)
	{
        TOOLS.AppendNode = function(oArgs)
		{ // oRoot, oInsertAfter, sChild, sText, sCDATA, aAttrs
            var oDoc = oArgs.oRoot.ownerDocument;
            var oElemNode = oDoc.createElement(oArgs.sChild);
            var oTextNode = null;
            if(oArgs.sCDATA != null && oArgs.sCDATA != "")
			{
                oTextNode = oDoc.createCDATASection(oArgs.sCDATA);
            }
			else if(oArgs.sText != null && oArgs.sText != "")
			{
                oTextNode = oDoc.createTextNode(oArgs.sText);
            }
            if(oArgs.aAttrs != null)
			{
                for(var i = 0; i<oArgs.aAttrs.length; i++)
				{
                    oElemNode.setAttribute(oArgs.aAttrs[i].name, oArgs.aAttrs[i].value);
                }
            }
            if(oTextNode != null)
			{
                oElemNode.appendChild(oTextNode);
            }
            if(oArgs.oInsertAfter != null)
			{
                if(oArgs.oInsertAfter.nextSibling != null)
				{
                    oArgs.oRoot.insertBefore(oElemNode, oArgs.oInsertAfter.nextSibling);
                }
				else
				{
                    oArgs.oRoot.appendChild(oElemNode);
                }
            }
			else
			{
                oArgs.oRoot.appendChild(oElemNode);
            }
            return oElemNode;
        };
    }
    if(TOOLS.AppendURLParams == null)
	{
        TOOLS.AppendURLParams = function(oArgs)
		{ // sURL, sParams
            var iIdx = oArgs.sURL.indexOf("?");
            return ((iIdx == -1) ? ((oArgs.sURL.length == iIdx) ? (oArgs.sURL + oArgs.sParams) : (oArgs.sURL + "?" + oArgs.sParams)) : (oArgs.sURL + "&" + oArgs.sParams));
        };
    }
    if(TOOLS.GUID == null)
	{
        TOOLS.GUID = function()
		{
            var sGUID = "";
            var iRand = 0;
            for(var i = 0; i<32; i++)
			{
                if(i == 8 || i == 12 || i == 16 || i == 20)
				{
                    sGUID += "_";
                }
                iRand = Math.floor(Math.random() * 16).toString(16).toLowerCase();
                sGUID += iRand;
            }
            return sGUID;
        };
    }
    if(TOOLS.EncodeAngleBrackets == null)
	{
        TOOLS.EncodeAngleBrackets = function(oArgs)
		{
            var sText = oArgs.sText.split("<").join("&lt;").split(">").join("&gt;");
            return sText;
        };
    }
    if(TOOLS.Refine == null)
	{
        TOOLS.Refine = function(oArgs)
		{
            switch(oArgs.sType)
			{
                case "bool":
				{
					var sValue = String(oArgs.sValue).toLowerCase();
					return (sValue == "true" || sValue == "1" || sValue == "yes");
				}
                case "int":
				{
					if(oArgs.sValue == null)
					{
						return 0;
					}
					var iValue = parseInt(oArgs.sValue, 10);
					if(isNaN(iValue))
					{
						iValue = 0;
					}
					return iValue;
				}
				case "float":
				{
					if(oArgs.sValue == null)
					{
						return 0;
					}
					var nValue = parseFloat(oArgs.sValue);
					if(isNaN(nValue))
					{
						nValue = 0;
					}
					return nValue;
				}
            }
            return oArgs.sValue;
        };
    }
    if(TOOLS.ShortID == null)
	{
        TOOLS.ShortID = function()
		{
            var sAlpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var sAlphaNum = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            var sId = "";
            var nRixit;
            var nResidual = (new Date()).valueOf();
            while(true)
			{
                nRixit = nResidual % 62;
                sId = sAlphaNum.charAt(nRixit) + sId;
                nResidual = Math.floor(nResidual / 62);
                if(nResidual == 0)
				{
                    break;
                }
            }
            sId += sAlpha.charAt(Math.floor(Math.random() * 52));
            while(sId.length < 10)
			{
                sId = sAlpha.charAt(Math.floor(Math.random() * 52)) + sId;
            }
            return sId;
        };
    }
    if(TOOLS.EncodeVarName == null)
	{
        TOOLS.EncodeVarName = function(oArgs)
		{
            var sText = oArgs.sText.split(".").join("%46");
            return sText;
        };
    }
    if(TOOLS.DecodeVarName == null)
	{
        TOOLS.DecodeVarName = function(oArgs)
		{
            var sText = oArgs.sText.split("%46").join(".");
            return sText;
        };
    }
    if(TOOLS.UpdateNode == null)
	{
        TOOLS.UpdateNode = function(oArgs)
		{ // oNode, sText, sCDATA, aAttrs
            var oDoc = oArgs.oNode.ownerDocument;
            var oElemNode = oArgs.oNode;
            var oTextNode = null;
            if(oArgs.sCDATA != null && oArgs.sCDATA != "")
			{
                oTextNode = oDoc.createCDATASection(oArgs.sCDATA);
            }
			else if(oArgs.sText != null && oArgs.sText != "")
			{
                oTextNode = oDoc.createTextNode(oArgs.sText);
            }
            if(oArgs.aAttrs != null)
			{
                for(var i = 0; i<oArgs.aAttrs.length; i++)
				{
                    oElemNode.setAttribute(oArgs.aAttrs[i].name, oArgs.aAttrs[i].value);
                }
            }
            if(oTextNode != null)
			{
                while (oElemNode.firstChild)
				{
                    oElemNode.removeChild(oElemNode.firstChild);
                }
                oElemNode.appendChild(oTextNode);
            }
            return oElemNode;
        };
    }
    if(TOOLS.FileSizeString == null)
	{
        TOOLS.FileSizeString = function(oArgs)
		{ // nBytes
            var sString = "-";
            var nBytes = parseInt(oArgs.nBytes, 10);
            if(!isNaN(nBytes))
			{
                if(nBytes < 1024)
				{
                    sString = nBytes + "B";
                }
				else if(nBytes < 10240)
				{
                    sString = (Math.round(10 * nBytes / 1024) / 10).toFixed(1) + "kB";
                }
				else if(nBytes < 1048576)
				{
                    sString = Math.round(nBytes / 1024) + "kB";
                }
				else if(nBytes < 10485760)
				{
                    sString = (Math.round(10 * nBytes / 1048576) / 10).toFixed(1) + "MB";
                }
				else
				{
                    sString = Math.round(nBytes / 1048576) + "MB";
                }
            }
            return sString;
        };
    }
	if(TOOLS.Base64==null)
	{
		TOOLS.Base64 =
		{
			_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
			Encode: function (oArgs)
			{
				var input = oArgs.sString;
				var output = "";
				var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
				var i = 0;

				input = TOOLS.Base64._utf8_encode(input);

				while (i < input.length)
				{

					chr1 = input.charCodeAt(i++);
					chr2 = input.charCodeAt(i++);
					chr3 = input.charCodeAt(i++);

					enc1 = chr1 >> 2;
					enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
					enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
					enc4 = chr3 & 63;

					if (isNaN(chr2))
					{
						enc3 = enc4 = 64;
					}
					else if (isNaN(chr3))
					{
						enc4 = 64;
					}

					output = output +
					this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
					this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

				}

				return output;
			},
			Decode: function (oArgs)
			{
				var input = oArgs.sString;
				var output = "";
				var chr1, chr2, chr3;
				var enc1, enc2, enc3, enc4;
				var i = 0;

				input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

				while (i < input.length) {

					enc1 = this._keyStr.indexOf(input.charAt(i++));
					enc2 = this._keyStr.indexOf(input.charAt(i++));
					enc3 = this._keyStr.indexOf(input.charAt(i++));
					enc4 = this._keyStr.indexOf(input.charAt(i++));

					chr1 = (enc1 << 2) | (enc2 >> 4);
					chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
					chr3 = ((enc3 & 3) << 6) | enc4;

					output = output + String.fromCharCode(chr1);

					if (enc3 != 64) {
						output = output + String.fromCharCode(chr2);
					}
					if (enc4 != 64) {
						output = output + String.fromCharCode(chr3);
					}

				}

				output = TOOLS.Base64._utf8_decode(output);

				return output;

			},
			_utf8_encode : function (string) {
				string = string.replace(/\r\n/g,"\n");
				var utftext = "";

				for (var n = 0; n < string.length; n++) {

					var c = string.charCodeAt(n);

					if (c < 128) {
						utftext += String.fromCharCode(c);
					}
					else if((c > 127) && (c < 2048)) {
						utftext += String.fromCharCode((c >> 6) | 192);
						utftext += String.fromCharCode((c & 63) | 128);
					}
					else {
						utftext += String.fromCharCode((c >> 12) | 224);
						utftext += String.fromCharCode(((c >> 6) & 63) | 128);
						utftext += String.fromCharCode((c & 63) | 128);
					}

				}

				return utftext;
			},
			_utf8_decode : function (utftext) {
				var string = "";
				var i = 0;
				var c = c1 = c2 = c3 = 0;

				while ( i < utftext.length ) {

					c = utftext.charCodeAt(i);

					if (c < 128) {
						string += String.fromCharCode(c);
						i++;
					}
					else if((c > 191) && (c < 224)) {
						c2 = utftext.charCodeAt(i+1);
						string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
						i += 2;
					}
					else {
						c2 = utftext.charCodeAt(i+1);
						c3 = utftext.charCodeAt(i+2);
						string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
						i += 3;
					}

				}

				return string;
			}
		};
	}
}
